abstract sig Unit {}
one sig U0, U1, U2, U3, U4, U5, U6, U7 extends Unit {}
abstract sig Label {}
one sig T0, T1 extends Label {}
abstract sig Q {}
one sig Q0, Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10, Q11, Q12, Q13, Q14, Q15 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E18, E19, E20, E21, E22, E23, E24, E25, E36, E37, E38, E39, E40, E41, E42, E43, E54, E55, E56, E57, E58, E59, E60, E61, E72, E73, E74, E75, E76, E77, E78, E79, E90, E91, E92, E93, E94, E95, E96, E97, E108, E109, E110, E111, E112, E113, E114, E115, E126, E127, E128, E129, E130, E131, E132, E133, E144, E145, E146, E147, E148, E149, E150, E151, E162, E163, E164, E165, E166, E167, E168, E169, E180, E181, E182, E183, E184, E185, E186, E187, E198, E199, E200, E201, E202, E203, E204, E205, E216, E217, E218, E219, E220, E221, E222, E223, E234, E235, E236, E237, E238, E239, E240, E241, E252, E253, E254, E255, E256, E257, E258, E259, E270, E271, E272, E273, E274, E275, E276, E277 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos }
one sig A0, A1 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos }
one sig R, C0, L0, D0, C1, L1, D1 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { T0 }
fun un: set Label { T1 }
fun bin: set Label { none }
fun nonempty: set Fiber { ((((((E1 + (E2 + E3)) + ((E4 + E5) + (E6 + E7))) + ((E19 + (E20 + E21)) + ((E22 + E23) + (E24 + E25)))) + (((E37 + (E38 + E39)) + ((E40 + E41) + (E42 + E43))) + ((E55 + (E56 + E57)) + ((E58 + E59) + (E60 + E61))))) + ((((E73 + (E74 + E75)) + ((E76 + E77) + (E78 + E79))) + ((E91 + (E92 + E93)) + ((E94 + E95) + (E96 + E97)))) + (((E109 + (E110 + E111)) + ((E112 + E113) + (E114 + E115))) + ((E127 + (E128 + E129)) + ((E130 + E131) + (E132 + E133)))))) + (((((E145 + (E146 + E147)) + ((E148 + E149) + (E150 + E151))) + ((E163 + (E164 + E165)) + ((E166 + E167) + (E168 + E169)))) + (((E181 + (E182 + E183)) + ((E184 + E185) + (E186 + E187))) + ((E199 + (E200 + E201)) + ((E202 + E203) + (E204 + E205))))) + ((((E217 + (E218 + E219)) + ((E220 + E221) + (E222 + E223))) + ((E235 + (E236 + E237)) + ((E238 + E239) + (E240 + E241)))) + (((E253 + (E254 + E255)) + ((E256 + E257) + (E258 + E259))) + ((E271 + (E272 + E273)) + ((E274 + E275) + (E276 + E277))))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { ((U0->U1 + (U1->U2 + U2->U3)) + ((U3->U4 + U4->U5) + (U5->U6 + U6->U7))) }
fun carrierNext: Carrier -> Carrier { (((A0->A1 + A1->R) + (R->C0 + C0->L0)) + ((L0->D0 + D0->C1) + (C1->L1 + L1->D1))) }
fun child[a: Anchor]: set Port { a.((A0->C0 + A1->C1)) }
fun left[a: Anchor]: set Port { a.((A0->L0 + A1->L1)) }
fun right[a: Anchor]: set Port { a.((A0->D0 + A1->D1)) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
#(lab.bin) <= 0
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q1
E2.qi = Q0
E2.qo = Q2
E3.qi = Q0
E3.qo = Q3
E4.qi = Q0
E4.qo = Q4
E5.qi = Q0
E5.qo = Q5
E6.qi = Q0
E6.qo = Q6
E7.qi = Q0
E7.qo = Q7
E18.qi = Q1
E18.qo = Q1
E19.qi = Q1
E19.qo = Q2
E20.qi = Q1
E20.qo = Q3
E21.qi = Q1
E21.qo = Q4
E22.qi = Q1
E22.qo = Q5
E23.qi = Q1
E23.qo = Q6
E24.qi = Q1
E24.qo = Q7
E25.qi = Q1
E25.qo = Q8
E36.qi = Q2
E36.qo = Q2
E37.qi = Q2
E37.qo = Q3
E38.qi = Q2
E38.qo = Q4
E39.qi = Q2
E39.qo = Q5
E40.qi = Q2
E40.qo = Q6
E41.qi = Q2
E41.qo = Q7
E42.qi = Q2
E42.qo = Q8
E43.qi = Q2
E43.qo = Q9
E54.qi = Q3
E54.qo = Q3
E55.qi = Q3
E55.qo = Q4
E56.qi = Q3
E56.qo = Q5
E57.qi = Q3
E57.qo = Q6
E58.qi = Q3
E58.qo = Q7
E59.qi = Q3
E59.qo = Q8
E60.qi = Q3
E60.qo = Q9
E61.qi = Q3
E61.qo = Q10
E72.qi = Q4
E72.qo = Q4
E73.qi = Q4
E73.qo = Q5
E74.qi = Q4
E74.qo = Q6
E75.qi = Q4
E75.qo = Q7
E76.qi = Q4
E76.qo = Q8
E77.qi = Q4
E77.qo = Q9
E78.qi = Q4
E78.qo = Q10
E79.qi = Q4
E79.qo = Q11
E90.qi = Q5
E90.qo = Q5
E91.qi = Q5
E91.qo = Q6
E92.qi = Q5
E92.qo = Q7
E93.qi = Q5
E93.qo = Q8
E94.qi = Q5
E94.qo = Q9
E95.qi = Q5
E95.qo = Q10
E96.qi = Q5
E96.qo = Q11
E97.qi = Q5
E97.qo = Q12
E108.qi = Q6
E108.qo = Q6
E109.qi = Q6
E109.qo = Q7
E110.qi = Q6
E110.qo = Q8
E111.qi = Q6
E111.qo = Q9
E112.qi = Q6
E112.qo = Q10
E113.qi = Q6
E113.qo = Q11
E114.qi = Q6
E114.qo = Q12
E115.qi = Q6
E115.qo = Q13
E126.qi = Q7
E126.qo = Q7
E127.qi = Q7
E127.qo = Q8
E128.qi = Q7
E128.qo = Q9
E129.qi = Q7
E129.qo = Q10
E130.qi = Q7
E130.qo = Q11
E131.qi = Q7
E131.qo = Q12
E132.qi = Q7
E132.qo = Q13
E133.qi = Q7
E133.qo = Q14
E144.qi = Q8
E144.qo = Q8
E145.qi = Q8
E145.qo = Q9
E146.qi = Q8
E146.qo = Q10
E147.qi = Q8
E147.qo = Q11
E148.qi = Q8
E148.qo = Q12
E149.qi = Q8
E149.qo = Q13
E150.qi = Q8
E150.qo = Q14
E151.qi = Q8
E151.qo = Q15
E162.qi = Q9
E162.qo = Q9
E163.qi = Q9
E163.qo = Q10
E164.qi = Q9
E164.qo = Q11
E165.qi = Q9
E165.qo = Q12
E166.qi = Q9
E166.qo = Q13
E167.qi = Q9
E167.qo = Q14
E168.qi = Q9
E168.qo = Q15
E169.qi = Q9
E169.qo = Q0
E180.qi = Q10
E180.qo = Q10
E181.qi = Q10
E181.qo = Q11
E182.qi = Q10
E182.qo = Q12
E183.qi = Q10
E183.qo = Q13
E184.qi = Q10
E184.qo = Q14
E185.qi = Q10
E185.qo = Q15
E186.qi = Q10
E186.qo = Q0
E187.qi = Q10
E187.qo = Q1
E198.qi = Q11
E198.qo = Q11
E199.qi = Q11
E199.qo = Q12
E200.qi = Q11
E200.qo = Q13
E201.qi = Q11
E201.qo = Q14
E202.qi = Q11
E202.qo = Q15
E203.qi = Q11
E203.qo = Q0
E204.qi = Q11
E204.qo = Q1
E205.qi = Q11
E205.qo = Q2
E216.qi = Q12
E216.qo = Q12
E217.qi = Q12
E217.qo = Q13
E218.qi = Q12
E218.qo = Q14
E219.qi = Q12
E219.qo = Q15
E220.qi = Q12
E220.qo = Q0
E221.qi = Q12
E221.qo = Q1
E222.qi = Q12
E222.qo = Q2
E223.qi = Q12
E223.qo = Q3
E234.qi = Q13
E234.qo = Q13
E235.qi = Q13
E235.qo = Q14
E236.qi = Q13
E236.qo = Q15
E237.qi = Q13
E237.qo = Q0
E238.qi = Q13
E238.qo = Q1
E239.qi = Q13
E239.qo = Q2
E240.qi = Q13
E240.qo = Q3
E241.qi = Q13
E241.qo = Q4
E252.qi = Q14
E252.qo = Q14
E253.qi = Q14
E253.qo = Q15
E254.qi = Q14
E254.qo = Q0
E255.qi = Q14
E255.qo = Q1
E256.qi = Q14
E256.qo = Q2
E257.qi = Q14
E257.qo = Q3
E258.qi = Q14
E258.qo = Q4
E259.qi = Q14
E259.qo = Q5
E270.qi = Q15
E270.qo = Q15
E271.qi = Q15
E271.qo = Q0
E272.qi = Q15
E272.qo = Q1
E273.qi = Q15
E273.qo = Q2
E274.qi = Q15
E274.qo = Q3
E275.qi = Q15
E275.qo = Q4
E276.qi = Q15
E276.qo = Q5
E277.qi = Q15
E277.qo = Q6
all e: used | e.fiber in (((((E0 + E18) + (E36 + E54)) + ((E72 + E90) + (E108 + E126))) + (((E144 + E162) + (E180 + E198)) + ((E216 + E234) + (E252 + E270))))) implies #e.cost = 0
all e: used | e.fiber in (((((E1 + E19) + (E37 + E55)) + ((E73 + E91) + (E109 + E127))) + (((E145 + E163) + (E181 + E199)) + ((E217 + E235) + (E253 + E271))))) implies #e.cost = 1
all e: used | e.fiber in (((((E2 + E20) + (E38 + E56)) + ((E74 + E92) + (E110 + E128))) + (((E146 + E164) + (E182 + E200)) + ((E218 + E236) + (E254 + E272))))) implies #e.cost = 2
all e: used | e.fiber in (((((E3 + E21) + (E39 + E57)) + ((E75 + E93) + (E111 + E129))) + (((E147 + E165) + (E183 + E201)) + ((E219 + E237) + (E255 + E273))))) implies #e.cost = 3
all e: used | e.fiber in (((((E4 + E22) + (E40 + E58)) + ((E76 + E94) + (E112 + E130))) + (((E148 + E166) + (E184 + E202)) + ((E220 + E238) + (E256 + E274))))) implies #e.cost = 4
all e: used | e.fiber in (((((E5 + E23) + (E41 + E59)) + ((E77 + E95) + (E113 + E131))) + (((E149 + E167) + (E185 + E203)) + ((E221 + E239) + (E257 + E275))))) implies #e.cost = 5
all e: used | e.fiber in (((((E6 + E24) + (E42 + E60)) + ((E78 + E96) + (E114 + E132))) + (((E150 + E168) + (E186 + E204)) + ((E222 + E240) + (E258 + E276))))) implies #e.cost = 6
all e: used | e.fiber in (((((E7 + E25) + (E43 + E61)) + ((E79 + E97) + (E115 + E133))) + (((E151 + E169) + (E187 + E205)) + ((E223 + E241) + (E259 + E277))))) implies #e.cost = 7
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (((((Q0 + Q1) + (Q2 + Q3)) + ((Q4 + Q5) + (Q6 + Q7))) + (((Q8 + Q9) + (Q10 + Q11)) + ((Q12 + Q13) + (Q14 + Q15)))))
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 and child[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T1 and child[a].fiber.qo = Q1 implies a.state = Q2
all a: active | a.lab = T1 and child[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T1 and child[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T1 and child[a].fiber.qo = Q4 implies a.state = Q5
all a: active | a.lab = T1 and child[a].fiber.qo = Q5 implies a.state = Q6
all a: active | a.lab = T1 and child[a].fiber.qo = Q6 implies a.state = Q7
all a: active | a.lab = T1 and child[a].fiber.qo = Q7 implies a.state = Q8
all a: active | a.lab = T1 and child[a].fiber.qo = Q8 implies a.state = Q9
all a: active | a.lab = T1 and child[a].fiber.qo = Q9 implies a.state = Q10
all a: active | a.lab = T1 and child[a].fiber.qo = Q10 implies a.state = Q11
all a: active | a.lab = T1 and child[a].fiber.qo = Q11 implies a.state = Q12
all a: active | a.lab = T1 and child[a].fiber.qo = Q12 implies a.state = Q13
all a: active | a.lab = T1 and child[a].fiber.qo = Q13 implies a.state = Q14
all a: active | a.lab = T1 and child[a].fiber.qo = Q14 implies a.state = Q15
all a: active | a.lab = T1 and child[a].fiber.qo = Q15 implies a.state = Q0
}
fun range0: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop0: set Pos { P3 }
fun next0: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift0_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun shift0_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P3 + P3->P3)) }
fun shift0_3: Pos -> Pos { ((P0->P3 + P1->P3) + (P2->P3 + P3->P3)) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in (((((E0 + E18) + (E36 + E54)) + ((E72 + E90) + (E108 + E126))) + (((E144 + E162) + (E180 + E198)) + ((E216 + E234) + (E252 + E270))))) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (((((E1 + E19) + (E37 + E55)) + ((E73 + E91) + (E109 + E127))) + (((E145 + E163) + (E181 + E199)) + ((E217 + E235) + (E253 + E271))))) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (((((E2 + E20) + (E38 + E56)) + ((E74 + E92) + (E110 + E128))) + (((E146 + E164) + (E182 + E200)) + ((E218 + E236) + (E254 + E272))))) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all e: used | e.fiber in (((((((E3 + E4) + (E5 + (E6 + E7))) + ((E21 + E22) + (E23 + (E24 + E25)))) + (((E39 + E40) + (E41 + (E42 + E43))) + ((E57 + E58) + (E59 + (E60 + E61))))) + ((((E75 + E76) + (E77 + (E78 + E79))) + ((E93 + E94) + (E95 + (E96 + E97)))) + (((E111 + E112) + (E113 + (E114 + E115))) + ((E129 + E130) + (E131 + (E132 + E133)))))) + (((((E147 + E148) + (E149 + (E150 + E151))) + ((E165 + E166) + (E167 + (E168 + E169)))) + (((E183 + E184) + (E185 + (E186 + E187))) + ((E201 + E202) + (E203 + (E204 + E205))))) + ((((E219 + E220) + (E221 + (E222 + E223))) + ((E237 + E238) + (E239 + (E240 + E241)))) + (((E255 + E256) + (E257 + (E258 + E259))) + ((E273 + E274) + (E275 + (E276 + E277)))))))) implies e.ev = {i: range0 | (i.shift0_3) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next0.(child[a].ev))
}
fun range1: set Pos { P0 }
fun loop1: set Pos { P0 }
fun next1: Pos -> Pos { P0->P0 }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { P0->P0 }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in ((((((((E0 + E1) + (E2 + E3)) + ((E4 + E5) + (E6 + E7))) + (((E18 + E19) + (E20 + E21)) + ((E22 + E23) + (E24 + E25)))) + ((((E36 + E37) + (E38 + E39)) + ((E40 + E41) + (E42 + E43))) + (((E54 + E55) + (E56 + E57)) + ((E58 + E59) + (E60 + E61))))) + (((((E72 + E73) + (E74 + E75)) + ((E76 + E77) + (E78 + E79))) + (((E90 + E91) + (E92 + E93)) + ((E94 + E95) + (E96 + E97)))) + ((((E108 + E109) + (E110 + E111)) + ((E112 + E113) + (E114 + E115))) + (((E126 + E127) + (E128 + E129)) + ((E130 + E131) + (E132 + E133)))))) + ((((((E144 + E145) + (E146 + E147)) + ((E148 + E149) + (E150 + E151))) + (((E162 + E163) + (E164 + E165)) + ((E166 + E167) + (E168 + E169)))) + ((((E180 + E181) + (E182 + E183)) + ((E184 + E185) + (E186 + E187))) + (((E198 + E199) + (E200 + E201)) + ((E202 + E203) + (E204 + E205))))) + (((((E216 + E217) + (E218 + E219)) + ((E220 + E221) + (E222 + E223))) + (((E234 + E235) + (E236 + E237)) + ((E238 + E239) + (E240 + E241)))) + ((((E252 + E253) + (E254 + E255)) + ((E256 + E257) + (E258 + E259))) + (((E270 + E271) + (E272 + E273)) + ((E274 + E275) + (E276 + E277)))))))) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next1.(child[a].ev))
}
fun range2: set Pos { (P0 + (P1 + P2)) }
fun loop2: set Pos { P2 }
fun next2: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift2_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun shift2_2: Pos -> Pos { (P0->P2 + (P1->P2 + P2->P2)) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in (((((E0 + E18) + (E36 + E54)) + ((E72 + E90) + (E108 + E126))) + (((E144 + E162) + (E180 + E198)) + ((E216 + E234) + (E252 + E270))))) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (((((E1 + E19) + (E37 + E55)) + ((E73 + E91) + (E109 + E127))) + (((E145 + E163) + (E181 + E199)) + ((E217 + E235) + (E253 + E271))))) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (((((((E2 + (E3 + E4)) + (E5 + (E6 + E7))) + ((E20 + (E21 + E22)) + (E23 + (E24 + E25)))) + (((E38 + (E39 + E40)) + (E41 + (E42 + E43))) + ((E56 + (E57 + E58)) + (E59 + (E60 + E61))))) + ((((E74 + (E75 + E76)) + (E77 + (E78 + E79))) + ((E92 + (E93 + E94)) + (E95 + (E96 + E97)))) + (((E110 + (E111 + E112)) + (E113 + (E114 + E115))) + ((E128 + (E129 + E130)) + (E131 + (E132 + E133)))))) + (((((E146 + (E147 + E148)) + (E149 + (E150 + E151))) + ((E164 + (E165 + E166)) + (E167 + (E168 + E169)))) + (((E182 + (E183 + E184)) + (E185 + (E186 + E187))) + ((E200 + (E201 + E202)) + (E203 + (E204 + E205))))) + ((((E218 + (E219 + E220)) + (E221 + (E222 + E223))) + ((E236 + (E237 + E238)) + (E239 + (E240 + E241)))) + (((E254 + (E255 + E256)) + (E257 + (E258 + E259))) + ((E272 + (E273 + E274)) + (E275 + (E276 + E277)))))))) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next2.(child[a].ev))
}
fun range3: set Pos { (P0 + P1) }
fun loop3: set Pos { P1 }
fun next3: Pos -> Pos { (P0->P1 + P1->P1) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift3_1: Pos -> Pos { (P0->P1 + P1->P1) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in (((((E0 + E18) + (E36 + E54)) + ((E72 + E90) + (E108 + E126))) + (((E144 + E162) + (E180 + E198)) + ((E216 + E234) + (E252 + E270))))) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (((((((E1 + (E2 + E3)) + ((E4 + E5) + (E6 + E7))) + ((E19 + (E20 + E21)) + ((E22 + E23) + (E24 + E25)))) + (((E37 + (E38 + E39)) + ((E40 + E41) + (E42 + E43))) + ((E55 + (E56 + E57)) + ((E58 + E59) + (E60 + E61))))) + ((((E73 + (E74 + E75)) + ((E76 + E77) + (E78 + E79))) + ((E91 + (E92 + E93)) + ((E94 + E95) + (E96 + E97)))) + (((E109 + (E110 + E111)) + ((E112 + E113) + (E114 + E115))) + ((E127 + (E128 + E129)) + ((E130 + E131) + (E132 + E133)))))) + (((((E145 + (E146 + E147)) + ((E148 + E149) + (E150 + E151))) + ((E163 + (E164 + E165)) + ((E166 + E167) + (E168 + E169)))) + (((E181 + (E182 + E183)) + ((E184 + E185) + (E186 + E187))) + ((E199 + (E200 + E201)) + ((E202 + E203) + (E204 + E205))))) + ((((E217 + (E218 + E219)) + ((E220 + E221) + (E222 + E223))) + ((E235 + (E236 + E237)) + ((E238 + E239) + (E240 + E241)))) + (((E253 + (E254 + E255)) + ((E256 + E257) + (E258 + E259))) + ((E271 + (E272 + E273)) + ((E274 + E275) + (E276 + E277)))))))) implies e.ev = {i: range3 | (i.shift3_1) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next3.(child[a].ev))
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (P2)
(R->P0 in ev0)
semantics0[av1, ev1]
all a: lab.T0 | a.av1 = ((P1 + P2))
(R->P0 in ev1)
semantics0[av2, ev2]
all a: lab.T0 | a.av2 = ((P0 + P2))
(R->P0 in ev2)
semantics0[av3, ev3]
all a: lab.T0 | a.av3 = ((P0 + (P1 + P2)))
(R->P0 in ev3)
semantics1[av4, ev4]
all a: lab.T0 | a.av4 = (none)
not (R->P0 in ev4)
semantics2[av5, ev5]
all a: lab.T0 | a.av5 = (P1)
not (R->P0 in ev5)
semantics3[av6, ev6]
all a: lab.T0 | a.av6 = (P0)
not (R->P0 in ev6)
semantics2[av7, ev7]
all a: lab.T0 | a.av7 = ((P0 + P1))
not (R->P0 in ev7)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 5 Int


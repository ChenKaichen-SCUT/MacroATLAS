abstract sig Unit {}
one sig U0, U1, U2, U3, U4, U5, U6, U7 extends Unit {}
abstract sig Label {}
one sig T0, T1 extends Label {}
abstract sig Q {}
one sig Q0, Q1, Q2, Q3 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E26, E27 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos }
one sig A0, A1 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos }
one sig R, C0, L0, D0, C1, L1, D1 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { T0 }
fun un: set Label { T1 }
fun bin: set Label { none }
fun nonempty: set Fiber { ((((E1 + (E2 + E3)) + (E4 + (E5 + E6))) + ((E8 + (E9 + E10)) + (E11 + (E12 + E13)))) + (((E15 + (E16 + E17)) + (E18 + (E19 + E20))) + ((E22 + (E23 + E24)) + (E25 + (E26 + E27))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { ((U0->U1 + (U1->U2 + U2->U3)) + ((U3->U4 + U4->U5) + (U5->U6 + U6->U7))) }
fun carrierNext: Carrier -> Carrier { (((A0->A1 + A1->R) + (R->C0 + C0->L0)) + ((L0->D0 + D0->C1) + (C1->L1 + L1->D1))) }
fun child[a: Anchor]: set Port { a.((A0->C0 + A1->C1)) }
fun left[a: Anchor]: set Port { a.((A0->L0 + A1->L1)) }
fun right[a: Anchor]: set Port { a.((A0->D0 + A1->D1)) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
#(lab.bin) <= 0
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q1
E2.qi = Q0
E2.qo = Q2
E3.qi = Q0
E3.qo = Q3
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q1
E6.qi = Q0
E6.qo = Q2
E7.qi = Q1
E7.qo = Q1
E8.qi = Q1
E8.qo = Q2
E9.qi = Q1
E9.qo = Q3
E10.qi = Q1
E10.qo = Q0
E11.qi = Q1
E11.qo = Q1
E12.qi = Q1
E12.qo = Q2
E13.qi = Q1
E13.qo = Q3
E14.qi = Q2
E14.qo = Q2
E15.qi = Q2
E15.qo = Q3
E16.qi = Q2
E16.qo = Q0
E17.qi = Q2
E17.qo = Q1
E18.qi = Q2
E18.qo = Q2
E19.qi = Q2
E19.qo = Q3
E20.qi = Q2
E20.qo = Q0
E21.qi = Q3
E21.qo = Q3
E22.qi = Q3
E22.qo = Q0
E23.qi = Q3
E23.qo = Q1
E24.qi = Q3
E24.qo = Q2
E25.qi = Q3
E25.qo = Q3
E26.qi = Q3
E26.qo = Q0
E27.qi = Q3
E27.qo = Q1
all e: used | e.fiber in (((E0 + E7) + (E14 + E21))) implies #e.cost = 0
all e: used | e.fiber in (((E1 + E8) + (E15 + E22))) implies #e.cost = 1
all e: used | e.fiber in (((E2 + E9) + (E16 + E23))) implies #e.cost = 2
all e: used | e.fiber in (((E3 + E10) + (E17 + E24))) implies #e.cost = 3
all e: used | e.fiber in (((E4 + E11) + (E18 + E25))) implies #e.cost = 4
all e: used | e.fiber in (((E5 + E12) + (E19 + E26))) implies #e.cost = 5
all e: used | e.fiber in (((E6 + E13) + (E20 + E27))) implies #e.cost = 6
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (((Q0 + Q1) + (Q2 + Q3)))
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 and child[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T1 and child[a].fiber.qo = Q1 implies a.state = Q2
all a: active | a.lab = T1 and child[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T1 and child[a].fiber.qo = Q3 implies a.state = Q0
}
fun range0: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop0: set Pos { P3 }
fun next0: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift0_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun shift0_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P3 + P3->P3)) }
fun shift0_3: Pos -> Pos { ((P0->P3 + P1->P3) + (P2->P3 + P3->P3)) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in (((E0 + E7) + (E14 + E21))) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (((E1 + E8) + (E15 + E22))) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (((E2 + E9) + (E16 + E23))) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all e: used | e.fiber in (((((E3 + E4) + (E5 + E6)) + ((E10 + E11) + (E12 + E13))) + (((E17 + E18) + (E19 + E20)) + ((E24 + E25) + (E26 + E27))))) implies e.ev = {i: range0 | (i.shift0_3) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next0.(child[a].ev))
}
fun range1: set Pos { P0 }
fun loop1: set Pos { P0 }
fun next1: Pos -> Pos { P0->P0 }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { P0->P0 }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in (((((E0 + (E1 + E2)) + ((E3 + E4) + (E5 + E6))) + ((E7 + (E8 + E9)) + ((E10 + E11) + (E12 + E13)))) + (((E14 + (E15 + E16)) + ((E17 + E18) + (E19 + E20))) + ((E21 + (E22 + E23)) + ((E24 + E25) + (E26 + E27)))))) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next1.(child[a].ev))
}
fun range2: set Pos { (P0 + (P1 + P2)) }
fun loop2: set Pos { P2 }
fun next2: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift2_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun shift2_2: Pos -> Pos { (P0->P2 + (P1->P2 + P2->P2)) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in (((E0 + E7) + (E14 + E21))) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (((E1 + E8) + (E15 + E22))) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (((((E2 + E3) + (E4 + (E5 + E6))) + ((E9 + E10) + (E11 + (E12 + E13)))) + (((E16 + E17) + (E18 + (E19 + E20))) + ((E23 + E24) + (E25 + (E26 + E27)))))) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next2.(child[a].ev))
}
fun range3: set Pos { (P0 + P1) }
fun loop3: set Pos { P1 }
fun next3: Pos -> Pos { (P0->P1 + P1->P1) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift3_1: Pos -> Pos { (P0->P1 + P1->P1) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in (((E0 + E7) + (E14 + E21))) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (((((E1 + (E2 + E3)) + (E4 + (E5 + E6))) + ((E8 + (E9 + E10)) + (E11 + (E12 + E13)))) + (((E15 + (E16 + E17)) + (E18 + (E19 + E20))) + ((E22 + (E23 + E24)) + (E25 + (E26 + E27)))))) implies e.ev = {i: range3 | (i.shift3_1) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next3.(child[a].ev))
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (P2)
(R->P0 in ev0)
semantics0[av1, ev1]
all a: lab.T0 | a.av1 = ((P1 + P2))
(R->P0 in ev1)
semantics0[av2, ev2]
all a: lab.T0 | a.av2 = ((P0 + P2))
(R->P0 in ev2)
semantics0[av3, ev3]
all a: lab.T0 | a.av3 = ((P0 + (P1 + P2)))
(R->P0 in ev3)
semantics1[av4, ev4]
all a: lab.T0 | a.av4 = (none)
not (R->P0 in ev4)
semantics2[av5, ev5]
all a: lab.T0 | a.av5 = (P1)
not (R->P0 in ev5)
semantics3[av6, ev6]
all a: lab.T0 | a.av6 = (P0)
not (R->P0 in ev6)
semantics2[av7, ev7]
all a: lab.T0 | a.av7 = ((P0 + P1))
not (R->P0 in ev7)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 5 Int


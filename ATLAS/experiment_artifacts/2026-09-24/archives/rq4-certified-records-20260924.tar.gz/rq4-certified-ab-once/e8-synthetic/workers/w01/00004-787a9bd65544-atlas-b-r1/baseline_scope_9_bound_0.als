open util/ordering[SeqIdx]

abstract sig DAGNode {
	l: set DAGNode,
	r: set DAGNode
}
fact {
	all n: DAGNode | n not in n.^(l + r)
}

sig And extends DAGNode {} {
	one l
	one r
}

abstract sig Literal extends DAGNode {} {
	no l
	no r
}

abstract sig SeqIdx {}
abstract sig Trace {
	lasso: SeqIdx -> SeqIdx,
	valuation: DAGNode -> SeqIdx
} {
	// Negation
    
	// Or
    
	// And
    all n: And, i: seqRange | n->i in valuation iff (n.l->i in valuation and n.r->i in valuation)
	// Imply
    
	// G
    
    // X
    
	// F
    
	// Until
    
}
fun seqRange[t: Trace]: set SeqIdx {
	let lastOfTrace = t.lasso.SeqIdx | lastOfTrace.prevs + lastOfTrace
}
fun futureIdx[t: Trace, i: SeqIdx]: set SeqIdx {
	i.^((next :> seqRange[t]) + t.lasso) + i
}
abstract sig PositiveTrace extends Trace {}
abstract sig NegativeTrace extends Trace {}
one sig x0, x1, x2, x3, x4 extends Literal {}
one sig T0 extends SeqIdx {}
fact {
    first = T0
    ordering/next = none->none
}

one sig PT0 extends PositiveTrace {} {
    lasso = T0->T0
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 in valuation
    
}


one sig NT0 extends NegativeTrace {} {
    lasso = T0->T0
    
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0) & valuation
}

one sig NT1 extends NegativeTrace {} {
    lasso = T0->T0
    x4->T0 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0) & valuation
}

one sig NT2 extends NegativeTrace {} {
    lasso = T0->T0
    x3->T0 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0) & valuation
}

one sig NT3 extends NegativeTrace {} {
    lasso = T0->T0
    x3->T0 + x4->T0 in valuation
    no (x0->T0 + x1->T0 + x2->T0) & valuation
}

one sig NT4 extends NegativeTrace {} {
    lasso = T0->T0
    x2->T0 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x4->T0) & valuation
}

one sig NT5 extends NegativeTrace {} {
    lasso = T0->T0
    x2->T0 + x4->T0 in valuation
    no (x0->T0 + x1->T0 + x3->T0) & valuation
}

one sig NT6 extends NegativeTrace {} {
    lasso = T0->T0
    x2->T0 + x3->T0 in valuation
    no (x0->T0 + x1->T0 + x4->T0) & valuation
}

one sig NT7 extends NegativeTrace {} {
    lasso = T0->T0
    x2->T0 + x3->T0 + x4->T0 in valuation
    no (x0->T0 + x1->T0) & valuation
}

one sig NT8 extends NegativeTrace {} {
    lasso = T0->T0
    x1->T0 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0) & valuation
}

one sig NT9 extends NegativeTrace {} {
    lasso = T0->T0
    x1->T0 + x4->T0 in valuation
    no (x0->T0 + x2->T0 + x3->T0) & valuation
}

one sig NT10 extends NegativeTrace {} {
    lasso = T0->T0
    x1->T0 + x3->T0 in valuation
    no (x0->T0 + x2->T0 + x4->T0) & valuation
}

one sig NT11 extends NegativeTrace {} {
    lasso = T0->T0
    x1->T0 + x3->T0 + x4->T0 in valuation
    no (x0->T0 + x2->T0) & valuation
}

one sig NT12 extends NegativeTrace {} {
    lasso = T0->T0
    x1->T0 + x2->T0 in valuation
    no (x0->T0 + x3->T0 + x4->T0) & valuation
}

one sig NT13 extends NegativeTrace {} {
    lasso = T0->T0
    x1->T0 + x2->T0 + x4->T0 in valuation
    no (x0->T0 + x3->T0) & valuation
}

one sig NT14 extends NegativeTrace {} {
    lasso = T0->T0
    x1->T0 + x2->T0 + x3->T0 in valuation
    no (x0->T0 + x4->T0) & valuation
}

one sig NT15 extends NegativeTrace {} {
    lasso = T0->T0
    x1->T0 + x2->T0 + x3->T0 + x4->T0 in valuation
    no (x0->T0) & valuation
}

one sig NT16 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0) & valuation
}

one sig NT17 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x4->T0 in valuation
    no (x1->T0 + x2->T0 + x3->T0) & valuation
}

one sig NT18 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x3->T0 in valuation
    no (x1->T0 + x2->T0 + x4->T0) & valuation
}

one sig NT19 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x3->T0 + x4->T0 in valuation
    no (x1->T0 + x2->T0) & valuation
}

one sig NT20 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x2->T0 in valuation
    no (x1->T0 + x3->T0 + x4->T0) & valuation
}

one sig NT21 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x2->T0 + x4->T0 in valuation
    no (x1->T0 + x3->T0) & valuation
}

one sig NT22 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x2->T0 + x3->T0 in valuation
    no (x1->T0 + x4->T0) & valuation
}

one sig NT23 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x2->T0 + x3->T0 + x4->T0 in valuation
    no (x1->T0) & valuation
}

one sig NT24 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x1->T0 in valuation
    no (x2->T0 + x3->T0 + x4->T0) & valuation
}

one sig NT25 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x1->T0 + x4->T0 in valuation
    no (x2->T0 + x3->T0) & valuation
}

one sig NT26 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x1->T0 + x3->T0 in valuation
    no (x2->T0 + x4->T0) & valuation
}

one sig NT27 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x1->T0 + x3->T0 + x4->T0 in valuation
    no (x2->T0) & valuation
}

one sig NT28 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x1->T0 + x2->T0 in valuation
    no (x3->T0 + x4->T0) & valuation
}

one sig NT29 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x1->T0 + x2->T0 + x4->T0 in valuation
    no (x3->T0) & valuation
}

one sig NT30 extends NegativeTrace {} {
    lasso = T0->T0
    x0->T0 + x1->T0 + x2->T0 + x3->T0 in valuation
    no (x4->T0) & valuation
}

one sig LearnedLTL {
    Root: DAGNode
}
fun root: one DAGNode { LearnedLTL.Root }
fun childrenOf[n: DAGNode]: set DAGNode { n.^(l+r) }
fun childrenAndSelfOf[n: DAGNode]: set DAGNode { n.*(l+r) }
fun ancestorsOf[n: DAGNode]: set DAGNode { n.~^(l+r) }
fun ancestorsAndSelfOf[n: DAGNode]: set DAGNode { n.~*(l+r) }
fun subDAG[n: DAGNode]: DAGNode -> DAGNode { n.*(l+r) <: (l+r) }



fun experimentReach: set DAGNode { childrenAndSelfOf[root] }
fun experimentKept: DAGNode -> DAGNode { (none->none) & subDAG[root] }
one sig ExperimentCost { used: set DAGNode }
fact { ExperimentCost.used = experimentReach }
fact ExperimentBounds {
  DAGNode = experimentReach + Literal + (none)
  #experimentReach <= 9
  #(experimentReach & (And)) <= 4
  minsome ExperimentCost.used
}
run {
    all t: PositiveTrace | root->T0 in t.valuation
    all t: NegativeTrace | root->T0 not in t.valuation
    
} for 14 DAGNode, 5 Int
abstract sig Unit {}
one sig U0, U1, U2, U3, U4, U5, U6, U7 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5 extends Label {}
abstract sig Q {}
one sig Q0 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0 extends Fiber {}
abstract sig Pos {}
one sig P0 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos, av20: set Pos, av21: set Pos, av22: set Pos, av23: set Pos, av24: set Pos, av25: set Pos, av26: set Pos, av27: set Pos, av28: set Pos, av29: set Pos, av30: set Pos, av31: set Pos }
one sig A0, A1, A2, A3, A4, A5, A6, A7 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos, ev20: set Pos, ev21: set Pos, ev22: set Pos, ev23: set Pos, ev24: set Pos, ev25: set Pos, ev26: set Pos, ev27: set Pos, ev28: set Pos, ev29: set Pos, ev30: set Pos, ev31: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4, C5, L5, D5, C6, L6, D6, C7, L7, D7 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { ((T0 + T1) + (T2 + (T3 + T4))) }
fun un: set Label { none }
fun bin: set Label { T5 }
fun nonempty: set Fiber { none }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { ((U0->U1 + (U1->U2 + U2->U3)) + ((U3->U4 + U4->U5) + (U5->U6 + U6->U7))) }
fun carrierNext: Carrier -> Carrier { (((((A0->A1 + A1->A2) + (A2->A3 + A3->A4)) + ((A4->A5 + A5->A6) + (A6->A7 + A7->R))) + (((R->C0 + C0->L0) + (L0->D0 + D0->C1)) + ((C1->L1 + L1->D1) + (D1->C2 + C2->L2)))) + ((((L2->D2 + D2->C3) + (C3->L3 + L3->D3)) + ((D3->C4 + C4->L4) + (L4->D4 + D4->C5))) + (((C5->L5 + L5->D5) + (D5->C6 + C6->L6)) + ((L6->D6 + D6->C7) + (C7->L7 + L7->D7))))) }
fun child[a: Anchor]: set Port { a.((((A0->C0 + A1->C1) + (A2->C2 + A3->C3)) + ((A4->C4 + A5->C5) + (A6->C6 + A7->C7)))) }
fun left[a: Anchor]: set Port { a.((((A0->L0 + A1->L1) + (A2->L2 + A3->L3)) + ((A4->L4 + A5->L5) + (A6->L6 + A7->L7)))) }
fun right[a: Anchor]: set Port { a.((((A0->D0 + A1->D1) + (A2->D2 + A3->D3)) + ((A4->D4 + A5->D5) + (A6->D6 + A7->D7)))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
C5.src = A5
L5.src = A5
D5.src = A5
(some C5.target iff A5.lab in un and some A5.lab)
(some L5.target iff A5.lab in bin and some A5.lab)
(some D5.target iff A5.lab in bin and some A5.lab)
C6.src = A6
L6.src = A6
D6.src = A6
(some C6.target iff A6.lab in un and some A6.lab)
(some L6.target iff A6.lab in bin and some A6.lab)
(some D6.target iff A6.lab in bin and some A6.lab)
C7.src = A7
L7.src = A7
D7.src = A7
(some C7.target iff A7.lab in un and some A7.lab)
(some L7.target iff A7.lab in bin and some A7.lab)
(some D7.target iff A7.lab in bin and some A7.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
no A3.graph & (((A0 + A1) + (A2 + A3)))
no A4.graph & (((A0 + A1) + (A2 + (A3 + A4))))
no A5.graph & (((A0 + (A1 + A2)) + (A3 + (A4 + A5))))
no A6.graph & (((A0 + (A1 + A2)) + ((A3 + A4) + (A5 + A6))))
no A7.graph & ((((A0 + A1) + (A2 + A3)) + ((A4 + A5) + (A6 + A7))))
#(lab.bin) <= 4
lone lab.T0
lone lab.T1
lone lab.T2
lone lab.T3
lone lab.T4
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un implies #(target.A2) > 1
some A2.lab implies some A1.lab
some A3.lab and A3.lab in un implies #(target.A3) > 1
some A3.lab implies some A2.lab
some A4.lab and A4.lab in un implies #(target.A4) > 1
some A4.lab implies some A3.lab
some A5.lab and A5.lab in un implies #(target.A5) > 1
some A5.lab implies some A4.lab
some A6.lab and A6.lab in un implies #(target.A6) > 1
some A6.lab implies some A5.lab
some A7.lab and A7.lab in un implies #(target.A7) > 1
some A7.lab implies some A6.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
all e: used | e.fiber in (E0) implies #e.cost = 0
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q0)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 implies a.state = Q0
all a: active | a.lab = T3 implies a.state = Q0
all a: active | a.lab = T4 implies a.state = Q0
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
}
fun range0: set Pos { P0 }
fun loop0: set Pos { P0 }
fun next0: Pos -> Pos { P0->P0 }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { P0->P0 }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in (E0) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all a: active | a.lab = T5 implies a.av = (left[a].ev & right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (P0)
all a: lab.T1 | a.av0 = (P0)
all a: lab.T2 | a.av0 = (P0)
all a: lab.T3 | a.av0 = (P0)
all a: lab.T4 | a.av0 = (P0)
(R->P0 in ev0)
semantics0[av1, ev1]
all a: lab.T0 | a.av1 = (none)
all a: lab.T1 | a.av1 = (none)
all a: lab.T2 | a.av1 = (none)
all a: lab.T3 | a.av1 = (none)
all a: lab.T4 | a.av1 = (none)
not (R->P0 in ev1)
semantics0[av2, ev2]
all a: lab.T0 | a.av2 = (none)
all a: lab.T1 | a.av2 = (none)
all a: lab.T2 | a.av2 = (none)
all a: lab.T3 | a.av2 = (none)
all a: lab.T4 | a.av2 = (P0)
not (R->P0 in ev2)
semantics0[av3, ev3]
all a: lab.T0 | a.av3 = (none)
all a: lab.T1 | a.av3 = (none)
all a: lab.T2 | a.av3 = (none)
all a: lab.T3 | a.av3 = (P0)
all a: lab.T4 | a.av3 = (none)
not (R->P0 in ev3)
semantics0[av4, ev4]
all a: lab.T0 | a.av4 = (none)
all a: lab.T1 | a.av4 = (none)
all a: lab.T2 | a.av4 = (none)
all a: lab.T3 | a.av4 = (P0)
all a: lab.T4 | a.av4 = (P0)
not (R->P0 in ev4)
semantics0[av5, ev5]
all a: lab.T0 | a.av5 = (none)
all a: lab.T1 | a.av5 = (none)
all a: lab.T2 | a.av5 = (P0)
all a: lab.T3 | a.av5 = (none)
all a: lab.T4 | a.av5 = (none)
not (R->P0 in ev5)
semantics0[av6, ev6]
all a: lab.T0 | a.av6 = (none)
all a: lab.T1 | a.av6 = (none)
all a: lab.T2 | a.av6 = (P0)
all a: lab.T3 | a.av6 = (none)
all a: lab.T4 | a.av6 = (P0)
not (R->P0 in ev6)
semantics0[av7, ev7]
all a: lab.T0 | a.av7 = (none)
all a: lab.T1 | a.av7 = (none)
all a: lab.T2 | a.av7 = (P0)
all a: lab.T3 | a.av7 = (P0)
all a: lab.T4 | a.av7 = (none)
not (R->P0 in ev7)
semantics0[av8, ev8]
all a: lab.T0 | a.av8 = (none)
all a: lab.T1 | a.av8 = (none)
all a: lab.T2 | a.av8 = (P0)
all a: lab.T3 | a.av8 = (P0)
all a: lab.T4 | a.av8 = (P0)
not (R->P0 in ev8)
semantics0[av9, ev9]
all a: lab.T0 | a.av9 = (none)
all a: lab.T1 | a.av9 = (P0)
all a: lab.T2 | a.av9 = (none)
all a: lab.T3 | a.av9 = (none)
all a: lab.T4 | a.av9 = (none)
not (R->P0 in ev9)
semantics0[av10, ev10]
all a: lab.T0 | a.av10 = (none)
all a: lab.T1 | a.av10 = (P0)
all a: lab.T2 | a.av10 = (none)
all a: lab.T3 | a.av10 = (none)
all a: lab.T4 | a.av10 = (P0)
not (R->P0 in ev10)
semantics0[av11, ev11]
all a: lab.T0 | a.av11 = (none)
all a: lab.T1 | a.av11 = (P0)
all a: lab.T2 | a.av11 = (none)
all a: lab.T3 | a.av11 = (P0)
all a: lab.T4 | a.av11 = (none)
not (R->P0 in ev11)
semantics0[av12, ev12]
all a: lab.T0 | a.av12 = (none)
all a: lab.T1 | a.av12 = (P0)
all a: lab.T2 | a.av12 = (none)
all a: lab.T3 | a.av12 = (P0)
all a: lab.T4 | a.av12 = (P0)
not (R->P0 in ev12)
semantics0[av13, ev13]
all a: lab.T0 | a.av13 = (none)
all a: lab.T1 | a.av13 = (P0)
all a: lab.T2 | a.av13 = (P0)
all a: lab.T3 | a.av13 = (none)
all a: lab.T4 | a.av13 = (none)
not (R->P0 in ev13)
semantics0[av14, ev14]
all a: lab.T0 | a.av14 = (none)
all a: lab.T1 | a.av14 = (P0)
all a: lab.T2 | a.av14 = (P0)
all a: lab.T3 | a.av14 = (none)
all a: lab.T4 | a.av14 = (P0)
not (R->P0 in ev14)
semantics0[av15, ev15]
all a: lab.T0 | a.av15 = (none)
all a: lab.T1 | a.av15 = (P0)
all a: lab.T2 | a.av15 = (P0)
all a: lab.T3 | a.av15 = (P0)
all a: lab.T4 | a.av15 = (none)
not (R->P0 in ev15)
semantics0[av16, ev16]
all a: lab.T0 | a.av16 = (none)
all a: lab.T1 | a.av16 = (P0)
all a: lab.T2 | a.av16 = (P0)
all a: lab.T3 | a.av16 = (P0)
all a: lab.T4 | a.av16 = (P0)
not (R->P0 in ev16)
semantics0[av17, ev17]
all a: lab.T0 | a.av17 = (P0)
all a: lab.T1 | a.av17 = (none)
all a: lab.T2 | a.av17 = (none)
all a: lab.T3 | a.av17 = (none)
all a: lab.T4 | a.av17 = (none)
not (R->P0 in ev17)
semantics0[av18, ev18]
all a: lab.T0 | a.av18 = (P0)
all a: lab.T1 | a.av18 = (none)
all a: lab.T2 | a.av18 = (none)
all a: lab.T3 | a.av18 = (none)
all a: lab.T4 | a.av18 = (P0)
not (R->P0 in ev18)
semantics0[av19, ev19]
all a: lab.T0 | a.av19 = (P0)
all a: lab.T1 | a.av19 = (none)
all a: lab.T2 | a.av19 = (none)
all a: lab.T3 | a.av19 = (P0)
all a: lab.T4 | a.av19 = (none)
not (R->P0 in ev19)
semantics0[av20, ev20]
all a: lab.T0 | a.av20 = (P0)
all a: lab.T1 | a.av20 = (none)
all a: lab.T2 | a.av20 = (none)
all a: lab.T3 | a.av20 = (P0)
all a: lab.T4 | a.av20 = (P0)
not (R->P0 in ev20)
semantics0[av21, ev21]
all a: lab.T0 | a.av21 = (P0)
all a: lab.T1 | a.av21 = (none)
all a: lab.T2 | a.av21 = (P0)
all a: lab.T3 | a.av21 = (none)
all a: lab.T4 | a.av21 = (none)
not (R->P0 in ev21)
semantics0[av22, ev22]
all a: lab.T0 | a.av22 = (P0)
all a: lab.T1 | a.av22 = (none)
all a: lab.T2 | a.av22 = (P0)
all a: lab.T3 | a.av22 = (none)
all a: lab.T4 | a.av22 = (P0)
not (R->P0 in ev22)
semantics0[av23, ev23]
all a: lab.T0 | a.av23 = (P0)
all a: lab.T1 | a.av23 = (none)
all a: lab.T2 | a.av23 = (P0)
all a: lab.T3 | a.av23 = (P0)
all a: lab.T4 | a.av23 = (none)
not (R->P0 in ev23)
semantics0[av24, ev24]
all a: lab.T0 | a.av24 = (P0)
all a: lab.T1 | a.av24 = (none)
all a: lab.T2 | a.av24 = (P0)
all a: lab.T3 | a.av24 = (P0)
all a: lab.T4 | a.av24 = (P0)
not (R->P0 in ev24)
semantics0[av25, ev25]
all a: lab.T0 | a.av25 = (P0)
all a: lab.T1 | a.av25 = (P0)
all a: lab.T2 | a.av25 = (none)
all a: lab.T3 | a.av25 = (none)
all a: lab.T4 | a.av25 = (none)
not (R->P0 in ev25)
semantics0[av26, ev26]
all a: lab.T0 | a.av26 = (P0)
all a: lab.T1 | a.av26 = (P0)
all a: lab.T2 | a.av26 = (none)
all a: lab.T3 | a.av26 = (none)
all a: lab.T4 | a.av26 = (P0)
not (R->P0 in ev26)
semantics0[av27, ev27]
all a: lab.T0 | a.av27 = (P0)
all a: lab.T1 | a.av27 = (P0)
all a: lab.T2 | a.av27 = (none)
all a: lab.T3 | a.av27 = (P0)
all a: lab.T4 | a.av27 = (none)
not (R->P0 in ev27)
semantics0[av28, ev28]
all a: lab.T0 | a.av28 = (P0)
all a: lab.T1 | a.av28 = (P0)
all a: lab.T2 | a.av28 = (none)
all a: lab.T3 | a.av28 = (P0)
all a: lab.T4 | a.av28 = (P0)
not (R->P0 in ev28)
semantics0[av29, ev29]
all a: lab.T0 | a.av29 = (P0)
all a: lab.T1 | a.av29 = (P0)
all a: lab.T2 | a.av29 = (P0)
all a: lab.T3 | a.av29 = (none)
all a: lab.T4 | a.av29 = (none)
not (R->P0 in ev29)
semantics0[av30, ev30]
all a: lab.T0 | a.av30 = (P0)
all a: lab.T1 | a.av30 = (P0)
all a: lab.T2 | a.av30 = (P0)
all a: lab.T3 | a.av30 = (none)
all a: lab.T4 | a.av30 = (P0)
not (R->P0 in ev30)
semantics0[av31, ev31]
all a: lab.T0 | a.av31 = (P0)
all a: lab.T1 | a.av31 = (P0)
all a: lab.T2 | a.av31 = (P0)
all a: lab.T3 | a.av31 = (P0)
all a: lab.T4 | a.av31 = (none)
not (R->P0 in ev31)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int


abstract sig Unit {}
one sig U0, U1, U2, U3, U4, U5, U6, U7, U8, U9, U10, U11, U12, U13, U14, U15, U16, U17, U18, U19, U20, U21, U22, U23, U24, U25, U26, U27, U28 extends Unit {}
abstract sig Label {}
one sig T0, T1 extends Label {}
abstract sig Q {}
one sig Q0 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E26, E27, E28 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17, P18, P19, P20, P21, P22, P23, P24, P25, P26, P27, P28, P29 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos, av20: set Pos, av21: set Pos, av22: set Pos, av23: set Pos, av24: set Pos, av25: set Pos, av26: set Pos, av27: set Pos, av28: set Pos, av29: set Pos, av30: set Pos, av31: set Pos }
one sig A0, A1 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos, ev20: set Pos, ev21: set Pos, ev22: set Pos, ev23: set Pos, ev24: set Pos, ev25: set Pos, ev26: set Pos, ev27: set Pos, ev28: set Pos, ev29: set Pos, ev30: set Pos, ev31: set Pos }
one sig R, C0, L0, D0, C1, L1, D1 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { T0 }
fun un: set Label { T1 }
fun bin: set Label { none }
fun nonempty: set Fiber { ((((E1 + (E2 + E3)) + ((E4 + E5) + (E6 + E7))) + ((E8 + (E9 + E10)) + ((E11 + E12) + (E13 + E14)))) + (((E15 + (E16 + E17)) + ((E18 + E19) + (E20 + E21))) + ((E22 + (E23 + E24)) + ((E25 + E26) + (E27 + E28))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { ((((U0->U1 + (U1->U2 + U2->U3)) + ((U3->U4 + U4->U5) + (U5->U6 + U6->U7))) + ((U7->U8 + (U8->U9 + U9->U10)) + ((U10->U11 + U11->U12) + (U12->U13 + U13->U14)))) + (((U14->U15 + (U15->U16 + U16->U17)) + ((U17->U18 + U18->U19) + (U19->U20 + U20->U21))) + ((U21->U22 + (U22->U23 + U23->U24)) + ((U24->U25 + U25->U26) + (U26->U27 + U27->U28))))) }
fun carrierNext: Carrier -> Carrier { (((A0->A1 + A1->R) + (R->C0 + C0->L0)) + ((L0->D0 + D0->C1) + (C1->L1 + L1->D1))) }
fun child[a: Anchor]: set Port { a.((A0->C0 + A1->C1)) }
fun left[a: Anchor]: set Port { a.((A0->L0 + A1->L1)) }
fun right[a: Anchor]: set Port { a.((A0->D0 + A1->D1)) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
#(lab.bin) <= 0
lone lab.T0
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q0
E7.qo = Q0
E8.qi = Q0
E8.qo = Q0
E9.qi = Q0
E9.qo = Q0
E10.qi = Q0
E10.qo = Q0
E11.qi = Q0
E11.qo = Q0
E12.qi = Q0
E12.qo = Q0
E13.qi = Q0
E13.qo = Q0
E14.qi = Q0
E14.qo = Q0
E15.qi = Q0
E15.qo = Q0
E16.qi = Q0
E16.qo = Q0
E17.qi = Q0
E17.qo = Q0
E18.qi = Q0
E18.qo = Q0
E19.qi = Q0
E19.qo = Q0
E20.qi = Q0
E20.qo = Q0
E21.qi = Q0
E21.qo = Q0
E22.qi = Q0
E22.qo = Q0
E23.qi = Q0
E23.qo = Q0
E24.qi = Q0
E24.qo = Q0
E25.qi = Q0
E25.qo = Q0
E26.qi = Q0
E26.qo = Q0
E27.qi = Q0
E27.qo = Q0
E28.qi = Q0
E28.qo = Q0
all e: used | e.fiber in (E0) implies #e.cost = 0
all e: used | e.fiber in (E1) implies #e.cost = 1
all e: used | e.fiber in (E2) implies #e.cost = 2
all e: used | e.fiber in (E3) implies #e.cost = 3
all e: used | e.fiber in (E4) implies #e.cost = 4
all e: used | e.fiber in (E5) implies #e.cost = 5
all e: used | e.fiber in (E6) implies #e.cost = 6
all e: used | e.fiber in (E7) implies #e.cost = 7
all e: used | e.fiber in (E8) implies #e.cost = 8
all e: used | e.fiber in (E9) implies #e.cost = 9
all e: used | e.fiber in (E10) implies #e.cost = 10
all e: used | e.fiber in (E11) implies #e.cost = 11
all e: used | e.fiber in (E12) implies #e.cost = 12
all e: used | e.fiber in (E13) implies #e.cost = 13
all e: used | e.fiber in (E14) implies #e.cost = 14
all e: used | e.fiber in (E15) implies #e.cost = 15
all e: used | e.fiber in (E16) implies #e.cost = 16
all e: used | e.fiber in (E17) implies #e.cost = 17
all e: used | e.fiber in (E18) implies #e.cost = 18
all e: used | e.fiber in (E19) implies #e.cost = 19
all e: used | e.fiber in (E20) implies #e.cost = 20
all e: used | e.fiber in (E21) implies #e.cost = 21
all e: used | e.fiber in (E22) implies #e.cost = 22
all e: used | e.fiber in (E23) implies #e.cost = 23
all e: used | e.fiber in (E24) implies #e.cost = 24
all e: used | e.fiber in (E25) implies #e.cost = 25
all e: used | e.fiber in (E26) implies #e.cost = 26
all e: used | e.fiber in (E27) implies #e.cost = 27
all e: used | e.fiber in (E28) implies #e.cost = 28
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q0)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 and child[a].fiber.qo = Q0 implies a.state = Q0
}
fun range0: set Pos { ((((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) + (((P7 + P8) + (P9 + P10)) + ((P11 + P12) + (P13 + P14)))) + (((P15 + (P16 + P17)) + ((P18 + P19) + (P20 + P21))) + (((P22 + P23) + (P24 + P25)) + ((P26 + P27) + (P28 + P29))))) }
fun loop0: set Pos { P29 }
fun next0: Pos -> Pos { ((((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P7))) + (((P7->P8 + P8->P9) + (P9->P10 + P10->P11)) + ((P11->P12 + P12->P13) + (P13->P14 + P14->P15)))) + (((P15->P16 + (P16->P17 + P17->P18)) + ((P18->P19 + P19->P20) + (P20->P21 + P21->P22))) + (((P22->P23 + P23->P24) + (P24->P25 + P25->P26)) + ((P26->P27 + P27->P28) + (P28->P29 + P29->P29))))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((((P0->P0 + (P1->P1 + P2->P2)) + ((P3->P3 + P4->P4) + (P5->P5 + P6->P6))) + (((P7->P7 + P8->P8) + (P9->P9 + P10->P10)) + ((P11->P11 + P12->P12) + (P13->P13 + P14->P14)))) + (((P15->P15 + (P16->P16 + P17->P17)) + ((P18->P18 + P19->P19) + (P20->P20 + P21->P21))) + (((P22->P22 + P23->P23) + (P24->P24 + P25->P25)) + ((P26->P26 + P27->P27) + (P28->P28 + P29->P29))))) }
fun shift0_1: Pos -> Pos { ((((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P7))) + (((P7->P8 + P8->P9) + (P9->P10 + P10->P11)) + ((P11->P12 + P12->P13) + (P13->P14 + P14->P15)))) + (((P15->P16 + (P16->P17 + P17->P18)) + ((P18->P19 + P19->P20) + (P20->P21 + P21->P22))) + (((P22->P23 + P23->P24) + (P24->P25 + P25->P26)) + ((P26->P27 + P27->P28) + (P28->P29 + P29->P29))))) }
fun shift0_2: Pos -> Pos { ((((P0->P2 + (P1->P3 + P2->P4)) + ((P3->P5 + P4->P6) + (P5->P7 + P6->P8))) + (((P7->P9 + P8->P10) + (P9->P11 + P10->P12)) + ((P11->P13 + P12->P14) + (P13->P15 + P14->P16)))) + (((P15->P17 + (P16->P18 + P17->P19)) + ((P18->P20 + P19->P21) + (P20->P22 + P21->P23))) + (((P22->P24 + P23->P25) + (P24->P26 + P25->P27)) + ((P26->P28 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_3: Pos -> Pos { ((((P0->P3 + (P1->P4 + P2->P5)) + ((P3->P6 + P4->P7) + (P5->P8 + P6->P9))) + (((P7->P10 + P8->P11) + (P9->P12 + P10->P13)) + ((P11->P14 + P12->P15) + (P13->P16 + P14->P17)))) + (((P15->P18 + (P16->P19 + P17->P20)) + ((P18->P21 + P19->P22) + (P20->P23 + P21->P24))) + (((P22->P25 + P23->P26) + (P24->P27 + P25->P28)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_4: Pos -> Pos { ((((P0->P4 + (P1->P5 + P2->P6)) + ((P3->P7 + P4->P8) + (P5->P9 + P6->P10))) + (((P7->P11 + P8->P12) + (P9->P13 + P10->P14)) + ((P11->P15 + P12->P16) + (P13->P17 + P14->P18)))) + (((P15->P19 + (P16->P20 + P17->P21)) + ((P18->P22 + P19->P23) + (P20->P24 + P21->P25))) + (((P22->P26 + P23->P27) + (P24->P28 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_5: Pos -> Pos { ((((P0->P5 + (P1->P6 + P2->P7)) + ((P3->P8 + P4->P9) + (P5->P10 + P6->P11))) + (((P7->P12 + P8->P13) + (P9->P14 + P10->P15)) + ((P11->P16 + P12->P17) + (P13->P18 + P14->P19)))) + (((P15->P20 + (P16->P21 + P17->P22)) + ((P18->P23 + P19->P24) + (P20->P25 + P21->P26))) + (((P22->P27 + P23->P28) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_6: Pos -> Pos { ((((P0->P6 + (P1->P7 + P2->P8)) + ((P3->P9 + P4->P10) + (P5->P11 + P6->P12))) + (((P7->P13 + P8->P14) + (P9->P15 + P10->P16)) + ((P11->P17 + P12->P18) + (P13->P19 + P14->P20)))) + (((P15->P21 + (P16->P22 + P17->P23)) + ((P18->P24 + P19->P25) + (P20->P26 + P21->P27))) + (((P22->P28 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_7: Pos -> Pos { ((((P0->P7 + (P1->P8 + P2->P9)) + ((P3->P10 + P4->P11) + (P5->P12 + P6->P13))) + (((P7->P14 + P8->P15) + (P9->P16 + P10->P17)) + ((P11->P18 + P12->P19) + (P13->P20 + P14->P21)))) + (((P15->P22 + (P16->P23 + P17->P24)) + ((P18->P25 + P19->P26) + (P20->P27 + P21->P28))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_8: Pos -> Pos { ((((P0->P8 + (P1->P9 + P2->P10)) + ((P3->P11 + P4->P12) + (P5->P13 + P6->P14))) + (((P7->P15 + P8->P16) + (P9->P17 + P10->P18)) + ((P11->P19 + P12->P20) + (P13->P21 + P14->P22)))) + (((P15->P23 + (P16->P24 + P17->P25)) + ((P18->P26 + P19->P27) + (P20->P28 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_9: Pos -> Pos { ((((P0->P9 + (P1->P10 + P2->P11)) + ((P3->P12 + P4->P13) + (P5->P14 + P6->P15))) + (((P7->P16 + P8->P17) + (P9->P18 + P10->P19)) + ((P11->P20 + P12->P21) + (P13->P22 + P14->P23)))) + (((P15->P24 + (P16->P25 + P17->P26)) + ((P18->P27 + P19->P28) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_10: Pos -> Pos { ((((P0->P10 + (P1->P11 + P2->P12)) + ((P3->P13 + P4->P14) + (P5->P15 + P6->P16))) + (((P7->P17 + P8->P18) + (P9->P19 + P10->P20)) + ((P11->P21 + P12->P22) + (P13->P23 + P14->P24)))) + (((P15->P25 + (P16->P26 + P17->P27)) + ((P18->P28 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_11: Pos -> Pos { ((((P0->P11 + (P1->P12 + P2->P13)) + ((P3->P14 + P4->P15) + (P5->P16 + P6->P17))) + (((P7->P18 + P8->P19) + (P9->P20 + P10->P21)) + ((P11->P22 + P12->P23) + (P13->P24 + P14->P25)))) + (((P15->P26 + (P16->P27 + P17->P28)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_12: Pos -> Pos { ((((P0->P12 + (P1->P13 + P2->P14)) + ((P3->P15 + P4->P16) + (P5->P17 + P6->P18))) + (((P7->P19 + P8->P20) + (P9->P21 + P10->P22)) + ((P11->P23 + P12->P24) + (P13->P25 + P14->P26)))) + (((P15->P27 + (P16->P28 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_13: Pos -> Pos { ((((P0->P13 + (P1->P14 + P2->P15)) + ((P3->P16 + P4->P17) + (P5->P18 + P6->P19))) + (((P7->P20 + P8->P21) + (P9->P22 + P10->P23)) + ((P11->P24 + P12->P25) + (P13->P26 + P14->P27)))) + (((P15->P28 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_14: Pos -> Pos { ((((P0->P14 + (P1->P15 + P2->P16)) + ((P3->P17 + P4->P18) + (P5->P19 + P6->P20))) + (((P7->P21 + P8->P22) + (P9->P23 + P10->P24)) + ((P11->P25 + P12->P26) + (P13->P27 + P14->P28)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_15: Pos -> Pos { ((((P0->P15 + (P1->P16 + P2->P17)) + ((P3->P18 + P4->P19) + (P5->P20 + P6->P21))) + (((P7->P22 + P8->P23) + (P9->P24 + P10->P25)) + ((P11->P26 + P12->P27) + (P13->P28 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_16: Pos -> Pos { ((((P0->P16 + (P1->P17 + P2->P18)) + ((P3->P19 + P4->P20) + (P5->P21 + P6->P22))) + (((P7->P23 + P8->P24) + (P9->P25 + P10->P26)) + ((P11->P27 + P12->P28) + (P13->P29 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_17: Pos -> Pos { ((((P0->P17 + (P1->P18 + P2->P19)) + ((P3->P20 + P4->P21) + (P5->P22 + P6->P23))) + (((P7->P24 + P8->P25) + (P9->P26 + P10->P27)) + ((P11->P28 + P12->P29) + (P13->P29 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_18: Pos -> Pos { ((((P0->P18 + (P1->P19 + P2->P20)) + ((P3->P21 + P4->P22) + (P5->P23 + P6->P24))) + (((P7->P25 + P8->P26) + (P9->P27 + P10->P28)) + ((P11->P29 + P12->P29) + (P13->P29 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_19: Pos -> Pos { ((((P0->P19 + (P1->P20 + P2->P21)) + ((P3->P22 + P4->P23) + (P5->P24 + P6->P25))) + (((P7->P26 + P8->P27) + (P9->P28 + P10->P29)) + ((P11->P29 + P12->P29) + (P13->P29 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_20: Pos -> Pos { ((((P0->P20 + (P1->P21 + P2->P22)) + ((P3->P23 + P4->P24) + (P5->P25 + P6->P26))) + (((P7->P27 + P8->P28) + (P9->P29 + P10->P29)) + ((P11->P29 + P12->P29) + (P13->P29 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_21: Pos -> Pos { ((((P0->P21 + (P1->P22 + P2->P23)) + ((P3->P24 + P4->P25) + (P5->P26 + P6->P27))) + (((P7->P28 + P8->P29) + (P9->P29 + P10->P29)) + ((P11->P29 + P12->P29) + (P13->P29 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_22: Pos -> Pos { ((((P0->P22 + (P1->P23 + P2->P24)) + ((P3->P25 + P4->P26) + (P5->P27 + P6->P28))) + (((P7->P29 + P8->P29) + (P9->P29 + P10->P29)) + ((P11->P29 + P12->P29) + (P13->P29 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_23: Pos -> Pos { ((((P0->P23 + (P1->P24 + P2->P25)) + ((P3->P26 + P4->P27) + (P5->P28 + P6->P29))) + (((P7->P29 + P8->P29) + (P9->P29 + P10->P29)) + ((P11->P29 + P12->P29) + (P13->P29 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_24: Pos -> Pos { ((((P0->P24 + (P1->P25 + P2->P26)) + ((P3->P27 + P4->P28) + (P5->P29 + P6->P29))) + (((P7->P29 + P8->P29) + (P9->P29 + P10->P29)) + ((P11->P29 + P12->P29) + (P13->P29 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_25: Pos -> Pos { ((((P0->P25 + (P1->P26 + P2->P27)) + ((P3->P28 + P4->P29) + (P5->P29 + P6->P29))) + (((P7->P29 + P8->P29) + (P9->P29 + P10->P29)) + ((P11->P29 + P12->P29) + (P13->P29 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_26: Pos -> Pos { ((((P0->P26 + (P1->P27 + P2->P28)) + ((P3->P29 + P4->P29) + (P5->P29 + P6->P29))) + (((P7->P29 + P8->P29) + (P9->P29 + P10->P29)) + ((P11->P29 + P12->P29) + (P13->P29 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_27: Pos -> Pos { ((((P0->P27 + (P1->P28 + P2->P29)) + ((P3->P29 + P4->P29) + (P5->P29 + P6->P29))) + (((P7->P29 + P8->P29) + (P9->P29 + P10->P29)) + ((P11->P29 + P12->P29) + (P13->P29 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
fun shift0_28: Pos -> Pos { ((((P0->P28 + (P1->P29 + P2->P29)) + ((P3->P29 + P4->P29) + (P5->P29 + P6->P29))) + (((P7->P29 + P8->P29) + (P9->P29 + P10->P29)) + ((P11->P29 + P12->P29) + (P13->P29 + P14->P29)))) + (((P15->P29 + (P16->P29 + P17->P29)) + ((P18->P29 + P19->P29) + (P20->P29 + P21->P29))) + (((P22->P29 + P23->P29) + (P24->P29 + P25->P29)) + ((P26->P29 + P27->P29) + (P28->P29 + P29->P29))))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in (E0) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (E1) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range0 | (i.shift0_3) in (e.target.av)}
all e: used | e.fiber in (E4) implies e.ev = {i: range0 | (i.shift0_4) in (e.target.av)}
all e: used | e.fiber in (E5) implies e.ev = {i: range0 | (i.shift0_5) in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range0 | (i.shift0_6) in (e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range0 | (i.shift0_7) in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range0 | (i.shift0_8) in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range0 | (i.shift0_9) in (e.target.av)}
all e: used | e.fiber in (E10) implies e.ev = {i: range0 | (i.shift0_10) in (e.target.av)}
all e: used | e.fiber in (E11) implies e.ev = {i: range0 | (i.shift0_11) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range0 | (i.shift0_12) in (e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range0 | (i.shift0_13) in (e.target.av)}
all e: used | e.fiber in (E14) implies e.ev = {i: range0 | (i.shift0_14) in (e.target.av)}
all e: used | e.fiber in (E15) implies e.ev = {i: range0 | (i.shift0_15) in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range0 | (i.shift0_16) in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range0 | (i.shift0_17) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range0 | (i.shift0_18) in (e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range0 | (i.shift0_19) in (e.target.av)}
all e: used | e.fiber in (E20) implies e.ev = {i: range0 | (i.shift0_20) in (e.target.av)}
all e: used | e.fiber in (E21) implies e.ev = {i: range0 | (i.shift0_21) in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range0 | (i.shift0_22) in (e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range0 | (i.shift0_23) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range0 | (i.shift0_24) in (e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range0 | (i.shift0_25) in (e.target.av)}
all e: used | e.fiber in (E26) implies e.ev = {i: range0 | (i.shift0_26) in (e.target.av)}
all e: used | e.fiber in (E27) implies e.ev = {i: range0 | (i.shift0_27) in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range0 | (i.shift0_28) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next0.(child[a].ev))
}
fun range1: set Pos { P0 }
fun loop1: set Pos { P0 }
fun next1: Pos -> Pos { P0->P0 }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { P0->P0 }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in (((((E0 + (E1 + E2)) + ((E3 + E4) + (E5 + E6))) + ((E7 + (E8 + E9)) + ((E10 + E11) + (E12 + E13)))) + (((E14 + (E15 + E16)) + ((E17 + E18) + (E19 + E20))) + (((E21 + E22) + (E23 + E24)) + ((E25 + E26) + (E27 + E28)))))) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next1.(child[a].ev))
}
fun range2: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop2: set Pos { P4 }
fun next2: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift2_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun shift2_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift2_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift2_4: Pos -> Pos { ((P0->P4 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in (E0) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (E1) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range2 | (i.shift2_3) in (e.target.av)}
all e: used | e.fiber in (((((E4 + (E5 + E6)) + (E7 + (E8 + E9))) + ((E10 + (E11 + E12)) + (E13 + (E14 + E15)))) + (((E16 + (E17 + E18)) + (E19 + (E20 + E21))) + ((E22 + (E23 + E24)) + ((E25 + E26) + (E27 + E28)))))) implies e.ev = {i: range2 | (i.shift2_4) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next2.(child[a].ev))
}
fun range3: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop3: set Pos { P3 }
fun next3: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift3_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun shift3_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P3 + P3->P3)) }
fun shift3_3: Pos -> Pos { ((P0->P3 + P1->P3) + (P2->P3 + P3->P3)) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in (E0) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (E1) implies e.ev = {i: range3 | (i.shift3_1) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range3 | (i.shift3_2) in (e.target.av)}
all e: used | e.fiber in (((((E3 + (E4 + E5)) + (E6 + (E7 + E8))) + ((E9 + (E10 + E11)) + ((E12 + E13) + (E14 + E15)))) + (((E16 + (E17 + E18)) + (E19 + (E20 + E21))) + ((E22 + (E23 + E24)) + ((E25 + E26) + (E27 + E28)))))) implies e.ev = {i: range3 | (i.shift3_3) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next3.(child[a].ev))
}
fun range4: set Pos { (P0 + (P1 + P2)) }
fun loop4: set Pos { P2 }
fun next4: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift4_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun shift4_2: Pos -> Pos { (P0->P2 + (P1->P2 + P2->P2)) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in (E0) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in (E1) implies e.ev = {i: range4 | (i.shift4_1) in (e.target.av)}
all e: used | e.fiber in (((((E2 + (E3 + E4)) + (E5 + (E6 + E7))) + ((E8 + (E9 + E10)) + ((E11 + E12) + (E13 + E14)))) + (((E15 + (E16 + E17)) + ((E18 + E19) + (E20 + E21))) + ((E22 + (E23 + E24)) + ((E25 + E26) + (E27 + E28)))))) implies e.ev = {i: range4 | (i.shift4_2) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next4.(child[a].ev))
}
fun range5: set Pos { (P0 + P1) }
fun loop5: set Pos { P1 }
fun next5: Pos -> Pos { (P0->P1 + P1->P1) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift5_1: Pos -> Pos { (P0->P1 + P1->P1) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in (E0) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in (((((E1 + (E2 + E3)) + ((E4 + E5) + (E6 + E7))) + ((E8 + (E9 + E10)) + ((E11 + E12) + (E13 + E14)))) + (((E15 + (E16 + E17)) + ((E18 + E19) + (E20 + E21))) + ((E22 + (E23 + E24)) + ((E25 + E26) + (E27 + E28)))))) implies e.ev = {i: range5 | (i.shift5_1) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next5.(child[a].ev))
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (P28)
(R->P0 in ev0)
semantics0[av1, ev1]
all a: lab.T0 | a.av1 = ((P3 + P28))
(R->P0 in ev1)
semantics0[av2, ev2]
all a: lab.T0 | a.av2 = ((P2 + P28))
(R->P0 in ev2)
semantics0[av3, ev3]
all a: lab.T0 | a.av3 = ((P2 + (P3 + P28)))
(R->P0 in ev3)
semantics0[av4, ev4]
all a: lab.T0 | a.av4 = ((P1 + P28))
(R->P0 in ev4)
semantics0[av5, ev5]
all a: lab.T0 | a.av5 = ((P1 + (P3 + P28)))
(R->P0 in ev5)
semantics0[av6, ev6]
all a: lab.T0 | a.av6 = ((P1 + (P2 + P28)))
(R->P0 in ev6)
semantics0[av7, ev7]
all a: lab.T0 | a.av7 = (((P1 + P2) + (P3 + P28)))
(R->P0 in ev7)
semantics0[av8, ev8]
all a: lab.T0 | a.av8 = ((P0 + P28))
(R->P0 in ev8)
semantics0[av9, ev9]
all a: lab.T0 | a.av9 = ((P0 + (P3 + P28)))
(R->P0 in ev9)
semantics0[av10, ev10]
all a: lab.T0 | a.av10 = ((P0 + (P2 + P28)))
(R->P0 in ev10)
semantics0[av11, ev11]
all a: lab.T0 | a.av11 = (((P0 + P2) + (P3 + P28)))
(R->P0 in ev11)
semantics0[av12, ev12]
all a: lab.T0 | a.av12 = ((P0 + (P1 + P28)))
(R->P0 in ev12)
semantics0[av13, ev13]
all a: lab.T0 | a.av13 = (((P0 + P1) + (P3 + P28)))
(R->P0 in ev13)
semantics0[av14, ev14]
all a: lab.T0 | a.av14 = (((P0 + P1) + (P2 + P28)))
(R->P0 in ev14)
semantics0[av15, ev15]
all a: lab.T0 | a.av15 = (((P0 + P1) + (P2 + (P3 + P28))))
(R->P0 in ev15)
semantics1[av16, ev16]
all a: lab.T0 | a.av16 = (none)
not (R->P0 in ev16)
semantics2[av17, ev17]
all a: lab.T0 | a.av17 = (P3)
not (R->P0 in ev17)
semantics3[av18, ev18]
all a: lab.T0 | a.av18 = (P2)
not (R->P0 in ev18)
semantics2[av19, ev19]
all a: lab.T0 | a.av19 = ((P2 + P3))
not (R->P0 in ev19)
semantics4[av20, ev20]
all a: lab.T0 | a.av20 = (P1)
not (R->P0 in ev20)
semantics2[av21, ev21]
all a: lab.T0 | a.av21 = ((P1 + P3))
not (R->P0 in ev21)
semantics3[av22, ev22]
all a: lab.T0 | a.av22 = ((P1 + P2))
not (R->P0 in ev22)
semantics2[av23, ev23]
all a: lab.T0 | a.av23 = ((P1 + (P2 + P3)))
not (R->P0 in ev23)
semantics5[av24, ev24]
all a: lab.T0 | a.av24 = (P0)
not (R->P0 in ev24)
semantics2[av25, ev25]
all a: lab.T0 | a.av25 = ((P0 + P3))
not (R->P0 in ev25)
semantics3[av26, ev26]
all a: lab.T0 | a.av26 = ((P0 + P2))
not (R->P0 in ev26)
semantics2[av27, ev27]
all a: lab.T0 | a.av27 = ((P0 + (P2 + P3)))
not (R->P0 in ev27)
semantics4[av28, ev28]
all a: lab.T0 | a.av28 = ((P0 + P1))
not (R->P0 in ev28)
semantics2[av29, ev29]
all a: lab.T0 | a.av29 = ((P0 + (P1 + P3)))
not (R->P0 in ev29)
semantics3[av30, ev30]
all a: lab.T0 | a.av30 = ((P0 + (P1 + P2)))
not (R->P0 in ev30)
semantics2[av31, ev31]
all a: lab.T0 | a.av31 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev31)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int


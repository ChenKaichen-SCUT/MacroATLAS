abstract sig Unit {}
one sig U0, U1, U2, U3, U4, U5, U6, U7, U8, U9, U10, U11, U12, U13, U14, U15, U16, U17, U18, U19, U20, U21, U22, U23, U24, U25, U26, U27, U28, U29, U30, U31, U32, U33, U34, U35, U36, U37, U38, U39, U40 extends Unit {}
abstract sig Label {}
one sig T0, T1 extends Label {}
abstract sig Q {}
one sig Q0 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E26, E27, E28, E29, E30, E31, E32, E33, E34, E35, E36, E37, E38, E39, E40 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17, P18, P19, P20, P21, P22, P23, P24, P25, P26, P27, P28, P29, P30, P31, P32, P33, P34, P35, P36, P37, P38, P39, P40, P41 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos, av20: set Pos, av21: set Pos, av22: set Pos, av23: set Pos, av24: set Pos, av25: set Pos, av26: set Pos, av27: set Pos, av28: set Pos, av29: set Pos, av30: set Pos, av31: set Pos }
one sig A0, A1 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos, ev20: set Pos, ev21: set Pos, ev22: set Pos, ev23: set Pos, ev24: set Pos, ev25: set Pos, ev26: set Pos, ev27: set Pos, ev28: set Pos, ev29: set Pos, ev30: set Pos, ev31: set Pos }
one sig R, C0, L0, D0, C1, L1, D1 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { T0 }
fun un: set Label { T1 }
fun bin: set Label { none }
fun nonempty: set Fiber { (((((E1 + E2) + (E3 + (E4 + E5))) + ((E6 + E7) + (E8 + (E9 + E10)))) + (((E11 + E12) + (E13 + (E14 + E15))) + ((E16 + E17) + (E18 + (E19 + E20))))) + ((((E21 + E22) + (E23 + (E24 + E25))) + ((E26 + E27) + (E28 + (E29 + E30)))) + (((E31 + E32) + (E33 + (E34 + E35))) + ((E36 + E37) + (E38 + (E39 + E40)))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { (((((U0->U1 + U1->U2) + (U2->U3 + (U3->U4 + U4->U5))) + ((U5->U6 + U6->U7) + (U7->U8 + (U8->U9 + U9->U10)))) + (((U10->U11 + U11->U12) + (U12->U13 + (U13->U14 + U14->U15))) + ((U15->U16 + U16->U17) + (U17->U18 + (U18->U19 + U19->U20))))) + ((((U20->U21 + U21->U22) + (U22->U23 + (U23->U24 + U24->U25))) + ((U25->U26 + U26->U27) + (U27->U28 + (U28->U29 + U29->U30)))) + (((U30->U31 + U31->U32) + (U32->U33 + (U33->U34 + U34->U35))) + ((U35->U36 + U36->U37) + (U37->U38 + (U38->U39 + U39->U40)))))) }
fun carrierNext: Carrier -> Carrier { (((A0->A1 + A1->R) + (R->C0 + C0->L0)) + ((L0->D0 + D0->C1) + (C1->L1 + L1->D1))) }
fun child[a: Anchor]: set Port { a.((A0->C0 + A1->C1)) }
fun left[a: Anchor]: set Port { a.((A0->L0 + A1->L1)) }
fun right[a: Anchor]: set Port { a.((A0->D0 + A1->D1)) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
#(lab.bin) <= 0
lone lab.T0
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q0
E7.qo = Q0
E8.qi = Q0
E8.qo = Q0
E9.qi = Q0
E9.qo = Q0
E10.qi = Q0
E10.qo = Q0
E11.qi = Q0
E11.qo = Q0
E12.qi = Q0
E12.qo = Q0
E13.qi = Q0
E13.qo = Q0
E14.qi = Q0
E14.qo = Q0
E15.qi = Q0
E15.qo = Q0
E16.qi = Q0
E16.qo = Q0
E17.qi = Q0
E17.qo = Q0
E18.qi = Q0
E18.qo = Q0
E19.qi = Q0
E19.qo = Q0
E20.qi = Q0
E20.qo = Q0
E21.qi = Q0
E21.qo = Q0
E22.qi = Q0
E22.qo = Q0
E23.qi = Q0
E23.qo = Q0
E24.qi = Q0
E24.qo = Q0
E25.qi = Q0
E25.qo = Q0
E26.qi = Q0
E26.qo = Q0
E27.qi = Q0
E27.qo = Q0
E28.qi = Q0
E28.qo = Q0
E29.qi = Q0
E29.qo = Q0
E30.qi = Q0
E30.qo = Q0
E31.qi = Q0
E31.qo = Q0
E32.qi = Q0
E32.qo = Q0
E33.qi = Q0
E33.qo = Q0
E34.qi = Q0
E34.qo = Q0
E35.qi = Q0
E35.qo = Q0
E36.qi = Q0
E36.qo = Q0
E37.qi = Q0
E37.qo = Q0
E38.qi = Q0
E38.qo = Q0
E39.qi = Q0
E39.qo = Q0
E40.qi = Q0
E40.qo = Q0
all e: used | e.fiber in (E0) implies #e.cost = 0
all e: used | e.fiber in (E1) implies #e.cost = 1
all e: used | e.fiber in (E2) implies #e.cost = 2
all e: used | e.fiber in (E3) implies #e.cost = 3
all e: used | e.fiber in (E4) implies #e.cost = 4
all e: used | e.fiber in (E5) implies #e.cost = 5
all e: used | e.fiber in (E6) implies #e.cost = 6
all e: used | e.fiber in (E7) implies #e.cost = 7
all e: used | e.fiber in (E8) implies #e.cost = 8
all e: used | e.fiber in (E9) implies #e.cost = 9
all e: used | e.fiber in (E10) implies #e.cost = 10
all e: used | e.fiber in (E11) implies #e.cost = 11
all e: used | e.fiber in (E12) implies #e.cost = 12
all e: used | e.fiber in (E13) implies #e.cost = 13
all e: used | e.fiber in (E14) implies #e.cost = 14
all e: used | e.fiber in (E15) implies #e.cost = 15
all e: used | e.fiber in (E16) implies #e.cost = 16
all e: used | e.fiber in (E17) implies #e.cost = 17
all e: used | e.fiber in (E18) implies #e.cost = 18
all e: used | e.fiber in (E19) implies #e.cost = 19
all e: used | e.fiber in (E20) implies #e.cost = 20
all e: used | e.fiber in (E21) implies #e.cost = 21
all e: used | e.fiber in (E22) implies #e.cost = 22
all e: used | e.fiber in (E23) implies #e.cost = 23
all e: used | e.fiber in (E24) implies #e.cost = 24
all e: used | e.fiber in (E25) implies #e.cost = 25
all e: used | e.fiber in (E26) implies #e.cost = 26
all e: used | e.fiber in (E27) implies #e.cost = 27
all e: used | e.fiber in (E28) implies #e.cost = 28
all e: used | e.fiber in (E29) implies #e.cost = 29
all e: used | e.fiber in (E30) implies #e.cost = 30
all e: used | e.fiber in (E31) implies #e.cost = 31
all e: used | e.fiber in (E32) implies #e.cost = 32
all e: used | e.fiber in (E33) implies #e.cost = 33
all e: used | e.fiber in (E34) implies #e.cost = 34
all e: used | e.fiber in (E35) implies #e.cost = 35
all e: used | e.fiber in (E36) implies #e.cost = 36
all e: used | e.fiber in (E37) implies #e.cost = 37
all e: used | e.fiber in (E38) implies #e.cost = 38
all e: used | e.fiber in (E39) implies #e.cost = 39
all e: used | e.fiber in (E40) implies #e.cost = 40
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q0)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 and child[a].fiber.qo = Q0 implies a.state = Q0
}
fun range0: set Pos { (((((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) + (((P10 + P11) + (P12 + (P13 + P14))) + ((P15 + (P16 + P17)) + (P18 + (P19 + P20))))) + ((((P21 + P22) + (P23 + (P24 + P25))) + ((P26 + P27) + (P28 + (P29 + P30)))) + (((P31 + P32) + (P33 + (P34 + P35))) + ((P36 + (P37 + P38)) + (P39 + (P40 + P41)))))) }
fun loop0: set Pos { P41 }
fun next0: Pos -> Pos { (((((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P10)))) + (((P10->P11 + P11->P12) + (P12->P13 + (P13->P14 + P14->P15))) + ((P15->P16 + (P16->P17 + P17->P18)) + (P18->P19 + (P19->P20 + P20->P21))))) + ((((P21->P22 + P22->P23) + (P23->P24 + (P24->P25 + P25->P26))) + ((P26->P27 + P27->P28) + (P28->P29 + (P29->P30 + P30->P31)))) + (((P31->P32 + P32->P33) + (P33->P34 + (P34->P35 + P35->P36))) + ((P36->P37 + (P37->P38 + P38->P39)) + (P39->P40 + (P40->P41 + P41->P41)))))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { (((((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) + (((P10->P10 + P11->P11) + (P12->P12 + (P13->P13 + P14->P14))) + ((P15->P15 + (P16->P16 + P17->P17)) + (P18->P18 + (P19->P19 + P20->P20))))) + ((((P21->P21 + P22->P22) + (P23->P23 + (P24->P24 + P25->P25))) + ((P26->P26 + P27->P27) + (P28->P28 + (P29->P29 + P30->P30)))) + (((P31->P31 + P32->P32) + (P33->P33 + (P34->P34 + P35->P35))) + ((P36->P36 + (P37->P37 + P38->P38)) + (P39->P39 + (P40->P40 + P41->P41)))))) }
fun shift0_1: Pos -> Pos { (((((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P10)))) + (((P10->P11 + P11->P12) + (P12->P13 + (P13->P14 + P14->P15))) + ((P15->P16 + (P16->P17 + P17->P18)) + (P18->P19 + (P19->P20 + P20->P21))))) + ((((P21->P22 + P22->P23) + (P23->P24 + (P24->P25 + P25->P26))) + ((P26->P27 + P27->P28) + (P28->P29 + (P29->P30 + P30->P31)))) + (((P31->P32 + P32->P33) + (P33->P34 + (P34->P35 + P35->P36))) + ((P36->P37 + (P37->P38 + P38->P39)) + (P39->P40 + (P40->P41 + P41->P41)))))) }
fun shift0_2: Pos -> Pos { (((((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P10 + P9->P11)))) + (((P10->P12 + P11->P13) + (P12->P14 + (P13->P15 + P14->P16))) + ((P15->P17 + (P16->P18 + P17->P19)) + (P18->P20 + (P19->P21 + P20->P22))))) + ((((P21->P23 + P22->P24) + (P23->P25 + (P24->P26 + P25->P27))) + ((P26->P28 + P27->P29) + (P28->P30 + (P29->P31 + P30->P32)))) + (((P31->P33 + P32->P34) + (P33->P35 + (P34->P36 + P35->P37))) + ((P36->P38 + (P37->P39 + P38->P40)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_3: Pos -> Pos { (((((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P10 + (P8->P11 + P9->P12)))) + (((P10->P13 + P11->P14) + (P12->P15 + (P13->P16 + P14->P17))) + ((P15->P18 + (P16->P19 + P17->P20)) + (P18->P21 + (P19->P22 + P20->P23))))) + ((((P21->P24 + P22->P25) + (P23->P26 + (P24->P27 + P25->P28))) + ((P26->P29 + P27->P30) + (P28->P31 + (P29->P32 + P30->P33)))) + (((P31->P34 + P32->P35) + (P33->P36 + (P34->P37 + P35->P38))) + ((P36->P39 + (P37->P40 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_4: Pos -> Pos { (((((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P10) + (P7->P11 + (P8->P12 + P9->P13)))) + (((P10->P14 + P11->P15) + (P12->P16 + (P13->P17 + P14->P18))) + ((P15->P19 + (P16->P20 + P17->P21)) + (P18->P22 + (P19->P23 + P20->P24))))) + ((((P21->P25 + P22->P26) + (P23->P27 + (P24->P28 + P25->P29))) + ((P26->P30 + P27->P31) + (P28->P32 + (P29->P33 + P30->P34)))) + (((P31->P35 + P32->P36) + (P33->P37 + (P34->P38 + P35->P39))) + ((P36->P40 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_5: Pos -> Pos { (((((P0->P5 + P1->P6) + (P2->P7 + (P3->P8 + P4->P9))) + ((P5->P10 + P6->P11) + (P7->P12 + (P8->P13 + P9->P14)))) + (((P10->P15 + P11->P16) + (P12->P17 + (P13->P18 + P14->P19))) + ((P15->P20 + (P16->P21 + P17->P22)) + (P18->P23 + (P19->P24 + P20->P25))))) + ((((P21->P26 + P22->P27) + (P23->P28 + (P24->P29 + P25->P30))) + ((P26->P31 + P27->P32) + (P28->P33 + (P29->P34 + P30->P35)))) + (((P31->P36 + P32->P37) + (P33->P38 + (P34->P39 + P35->P40))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_6: Pos -> Pos { (((((P0->P6 + P1->P7) + (P2->P8 + (P3->P9 + P4->P10))) + ((P5->P11 + P6->P12) + (P7->P13 + (P8->P14 + P9->P15)))) + (((P10->P16 + P11->P17) + (P12->P18 + (P13->P19 + P14->P20))) + ((P15->P21 + (P16->P22 + P17->P23)) + (P18->P24 + (P19->P25 + P20->P26))))) + ((((P21->P27 + P22->P28) + (P23->P29 + (P24->P30 + P25->P31))) + ((P26->P32 + P27->P33) + (P28->P34 + (P29->P35 + P30->P36)))) + (((P31->P37 + P32->P38) + (P33->P39 + (P34->P40 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_7: Pos -> Pos { (((((P0->P7 + P1->P8) + (P2->P9 + (P3->P10 + P4->P11))) + ((P5->P12 + P6->P13) + (P7->P14 + (P8->P15 + P9->P16)))) + (((P10->P17 + P11->P18) + (P12->P19 + (P13->P20 + P14->P21))) + ((P15->P22 + (P16->P23 + P17->P24)) + (P18->P25 + (P19->P26 + P20->P27))))) + ((((P21->P28 + P22->P29) + (P23->P30 + (P24->P31 + P25->P32))) + ((P26->P33 + P27->P34) + (P28->P35 + (P29->P36 + P30->P37)))) + (((P31->P38 + P32->P39) + (P33->P40 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_8: Pos -> Pos { (((((P0->P8 + P1->P9) + (P2->P10 + (P3->P11 + P4->P12))) + ((P5->P13 + P6->P14) + (P7->P15 + (P8->P16 + P9->P17)))) + (((P10->P18 + P11->P19) + (P12->P20 + (P13->P21 + P14->P22))) + ((P15->P23 + (P16->P24 + P17->P25)) + (P18->P26 + (P19->P27 + P20->P28))))) + ((((P21->P29 + P22->P30) + (P23->P31 + (P24->P32 + P25->P33))) + ((P26->P34 + P27->P35) + (P28->P36 + (P29->P37 + P30->P38)))) + (((P31->P39 + P32->P40) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_9: Pos -> Pos { (((((P0->P9 + P1->P10) + (P2->P11 + (P3->P12 + P4->P13))) + ((P5->P14 + P6->P15) + (P7->P16 + (P8->P17 + P9->P18)))) + (((P10->P19 + P11->P20) + (P12->P21 + (P13->P22 + P14->P23))) + ((P15->P24 + (P16->P25 + P17->P26)) + (P18->P27 + (P19->P28 + P20->P29))))) + ((((P21->P30 + P22->P31) + (P23->P32 + (P24->P33 + P25->P34))) + ((P26->P35 + P27->P36) + (P28->P37 + (P29->P38 + P30->P39)))) + (((P31->P40 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_10: Pos -> Pos { (((((P0->P10 + P1->P11) + (P2->P12 + (P3->P13 + P4->P14))) + ((P5->P15 + P6->P16) + (P7->P17 + (P8->P18 + P9->P19)))) + (((P10->P20 + P11->P21) + (P12->P22 + (P13->P23 + P14->P24))) + ((P15->P25 + (P16->P26 + P17->P27)) + (P18->P28 + (P19->P29 + P20->P30))))) + ((((P21->P31 + P22->P32) + (P23->P33 + (P24->P34 + P25->P35))) + ((P26->P36 + P27->P37) + (P28->P38 + (P29->P39 + P30->P40)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_11: Pos -> Pos { (((((P0->P11 + P1->P12) + (P2->P13 + (P3->P14 + P4->P15))) + ((P5->P16 + P6->P17) + (P7->P18 + (P8->P19 + P9->P20)))) + (((P10->P21 + P11->P22) + (P12->P23 + (P13->P24 + P14->P25))) + ((P15->P26 + (P16->P27 + P17->P28)) + (P18->P29 + (P19->P30 + P20->P31))))) + ((((P21->P32 + P22->P33) + (P23->P34 + (P24->P35 + P25->P36))) + ((P26->P37 + P27->P38) + (P28->P39 + (P29->P40 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_12: Pos -> Pos { (((((P0->P12 + P1->P13) + (P2->P14 + (P3->P15 + P4->P16))) + ((P5->P17 + P6->P18) + (P7->P19 + (P8->P20 + P9->P21)))) + (((P10->P22 + P11->P23) + (P12->P24 + (P13->P25 + P14->P26))) + ((P15->P27 + (P16->P28 + P17->P29)) + (P18->P30 + (P19->P31 + P20->P32))))) + ((((P21->P33 + P22->P34) + (P23->P35 + (P24->P36 + P25->P37))) + ((P26->P38 + P27->P39) + (P28->P40 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_13: Pos -> Pos { (((((P0->P13 + P1->P14) + (P2->P15 + (P3->P16 + P4->P17))) + ((P5->P18 + P6->P19) + (P7->P20 + (P8->P21 + P9->P22)))) + (((P10->P23 + P11->P24) + (P12->P25 + (P13->P26 + P14->P27))) + ((P15->P28 + (P16->P29 + P17->P30)) + (P18->P31 + (P19->P32 + P20->P33))))) + ((((P21->P34 + P22->P35) + (P23->P36 + (P24->P37 + P25->P38))) + ((P26->P39 + P27->P40) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_14: Pos -> Pos { (((((P0->P14 + P1->P15) + (P2->P16 + (P3->P17 + P4->P18))) + ((P5->P19 + P6->P20) + (P7->P21 + (P8->P22 + P9->P23)))) + (((P10->P24 + P11->P25) + (P12->P26 + (P13->P27 + P14->P28))) + ((P15->P29 + (P16->P30 + P17->P31)) + (P18->P32 + (P19->P33 + P20->P34))))) + ((((P21->P35 + P22->P36) + (P23->P37 + (P24->P38 + P25->P39))) + ((P26->P40 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_15: Pos -> Pos { (((((P0->P15 + P1->P16) + (P2->P17 + (P3->P18 + P4->P19))) + ((P5->P20 + P6->P21) + (P7->P22 + (P8->P23 + P9->P24)))) + (((P10->P25 + P11->P26) + (P12->P27 + (P13->P28 + P14->P29))) + ((P15->P30 + (P16->P31 + P17->P32)) + (P18->P33 + (P19->P34 + P20->P35))))) + ((((P21->P36 + P22->P37) + (P23->P38 + (P24->P39 + P25->P40))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_16: Pos -> Pos { (((((P0->P16 + P1->P17) + (P2->P18 + (P3->P19 + P4->P20))) + ((P5->P21 + P6->P22) + (P7->P23 + (P8->P24 + P9->P25)))) + (((P10->P26 + P11->P27) + (P12->P28 + (P13->P29 + P14->P30))) + ((P15->P31 + (P16->P32 + P17->P33)) + (P18->P34 + (P19->P35 + P20->P36))))) + ((((P21->P37 + P22->P38) + (P23->P39 + (P24->P40 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_17: Pos -> Pos { (((((P0->P17 + P1->P18) + (P2->P19 + (P3->P20 + P4->P21))) + ((P5->P22 + P6->P23) + (P7->P24 + (P8->P25 + P9->P26)))) + (((P10->P27 + P11->P28) + (P12->P29 + (P13->P30 + P14->P31))) + ((P15->P32 + (P16->P33 + P17->P34)) + (P18->P35 + (P19->P36 + P20->P37))))) + ((((P21->P38 + P22->P39) + (P23->P40 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_18: Pos -> Pos { (((((P0->P18 + P1->P19) + (P2->P20 + (P3->P21 + P4->P22))) + ((P5->P23 + P6->P24) + (P7->P25 + (P8->P26 + P9->P27)))) + (((P10->P28 + P11->P29) + (P12->P30 + (P13->P31 + P14->P32))) + ((P15->P33 + (P16->P34 + P17->P35)) + (P18->P36 + (P19->P37 + P20->P38))))) + ((((P21->P39 + P22->P40) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_19: Pos -> Pos { (((((P0->P19 + P1->P20) + (P2->P21 + (P3->P22 + P4->P23))) + ((P5->P24 + P6->P25) + (P7->P26 + (P8->P27 + P9->P28)))) + (((P10->P29 + P11->P30) + (P12->P31 + (P13->P32 + P14->P33))) + ((P15->P34 + (P16->P35 + P17->P36)) + (P18->P37 + (P19->P38 + P20->P39))))) + ((((P21->P40 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_20: Pos -> Pos { (((((P0->P20 + P1->P21) + (P2->P22 + (P3->P23 + P4->P24))) + ((P5->P25 + P6->P26) + (P7->P27 + (P8->P28 + P9->P29)))) + (((P10->P30 + P11->P31) + (P12->P32 + (P13->P33 + P14->P34))) + ((P15->P35 + (P16->P36 + P17->P37)) + (P18->P38 + (P19->P39 + P20->P40))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_21: Pos -> Pos { (((((P0->P21 + P1->P22) + (P2->P23 + (P3->P24 + P4->P25))) + ((P5->P26 + P6->P27) + (P7->P28 + (P8->P29 + P9->P30)))) + (((P10->P31 + P11->P32) + (P12->P33 + (P13->P34 + P14->P35))) + ((P15->P36 + (P16->P37 + P17->P38)) + (P18->P39 + (P19->P40 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_22: Pos -> Pos { (((((P0->P22 + P1->P23) + (P2->P24 + (P3->P25 + P4->P26))) + ((P5->P27 + P6->P28) + (P7->P29 + (P8->P30 + P9->P31)))) + (((P10->P32 + P11->P33) + (P12->P34 + (P13->P35 + P14->P36))) + ((P15->P37 + (P16->P38 + P17->P39)) + (P18->P40 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_23: Pos -> Pos { (((((P0->P23 + P1->P24) + (P2->P25 + (P3->P26 + P4->P27))) + ((P5->P28 + P6->P29) + (P7->P30 + (P8->P31 + P9->P32)))) + (((P10->P33 + P11->P34) + (P12->P35 + (P13->P36 + P14->P37))) + ((P15->P38 + (P16->P39 + P17->P40)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_24: Pos -> Pos { (((((P0->P24 + P1->P25) + (P2->P26 + (P3->P27 + P4->P28))) + ((P5->P29 + P6->P30) + (P7->P31 + (P8->P32 + P9->P33)))) + (((P10->P34 + P11->P35) + (P12->P36 + (P13->P37 + P14->P38))) + ((P15->P39 + (P16->P40 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_25: Pos -> Pos { (((((P0->P25 + P1->P26) + (P2->P27 + (P3->P28 + P4->P29))) + ((P5->P30 + P6->P31) + (P7->P32 + (P8->P33 + P9->P34)))) + (((P10->P35 + P11->P36) + (P12->P37 + (P13->P38 + P14->P39))) + ((P15->P40 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_26: Pos -> Pos { (((((P0->P26 + P1->P27) + (P2->P28 + (P3->P29 + P4->P30))) + ((P5->P31 + P6->P32) + (P7->P33 + (P8->P34 + P9->P35)))) + (((P10->P36 + P11->P37) + (P12->P38 + (P13->P39 + P14->P40))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_27: Pos -> Pos { (((((P0->P27 + P1->P28) + (P2->P29 + (P3->P30 + P4->P31))) + ((P5->P32 + P6->P33) + (P7->P34 + (P8->P35 + P9->P36)))) + (((P10->P37 + P11->P38) + (P12->P39 + (P13->P40 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_28: Pos -> Pos { (((((P0->P28 + P1->P29) + (P2->P30 + (P3->P31 + P4->P32))) + ((P5->P33 + P6->P34) + (P7->P35 + (P8->P36 + P9->P37)))) + (((P10->P38 + P11->P39) + (P12->P40 + (P13->P41 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_29: Pos -> Pos { (((((P0->P29 + P1->P30) + (P2->P31 + (P3->P32 + P4->P33))) + ((P5->P34 + P6->P35) + (P7->P36 + (P8->P37 + P9->P38)))) + (((P10->P39 + P11->P40) + (P12->P41 + (P13->P41 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_30: Pos -> Pos { (((((P0->P30 + P1->P31) + (P2->P32 + (P3->P33 + P4->P34))) + ((P5->P35 + P6->P36) + (P7->P37 + (P8->P38 + P9->P39)))) + (((P10->P40 + P11->P41) + (P12->P41 + (P13->P41 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_31: Pos -> Pos { (((((P0->P31 + P1->P32) + (P2->P33 + (P3->P34 + P4->P35))) + ((P5->P36 + P6->P37) + (P7->P38 + (P8->P39 + P9->P40)))) + (((P10->P41 + P11->P41) + (P12->P41 + (P13->P41 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_32: Pos -> Pos { (((((P0->P32 + P1->P33) + (P2->P34 + (P3->P35 + P4->P36))) + ((P5->P37 + P6->P38) + (P7->P39 + (P8->P40 + P9->P41)))) + (((P10->P41 + P11->P41) + (P12->P41 + (P13->P41 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_33: Pos -> Pos { (((((P0->P33 + P1->P34) + (P2->P35 + (P3->P36 + P4->P37))) + ((P5->P38 + P6->P39) + (P7->P40 + (P8->P41 + P9->P41)))) + (((P10->P41 + P11->P41) + (P12->P41 + (P13->P41 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_34: Pos -> Pos { (((((P0->P34 + P1->P35) + (P2->P36 + (P3->P37 + P4->P38))) + ((P5->P39 + P6->P40) + (P7->P41 + (P8->P41 + P9->P41)))) + (((P10->P41 + P11->P41) + (P12->P41 + (P13->P41 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_35: Pos -> Pos { (((((P0->P35 + P1->P36) + (P2->P37 + (P3->P38 + P4->P39))) + ((P5->P40 + P6->P41) + (P7->P41 + (P8->P41 + P9->P41)))) + (((P10->P41 + P11->P41) + (P12->P41 + (P13->P41 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_36: Pos -> Pos { (((((P0->P36 + P1->P37) + (P2->P38 + (P3->P39 + P4->P40))) + ((P5->P41 + P6->P41) + (P7->P41 + (P8->P41 + P9->P41)))) + (((P10->P41 + P11->P41) + (P12->P41 + (P13->P41 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_37: Pos -> Pos { (((((P0->P37 + P1->P38) + (P2->P39 + (P3->P40 + P4->P41))) + ((P5->P41 + P6->P41) + (P7->P41 + (P8->P41 + P9->P41)))) + (((P10->P41 + P11->P41) + (P12->P41 + (P13->P41 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_38: Pos -> Pos { (((((P0->P38 + P1->P39) + (P2->P40 + (P3->P41 + P4->P41))) + ((P5->P41 + P6->P41) + (P7->P41 + (P8->P41 + P9->P41)))) + (((P10->P41 + P11->P41) + (P12->P41 + (P13->P41 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_39: Pos -> Pos { (((((P0->P39 + P1->P40) + (P2->P41 + (P3->P41 + P4->P41))) + ((P5->P41 + P6->P41) + (P7->P41 + (P8->P41 + P9->P41)))) + (((P10->P41 + P11->P41) + (P12->P41 + (P13->P41 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
fun shift0_40: Pos -> Pos { (((((P0->P40 + P1->P41) + (P2->P41 + (P3->P41 + P4->P41))) + ((P5->P41 + P6->P41) + (P7->P41 + (P8->P41 + P9->P41)))) + (((P10->P41 + P11->P41) + (P12->P41 + (P13->P41 + P14->P41))) + ((P15->P41 + (P16->P41 + P17->P41)) + (P18->P41 + (P19->P41 + P20->P41))))) + ((((P21->P41 + P22->P41) + (P23->P41 + (P24->P41 + P25->P41))) + ((P26->P41 + P27->P41) + (P28->P41 + (P29->P41 + P30->P41)))) + (((P31->P41 + P32->P41) + (P33->P41 + (P34->P41 + P35->P41))) + ((P36->P41 + (P37->P41 + P38->P41)) + (P39->P41 + (P40->P41 + P41->P41)))))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in (E0) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (E1) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range0 | (i.shift0_3) in (e.target.av)}
all e: used | e.fiber in (E4) implies e.ev = {i: range0 | (i.shift0_4) in (e.target.av)}
all e: used | e.fiber in (E5) implies e.ev = {i: range0 | (i.shift0_5) in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range0 | (i.shift0_6) in (e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range0 | (i.shift0_7) in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range0 | (i.shift0_8) in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range0 | (i.shift0_9) in (e.target.av)}
all e: used | e.fiber in (E10) implies e.ev = {i: range0 | (i.shift0_10) in (e.target.av)}
all e: used | e.fiber in (E11) implies e.ev = {i: range0 | (i.shift0_11) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range0 | (i.shift0_12) in (e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range0 | (i.shift0_13) in (e.target.av)}
all e: used | e.fiber in (E14) implies e.ev = {i: range0 | (i.shift0_14) in (e.target.av)}
all e: used | e.fiber in (E15) implies e.ev = {i: range0 | (i.shift0_15) in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range0 | (i.shift0_16) in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range0 | (i.shift0_17) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range0 | (i.shift0_18) in (e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range0 | (i.shift0_19) in (e.target.av)}
all e: used | e.fiber in (E20) implies e.ev = {i: range0 | (i.shift0_20) in (e.target.av)}
all e: used | e.fiber in (E21) implies e.ev = {i: range0 | (i.shift0_21) in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range0 | (i.shift0_22) in (e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range0 | (i.shift0_23) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range0 | (i.shift0_24) in (e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range0 | (i.shift0_25) in (e.target.av)}
all e: used | e.fiber in (E26) implies e.ev = {i: range0 | (i.shift0_26) in (e.target.av)}
all e: used | e.fiber in (E27) implies e.ev = {i: range0 | (i.shift0_27) in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range0 | (i.shift0_28) in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range0 | (i.shift0_29) in (e.target.av)}
all e: used | e.fiber in (E30) implies e.ev = {i: range0 | (i.shift0_30) in (e.target.av)}
all e: used | e.fiber in (E31) implies e.ev = {i: range0 | (i.shift0_31) in (e.target.av)}
all e: used | e.fiber in (E32) implies e.ev = {i: range0 | (i.shift0_32) in (e.target.av)}
all e: used | e.fiber in (E33) implies e.ev = {i: range0 | (i.shift0_33) in (e.target.av)}
all e: used | e.fiber in (E34) implies e.ev = {i: range0 | (i.shift0_34) in (e.target.av)}
all e: used | e.fiber in (E35) implies e.ev = {i: range0 | (i.shift0_35) in (e.target.av)}
all e: used | e.fiber in (E36) implies e.ev = {i: range0 | (i.shift0_36) in (e.target.av)}
all e: used | e.fiber in (E37) implies e.ev = {i: range0 | (i.shift0_37) in (e.target.av)}
all e: used | e.fiber in (E38) implies e.ev = {i: range0 | (i.shift0_38) in (e.target.av)}
all e: used | e.fiber in (E39) implies e.ev = {i: range0 | (i.shift0_39) in (e.target.av)}
all e: used | e.fiber in (E40) implies e.ev = {i: range0 | (i.shift0_40) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next0.(child[a].ev))
}
fun range1: set Pos { P0 }
fun loop1: set Pos { P0 }
fun next1: Pos -> Pos { P0->P0 }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { P0->P0 }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in ((((((E0 + E1) + (E2 + (E3 + E4))) + ((E5 + E6) + (E7 + (E8 + E9)))) + (((E10 + E11) + (E12 + (E13 + E14))) + ((E15 + E16) + (E17 + (E18 + E19))))) + ((((E20 + E21) + (E22 + (E23 + E24))) + ((E25 + E26) + (E27 + (E28 + E29)))) + (((E30 + E31) + (E32 + (E33 + E34))) + ((E35 + (E36 + E37)) + (E38 + (E39 + E40))))))) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next1.(child[a].ev))
}
fun range2: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop2: set Pos { P4 }
fun next2: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift2_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun shift2_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift2_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift2_4: Pos -> Pos { ((P0->P4 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in (E0) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (E1) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range2 | (i.shift2_3) in (e.target.av)}
all e: used | e.fiber in ((((((E4 + E5) + (E6 + E7)) + ((E8 + E9) + (E10 + (E11 + E12)))) + (((E13 + E14) + (E15 + E16)) + ((E17 + E18) + (E19 + (E20 + E21))))) + ((((E22 + E23) + (E24 + E25)) + ((E26 + E27) + (E28 + (E29 + E30)))) + (((E31 + E32) + (E33 + (E34 + E35))) + ((E36 + E37) + (E38 + (E39 + E40))))))) implies e.ev = {i: range2 | (i.shift2_4) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next2.(child[a].ev))
}
fun range3: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop3: set Pos { P3 }
fun next3: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift3_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun shift3_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P3 + P3->P3)) }
fun shift3_3: Pos -> Pos { ((P0->P3 + P1->P3) + (P2->P3 + P3->P3)) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in (E0) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (E1) implies e.ev = {i: range3 | (i.shift3_1) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range3 | (i.shift3_2) in (e.target.av)}
all e: used | e.fiber in ((((((E3 + E4) + (E5 + E6)) + ((E7 + E8) + (E9 + (E10 + E11)))) + (((E12 + E13) + (E14 + (E15 + E16))) + ((E17 + E18) + (E19 + (E20 + E21))))) + ((((E22 + E23) + (E24 + E25)) + ((E26 + E27) + (E28 + (E29 + E30)))) + (((E31 + E32) + (E33 + (E34 + E35))) + ((E36 + E37) + (E38 + (E39 + E40))))))) implies e.ev = {i: range3 | (i.shift3_3) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next3.(child[a].ev))
}
fun range4: set Pos { (P0 + (P1 + P2)) }
fun loop4: set Pos { P2 }
fun next4: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift4_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun shift4_2: Pos -> Pos { (P0->P2 + (P1->P2 + P2->P2)) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in (E0) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in (E1) implies e.ev = {i: range4 | (i.shift4_1) in (e.target.av)}
all e: used | e.fiber in ((((((E2 + E3) + (E4 + E5)) + ((E6 + E7) + (E8 + (E9 + E10)))) + (((E11 + E12) + (E13 + (E14 + E15))) + ((E16 + E17) + (E18 + (E19 + E20))))) + ((((E21 + E22) + (E23 + (E24 + E25))) + ((E26 + E27) + (E28 + (E29 + E30)))) + (((E31 + E32) + (E33 + (E34 + E35))) + ((E36 + E37) + (E38 + (E39 + E40))))))) implies e.ev = {i: range4 | (i.shift4_2) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next4.(child[a].ev))
}
fun range5: set Pos { (P0 + P1) }
fun loop5: set Pos { P1 }
fun next5: Pos -> Pos { (P0->P1 + P1->P1) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift5_1: Pos -> Pos { (P0->P1 + P1->P1) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in (E0) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in ((((((E1 + E2) + (E3 + (E4 + E5))) + ((E6 + E7) + (E8 + (E9 + E10)))) + (((E11 + E12) + (E13 + (E14 + E15))) + ((E16 + E17) + (E18 + (E19 + E20))))) + ((((E21 + E22) + (E23 + (E24 + E25))) + ((E26 + E27) + (E28 + (E29 + E30)))) + (((E31 + E32) + (E33 + (E34 + E35))) + ((E36 + E37) + (E38 + (E39 + E40))))))) implies e.ev = {i: range5 | (i.shift5_1) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next5.(child[a].ev))
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (P40)
(R->P0 in ev0)
semantics0[av1, ev1]
all a: lab.T0 | a.av1 = ((P3 + P40))
(R->P0 in ev1)
semantics0[av2, ev2]
all a: lab.T0 | a.av2 = ((P2 + P40))
(R->P0 in ev2)
semantics0[av3, ev3]
all a: lab.T0 | a.av3 = ((P2 + (P3 + P40)))
(R->P0 in ev3)
semantics0[av4, ev4]
all a: lab.T0 | a.av4 = ((P1 + P40))
(R->P0 in ev4)
semantics0[av5, ev5]
all a: lab.T0 | a.av5 = ((P1 + (P3 + P40)))
(R->P0 in ev5)
semantics0[av6, ev6]
all a: lab.T0 | a.av6 = ((P1 + (P2 + P40)))
(R->P0 in ev6)
semantics0[av7, ev7]
all a: lab.T0 | a.av7 = (((P1 + P2) + (P3 + P40)))
(R->P0 in ev7)
semantics0[av8, ev8]
all a: lab.T0 | a.av8 = ((P0 + P40))
(R->P0 in ev8)
semantics0[av9, ev9]
all a: lab.T0 | a.av9 = ((P0 + (P3 + P40)))
(R->P0 in ev9)
semantics0[av10, ev10]
all a: lab.T0 | a.av10 = ((P0 + (P2 + P40)))
(R->P0 in ev10)
semantics0[av11, ev11]
all a: lab.T0 | a.av11 = (((P0 + P2) + (P3 + P40)))
(R->P0 in ev11)
semantics0[av12, ev12]
all a: lab.T0 | a.av12 = ((P0 + (P1 + P40)))
(R->P0 in ev12)
semantics0[av13, ev13]
all a: lab.T0 | a.av13 = (((P0 + P1) + (P3 + P40)))
(R->P0 in ev13)
semantics0[av14, ev14]
all a: lab.T0 | a.av14 = (((P0 + P1) + (P2 + P40)))
(R->P0 in ev14)
semantics0[av15, ev15]
all a: lab.T0 | a.av15 = (((P0 + P1) + (P2 + (P3 + P40))))
(R->P0 in ev15)
semantics1[av16, ev16]
all a: lab.T0 | a.av16 = (none)
not (R->P0 in ev16)
semantics2[av17, ev17]
all a: lab.T0 | a.av17 = (P3)
not (R->P0 in ev17)
semantics3[av18, ev18]
all a: lab.T0 | a.av18 = (P2)
not (R->P0 in ev18)
semantics2[av19, ev19]
all a: lab.T0 | a.av19 = ((P2 + P3))
not (R->P0 in ev19)
semantics4[av20, ev20]
all a: lab.T0 | a.av20 = (P1)
not (R->P0 in ev20)
semantics2[av21, ev21]
all a: lab.T0 | a.av21 = ((P1 + P3))
not (R->P0 in ev21)
semantics3[av22, ev22]
all a: lab.T0 | a.av22 = ((P1 + P2))
not (R->P0 in ev22)
semantics2[av23, ev23]
all a: lab.T0 | a.av23 = ((P1 + (P2 + P3)))
not (R->P0 in ev23)
semantics5[av24, ev24]
all a: lab.T0 | a.av24 = (P0)
not (R->P0 in ev24)
semantics2[av25, ev25]
all a: lab.T0 | a.av25 = ((P0 + P3))
not (R->P0 in ev25)
semantics3[av26, ev26]
all a: lab.T0 | a.av26 = ((P0 + P2))
not (R->P0 in ev26)
semantics2[av27, ev27]
all a: lab.T0 | a.av27 = ((P0 + (P2 + P3)))
not (R->P0 in ev27)
semantics4[av28, ev28]
all a: lab.T0 | a.av28 = ((P0 + P1))
not (R->P0 in ev28)
semantics2[av29, ev29]
all a: lab.T0 | a.av29 = ((P0 + (P1 + P3)))
not (R->P0 in ev29)
semantics3[av30, ev30]
all a: lab.T0 | a.av30 = ((P0 + (P1 + P2)))
not (R->P0 in ev30)
semantics2[av31, ev31]
all a: lab.T0 | a.av31 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev31)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 7 Int


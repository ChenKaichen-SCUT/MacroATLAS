abstract sig Unit {}
one sig U0, U1, U2, U3, U4, U5, U6, U7, U8, U9, U10 extends Unit {}
abstract sig Label {}
one sig T0, T1 extends Label {}
abstract sig Q {}
one sig Q0 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos, av20: set Pos, av21: set Pos, av22: set Pos, av23: set Pos, av24: set Pos, av25: set Pos, av26: set Pos, av27: set Pos, av28: set Pos, av29: set Pos, av30: set Pos, av31: set Pos }
one sig A0, A1 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos, ev20: set Pos, ev21: set Pos, ev22: set Pos, ev23: set Pos, ev24: set Pos, ev25: set Pos, ev26: set Pos, ev27: set Pos, ev28: set Pos, ev29: set Pos, ev30: set Pos, ev31: set Pos }
one sig R, C0, L0, D0, C1, L1, D1 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { T0 }
fun un: set Label { T1 }
fun bin: set Label { none }
fun nonempty: set Fiber { (((E1 + E2) + (E3 + (E4 + E5))) + ((E6 + E7) + (E8 + (E9 + E10)))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { (((U0->U1 + U1->U2) + (U2->U3 + (U3->U4 + U4->U5))) + ((U5->U6 + U6->U7) + (U7->U8 + (U8->U9 + U9->U10)))) }
fun carrierNext: Carrier -> Carrier { (((A0->A1 + A1->R) + (R->C0 + C0->L0)) + ((L0->D0 + D0->C1) + (C1->L1 + L1->D1))) }
fun child[a: Anchor]: set Port { a.((A0->C0 + A1->C1)) }
fun left[a: Anchor]: set Port { a.((A0->L0 + A1->L1)) }
fun right[a: Anchor]: set Port { a.((A0->D0 + A1->D1)) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
#(lab.bin) <= 0
lone lab.T0
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q0
E7.qo = Q0
E8.qi = Q0
E8.qo = Q0
E9.qi = Q0
E9.qo = Q0
E10.qi = Q0
E10.qo = Q0
all e: used | e.fiber in (E0) implies #e.cost = 0
all e: used | e.fiber in (E1) implies #e.cost = 1
all e: used | e.fiber in (E2) implies #e.cost = 2
all e: used | e.fiber in (E3) implies #e.cost = 3
all e: used | e.fiber in (E4) implies #e.cost = 4
all e: used | e.fiber in (E5) implies #e.cost = 5
all e: used | e.fiber in (E6) implies #e.cost = 6
all e: used | e.fiber in (E7) implies #e.cost = 7
all e: used | e.fiber in (E8) implies #e.cost = 8
all e: used | e.fiber in (E9) implies #e.cost = 9
all e: used | e.fiber in (E10) implies #e.cost = 10
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q0)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 and child[a].fiber.qo = Q0 implies a.state = Q0
}
fun range0: set Pos { (((P0 + (P1 + P2)) + (P3 + (P4 + P5))) + ((P6 + (P7 + P8)) + (P9 + (P10 + P11)))) }
fun loop0: set Pos { P11 }
fun next0: Pos -> Pos { (((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P6))) + ((P6->P7 + (P7->P8 + P8->P9)) + (P9->P10 + (P10->P11 + P11->P11)))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { (((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) + ((P6->P6 + (P7->P7 + P8->P8)) + (P9->P9 + (P10->P10 + P11->P11)))) }
fun shift0_1: Pos -> Pos { (((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P6))) + ((P6->P7 + (P7->P8 + P8->P9)) + (P9->P10 + (P10->P11 + P11->P11)))) }
fun shift0_2: Pos -> Pos { (((P0->P2 + (P1->P3 + P2->P4)) + (P3->P5 + (P4->P6 + P5->P7))) + ((P6->P8 + (P7->P9 + P8->P10)) + (P9->P11 + (P10->P11 + P11->P11)))) }
fun shift0_3: Pos -> Pos { (((P0->P3 + (P1->P4 + P2->P5)) + (P3->P6 + (P4->P7 + P5->P8))) + ((P6->P9 + (P7->P10 + P8->P11)) + (P9->P11 + (P10->P11 + P11->P11)))) }
fun shift0_4: Pos -> Pos { (((P0->P4 + (P1->P5 + P2->P6)) + (P3->P7 + (P4->P8 + P5->P9))) + ((P6->P10 + (P7->P11 + P8->P11)) + (P9->P11 + (P10->P11 + P11->P11)))) }
fun shift0_5: Pos -> Pos { (((P0->P5 + (P1->P6 + P2->P7)) + (P3->P8 + (P4->P9 + P5->P10))) + ((P6->P11 + (P7->P11 + P8->P11)) + (P9->P11 + (P10->P11 + P11->P11)))) }
fun shift0_6: Pos -> Pos { (((P0->P6 + (P1->P7 + P2->P8)) + (P3->P9 + (P4->P10 + P5->P11))) + ((P6->P11 + (P7->P11 + P8->P11)) + (P9->P11 + (P10->P11 + P11->P11)))) }
fun shift0_7: Pos -> Pos { (((P0->P7 + (P1->P8 + P2->P9)) + (P3->P10 + (P4->P11 + P5->P11))) + ((P6->P11 + (P7->P11 + P8->P11)) + (P9->P11 + (P10->P11 + P11->P11)))) }
fun shift0_8: Pos -> Pos { (((P0->P8 + (P1->P9 + P2->P10)) + (P3->P11 + (P4->P11 + P5->P11))) + ((P6->P11 + (P7->P11 + P8->P11)) + (P9->P11 + (P10->P11 + P11->P11)))) }
fun shift0_9: Pos -> Pos { (((P0->P9 + (P1->P10 + P2->P11)) + (P3->P11 + (P4->P11 + P5->P11))) + ((P6->P11 + (P7->P11 + P8->P11)) + (P9->P11 + (P10->P11 + P11->P11)))) }
fun shift0_10: Pos -> Pos { (((P0->P10 + (P1->P11 + P2->P11)) + (P3->P11 + (P4->P11 + P5->P11))) + ((P6->P11 + (P7->P11 + P8->P11)) + (P9->P11 + (P10->P11 + P11->P11)))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in (E0) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (E1) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range0 | (i.shift0_3) in (e.target.av)}
all e: used | e.fiber in (E4) implies e.ev = {i: range0 | (i.shift0_4) in (e.target.av)}
all e: used | e.fiber in (E5) implies e.ev = {i: range0 | (i.shift0_5) in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range0 | (i.shift0_6) in (e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range0 | (i.shift0_7) in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range0 | (i.shift0_8) in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range0 | (i.shift0_9) in (e.target.av)}
all e: used | e.fiber in (E10) implies e.ev = {i: range0 | (i.shift0_10) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next0.(child[a].ev))
}
fun range1: set Pos { P0 }
fun loop1: set Pos { P0 }
fun next1: Pos -> Pos { P0->P0 }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { P0->P0 }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in ((((E0 + E1) + (E2 + (E3 + E4))) + ((E5 + (E6 + E7)) + (E8 + (E9 + E10))))) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next1.(child[a].ev))
}
fun range2: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop2: set Pos { P4 }
fun next2: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift2_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun shift2_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift2_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift2_4: Pos -> Pos { ((P0->P4 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in (E0) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (E1) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range2 | (i.shift2_3) in (e.target.av)}
all e: used | e.fiber in (((E4 + (E5 + E6)) + ((E7 + E8) + (E9 + E10)))) implies e.ev = {i: range2 | (i.shift2_4) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next2.(child[a].ev))
}
fun range3: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop3: set Pos { P3 }
fun next3: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift3_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun shift3_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P3 + P3->P3)) }
fun shift3_3: Pos -> Pos { ((P0->P3 + P1->P3) + (P2->P3 + P3->P3)) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in (E0) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (E1) implies e.ev = {i: range3 | (i.shift3_1) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range3 | (i.shift3_2) in (e.target.av)}
all e: used | e.fiber in ((((E3 + E4) + (E5 + E6)) + ((E7 + E8) + (E9 + E10)))) implies e.ev = {i: range3 | (i.shift3_3) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next3.(child[a].ev))
}
fun range4: set Pos { (P0 + (P1 + P2)) }
fun loop4: set Pos { P2 }
fun next4: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift4_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun shift4_2: Pos -> Pos { (P0->P2 + (P1->P2 + P2->P2)) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in (E0) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in (E1) implies e.ev = {i: range4 | (i.shift4_1) in (e.target.av)}
all e: used | e.fiber in ((((E2 + E3) + (E4 + E5)) + ((E6 + E7) + (E8 + (E9 + E10))))) implies e.ev = {i: range4 | (i.shift4_2) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next4.(child[a].ev))
}
fun range5: set Pos { (P0 + P1) }
fun loop5: set Pos { P1 }
fun next5: Pos -> Pos { (P0->P1 + P1->P1) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift5_1: Pos -> Pos { (P0->P1 + P1->P1) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in (E0) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in ((((E1 + E2) + (E3 + (E4 + E5))) + ((E6 + E7) + (E8 + (E9 + E10))))) implies e.ev = {i: range5 | (i.shift5_1) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (next5.(child[a].ev))
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (P10)
(R->P0 in ev0)
semantics0[av1, ev1]
all a: lab.T0 | a.av1 = ((P3 + P10))
(R->P0 in ev1)
semantics0[av2, ev2]
all a: lab.T0 | a.av2 = ((P2 + P10))
(R->P0 in ev2)
semantics0[av3, ev3]
all a: lab.T0 | a.av3 = ((P2 + (P3 + P10)))
(R->P0 in ev3)
semantics0[av4, ev4]
all a: lab.T0 | a.av4 = ((P1 + P10))
(R->P0 in ev4)
semantics0[av5, ev5]
all a: lab.T0 | a.av5 = ((P1 + (P3 + P10)))
(R->P0 in ev5)
semantics0[av6, ev6]
all a: lab.T0 | a.av6 = ((P1 + (P2 + P10)))
(R->P0 in ev6)
semantics0[av7, ev7]
all a: lab.T0 | a.av7 = (((P1 + P2) + (P3 + P10)))
(R->P0 in ev7)
semantics0[av8, ev8]
all a: lab.T0 | a.av8 = ((P0 + P10))
(R->P0 in ev8)
semantics0[av9, ev9]
all a: lab.T0 | a.av9 = ((P0 + (P3 + P10)))
(R->P0 in ev9)
semantics0[av10, ev10]
all a: lab.T0 | a.av10 = ((P0 + (P2 + P10)))
(R->P0 in ev10)
semantics0[av11, ev11]
all a: lab.T0 | a.av11 = (((P0 + P2) + (P3 + P10)))
(R->P0 in ev11)
semantics0[av12, ev12]
all a: lab.T0 | a.av12 = ((P0 + (P1 + P10)))
(R->P0 in ev12)
semantics0[av13, ev13]
all a: lab.T0 | a.av13 = (((P0 + P1) + (P3 + P10)))
(R->P0 in ev13)
semantics0[av14, ev14]
all a: lab.T0 | a.av14 = (((P0 + P1) + (P2 + P10)))
(R->P0 in ev14)
semantics0[av15, ev15]
all a: lab.T0 | a.av15 = (((P0 + P1) + (P2 + (P3 + P10))))
(R->P0 in ev15)
semantics1[av16, ev16]
all a: lab.T0 | a.av16 = (none)
not (R->P0 in ev16)
semantics2[av17, ev17]
all a: lab.T0 | a.av17 = (P3)
not (R->P0 in ev17)
semantics3[av18, ev18]
all a: lab.T0 | a.av18 = (P2)
not (R->P0 in ev18)
semantics2[av19, ev19]
all a: lab.T0 | a.av19 = ((P2 + P3))
not (R->P0 in ev19)
semantics4[av20, ev20]
all a: lab.T0 | a.av20 = (P1)
not (R->P0 in ev20)
semantics2[av21, ev21]
all a: lab.T0 | a.av21 = ((P1 + P3))
not (R->P0 in ev21)
semantics3[av22, ev22]
all a: lab.T0 | a.av22 = ((P1 + P2))
not (R->P0 in ev22)
semantics2[av23, ev23]
all a: lab.T0 | a.av23 = ((P1 + (P2 + P3)))
not (R->P0 in ev23)
semantics5[av24, ev24]
all a: lab.T0 | a.av24 = (P0)
not (R->P0 in ev24)
semantics2[av25, ev25]
all a: lab.T0 | a.av25 = ((P0 + P3))
not (R->P0 in ev25)
semantics3[av26, ev26]
all a: lab.T0 | a.av26 = ((P0 + P2))
not (R->P0 in ev26)
semantics2[av27, ev27]
all a: lab.T0 | a.av27 = ((P0 + (P2 + P3)))
not (R->P0 in ev27)
semantics4[av28, ev28]
all a: lab.T0 | a.av28 = ((P0 + P1))
not (R->P0 in ev28)
semantics2[av29, ev29]
all a: lab.T0 | a.av29 = ((P0 + (P1 + P3)))
not (R->P0 in ev29)
semantics3[av30, ev30]
all a: lab.T0 | a.av30 = ((P0 + (P1 + P2)))
not (R->P0 in ev30)
semantics2[av31, ev31]
all a: lab.T0 | a.av31 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev31)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 5 Int


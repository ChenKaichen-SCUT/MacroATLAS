open util/ordering[SeqIdx]

abstract sig DAGNode {
	l: set DAGNode,
	r: set DAGNode
}
fact {
	all n: DAGNode | n not in n.^(l + r)
}


sig X extends DAGNode {} {
    one l
    no r
}
abstract sig Literal extends DAGNode {} {
	no l
	no r
}

abstract sig SeqIdx {}
abstract sig Trace {
	lasso: SeqIdx -> SeqIdx,
	valuation: DAGNode -> SeqIdx
} {
	// Negation
    
	// Or
    
	// And
    
	// Imply
    
	// G
    
    // X
    all n: X, i: seqRange | n->i in valuation iff n.l->i.((next :> seqRange) + lasso) in valuation
	// F
    
	// Until
    
}
fun seqRange[t: Trace]: set SeqIdx {
	let lastOfTrace = t.lasso.SeqIdx | lastOfTrace.prevs + lastOfTrace
}
fun futureIdx[t: Trace, i: SeqIdx]: set SeqIdx {
	i.^((next :> seqRange[t]) + t.lasso) + i
}
abstract sig PositiveTrace extends Trace {}
abstract sig NegativeTrace extends Trace {}
one sig x0 extends Literal {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22, T23, T24, T25, T26, T27, T28, T29 extends SeqIdx {}
fact {
    first = T0
    next = T0->T1 + T1->T2 + T2->T3 + T3->T4 + T4->T5 + T5->T6 + T6->T7 + T7->T8 + T8->T9 + T9->T10 + T10->T11 + T11->T12 + T12->T13 + T13->T14 + T14->T15 + T15->T16 + T16->T17 + T17->T18 + T18->T19 + T19->T20 + T20->T21 + T21->T22 + T22->T23 + T23->T24 + T24->T25 + T25->T26 + T26->T27 + T27->T28 + T28->T29
}

one sig PT0 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T28 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT1 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T3 + x0->T28 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT2 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T2 + x0->T28 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT3 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T2 + x0->T3 + x0->T28 in valuation
    no (x0->T0 + x0->T1 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT4 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T1 + x0->T28 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT5 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T1 + x0->T3 + x0->T28 in valuation
    no (x0->T0 + x0->T2 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT6 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T1 + x0->T2 + x0->T28 in valuation
    no (x0->T0 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT7 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T1 + x0->T2 + x0->T3 + x0->T28 in valuation
    no (x0->T0 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT8 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T28 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT9 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T3 + x0->T28 in valuation
    no (x0->T1 + x0->T2 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT10 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T2 + x0->T28 in valuation
    no (x0->T1 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT11 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T2 + x0->T3 + x0->T28 in valuation
    no (x0->T1 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT12 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T1 + x0->T28 in valuation
    no (x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT13 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T1 + x0->T3 + x0->T28 in valuation
    no (x0->T2 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT14 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T1 + x0->T2 + x0->T28 in valuation
    no (x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}

one sig PT15 extends PositiveTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T28 in valuation
    no (x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T29) & valuation
}


one sig NT0 extends NegativeTrace {} {
    lasso = T29->T29
    
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT1 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT2 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT3 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT4 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T1 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT5 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T1 + x0->T3 in valuation
    no (x0->T0 + x0->T2 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT6 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T1 + x0->T2 in valuation
    no (x0->T0 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT7 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT8 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T0 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT9 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT10 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T2 in valuation
    no (x0->T1 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT11 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT12 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T1 in valuation
    no (x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT13 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T1 + x0->T3 in valuation
    no (x0->T2 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT14 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T1 + x0->T2 in valuation
    no (x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig NT15 extends NegativeTrace {} {
    lasso = T29->T29
    x0->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x0->T22 + x0->T23 + x0->T24 + x0->T25 + x0->T26 + x0->T27 + x0->T28 + x0->T29) & valuation
}

one sig LearnedLTL {
    Root: DAGNode
}
fun root: one DAGNode { LearnedLTL.Root }
fun childrenOf[n: DAGNode]: set DAGNode { n.^(l+r) }
fun childrenAndSelfOf[n: DAGNode]: set DAGNode { n.*(l+r) }
fun ancestorsOf[n: DAGNode]: set DAGNode { n.~^(l+r) }
fun ancestorsAndSelfOf[n: DAGNode]: set DAGNode { n.~*(l+r) }
fun subDAG[n: DAGNode]: DAGNode -> DAGNode { n.*(l+r) <: (l+r) }



fun experimentReach: set DAGNode { childrenAndSelfOf[root] }
fun experimentKept: DAGNode -> DAGNode { (none->none) & subDAG[root] }
one sig ExperimentCost { used: set DAGNode }
fact { ExperimentCost.used = experimentReach }
fact ExperimentBounds {
  DAGNode = experimentReach + Literal + (none)
  #experimentReach <= 8
  #(experimentReach & (none)) <= 0
  minsome ExperimentCost.used
}
run {
    all t: PositiveTrace | root->T0 in t.valuation
    all t: NegativeTrace | root->T0 not in t.valuation
    
} for 9 DAGNode, 5 Int
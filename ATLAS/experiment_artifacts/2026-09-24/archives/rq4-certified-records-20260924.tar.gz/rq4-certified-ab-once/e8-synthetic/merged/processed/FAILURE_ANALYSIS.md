# Failure analysis

- rq4c_binary/n05.trace: Macro >2x slower
- rq4c_binary/n06.trace: Macro >2x slower
- rq4c_binary/n07.trace: Only baseline solved
- rq4c_unary/d14.trace: Only macro solved
- rq4c_unary/d16.trace: Only macro solved
- rq4c_unary/d20.trace: Only macro solved
- rq4c_unary/d24.trace: Only macro solved
- rq4c_unary/d28.trace: Only macro solved
- rq4c_unary/d32.trace: Only macro solved
- rq4c_unary/d40.trace: Only macro solved

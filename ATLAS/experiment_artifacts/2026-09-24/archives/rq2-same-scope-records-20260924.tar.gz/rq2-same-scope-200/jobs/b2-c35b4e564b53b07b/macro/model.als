abstract sig Unit {}
one sig U0, U1, U2, U3, U4, U5, U6, U7, U8 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20 extends Label {}
abstract sig Q {}
one sig Q0, Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E26, E27, E28, E29, E30, E31, E32, E33, E34, E35, E36, E37, E38, E39, E40, E41, E42, E43, E44, E45, E46, E47, E48, E49, E50, E51, E52, E53, E54, E55, E56, E57, E58, E59, E60, E61, E62, E63, E64, E65, E66, E67, E68, E69, E70, E71, E72, E73, E74, E75, E76, E77, E78, E79, E80, E81, E82, E83, E84, E85, E86, E87, E88, E89, E90, E91, E92, E93, E94, E95, E96, E97, E98, E99, E100, E101, E102, E103, E104, E105, E106, E107, E108, E109, E110, E111, E112, E113, E114, E115, E116, E117, E118, E119, E120, E121, E122, E123, E124, E125, E126, E127, E128, E129, E130, E131, E132, E133, E134, E135, E136, E137, E138, E139, E140, E141, E142, E143, E144, E145, E146, E147, E148, E149, E150, E151, E152, E153, E154, E155, E156, E157, E158, E159, E160, E161, E162, E163, E164, E165, E166, E167, E168, E169, E170 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17, P18, P19, P20, P21, P22, P23, P24, P25, P26, P27, P28, P29, P30, P31 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos }
one sig A0, A1, A2, A3, A4, A5, A6, A7 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4, C5, L5, D5, C6, L6, D6, C7, L7, D7 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (((T0 + (T1 + T2)) + ((T3 + T4) + (T5 + T6))) + (((T7 + T8) + (T9 + T10)) + ((T11 + T12) + (T13 + T14)))) }
fun un: set Label { (T15 + (T16 + T17)) }
fun bin: set Label { (T18 + (T19 + T20)) }
fun nonempty: set Fiber { (((((((E1 + E2) + (E3 + (E4 + E5))) + ((E6 + E7) + (E8 + (E9 + E10)))) + (((E11 + E12) + (E13 + (E14 + E15))) + ((E16 + E18) + (E19 + (E20 + E21))))) + ((((E22 + E23) + (E24 + (E25 + E26))) + ((E27 + E28) + (E29 + (E30 + E31)))) + (((E32 + E33) + (E35 + (E36 + E37))) + ((E38 + E39) + (E40 + (E41 + E42)))))) + (((((E43 + E44) + (E45 + (E46 + E47))) + ((E48 + E49) + (E50 + (E52 + E53)))) + (((E54 + E55) + (E56 + (E57 + E58))) + ((E59 + E60) + (E61 + (E62 + E63))))) + ((((E64 + E65) + (E66 + (E67 + E69))) + ((E70 + E71) + (E72 + (E73 + E74)))) + (((E75 + E76) + (E77 + (E78 + E79))) + ((E80 + E81) + (E82 + (E83 + E84))))))) + ((((((E86 + E87) + (E88 + (E89 + E90))) + ((E91 + E92) + (E93 + (E94 + E95)))) + (((E96 + E97) + (E98 + (E99 + E100))) + ((E101 + E103) + (E104 + (E105 + E106))))) + ((((E107 + E108) + (E109 + (E110 + E111))) + ((E112 + E113) + (E114 + (E115 + E116)))) + (((E117 + E118) + (E120 + (E121 + E122))) + ((E123 + E124) + (E125 + (E126 + E127)))))) + (((((E128 + E129) + (E130 + (E131 + E132))) + ((E133 + E134) + (E135 + (E137 + E138)))) + (((E139 + E140) + (E141 + (E142 + E143))) + ((E144 + E145) + (E146 + (E147 + E148))))) + ((((E149 + E150) + (E151 + (E152 + E153))) + ((E155 + E156) + (E157 + (E158 + E159)))) + (((E160 + E161) + (E162 + (E163 + E164))) + ((E165 + (E166 + E167)) + (E168 + (E169 + E170)))))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { (((U0->U1 + U1->U2) + (U2->U3 + U3->U4)) + ((U4->U5 + U5->U6) + (U6->U7 + U7->U8))) }
fun carrierNext: Carrier -> Carrier { (((((A0->A1 + A1->A2) + (A2->A3 + A3->A4)) + ((A4->A5 + A5->A6) + (A6->A7 + A7->R))) + (((R->C0 + C0->L0) + (L0->D0 + D0->C1)) + ((C1->L1 + L1->D1) + (D1->C2 + C2->L2)))) + ((((L2->D2 + D2->C3) + (C3->L3 + L3->D3)) + ((D3->C4 + C4->L4) + (L4->D4 + D4->C5))) + (((C5->L5 + L5->D5) + (D5->C6 + C6->L6)) + ((L6->D6 + D6->C7) + (C7->L7 + L7->D7))))) }
fun child[a: Anchor]: set Port { a.((((A0->C0 + A1->C1) + (A2->C2 + A3->C3)) + ((A4->C4 + A5->C5) + (A6->C6 + A7->C7)))) }
fun left[a: Anchor]: set Port { a.((((A0->L0 + A1->L1) + (A2->L2 + A3->L3)) + ((A4->L4 + A5->L5) + (A6->L6 + A7->L7)))) }
fun right[a: Anchor]: set Port { a.((((A0->D0 + A1->D1) + (A2->D2 + A3->D3)) + ((A4->D4 + A5->D5) + (A6->D6 + A7->D7)))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
C5.src = A5
L5.src = A5
D5.src = A5
(some C5.target iff A5.lab in un and some A5.lab)
(some L5.target iff A5.lab in bin and some A5.lab)
(some D5.target iff A5.lab in bin and some A5.lab)
C6.src = A6
L6.src = A6
D6.src = A6
(some C6.target iff A6.lab in un and some A6.lab)
(some L6.target iff A6.lab in bin and some A6.lab)
(some D6.target iff A6.lab in bin and some A6.lab)
C7.src = A7
L7.src = A7
D7.src = A7
(some C7.target iff A7.lab in un and some A7.lab)
(some L7.target iff A7.lab in bin and some A7.lab)
(some D7.target iff A7.lab in bin and some A7.lab)
no iden & ^graph
active = R.target.*graph
R.fiber not in nonempty
R.target.lab = T17
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
no A3.graph & (((A0 + A1) + (A2 + A3)))
no A4.graph & (((A0 + A1) + (A2 + (A3 + A4))))
no A5.graph & (((A0 + (A1 + A2)) + (A3 + (A4 + A5))))
no A6.graph & (((A0 + (A1 + A2)) + ((A3 + A4) + (A5 + A6))))
no A7.graph & ((((A0 + A1) + (A2 + A3)) + ((A4 + A5) + (A6 + A7))))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
lone lab.T2
lone lab.T3
lone lab.T4
lone lab.T5
lone lab.T6
lone lab.T7
lone lab.T8
lone lab.T9
lone lab.T10
lone lab.T11
lone lab.T12
lone lab.T13
lone lab.T14
some A0.lab and A0.lab in un and R.target != A0 implies #(target.A0) > 1
some A1.lab and A1.lab in un and R.target != A1 implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un and R.target != A2 implies #(target.A2) > 1
some A2.lab implies some A1.lab
some A3.lab and A3.lab in un and R.target != A3 implies #(target.A3) > 1
some A3.lab implies some A2.lab
some A4.lab and A4.lab in un and R.target != A4 implies #(target.A4) > 1
some A4.lab implies some A3.lab
some A5.lab and A5.lab in un and R.target != A5 implies #(target.A5) > 1
some A5.lab implies some A4.lab
some A6.lab and A6.lab in un and R.target != A6 implies #(target.A6) > 1
some A6.lab implies some A5.lab
some A7.lab and A7.lab in un and R.target != A7 implies #(target.A7) > 1
some A7.lab implies some A6.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q3
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q3
E7.qi = Q0
E7.qo = Q0
E8.qi = Q0
E8.qo = Q0
E9.qi = Q0
E9.qo = Q0
E10.qi = Q0
E10.qo = Q3
E11.qi = Q0
E11.qo = Q0
E12.qi = Q0
E12.qo = Q3
E13.qi = Q0
E13.qo = Q0
E14.qi = Q0
E14.qo = Q3
E15.qi = Q0
E15.qo = Q0
E16.qi = Q0
E16.qo = Q3
E17.qi = Q1
E17.qo = Q1
E18.qi = Q1
E18.qo = Q1
E19.qi = Q1
E19.qo = Q1
E20.qi = Q1
E20.qo = Q1
E21.qi = Q1
E21.qo = Q4
E22.qi = Q1
E22.qo = Q1
E23.qi = Q1
E23.qo = Q4
E24.qi = Q1
E24.qo = Q1
E25.qi = Q1
E25.qo = Q1
E26.qi = Q1
E26.qo = Q1
E27.qi = Q1
E27.qo = Q4
E28.qi = Q1
E28.qo = Q1
E29.qi = Q1
E29.qo = Q4
E30.qi = Q1
E30.qo = Q1
E31.qi = Q1
E31.qo = Q4
E32.qi = Q1
E32.qo = Q1
E33.qi = Q1
E33.qo = Q4
E34.qi = Q2
E34.qo = Q2
E35.qi = Q2
E35.qo = Q2
E36.qi = Q2
E36.qo = Q2
E37.qi = Q2
E37.qo = Q2
E38.qi = Q2
E38.qo = Q5
E39.qi = Q2
E39.qo = Q2
E40.qi = Q2
E40.qo = Q5
E41.qi = Q2
E41.qo = Q2
E42.qi = Q2
E42.qo = Q2
E43.qi = Q2
E43.qo = Q2
E44.qi = Q2
E44.qo = Q5
E45.qi = Q2
E45.qo = Q2
E46.qi = Q2
E46.qo = Q5
E47.qi = Q2
E47.qo = Q2
E48.qi = Q2
E48.qo = Q5
E49.qi = Q2
E49.qo = Q2
E50.qi = Q2
E50.qo = Q5
E51.qi = Q3
E51.qo = Q3
E52.qi = Q3
E52.qo = Q0
E53.qi = Q3
E53.qo = Q0
E54.qi = Q3
E54.qo = Q0
E55.qi = Q3
E55.qo = Q3
E56.qi = Q3
E56.qo = Q0
E57.qi = Q3
E57.qo = Q3
E58.qi = Q3
E58.qo = Q0
E59.qi = Q3
E59.qo = Q0
E60.qi = Q3
E60.qo = Q0
E61.qi = Q3
E61.qo = Q3
E62.qi = Q3
E62.qo = Q0
E63.qi = Q3
E63.qo = Q3
E64.qi = Q3
E64.qo = Q0
E65.qi = Q3
E65.qo = Q3
E66.qi = Q3
E66.qo = Q0
E67.qi = Q3
E67.qo = Q3
E68.qi = Q4
E68.qo = Q4
E69.qi = Q4
E69.qo = Q1
E70.qi = Q4
E70.qo = Q1
E71.qi = Q4
E71.qo = Q1
E72.qi = Q4
E72.qo = Q4
E73.qi = Q4
E73.qo = Q1
E74.qi = Q4
E74.qo = Q4
E75.qi = Q4
E75.qo = Q1
E76.qi = Q4
E76.qo = Q1
E77.qi = Q4
E77.qo = Q1
E78.qi = Q4
E78.qo = Q4
E79.qi = Q4
E79.qo = Q1
E80.qi = Q4
E80.qo = Q4
E81.qi = Q4
E81.qo = Q1
E82.qi = Q4
E82.qo = Q4
E83.qi = Q4
E83.qo = Q1
E84.qi = Q4
E84.qo = Q4
E85.qi = Q5
E85.qo = Q5
E86.qi = Q5
E86.qo = Q2
E87.qi = Q5
E87.qo = Q2
E88.qi = Q5
E88.qo = Q2
E89.qi = Q5
E89.qo = Q5
E90.qi = Q5
E90.qo = Q2
E91.qi = Q5
E91.qo = Q5
E92.qi = Q5
E92.qo = Q2
E93.qi = Q5
E93.qo = Q2
E94.qi = Q5
E94.qo = Q2
E95.qi = Q5
E95.qo = Q5
E96.qi = Q5
E96.qo = Q2
E97.qi = Q5
E97.qo = Q5
E98.qi = Q5
E98.qo = Q2
E99.qi = Q5
E99.qo = Q5
E100.qi = Q5
E100.qo = Q2
E101.qi = Q5
E101.qo = Q5
E102.qi = Q6
E102.qo = Q6
E103.qi = Q6
E103.qo = Q6
E104.qi = Q6
E104.qo = Q6
E105.qi = Q6
E105.qo = Q6
E106.qi = Q6
E106.qo = Q7
E107.qi = Q6
E107.qo = Q6
E108.qi = Q6
E108.qo = Q7
E109.qi = Q6
E109.qo = Q6
E110.qi = Q6
E110.qo = Q6
E111.qi = Q6
E111.qo = Q6
E112.qi = Q6
E112.qo = Q7
E113.qi = Q6
E113.qo = Q6
E114.qi = Q6
E114.qo = Q7
E115.qi = Q6
E115.qo = Q6
E116.qi = Q6
E116.qo = Q7
E117.qi = Q6
E117.qo = Q6
E118.qi = Q6
E118.qo = Q7
E119.qi = Q7
E119.qo = Q7
E120.qi = Q7
E120.qo = Q6
E121.qi = Q7
E121.qo = Q6
E122.qi = Q7
E122.qo = Q6
E123.qi = Q7
E123.qo = Q7
E124.qi = Q7
E124.qo = Q6
E125.qi = Q7
E125.qo = Q7
E126.qi = Q7
E126.qo = Q6
E127.qi = Q7
E127.qo = Q6
E128.qi = Q7
E128.qo = Q6
E129.qi = Q7
E129.qo = Q7
E130.qi = Q7
E130.qo = Q6
E131.qi = Q7
E131.qo = Q7
E132.qi = Q7
E132.qo = Q6
E133.qi = Q7
E133.qo = Q7
E134.qi = Q7
E134.qo = Q6
E135.qi = Q7
E135.qo = Q7
E136.qi = Q8
E136.qo = Q8
E137.qi = Q8
E137.qo = Q6
E138.qi = Q8
E138.qo = Q6
E139.qi = Q8
E139.qo = Q6
E140.qi = Q8
E140.qo = Q7
E141.qi = Q8
E141.qo = Q6
E142.qi = Q8
E142.qo = Q7
E143.qi = Q8
E143.qo = Q6
E144.qi = Q8
E144.qo = Q9
E145.qi = Q8
E145.qo = Q6
E146.qi = Q8
E146.qo = Q6
E147.qi = Q8
E147.qo = Q7
E148.qi = Q8
E148.qo = Q6
E149.qi = Q8
E149.qo = Q7
E150.qi = Q8
E150.qo = Q6
E151.qi = Q8
E151.qo = Q7
E152.qi = Q8
E152.qo = Q6
E153.qi = Q8
E153.qo = Q7
E154.qi = Q9
E154.qo = Q9
E155.qi = Q9
E155.qo = Q6
E156.qi = Q9
E156.qo = Q6
E157.qi = Q9
E157.qo = Q6
E158.qi = Q9
E158.qo = Q7
E159.qi = Q9
E159.qo = Q6
E160.qi = Q9
E160.qo = Q7
E161.qi = Q9
E161.qo = Q6
E162.qi = Q9
E162.qo = Q6
E163.qi = Q9
E163.qo = Q6
E164.qi = Q9
E164.qo = Q7
E165.qi = Q9
E165.qo = Q6
E166.qi = Q9
E166.qo = Q7
E167.qi = Q9
E167.qo = Q6
E168.qi = Q9
E168.qo = Q7
E169.qi = Q9
E169.qo = Q6
E170.qi = Q9
E170.qo = Q7
all e: used | e.fiber in ((((E0 + E17) + (E34 + (E51 + E68))) + ((E85 + E102) + (E119 + (E136 + E154))))) implies #e.cost = 0
all e: used | e.fiber in ((((((E1 + (E5 + E6)) + ((E8 + E10) + (E13 + E18))) + (((E22 + E23) + (E25 + E27)) + ((E30 + E35) + (E39 + E40)))) + (((E42 + (E44 + E47)) + ((E52 + E56) + (E57 + E59))) + (((E61 + E64) + (E69 + E73)) + ((E74 + E76) + (E78 + E81))))) + ((((E86 + (E90 + E91)) + ((E93 + E95) + (E98 + E103))) + (((E107 + E108) + (E110 + E112)) + ((E115 + E120) + (E124 + E125)))) + ((((E127 + E129) + (E132 + E137)) + ((E141 + E142) + (E143 + E145))) + (((E147 + E150) + (E155 + E159)) + ((E160 + E162) + (E164 + E167))))))) implies #e.cost = 2
all e: used | e.fiber in (((((E2 + (E4 + E7)) + ((E19 + E21) + (E24 + E36))) + (((E38 + E41) + (E53 + E55)) + ((E58 + E70) + (E72 + E75)))) + (((E87 + (E89 + E92)) + ((E104 + E106) + (E109 + E121))) + (((E123 + E126) + (E138 + E140)) + ((E144 + E156) + (E158 + E161)))))) implies #e.cost = 1
all e: used | e.fiber in ((((((E3 + (E9 + E11)) + ((E12 + E14) + (E15 + E20))) + (((E26 + E28) + (E29 + E31)) + ((E32 + E37) + (E43 + E45)))) + (((E46 + (E48 + E49)) + ((E54 + E60) + (E62 + E63))) + (((E65 + E66) + (E71 + E77)) + ((E79 + E80) + (E82 + E83))))) + ((((E88 + (E94 + E96)) + ((E97 + E99) + (E100 + E105))) + (((E111 + E113) + (E114 + E116)) + ((E117 + E122) + (E128 + E130)))) + (((E131 + (E133 + E134)) + ((E139 + E146) + (E148 + E149))) + (((E151 + E152) + (E157 + E163)) + ((E165 + E166) + (E168 + E169))))))) implies #e.cost = 3
all e: used | e.fiber in ((((E16 + E33) + (E50 + (E67 + E84))) + ((E101 + E118) + (E135 + (E153 + E170))))) implies #e.cost = 4
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q9)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 implies a.state = Q0
all a: active | a.lab = T3 implies a.state = Q0
all a: active | a.lab = T4 implies a.state = Q0
all a: active | a.lab = T5 implies a.state = Q0
all a: active | a.lab = T6 implies a.state = Q0
all a: active | a.lab = T7 implies a.state = Q1
all a: active | a.lab = T8 implies a.state = Q0
all a: active | a.lab = T9 implies a.state = Q0
all a: active | a.lab = T10 implies a.state = Q0
all a: active | a.lab = T11 implies a.state = Q2
all a: active | a.lab = T12 implies a.state = Q0
all a: active | a.lab = T13 implies a.state = Q0
all a: active | a.lab = T14 implies a.state = Q0
all a: active | a.lab = T15 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T15 and child[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T15 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T15 and child[a].fiber.qo = Q3 implies a.state = Q0
all a: active | a.lab = T15 and child[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T15 and child[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T15 and child[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T15 and child[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T15 and child[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T15 and child[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T16 and child[a].fiber.qo = Q0 implies a.state = Q3
all a: active | a.lab = T16 and child[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T16 and child[a].fiber.qo = Q2 implies a.state = Q5
all a: active | a.lab = T16 and child[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T16 and child[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T16 and child[a].fiber.qo = Q5 implies a.state = Q5
all a: active | a.lab = T16 and child[a].fiber.qo = Q6 implies a.state = Q7
all a: active | a.lab = T16 and child[a].fiber.qo = Q7 implies a.state = Q7
all a: active | a.lab = T16 and child[a].fiber.qo = Q8 implies a.state = Q7
all a: active | a.lab = T16 and child[a].fiber.qo = Q9 implies a.state = Q7
all a: active | a.lab = T17 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T17 and child[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T17 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T17 and child[a].fiber.qo = Q3 implies a.state = Q0
all a: active | a.lab = T17 and child[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T17 and child[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T17 and child[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T17 and child[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T17 and child[a].fiber.qo = Q8 implies a.state = Q9
all a: active | a.lab = T17 and child[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q0
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q5 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q4 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q0
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q3 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q5 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q3 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q4 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q4 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q5 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q4 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q5 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q4 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q5 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q4 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q5 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T18 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q0
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q5 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q4 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q0
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q3 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q5 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q3 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q4 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q4 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q5 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q4 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q5 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q4 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q5 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q4 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q5 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q7 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T19 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q0
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q7 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q7 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q4 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q7 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q0
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q7 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q3 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q4 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q7 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q3 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q4 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q5 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q7 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q4 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q7 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q4 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q7 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q4 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q7 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q4 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q7 implies a.state = Q8
all a: active | a.lab = T20 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q8 implies a.state = Q6
all a: active | a.lab = T20 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: lab.bin | no left[a].target.*graph & right[a].target.*graph & lab.lit
}
fun range0: set Pos { (((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) + (((P7 + P8) + (P9 + P10)) + ((P11 + P12) + (P13 + P14)))) }
fun loop0: set Pos { (((P3 + (P4 + P5)) + (P6 + (P7 + P8))) + ((P9 + (P10 + P11)) + (P12 + (P13 + P14)))) }
fun next0: Pos -> Pos { (((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P7))) + (((P7->P8 + P8->P9) + (P9->P10 + P10->P11)) + ((P11->P12 + P12->P13) + (P13->P14 + P14->P3)))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { (((P0->P0 + (P1->P1 + P2->P2)) + ((P3->P3 + P4->P4) + (P5->P5 + P6->P6))) + (((P7->P7 + P8->P8) + (P9->P9 + P10->P10)) + ((P11->P11 + P12->P12) + (P13->P13 + P14->P14)))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in (((((E0 + E1) + (E17 + (E18 + E34))) + ((E35 + E51) + (E52 + (E68 + E69)))) + (((E85 + E86) + (E102 + (E103 + E119))) + ((E120 + E136) + (E137 + (E154 + E155)))))) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in ((((E2 + E19) + (E36 + (E53 + E70))) + ((E87 + E104) + (E121 + (E138 + E156))))) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in (((((E3 + E4) + (E20 + (E21 + E37))) + ((E38 + E54) + (E55 + (E71 + E72)))) + (((E88 + E89) + (E105 + (E106 + E122))) + ((E123 + E139) + (E140 + (E157 + E158)))))) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in (((((E5 + E6) + (E22 + (E23 + E39))) + ((E40 + E56) + (E57 + (E73 + E74)))) + (((E90 + E91) + (E107 + (E108 + E124))) + ((E125 + E141) + (E142 + (E159 + E160)))))) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in ((((E7 + E24) + (E41 + (E58 + E75))) + ((E92 + (E109 + E126)) + (E143 + (E144 + E161))))) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in ((((E8 + E25) + (E42 + (E59 + E76))) + ((E93 + E110) + (E127 + (E145 + E162))))) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (((((E9 + E10) + (E26 + (E27 + E43))) + ((E44 + E60) + (E61 + (E77 + E78)))) + (((E94 + E95) + (E111 + (E112 + E128))) + ((E129 + E146) + (E147 + (E163 + E164)))))) implies e.ev = {i: range0 | loop0 in (e.target.av)}
all e: used | e.fiber in (((((E11 + E12) + (E28 + (E29 + E45))) + ((E46 + E62) + (E63 + (E79 + E80)))) + (((E96 + E97) + (E113 + (E114 + E130))) + ((E131 + E148) + (E149 + (E165 + E166)))))) implies e.ev = {i: range0 | loop0 in (range0 - e.target.av)}
all e: used | e.fiber in (((((E13 + E14) + (E30 + (E31 + E47))) + ((E48 + E64) + (E65 + (E81 + E82)))) + (((E98 + E99) + (E115 + (E116 + E132))) + ((E133 + E150) + (E151 + (E167 + E168)))))) implies e.ev = {i: range0 | some (loop0 & (e.target.av))}
all e: used | e.fiber in (((((E15 + E16) + (E32 + (E33 + E49))) + ((E50 + E66) + (E67 + (E83 + E84)))) + (((E100 + E101) + (E117 + (E118 + E134))) + ((E135 + E152) + (E153 + (E169 + E170)))))) implies e.ev = {i: range0 | some (loop0 & (range0 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { (((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) + ((P7 + (P8 + P9)) + ((P10 + P11) + (P12 + P13)))) }
fun loop1: set Pos { (((P2 + (P3 + P4)) + (P5 + (P6 + P7))) + ((P8 + (P9 + P10)) + (P11 + (P12 + P13)))) }
fun next1: Pos -> Pos { (((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P7))) + ((P7->P8 + (P8->P9 + P9->P10)) + ((P10->P11 + P11->P12) + (P12->P13 + P13->P2)))) }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { (((P0->P0 + (P1->P1 + P2->P2)) + ((P3->P3 + P4->P4) + (P5->P5 + P6->P6))) + ((P7->P7 + (P8->P8 + P9->P9)) + ((P10->P10 + P11->P11) + (P12->P12 + P13->P13)))) }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in (((((E0 + E1) + (E17 + (E18 + E34))) + ((E35 + E51) + (E52 + (E68 + E69)))) + (((E85 + E86) + (E102 + (E103 + E119))) + ((E120 + E136) + (E137 + (E154 + E155)))))) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in ((((E2 + E19) + (E36 + (E53 + E70))) + ((E87 + E104) + (E121 + (E138 + E156))))) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in (((((E3 + E4) + (E20 + (E21 + E37))) + ((E38 + E54) + (E55 + (E71 + E72)))) + (((E88 + E89) + (E105 + (E106 + E122))) + ((E123 + E139) + (E140 + (E157 + E158)))))) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in (((((E5 + E6) + (E22 + (E23 + E39))) + ((E40 + E56) + (E57 + (E73 + E74)))) + (((E90 + E91) + (E107 + (E108 + E124))) + ((E125 + E141) + (E142 + (E159 + E160)))))) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in ((((E7 + E24) + (E41 + (E58 + E75))) + ((E92 + (E109 + E126)) + (E143 + (E144 + E161))))) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in ((((E8 + E25) + (E42 + (E59 + E76))) + ((E93 + E110) + (E127 + (E145 + E162))))) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (((((E9 + E10) + (E26 + (E27 + E43))) + ((E44 + E60) + (E61 + (E77 + E78)))) + (((E94 + E95) + (E111 + (E112 + E128))) + ((E129 + E146) + (E147 + (E163 + E164)))))) implies e.ev = {i: range1 | loop1 in (e.target.av)}
all e: used | e.fiber in (((((E11 + E12) + (E28 + (E29 + E45))) + ((E46 + E62) + (E63 + (E79 + E80)))) + (((E96 + E97) + (E113 + (E114 + E130))) + ((E131 + E148) + (E149 + (E165 + E166)))))) implies e.ev = {i: range1 | loop1 in (range1 - e.target.av)}
all e: used | e.fiber in (((((E13 + E14) + (E30 + (E31 + E47))) + ((E48 + E64) + (E65 + (E81 + E82)))) + (((E98 + E99) + (E115 + (E116 + E132))) + ((E133 + E150) + (E151 + (E167 + E168)))))) implies e.ev = {i: range1 | some (loop1 & (e.target.av))}
all e: used | e.fiber in (((((E15 + E16) + (E32 + (E33 + E49))) + ((E50 + E66) + (E67 + (E83 + E84)))) + (((E100 + E101) + (E117 + (E118 + E134))) + ((E135 + E152) + (E153 + (E169 + E170)))))) implies e.ev = {i: range1 | some (loop1 & (range1 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fun range2: set Pos { ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) + (((P8 + P9) + (P10 + P11)) + ((P12 + P13) + (P14 + P15)))) }
fun loop2: set Pos { (((P4 + (P5 + P6)) + (P7 + (P8 + P9))) + ((P10 + (P11 + P12)) + (P13 + (P14 + P15)))) }
fun next2: Pos -> Pos { ((((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P8))) + (((P8->P9 + P9->P10) + (P10->P11 + P11->P12)) + ((P12->P13 + P13->P14) + (P14->P15 + P15->P4)))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) + (((P8->P8 + P9->P9) + (P10->P10 + P11->P11)) + ((P12->P12 + P13->P13) + (P14->P14 + P15->P15)))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in (((((E0 + E1) + (E17 + (E18 + E34))) + ((E35 + E51) + (E52 + (E68 + E69)))) + (((E85 + E86) + (E102 + (E103 + E119))) + ((E120 + E136) + (E137 + (E154 + E155)))))) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in ((((E2 + E19) + (E36 + (E53 + E70))) + ((E87 + E104) + (E121 + (E138 + E156))))) implies e.ev = {i: range2 | (i.shift2_0) in (range2 - e.target.av)}
all e: used | e.fiber in (((((E3 + E4) + (E20 + (E21 + E37))) + ((E38 + E54) + (E55 + (E71 + E72)))) + (((E88 + E89) + (E105 + (E106 + E122))) + ((E123 + E139) + (E140 + (E157 + E158)))))) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (e.target.av))}
all e: used | e.fiber in (((((E5 + E6) + (E22 + (E23 + E39))) + ((E40 + E56) + (E57 + (E73 + E74)))) + (((E90 + E91) + (E107 + (E108 + E124))) + ((E125 + E141) + (E142 + (E159 + E160)))))) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (range2 - e.target.av))}
all e: used | e.fiber in ((((E7 + E24) + (E41 + (E58 + E75))) + ((E92 + (E109 + E126)) + (E143 + (E144 + E161))))) implies e.ev = {i: range2 | (i.shift2_0).future2 in (e.target.av)}
all e: used | e.fiber in ((((E8 + E25) + (E42 + (E59 + E76))) + ((E93 + E110) + (E127 + (E145 + E162))))) implies e.ev = {i: range2 | (i.shift2_0).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (((((E9 + E10) + (E26 + (E27 + E43))) + ((E44 + E60) + (E61 + (E77 + E78)))) + (((E94 + E95) + (E111 + (E112 + E128))) + ((E129 + E146) + (E147 + (E163 + E164)))))) implies e.ev = {i: range2 | loop2 in (e.target.av)}
all e: used | e.fiber in (((((E11 + E12) + (E28 + (E29 + E45))) + ((E46 + E62) + (E63 + (E79 + E80)))) + (((E96 + E97) + (E113 + (E114 + E130))) + ((E131 + E148) + (E149 + (E165 + E166)))))) implies e.ev = {i: range2 | loop2 in (range2 - e.target.av)}
all e: used | e.fiber in (((((E13 + E14) + (E30 + (E31 + E47))) + ((E48 + E64) + (E65 + (E81 + E82)))) + (((E98 + E99) + (E115 + (E116 + E132))) + ((E133 + E150) + (E151 + (E167 + E168)))))) implies e.ev = {i: range2 | some (loop2 & (e.target.av))}
all e: used | e.fiber in (((((E15 + E16) + (E32 + (E33 + E49))) + ((E50 + E66) + (E67 + (E83 + E84)))) + (((E100 + E101) + (E117 + (E118 + E134))) + ((E135 + E152) + (E153 + (E169 + E170)))))) implies e.ev = {i: range2 | some (loop2 & (range2 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range2 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range2 | some (i.future2 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range2 | i.future2 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range2 - left[a].ev) + right[a].ev)
}
fun range3: set Pos { ((((P0 + (P1 + P2)) + (P3 + (P4 + P5))) + ((P6 + (P7 + P8)) + (P9 + (P10 + P11)))) + (((P12 + (P13 + P14)) + (P15 + (P16 + P17))) + ((P18 + (P19 + P20)) + ((P21 + P22) + (P23 + P24))))) }
fun loop3: set Pos { ((P18 + (P19 + P20)) + ((P21 + P22) + (P23 + P24))) }
fun next3: Pos -> Pos { ((((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P6))) + ((P6->P7 + (P7->P8 + P8->P9)) + (P9->P10 + (P10->P11 + P11->P12)))) + (((P12->P13 + (P13->P14 + P14->P15)) + (P15->P16 + (P16->P17 + P17->P18))) + ((P18->P19 + (P19->P20 + P20->P21)) + ((P21->P22 + P22->P23) + (P23->P24 + P24->P18))))) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { ((((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) + ((P6->P6 + (P7->P7 + P8->P8)) + (P9->P9 + (P10->P10 + P11->P11)))) + (((P12->P12 + (P13->P13 + P14->P14)) + (P15->P15 + (P16->P16 + P17->P17))) + ((P18->P18 + (P19->P19 + P20->P20)) + ((P21->P21 + P22->P22) + (P23->P23 + P24->P24))))) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in (((((E0 + E1) + (E17 + (E18 + E34))) + ((E35 + E51) + (E52 + (E68 + E69)))) + (((E85 + E86) + (E102 + (E103 + E119))) + ((E120 + E136) + (E137 + (E154 + E155)))))) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in ((((E2 + E19) + (E36 + (E53 + E70))) + ((E87 + E104) + (E121 + (E138 + E156))))) implies e.ev = {i: range3 | (i.shift3_0) in (range3 - e.target.av)}
all e: used | e.fiber in (((((E3 + E4) + (E20 + (E21 + E37))) + ((E38 + E54) + (E55 + (E71 + E72)))) + (((E88 + E89) + (E105 + (E106 + E122))) + ((E123 + E139) + (E140 + (E157 + E158)))))) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (e.target.av))}
all e: used | e.fiber in (((((E5 + E6) + (E22 + (E23 + E39))) + ((E40 + E56) + (E57 + (E73 + E74)))) + (((E90 + E91) + (E107 + (E108 + E124))) + ((E125 + E141) + (E142 + (E159 + E160)))))) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (range3 - e.target.av))}
all e: used | e.fiber in ((((E7 + E24) + (E41 + (E58 + E75))) + ((E92 + (E109 + E126)) + (E143 + (E144 + E161))))) implies e.ev = {i: range3 | (i.shift3_0).future3 in (e.target.av)}
all e: used | e.fiber in ((((E8 + E25) + (E42 + (E59 + E76))) + ((E93 + E110) + (E127 + (E145 + E162))))) implies e.ev = {i: range3 | (i.shift3_0).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (((((E9 + E10) + (E26 + (E27 + E43))) + ((E44 + E60) + (E61 + (E77 + E78)))) + (((E94 + E95) + (E111 + (E112 + E128))) + ((E129 + E146) + (E147 + (E163 + E164)))))) implies e.ev = {i: range3 | loop3 in (e.target.av)}
all e: used | e.fiber in (((((E11 + E12) + (E28 + (E29 + E45))) + ((E46 + E62) + (E63 + (E79 + E80)))) + (((E96 + E97) + (E113 + (E114 + E130))) + ((E131 + E148) + (E149 + (E165 + E166)))))) implies e.ev = {i: range3 | loop3 in (range3 - e.target.av)}
all e: used | e.fiber in (((((E13 + E14) + (E30 + (E31 + E47))) + ((E48 + E64) + (E65 + (E81 + E82)))) + (((E98 + E99) + (E115 + (E116 + E132))) + ((E133 + E150) + (E151 + (E167 + E168)))))) implies e.ev = {i: range3 | some (loop3 & (e.target.av))}
all e: used | e.fiber in (((((E15 + E16) + (E32 + (E33 + E49))) + ((E50 + E66) + (E67 + (E83 + E84)))) + (((E100 + E101) + (E117 + (E118 + E134))) + ((E135 + E152) + (E153 + (E169 + E170)))))) implies e.ev = {i: range3 | some (loop3 & (range3 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range3 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range3 | some (i.future3 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range3 | i.future3 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range3 - left[a].ev) + right[a].ev)
}
fun range4: set Pos { ((((P0 + (P1 + P2)) + (P3 + (P4 + P5))) + ((P6 + (P7 + P8)) + ((P9 + P10) + (P11 + P12)))) + (((P13 + (P14 + P15)) + (P16 + (P17 + P18))) + ((P19 + (P20 + P21)) + ((P22 + P23) + (P24 + P25))))) }
fun loop4: set Pos { ((P19 + (P20 + P21)) + ((P22 + P23) + (P24 + P25))) }
fun next4: Pos -> Pos { ((((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P6))) + ((P6->P7 + (P7->P8 + P8->P9)) + ((P9->P10 + P10->P11) + (P11->P12 + P12->P13)))) + (((P13->P14 + (P14->P15 + P15->P16)) + (P16->P17 + (P17->P18 + P18->P19))) + ((P19->P20 + (P20->P21 + P21->P22)) + ((P22->P23 + P23->P24) + (P24->P25 + P25->P19))))) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { ((((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) + ((P6->P6 + (P7->P7 + P8->P8)) + ((P9->P9 + P10->P10) + (P11->P11 + P12->P12)))) + (((P13->P13 + (P14->P14 + P15->P15)) + (P16->P16 + (P17->P17 + P18->P18))) + ((P19->P19 + (P20->P20 + P21->P21)) + ((P22->P22 + P23->P23) + (P24->P24 + P25->P25))))) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in (((((E0 + E1) + (E17 + (E18 + E34))) + ((E35 + E51) + (E52 + (E68 + E69)))) + (((E85 + E86) + (E102 + (E103 + E119))) + ((E120 + E136) + (E137 + (E154 + E155)))))) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in ((((E2 + E19) + (E36 + (E53 + E70))) + ((E87 + E104) + (E121 + (E138 + E156))))) implies e.ev = {i: range4 | (i.shift4_0) in (range4 - e.target.av)}
all e: used | e.fiber in (((((E3 + E4) + (E20 + (E21 + E37))) + ((E38 + E54) + (E55 + (E71 + E72)))) + (((E88 + E89) + (E105 + (E106 + E122))) + ((E123 + E139) + (E140 + (E157 + E158)))))) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (e.target.av))}
all e: used | e.fiber in (((((E5 + E6) + (E22 + (E23 + E39))) + ((E40 + E56) + (E57 + (E73 + E74)))) + (((E90 + E91) + (E107 + (E108 + E124))) + ((E125 + E141) + (E142 + (E159 + E160)))))) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (range4 - e.target.av))}
all e: used | e.fiber in ((((E7 + E24) + (E41 + (E58 + E75))) + ((E92 + (E109 + E126)) + (E143 + (E144 + E161))))) implies e.ev = {i: range4 | (i.shift4_0).future4 in (e.target.av)}
all e: used | e.fiber in ((((E8 + E25) + (E42 + (E59 + E76))) + ((E93 + E110) + (E127 + (E145 + E162))))) implies e.ev = {i: range4 | (i.shift4_0).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (((((E9 + E10) + (E26 + (E27 + E43))) + ((E44 + E60) + (E61 + (E77 + E78)))) + (((E94 + E95) + (E111 + (E112 + E128))) + ((E129 + E146) + (E147 + (E163 + E164)))))) implies e.ev = {i: range4 | loop4 in (e.target.av)}
all e: used | e.fiber in (((((E11 + E12) + (E28 + (E29 + E45))) + ((E46 + E62) + (E63 + (E79 + E80)))) + (((E96 + E97) + (E113 + (E114 + E130))) + ((E131 + E148) + (E149 + (E165 + E166)))))) implies e.ev = {i: range4 | loop4 in (range4 - e.target.av)}
all e: used | e.fiber in (((((E13 + E14) + (E30 + (E31 + E47))) + ((E48 + E64) + (E65 + (E81 + E82)))) + (((E98 + E99) + (E115 + (E116 + E132))) + ((E133 + E150) + (E151 + (E167 + E168)))))) implies e.ev = {i: range4 | some (loop4 & (e.target.av))}
all e: used | e.fiber in (((((E15 + E16) + (E32 + (E33 + E49))) + ((E50 + E66) + (E67 + (E83 + E84)))) + (((E100 + E101) + (E117 + (E118 + E134))) + ((E135 + E152) + (E153 + (E169 + E170)))))) implies e.ev = {i: range4 | some (loop4 & (range4 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range4 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range4 | some (i.future4 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range4 | i.future4 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range4 - left[a].ev) + right[a].ev)
}
fun range5: set Pos { ((((P0 + (P1 + P2)) + (P3 + (P4 + P5))) + ((P6 + (P7 + P8)) + ((P9 + P10) + (P11 + P12)))) + (((P13 + (P14 + P15)) + ((P16 + P17) + (P18 + P19))) + ((P20 + (P21 + P22)) + ((P23 + P24) + (P25 + P26))))) }
fun loop5: set Pos { (((P19 + P20) + (P21 + P22)) + ((P23 + P24) + (P25 + P26))) }
fun next5: Pos -> Pos { ((((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P6))) + ((P6->P7 + (P7->P8 + P8->P9)) + ((P9->P10 + P10->P11) + (P11->P12 + P12->P13)))) + (((P13->P14 + (P14->P15 + P15->P16)) + ((P16->P17 + P17->P18) + (P18->P19 + P19->P20))) + ((P20->P21 + (P21->P22 + P22->P23)) + ((P23->P24 + P24->P25) + (P25->P26 + P26->P19))))) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { ((((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) + ((P6->P6 + (P7->P7 + P8->P8)) + ((P9->P9 + P10->P10) + (P11->P11 + P12->P12)))) + (((P13->P13 + (P14->P14 + P15->P15)) + ((P16->P16 + P17->P17) + (P18->P18 + P19->P19))) + ((P20->P20 + (P21->P21 + P22->P22)) + ((P23->P23 + P24->P24) + (P25->P25 + P26->P26))))) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in (((((E0 + E1) + (E17 + (E18 + E34))) + ((E35 + E51) + (E52 + (E68 + E69)))) + (((E85 + E86) + (E102 + (E103 + E119))) + ((E120 + E136) + (E137 + (E154 + E155)))))) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in ((((E2 + E19) + (E36 + (E53 + E70))) + ((E87 + E104) + (E121 + (E138 + E156))))) implies e.ev = {i: range5 | (i.shift5_0) in (range5 - e.target.av)}
all e: used | e.fiber in (((((E3 + E4) + (E20 + (E21 + E37))) + ((E38 + E54) + (E55 + (E71 + E72)))) + (((E88 + E89) + (E105 + (E106 + E122))) + ((E123 + E139) + (E140 + (E157 + E158)))))) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (e.target.av))}
all e: used | e.fiber in (((((E5 + E6) + (E22 + (E23 + E39))) + ((E40 + E56) + (E57 + (E73 + E74)))) + (((E90 + E91) + (E107 + (E108 + E124))) + ((E125 + E141) + (E142 + (E159 + E160)))))) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (range5 - e.target.av))}
all e: used | e.fiber in ((((E7 + E24) + (E41 + (E58 + E75))) + ((E92 + (E109 + E126)) + (E143 + (E144 + E161))))) implies e.ev = {i: range5 | (i.shift5_0).future5 in (e.target.av)}
all e: used | e.fiber in ((((E8 + E25) + (E42 + (E59 + E76))) + ((E93 + E110) + (E127 + (E145 + E162))))) implies e.ev = {i: range5 | (i.shift5_0).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (((((E9 + E10) + (E26 + (E27 + E43))) + ((E44 + E60) + (E61 + (E77 + E78)))) + (((E94 + E95) + (E111 + (E112 + E128))) + ((E129 + E146) + (E147 + (E163 + E164)))))) implies e.ev = {i: range5 | loop5 in (e.target.av)}
all e: used | e.fiber in (((((E11 + E12) + (E28 + (E29 + E45))) + ((E46 + E62) + (E63 + (E79 + E80)))) + (((E96 + E97) + (E113 + (E114 + E130))) + ((E131 + E148) + (E149 + (E165 + E166)))))) implies e.ev = {i: range5 | loop5 in (range5 - e.target.av)}
all e: used | e.fiber in (((((E13 + E14) + (E30 + (E31 + E47))) + ((E48 + E64) + (E65 + (E81 + E82)))) + (((E98 + E99) + (E115 + (E116 + E132))) + ((E133 + E150) + (E151 + (E167 + E168)))))) implies e.ev = {i: range5 | some (loop5 & (e.target.av))}
all e: used | e.fiber in (((((E15 + E16) + (E32 + (E33 + E49))) + ((E50 + E66) + (E67 + (E83 + E84)))) + (((E100 + E101) + (E117 + (E118 + E134))) + ((E135 + E152) + (E153 + (E169 + E170)))))) implies e.ev = {i: range5 | some (loop5 & (range5 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range5 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range5 | some (i.future5 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range5 | i.future5 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range5 - left[a].ev) + right[a].ev)
}
fun range6: set Pos { (((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) + (((P8 + P9) + (P10 + P11)) + ((P12 + P13) + (P14 + P15)))) + ((((P16 + P17) + (P18 + P19)) + ((P20 + P21) + (P22 + P23))) + (((P24 + P25) + (P26 + P27)) + ((P28 + P29) + (P30 + P31))))) }
fun loop6: set Pos { ((P28 + P29) + (P30 + P31)) }
fun next6: Pos -> Pos { (((((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P8))) + (((P8->P9 + P9->P10) + (P10->P11 + P11->P12)) + ((P12->P13 + P13->P14) + (P14->P15 + P15->P16)))) + ((((P16->P17 + P17->P18) + (P18->P19 + P19->P20)) + ((P20->P21 + P21->P22) + (P22->P23 + P23->P24))) + (((P24->P25 + P25->P26) + (P26->P27 + P27->P28)) + ((P28->P29 + P29->P30) + (P30->P31 + P31->P28))))) }
fun future6: Pos -> Pos { (*next6) & (range6->range6) }
fun shift6_0: Pos -> Pos { (((((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) + (((P8->P8 + P9->P9) + (P10->P10 + P11->P11)) + ((P12->P12 + P13->P13) + (P14->P14 + P15->P15)))) + ((((P16->P16 + P17->P17) + (P18->P18 + P19->P19)) + ((P20->P20 + P21->P21) + (P22->P22 + P23->P23))) + (((P24->P24 + P25->P25) + (P26->P26 + P27->P27)) + ((P28->P28 + P29->P29) + (P30->P30 + P31->P31))))) }
pred semantics6[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range6
ev in used->range6
all e: used | e.fiber in (((((E0 + E1) + (E17 + (E18 + E34))) + ((E35 + E51) + (E52 + (E68 + E69)))) + (((E85 + E86) + (E102 + (E103 + E119))) + ((E120 + E136) + (E137 + (E154 + E155)))))) implies e.ev = {i: range6 | (i.shift6_0) in (e.target.av)}
all e: used | e.fiber in ((((E2 + E19) + (E36 + (E53 + E70))) + ((E87 + E104) + (E121 + (E138 + E156))))) implies e.ev = {i: range6 | (i.shift6_0) in (range6 - e.target.av)}
all e: used | e.fiber in (((((E3 + E4) + (E20 + (E21 + E37))) + ((E38 + E54) + (E55 + (E71 + E72)))) + (((E88 + E89) + (E105 + (E106 + E122))) + ((E123 + E139) + (E140 + (E157 + E158)))))) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (e.target.av))}
all e: used | e.fiber in (((((E5 + E6) + (E22 + (E23 + E39))) + ((E40 + E56) + (E57 + (E73 + E74)))) + (((E90 + E91) + (E107 + (E108 + E124))) + ((E125 + E141) + (E142 + (E159 + E160)))))) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (range6 - e.target.av))}
all e: used | e.fiber in ((((E7 + E24) + (E41 + (E58 + E75))) + ((E92 + (E109 + E126)) + (E143 + (E144 + E161))))) implies e.ev = {i: range6 | (i.shift6_0).future6 in (e.target.av)}
all e: used | e.fiber in ((((E8 + E25) + (E42 + (E59 + E76))) + ((E93 + E110) + (E127 + (E145 + E162))))) implies e.ev = {i: range6 | (i.shift6_0).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (((((E9 + E10) + (E26 + (E27 + E43))) + ((E44 + E60) + (E61 + (E77 + E78)))) + (((E94 + E95) + (E111 + (E112 + E128))) + ((E129 + E146) + (E147 + (E163 + E164)))))) implies e.ev = {i: range6 | loop6 in (e.target.av)}
all e: used | e.fiber in (((((E11 + E12) + (E28 + (E29 + E45))) + ((E46 + E62) + (E63 + (E79 + E80)))) + (((E96 + E97) + (E113 + (E114 + E130))) + ((E131 + E148) + (E149 + (E165 + E166)))))) implies e.ev = {i: range6 | loop6 in (range6 - e.target.av)}
all e: used | e.fiber in (((((E13 + E14) + (E30 + (E31 + E47))) + ((E48 + E64) + (E65 + (E81 + E82)))) + (((E98 + E99) + (E115 + (E116 + E132))) + ((E133 + E150) + (E151 + (E167 + E168)))))) implies e.ev = {i: range6 | some (loop6 & (e.target.av))}
all e: used | e.fiber in (((((E15 + E16) + (E32 + (E33 + E49))) + ((E50 + E66) + (E67 + (E83 + E84)))) + (((E100 + E101) + (E117 + (E118 + E134))) + ((E135 + E152) + (E153 + (E169 + E170)))))) implies e.ev = {i: range6 | some (loop6 & (range6 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range6 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range6 | some (i.future6 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range6 | i.future6 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range6 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (((P8 + (P9 + P10)) + ((P11 + P12) + (P13 + P14))))
all a: lab.T1 | a.av0 = ((((P2 + P3) + (P4 + P5)) + ((P6 + P11) + (P12 + (P13 + P14)))))
all a: lab.T2 | a.av0 = ((P1 + (P9 + P10)))
all a: lab.T3 | a.av0 = ((P2 + P11))
all a: lab.T4 | a.av0 = (((P3 + P12) + (P13 + P14)))
all a: lab.T5 | a.av0 = ((P5 + P6))
all a: lab.T6 | a.av0 = ((P10 + P11))
all a: lab.T7 | a.av0 = (P13)
all a: lab.T8 | a.av0 = (((P0 + (P1 + P2)) + (P3 + (P4 + P5))))
all a: lab.T9 | a.av0 = ((P6 + P7))
all a: lab.T10 | a.av0 = ((P8 + P9))
all a: lab.T11 | a.av0 = ((P10 + (P11 + P12)))
all a: lab.T12 | a.av0 = (P14)
all a: lab.T13 | a.av0 = (P4)
all a: lab.T14 | a.av0 = ((P0 + (P7 + P8)))
(R->P0 in ev0)
semantics0[av1, ev1]
all a: lab.T0 | a.av1 = ((((P2 + P3) + (P4 + P5)) + ((P6 + P7) + (P8 + (P13 + P14)))))
all a: lab.T1 | a.av1 = ((((P7 + P8) + (P9 + P10)) + ((P11 + P12) + (P13 + P14))))
all a: lab.T2 | a.av1 = (P6)
all a: lab.T3 | a.av1 = (P7)
all a: lab.T4 | a.av1 = ((P8 + P9))
all a: lab.T5 | a.av1 = ((P12 + (P13 + P14)))
all a: lab.T6 | a.av1 = (((P3 + (P4 + P5)) + (P6 + (P7 + P14))))
all a: lab.T7 | a.av1 = (P4)
all a: lab.T8 | a.av1 = ((P0 + (P9 + P10)))
all a: lab.T9 | a.av1 = ((P1 + (P11 + P12)))
all a: lab.T10 | a.av1 = ((P2 + P13))
all a: lab.T11 | a.av1 = ((P3 + P14))
all a: lab.T12 | a.av1 = (((P5 + P6) + (P7 + P8)))
all a: lab.T13 | a.av1 = ((P10 + P11))
all a: lab.T14 | a.av1 = (((P0 + (P1 + P2)) + (P3 + (P4 + P5))))
(R->P0 in ev1)
semantics0[av2, ev2]
all a: lab.T0 | a.av2 = (((P2 + (P3 + P4)) + ((P5 + P6) + (P7 + P14))))
all a: lab.T1 | a.av2 = (((P7 + (P8 + P9)) + (P10 + (P11 + P12))))
all a: lab.T2 | a.av2 = ((P4 + (P5 + P6)))
all a: lab.T3 | a.av2 = ((P7 + (P8 + P9)))
all a: lab.T4 | a.av2 = (P10)
all a: lab.T5 | a.av2 = (P12)
all a: lab.T6 | a.av2 = ((((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T7 | a.av2 = (P5)
all a: lab.T8 | a.av2 = ((P0 + P8))
all a: lab.T9 | a.av2 = (((P1 + (P9 + P10)) + (P11 + (P12 + P13))))
all a: lab.T10 | a.av2 = ((P2 + P14))
all a: lab.T11 | a.av2 = ((P3 + P4))
all a: lab.T12 | a.av2 = ((P6 + P7))
all a: lab.T13 | a.av2 = (P11)
all a: lab.T14 | a.av2 = (((P0 + (P1 + P2)) + (P3 + (P13 + P14))))
(R->P0 in ev2)
semantics1[av3, ev3]
all a: lab.T0 | a.av3 = ((((P4 + P5) + (P6 + P7)) + ((P8 + P9) + (P10 + P11))))
all a: lab.T1 | a.av3 = (((P3 + (P4 + P5)) + (P6 + (P7 + P8))))
all a: lab.T2 | a.av3 = ((P2 + P13))
all a: lab.T3 | a.av3 = ((P3 + P4))
all a: lab.T4 | a.av3 = ((P5 + P6))
all a: lab.T5 | a.av3 = (P8)
all a: lab.T6 | a.av3 = ((((P0 + (P1 + P2)) + (P3 + (P4 + P6))) + ((P7 + (P8 + P9)) + ((P10 + P11) + (P12 + P13)))))
all a: lab.T7 | a.av3 = (P10)
all a: lab.T8 | a.av3 = ((P0 + (P12 + P13)))
all a: lab.T9 | a.av3 = ((P1 + (P2 + P3)))
all a: lab.T10 | a.av3 = ((P4 + P5))
all a: lab.T11 | a.av3 = (((P6 + P7) + (P8 + P9)))
all a: lab.T12 | a.av3 = (P11)
all a: lab.T13 | a.av3 = (P7)
all a: lab.T14 | a.av3 = (((P0 + (P1 + P9)) + (P10 + (P11 + P12))))
(R->P0 in ev3)
semantics0[av4, ev4]
all a: lab.T0 | a.av4 = ((((P2 + P3) + (P4 + (P5 + P6))) + ((P10 + P11) + (P12 + (P13 + P14)))))
all a: lab.T1 | a.av4 = (((P8 + (P9 + P10)) + ((P11 + P12) + (P13 + P14))))
all a: lab.T2 | a.av4 = ((P6 + P7))
all a: lab.T3 | a.av4 = ((P8 + (P9 + P10)))
all a: lab.T4 | a.av4 = ((P11 + P12))
all a: lab.T5 | a.av4 = (P14)
all a: lab.T6 | a.av4 = ((((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) + ((P7 + (P8 + P9)) + ((P10 + P12) + (P13 + P14)))))
all a: lab.T7 | a.av4 = (P4)
all a: lab.T8 | a.av4 = ((P0 + (P7 + P8)))
all a: lab.T9 | a.av4 = ((P1 + P9))
all a: lab.T10 | a.av4 = ((P2 + (P10 + P11)))
all a: lab.T11 | a.av4 = (((P3 + P12) + (P13 + P14)))
all a: lab.T12 | a.av4 = ((P5 + P6))
all a: lab.T13 | a.av4 = (P13)
all a: lab.T14 | a.av4 = (((P0 + (P1 + P2)) + (P3 + (P4 + P5))))
(R->P0 in ev4)
semantics1[av5, ev5]
all a: lab.T0 | a.av5 = ((((P6 + P7) + (P8 + P9)) + ((P10 + P11) + (P12 + P13))))
all a: lab.T1 | a.av5 = ((((P2 + P3) + (P4 + P5)) + ((P6 + P7) + (P8 + (P12 + P13)))))
all a: lab.T2 | a.av5 = ((P1 + (P10 + P11)))
all a: lab.T3 | a.av5 = ((P2 + (P12 + P13)))
all a: lab.T4 | a.av5 = ((P3 + P4))
all a: lab.T5 | a.av5 = (P8)
all a: lab.T6 | a.av5 = ((((P0 + P1) + (P2 + (P7 + P8))) + ((P9 + P10) + (P11 + (P12 + P13)))))
all a: lab.T7 | a.av5 = ((P11 + P12))
all a: lab.T8 | a.av5 = (((P0 + P1) + (P2 + P3)))
all a: lab.T9 | a.av5 = ((P4 + P5))
all a: lab.T10 | a.av5 = (P6)
all a: lab.T11 | a.av5 = (((P7 + P8) + (P9 + P10)))
all a: lab.T12 | a.av5 = (P13)
all a: lab.T13 | a.av5 = ((P5 + (P6 + P7)))
all a: lab.T14 | a.av5 = ((P0 + P9))
(R->P0 in ev5)
semantics2[av6, ev6]
all a: lab.T0 | a.av6 = ((((P3 + P4) + (P5 + P6)) + ((P7 + P12) + (P13 + (P14 + P15)))))
all a: lab.T1 | a.av6 = ((((P7 + P8) + (P9 + P10)) + ((P11 + P12) + (P13 + P14))))
all a: lab.T2 | a.av6 = (((P2 + P3) + (P4 + (P5 + P6))))
all a: lab.T3 | a.av6 = ((P7 + P8))
all a: lab.T4 | a.av6 = ((P9 + P10))
all a: lab.T5 | a.av6 = ((P13 + P14))
all a: lab.T6 | a.av6 = ((((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + (P6 + P7)) + (P8 + (P14 + P15)))))
all a: lab.T7 | a.av6 = (P5)
all a: lab.T8 | a.av6 = ((P0 + (P8 + P9)))
all a: lab.T9 | a.av6 = (((P1 + P2) + (P10 + P11)))
all a: lab.T10 | a.av6 = ((P3 + (P12 + P13)))
all a: lab.T11 | a.av6 = ((P4 + (P14 + P15)))
all a: lab.T12 | a.av6 = ((P6 + P7))
all a: lab.T13 | a.av6 = ((P11 + P12))
all a: lab.T14 | a.av6 = ((P0 + (P1 + P15)))
(R->P0 in ev6)
semantics2[av7, ev7]
all a: lab.T0 | a.av7 = ((((P2 + P3) + (P4 + P5)) + ((P6 + P13) + (P14 + P15))))
all a: lab.T1 | a.av7 = (((P8 + (P9 + P10)) + (P11 + (P12 + P13))))
all a: lab.T2 | a.av7 = (((P3 + (P4 + P5)) + (P6 + (P7 + P15))))
all a: lab.T3 | a.av7 = (P8)
all a: lab.T4 | a.av7 = (P9)
all a: lab.T5 | a.av7 = ((P12 + P13))
all a: lab.T6 | a.av7 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))))
all a: lab.T7 | a.av7 = (P5)
all a: lab.T8 | a.av7 = (((P0 + P7) + (P8 + (P9 + P10))))
all a: lab.T9 | a.av7 = ((P1 + (P11 + P12)))
all a: lab.T10 | a.av7 = (((P2 + P3) + (P13 + (P14 + P15))))
all a: lab.T11 | a.av7 = (P4)
all a: lab.T12 | a.av7 = (P6)
all a: lab.T13 | a.av7 = ((P10 + P11))
all a: lab.T14 | a.av7 = (((P0 + P1) + (P2 + P14)))
(R->P0 in ev7)
semantics3[av8, ev8]
all a: lab.T0 | a.av8 = (((((P5 + P6) + (P7 + P8)) + ((P9 + P10) + (P11 + P12))) + (((P16 + P17) + (P18 + P19)) + ((P20 + P21) + (P22 + (P23 + P24))))))
all a: lab.T1 | a.av8 = ((((P2 + (P3 + P4)) + ((P5 + P6) + (P7 + P8))) + (((P9 + P10) + (P17 + P18)) + ((P19 + P20) + (P21 + P24)))))
all a: lab.T2 | a.av8 = (((P1 + P15) + (P16 + P23)))
all a: lab.T3 | a.av8 = (((P2 + P17) + (P18 + P24)))
all a: lab.T4 | a.av8 = (((P3 + (P4 + P5)) + (P6 + (P7 + P19))))
all a: lab.T5 | a.av8 = ((P9 + (P10 + P21)))
all a: lab.T6 | a.av8 = (((((P6 + P7) + (P8 + P9)) + ((P10 + P11) + (P12 + (P13 + P14)))) + (((P15 + P16) + (P17 + (P18 + P19))) + ((P20 + P21) + (P22 + (P23 + P24))))))
all a: lab.T7 | a.av8 = (((P7 + P8) + (P9 + (P10 + P11))))
all a: lab.T8 | a.av8 = (((P0 + P1) + (P2 + (P3 + P13))))
all a: lab.T9 | a.av8 = ((P4 + (P14 + P15)))
all a: lab.T10 | a.av8 = ((P5 + (P16 + P17)))
all a: lab.T11 | a.av8 = ((((P6 + P18) + (P19 + P20)) + ((P21 + P22) + (P23 + P24))))
all a: lab.T12 | a.av8 = (P12)
all a: lab.T13 | a.av8 = ((P8 + P20))
all a: lab.T14 | a.av8 = (((P0 + (P11 + P12)) + (P13 + (P14 + P22))))
not (R->P0 in ev8)
semantics4[av9, ev9]
all a: lab.T0 | a.av9 = (((((P5 + P6) + (P7 + P8)) + ((P9 + P10) + (P11 + (P12 + P16)))) + (((P17 + P18) + (P19 + P20)) + ((P21 + P22) + (P23 + (P24 + P25))))))
all a: lab.T1 | a.av9 = (((((P2 + P3) + (P4 + P5)) + ((P6 + P7) + (P8 + P9))) + (((P10 + P17) + (P18 + P19)) + ((P20 + P21) + (P24 + P25)))))
all a: lab.T2 | a.av9 = (((P1 + P15) + (P16 + P23)))
all a: lab.T3 | a.av9 = (((P2 + P17) + (P18 + (P24 + P25))))
all a: lab.T4 | a.av9 = (((P3 + (P4 + P5)) + (P6 + (P7 + P19))))
all a: lab.T5 | a.av9 = ((P9 + (P10 + P21)))
all a: lab.T6 | a.av9 = ((((P6 + (P7 + P8)) + (P9 + (P10 + P11))) + ((P12 + (P13 + P14)) + ((P15 + P16) + (P17 + P18)))))
all a: lab.T7 | a.av9 = (((P7 + P8) + (P9 + (P10 + P11))))
all a: lab.T8 | a.av9 = (((P0 + P1) + (P2 + (P3 + P13))))
all a: lab.T9 | a.av9 = ((P4 + (P14 + P15)))
all a: lab.T10 | a.av9 = ((P5 + (P16 + P17)))
all a: lab.T11 | a.av9 = ((((P6 + P18) + (P19 + P20)) + ((P21 + P22) + (P23 + (P24 + P25)))))
all a: lab.T12 | a.av9 = (P12)
all a: lab.T13 | a.av9 = ((P8 + P20))
all a: lab.T14 | a.av9 = (((P0 + (P11 + P12)) + (P13 + (P14 + P22))))
not (R->P0 in ev9)
semantics5[av10, ev10]
all a: lab.T0 | a.av10 = (((((P5 + P6) + (P7 + P8)) + ((P9 + P10) + (P11 + (P12 + P16)))) + (((P17 + P18) + (P19 + (P20 + P21))) + ((P22 + P23) + (P24 + (P25 + P26))))))
all a: lab.T1 | a.av10 = (((((P2 + P3) + (P4 + P5)) + ((P6 + P7) + (P8 + P9))) + (((P10 + P17) + (P18 + P19)) + ((P20 + P21) + (P22 + (P25 + P26))))))
all a: lab.T2 | a.av10 = (((P1 + P15) + (P16 + P24)))
all a: lab.T3 | a.av10 = (((P2 + P17) + (P18 + (P25 + P26))))
all a: lab.T4 | a.av10 = (((P3 + (P4 + P5)) + ((P6 + P7) + (P19 + P20))))
all a: lab.T5 | a.av10 = ((P9 + (P10 + P22)))
all a: lab.T6 | a.av10 = ((((P6 + (P7 + P8)) + ((P9 + P10) + (P11 + P12))) + (((P13 + P14) + (P15 + P16)) + ((P17 + P18) + (P22 + P24)))))
all a: lab.T7 | a.av10 = (((P7 + P8) + (P9 + (P10 + P11))))
all a: lab.T8 | a.av10 = (((P0 + (P1 + P2)) + (P3 + (P13 + P20))))
all a: lab.T9 | a.av10 = (((P4 + P14) + (P15 + P20)))
all a: lab.T10 | a.av10 = (((P5 + P16) + (P17 + P20)))
all a: lab.T11 | a.av10 = ((((P6 + P18) + (P19 + (P20 + P21))) + ((P22 + P23) + (P24 + (P25 + P26)))))
all a: lab.T12 | a.av10 = (P12)
all a: lab.T13 | a.av10 = ((P8 + P21))
all a: lab.T14 | a.av10 = (((P0 + (P11 + P12)) + (P13 + (P14 + P23))))
not (R->P0 in ev10)
semantics6[av11, ev11]
all a: lab.T0 | a.av11 = (((((P5 + P6) + (P7 + (P8 + P9))) + ((P10 + (P11 + P12)) + (P16 + (P17 + P18)))) + (((P19 + P20) + (P21 + (P24 + P25))) + ((P26 + (P27 + P28)) + (P29 + (P30 + P31))))))
all a: lab.T1 | a.av11 = (((((P2 + P3) + (P4 + (P5 + P6))) + ((P7 + (P8 + P9)) + (P10 + (P17 + P18)))) + (((P19 + P20) + (P21 + (P22 + P23))) + ((P24 + (P25 + P26)) + (P27 + (P30 + P31))))))
all a: lab.T2 | a.av11 = (((P1 + P15) + (P16 + P29)))
all a: lab.T3 | a.av11 = (((P2 + P17) + (P18 + (P30 + P31))))
all a: lab.T4 | a.av11 = ((((P3 + (P4 + P5)) + (P6 + (P7 + P19))) + ((P20 + (P21 + P22)) + (P23 + (P24 + P25)))))
all a: lab.T5 | a.av11 = ((P9 + (P10 + P27)))
all a: lab.T6 | a.av11 = (((((P6 + P7) + (P8 + (P9 + P10))) + ((P11 + P12) + (P13 + (P14 + P15)))) + (((P16 + P17) + (P18 + (P25 + P26))) + ((P27 + P28) + (P29 + (P30 + P31))))))
all a: lab.T7 | a.av11 = (((P7 + (P8 + P9)) + (P10 + (P11 + P20))))
all a: lab.T8 | a.av11 = (((P0 + (P1 + P2)) + (P3 + (P13 + P22))))
all a: lab.T9 | a.av11 = (((P4 + P14) + (P15 + P23)))
all a: lab.T10 | a.av11 = (((P5 + P16) + (P17 + P24)))
all a: lab.T11 | a.av11 = ((((P6 + P18) + (P19 + (P25 + P26))) + ((P27 + P28) + (P29 + (P30 + P31)))))
all a: lab.T12 | a.av11 = ((P12 + P21))
all a: lab.T13 | a.av11 = ((P8 + P26))
all a: lab.T14 | a.av11 = (((P0 + (P11 + P12)) + (P13 + (P14 + P28))))
not (R->P0 in ev11)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int

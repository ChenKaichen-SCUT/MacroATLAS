abstract sig Unit {}
one sig U0, U1, U2, U3, U4 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20 extends Label {}
abstract sig Q {}
one sig Q0, Q1, Q2, Q3, Q4 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E26, E27, E28, E29, E30, E31, E32, E33, E34, E35, E36, E37, E38, E39, E40, E41, E42, E43, E44, E45, E46, E47, E48, E49, E50, E51, E52, E53, E54, E55, E56, E57, E58, E59, E60, E61, E62, E63, E64, E65, E66 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17, P18, P19, P20, P21, P22, P23, P24, P25, P26, P27, P28, P29, P30, P31 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos }
one sig A0, A1, A2, A3, A4 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (((T0 + (T1 + T2)) + ((T3 + T4) + (T5 + T6))) + (((T7 + T8) + (T9 + T10)) + ((T11 + T12) + (T13 + T14)))) }
fun un: set Label { (T15 + (T16 + T17)) }
fun bin: set Label { (T18 + (T19 + T20)) }
fun nonempty: set Fiber { (((((E1 + (E2 + E3)) + ((E4 + E5) + (E6 + E7))) + (((E8 + E9) + (E10 + E12)) + ((E13 + E14) + (E15 + E16)))) + ((((E17 + E18) + (E19 + E20)) + ((E21 + E23) + (E24 + E25))) + (((E26 + E27) + (E28 + E29)) + ((E30 + E31) + (E32 + E34))))) + ((((E35 + (E36 + E37)) + ((E38 + E39) + (E40 + E41))) + (((E42 + E43) + (E44 + E45)) + ((E46 + E47) + (E48 + E49)))) + ((((E51 + E52) + (E53 + E54)) + ((E55 + E56) + (E57 + E58))) + (((E59 + E60) + (E61 + E62)) + ((E63 + E64) + (E65 + E66)))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { ((U0->U1 + U1->U2) + (U2->U3 + U3->U4)) }
fun carrierNext: Carrier -> Carrier { ((((A0->A1 + A1->A2) + (A2->A3 + (A3->A4 + A4->R))) + ((R->C0 + C0->L0) + (L0->D0 + (D0->C1 + C1->L1)))) + (((L1->D1 + D1->C2) + (C2->L2 + (L2->D2 + D2->C3))) + ((C3->L3 + L3->D3) + (D3->C4 + (C4->L4 + L4->D4))))) }
fun child[a: Anchor]: set Port { a.(((A0->C0 + A1->C1) + (A2->C2 + (A3->C3 + A4->C4)))) }
fun left[a: Anchor]: set Port { a.(((A0->L0 + A1->L1) + (A2->L2 + (A3->L3 + A4->L4)))) }
fun right[a: Anchor]: set Port { a.(((A0->D0 + A1->D1) + (A2->D2 + (A3->D3 + A4->D4)))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
no iden & ^graph
active = R.target.*graph
R.fiber not in nonempty
R.target.lab = T17
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
no A3.graph & (((A0 + A1) + (A2 + A3)))
no A4.graph & (((A0 + A1) + (A2 + (A3 + A4))))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
lone lab.T2
lone lab.T3
lone lab.T4
lone lab.T5
lone lab.T6
lone lab.T7
lone lab.T8
lone lab.T9
lone lab.T10
lone lab.T11
lone lab.T12
lone lab.T13
lone lab.T14
some A0.lab and A0.lab in un and R.target != A0 implies #(target.A0) > 1
some A1.lab and A1.lab in un and R.target != A1 implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un and R.target != A2 implies #(target.A2) > 1
some A2.lab implies some A1.lab
some A3.lab and A3.lab in un and R.target != A3 implies #(target.A3) > 1
some A3.lab implies some A2.lab
some A4.lab and A4.lab in un and R.target != A4 implies #(target.A4) > 1
some A4.lab implies some A3.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q0
E7.qo = Q0
E8.qi = Q0
E8.qo = Q0
E9.qi = Q0
E9.qo = Q0
E10.qi = Q0
E10.qo = Q0
E11.qi = Q1
E11.qo = Q1
E12.qi = Q1
E12.qo = Q1
E13.qi = Q1
E13.qo = Q1
E14.qi = Q1
E14.qo = Q1
E15.qi = Q1
E15.qo = Q1
E16.qi = Q1
E16.qo = Q1
E17.qi = Q1
E17.qo = Q1
E18.qi = Q1
E18.qo = Q1
E19.qi = Q1
E19.qo = Q1
E20.qi = Q1
E20.qo = Q1
E21.qi = Q1
E21.qo = Q1
E22.qi = Q2
E22.qo = Q2
E23.qi = Q2
E23.qo = Q2
E24.qi = Q2
E24.qo = Q2
E25.qi = Q2
E25.qo = Q2
E26.qi = Q2
E26.qo = Q2
E27.qi = Q2
E27.qo = Q2
E28.qi = Q2
E28.qo = Q2
E29.qi = Q2
E29.qo = Q2
E30.qi = Q2
E30.qo = Q2
E31.qi = Q2
E31.qo = Q2
E32.qi = Q2
E32.qo = Q2
E33.qi = Q3
E33.qo = Q3
E34.qi = Q3
E34.qo = Q3
E35.qi = Q3
E35.qo = Q3
E36.qi = Q3
E36.qo = Q3
E37.qi = Q3
E37.qo = Q3
E38.qi = Q3
E38.qo = Q3
E39.qi = Q3
E39.qo = Q4
E40.qi = Q3
E40.qo = Q3
E41.qi = Q3
E41.qo = Q4
E42.qi = Q3
E42.qo = Q3
E43.qi = Q3
E43.qo = Q4
E44.qi = Q3
E44.qo = Q3
E45.qi = Q3
E45.qo = Q4
E46.qi = Q3
E46.qo = Q3
E47.qi = Q3
E47.qo = Q4
E48.qi = Q3
E48.qo = Q3
E49.qi = Q3
E49.qo = Q4
E50.qi = Q4
E50.qo = Q4
E51.qi = Q4
E51.qo = Q3
E52.qi = Q4
E52.qo = Q3
E53.qi = Q4
E53.qo = Q3
E54.qi = Q4
E54.qo = Q3
E55.qi = Q4
E55.qo = Q3
E56.qi = Q4
E56.qo = Q4
E57.qi = Q4
E57.qo = Q3
E58.qi = Q4
E58.qo = Q4
E59.qi = Q4
E59.qo = Q3
E60.qi = Q4
E60.qo = Q4
E61.qi = Q4
E61.qo = Q3
E62.qi = Q4
E62.qo = Q4
E63.qi = Q4
E63.qo = Q3
E64.qi = Q4
E64.qo = Q4
E65.qi = Q4
E65.qo = Q3
E66.qi = Q4
E66.qo = Q4
all e: used | e.fiber in (((E0 + E11) + (E22 + (E33 + E50)))) implies #e.cost = 0
all e: used | e.fiber in (((((E1 + (E4 + E6)) + (E7 + (E9 + E12))) + ((E15 + (E17 + E18)) + ((E20 + E23) + (E26 + E28)))) + (((E29 + (E31 + E34)) + ((E37 + E40) + (E41 + E42))) + ((E47 + (E51 + E54)) + ((E57 + E58) + (E59 + E64)))))) implies #e.cost = 2
all e: used | e.fiber in ((((E2 + (E3 + E5)) + ((E13 + E14) + (E16 + E24))) + (((E25 + E27) + (E35 + E36)) + ((E39 + E52) + (E53 + E56))))) implies #e.cost = 1
all e: used | e.fiber in (((((E8 + E10) + (E19 + E21)) + ((E30 + E32) + (E38 + (E43 + E44)))) + (((E46 + E48) + (E49 + E55)) + ((E60 + E61) + (E63 + (E65 + E66)))))) implies #e.cost = 3
all e: used | e.fiber in ((E45 + E62)) implies #e.cost = 4
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q4)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 implies a.state = Q0
all a: active | a.lab = T3 implies a.state = Q0
all a: active | a.lab = T4 implies a.state = Q0
all a: active | a.lab = T5 implies a.state = Q0
all a: active | a.lab = T6 implies a.state = Q0
all a: active | a.lab = T7 implies a.state = Q1
all a: active | a.lab = T8 implies a.state = Q0
all a: active | a.lab = T9 implies a.state = Q0
all a: active | a.lab = T10 implies a.state = Q0
all a: active | a.lab = T11 implies a.state = Q0
all a: active | a.lab = T12 implies a.state = Q0
all a: active | a.lab = T13 implies a.state = Q2
all a: active | a.lab = T14 implies a.state = Q0
all a: active | a.lab = T15 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T15 and child[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T15 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T15 and child[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T15 and child[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T16 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T16 and child[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T16 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T16 and child[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T16 and child[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T17 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T17 and child[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T17 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T17 and child[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T17 and child[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q0 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T18 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q0 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T19 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q0 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T20 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q4 implies a.state = Q3
all a: lab.bin | no left[a].target.*graph & right[a].target.*graph & lab.lit
}
fun range0: set Pos { (((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) + (((P7 + P8) + (P9 + P10)) + ((P11 + P12) + (P13 + P14)))) }
fun loop0: set Pos { (((P3 + (P4 + P5)) + (P6 + (P7 + P8))) + ((P9 + (P10 + P11)) + (P12 + (P13 + P14)))) }
fun next0: Pos -> Pos { (((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P7))) + (((P7->P8 + P8->P9) + (P9->P10 + P10->P11)) + ((P11->P12 + P12->P13) + (P13->P14 + P14->P3)))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { (((P0->P0 + (P1->P1 + P2->P2)) + ((P3->P3 + P4->P4) + (P5->P5 + P6->P6))) + (((P7->P7 + P8->P8) + (P9->P9 + P10->P10)) + ((P11->P11 + P12->P12) + (P13->P13 + P14->P14)))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in ((((E0 + E1) + (E11 + (E12 + E22))) + ((E23 + E33) + (E34 + (E50 + E51))))) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E13) + (E24 + (E35 + E52)))) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in (((E3 + E14) + (E25 + (E36 + E53)))) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in (((E4 + E15) + (E26 + (E37 + E54)))) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (((E5 + (E16 + E27)) + ((E38 + E39) + (E55 + E56)))) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in (((E6 + (E17 + E28)) + ((E40 + E41) + (E57 + E58)))) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (((E7 + (E18 + E29)) + ((E42 + E43) + (E59 + E60)))) implies e.ev = {i: range0 | loop0 in (e.target.av)}
all e: used | e.fiber in (((E8 + (E19 + E30)) + ((E44 + E45) + (E61 + E62)))) implies e.ev = {i: range0 | loop0 in (range0 - e.target.av)}
all e: used | e.fiber in (((E9 + (E20 + E31)) + ((E46 + E47) + (E63 + E64)))) implies e.ev = {i: range0 | some (loop0 & (e.target.av))}
all e: used | e.fiber in (((E10 + (E21 + E32)) + ((E48 + E49) + (E65 + E66)))) implies e.ev = {i: range0 | some (loop0 & (range0 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { (((P0 + (P1 + P2)) + (P3 + (P4 + P5))) + ((P6 + (P7 + P8)) + (P9 + (P10 + P11)))) }
fun loop1: set Pos { (((P0 + (P1 + P2)) + (P3 + (P4 + P5))) + ((P6 + (P7 + P8)) + (P9 + (P10 + P11)))) }
fun next1: Pos -> Pos { (((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P6))) + ((P6->P7 + (P7->P8 + P8->P9)) + (P9->P10 + (P10->P11 + P11->P0)))) }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { (((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) + ((P6->P6 + (P7->P7 + P8->P8)) + (P9->P9 + (P10->P10 + P11->P11)))) }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in ((((E0 + E1) + (E11 + (E12 + E22))) + ((E23 + E33) + (E34 + (E50 + E51))))) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E13) + (E24 + (E35 + E52)))) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in (((E3 + E14) + (E25 + (E36 + E53)))) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in (((E4 + E15) + (E26 + (E37 + E54)))) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (((E5 + (E16 + E27)) + ((E38 + E39) + (E55 + E56)))) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in (((E6 + (E17 + E28)) + ((E40 + E41) + (E57 + E58)))) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (((E7 + (E18 + E29)) + ((E42 + E43) + (E59 + E60)))) implies e.ev = {i: range1 | loop1 in (e.target.av)}
all e: used | e.fiber in (((E8 + (E19 + E30)) + ((E44 + E45) + (E61 + E62)))) implies e.ev = {i: range1 | loop1 in (range1 - e.target.av)}
all e: used | e.fiber in (((E9 + (E20 + E31)) + ((E46 + E47) + (E63 + E64)))) implies e.ev = {i: range1 | some (loop1 & (e.target.av))}
all e: used | e.fiber in (((E10 + (E21 + E32)) + ((E48 + E49) + (E65 + E66)))) implies e.ev = {i: range1 | some (loop1 & (range1 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fun range2: set Pos { ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) + (((P8 + P9) + (P10 + P11)) + ((P12 + P13) + (P14 + P15)))) }
fun loop2: set Pos { (((P4 + (P5 + P6)) + (P7 + (P8 + P9))) + ((P10 + (P11 + P12)) + (P13 + (P14 + P15)))) }
fun next2: Pos -> Pos { ((((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P8))) + (((P8->P9 + P9->P10) + (P10->P11 + P11->P12)) + ((P12->P13 + P13->P14) + (P14->P15 + P15->P4)))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) + (((P8->P8 + P9->P9) + (P10->P10 + P11->P11)) + ((P12->P12 + P13->P13) + (P14->P14 + P15->P15)))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in ((((E0 + E1) + (E11 + (E12 + E22))) + ((E23 + E33) + (E34 + (E50 + E51))))) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E13) + (E24 + (E35 + E52)))) implies e.ev = {i: range2 | (i.shift2_0) in (range2 - e.target.av)}
all e: used | e.fiber in (((E3 + E14) + (E25 + (E36 + E53)))) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (e.target.av))}
all e: used | e.fiber in (((E4 + E15) + (E26 + (E37 + E54)))) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (((E5 + (E16 + E27)) + ((E38 + E39) + (E55 + E56)))) implies e.ev = {i: range2 | (i.shift2_0).future2 in (e.target.av)}
all e: used | e.fiber in (((E6 + (E17 + E28)) + ((E40 + E41) + (E57 + E58)))) implies e.ev = {i: range2 | (i.shift2_0).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (((E7 + (E18 + E29)) + ((E42 + E43) + (E59 + E60)))) implies e.ev = {i: range2 | loop2 in (e.target.av)}
all e: used | e.fiber in (((E8 + (E19 + E30)) + ((E44 + E45) + (E61 + E62)))) implies e.ev = {i: range2 | loop2 in (range2 - e.target.av)}
all e: used | e.fiber in (((E9 + (E20 + E31)) + ((E46 + E47) + (E63 + E64)))) implies e.ev = {i: range2 | some (loop2 & (e.target.av))}
all e: used | e.fiber in (((E10 + (E21 + E32)) + ((E48 + E49) + (E65 + E66)))) implies e.ev = {i: range2 | some (loop2 & (range2 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range2 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range2 | some (i.future2 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range2 | i.future2 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range2 - left[a].ev) + right[a].ev)
}
fun range3: set Pos { ((((P0 + (P1 + P2)) + (P3 + (P4 + P5))) + ((P6 + (P7 + P8)) + (P9 + (P10 + P11)))) + (((P12 + (P13 + P14)) + (P15 + (P16 + P17))) + ((P18 + (P19 + P20)) + ((P21 + P22) + (P23 + P24))))) }
fun loop3: set Pos { ((P18 + (P19 + P20)) + ((P21 + P22) + (P23 + P24))) }
fun next3: Pos -> Pos { ((((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P6))) + ((P6->P7 + (P7->P8 + P8->P9)) + (P9->P10 + (P10->P11 + P11->P12)))) + (((P12->P13 + (P13->P14 + P14->P15)) + (P15->P16 + (P16->P17 + P17->P18))) + ((P18->P19 + (P19->P20 + P20->P21)) + ((P21->P22 + P22->P23) + (P23->P24 + P24->P18))))) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { ((((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) + ((P6->P6 + (P7->P7 + P8->P8)) + (P9->P9 + (P10->P10 + P11->P11)))) + (((P12->P12 + (P13->P13 + P14->P14)) + (P15->P15 + (P16->P16 + P17->P17))) + ((P18->P18 + (P19->P19 + P20->P20)) + ((P21->P21 + P22->P22) + (P23->P23 + P24->P24))))) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in ((((E0 + E1) + (E11 + (E12 + E22))) + ((E23 + E33) + (E34 + (E50 + E51))))) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E13) + (E24 + (E35 + E52)))) implies e.ev = {i: range3 | (i.shift3_0) in (range3 - e.target.av)}
all e: used | e.fiber in (((E3 + E14) + (E25 + (E36 + E53)))) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (e.target.av))}
all e: used | e.fiber in (((E4 + E15) + (E26 + (E37 + E54)))) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (((E5 + (E16 + E27)) + ((E38 + E39) + (E55 + E56)))) implies e.ev = {i: range3 | (i.shift3_0).future3 in (e.target.av)}
all e: used | e.fiber in (((E6 + (E17 + E28)) + ((E40 + E41) + (E57 + E58)))) implies e.ev = {i: range3 | (i.shift3_0).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (((E7 + (E18 + E29)) + ((E42 + E43) + (E59 + E60)))) implies e.ev = {i: range3 | loop3 in (e.target.av)}
all e: used | e.fiber in (((E8 + (E19 + E30)) + ((E44 + E45) + (E61 + E62)))) implies e.ev = {i: range3 | loop3 in (range3 - e.target.av)}
all e: used | e.fiber in (((E9 + (E20 + E31)) + ((E46 + E47) + (E63 + E64)))) implies e.ev = {i: range3 | some (loop3 & (e.target.av))}
all e: used | e.fiber in (((E10 + (E21 + E32)) + ((E48 + E49) + (E65 + E66)))) implies e.ev = {i: range3 | some (loop3 & (range3 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range3 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range3 | some (i.future3 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range3 | i.future3 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range3 - left[a].ev) + right[a].ev)
}
fun range4: set Pos { ((((P0 + (P1 + P2)) + (P3 + (P4 + P5))) + ((P6 + (P7 + P8)) + ((P9 + P10) + (P11 + P12)))) + (((P13 + (P14 + P15)) + (P16 + (P17 + P18))) + ((P19 + (P20 + P21)) + ((P22 + P23) + (P24 + P25))))) }
fun loop4: set Pos { ((P19 + (P20 + P21)) + ((P22 + P23) + (P24 + P25))) }
fun next4: Pos -> Pos { ((((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P6))) + ((P6->P7 + (P7->P8 + P8->P9)) + ((P9->P10 + P10->P11) + (P11->P12 + P12->P13)))) + (((P13->P14 + (P14->P15 + P15->P16)) + (P16->P17 + (P17->P18 + P18->P19))) + ((P19->P20 + (P20->P21 + P21->P22)) + ((P22->P23 + P23->P24) + (P24->P25 + P25->P19))))) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { ((((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) + ((P6->P6 + (P7->P7 + P8->P8)) + ((P9->P9 + P10->P10) + (P11->P11 + P12->P12)))) + (((P13->P13 + (P14->P14 + P15->P15)) + (P16->P16 + (P17->P17 + P18->P18))) + ((P19->P19 + (P20->P20 + P21->P21)) + ((P22->P22 + P23->P23) + (P24->P24 + P25->P25))))) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in ((((E0 + E1) + (E11 + (E12 + E22))) + ((E23 + E33) + (E34 + (E50 + E51))))) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E13) + (E24 + (E35 + E52)))) implies e.ev = {i: range4 | (i.shift4_0) in (range4 - e.target.av)}
all e: used | e.fiber in (((E3 + E14) + (E25 + (E36 + E53)))) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (e.target.av))}
all e: used | e.fiber in (((E4 + E15) + (E26 + (E37 + E54)))) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (((E5 + (E16 + E27)) + ((E38 + E39) + (E55 + E56)))) implies e.ev = {i: range4 | (i.shift4_0).future4 in (e.target.av)}
all e: used | e.fiber in (((E6 + (E17 + E28)) + ((E40 + E41) + (E57 + E58)))) implies e.ev = {i: range4 | (i.shift4_0).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (((E7 + (E18 + E29)) + ((E42 + E43) + (E59 + E60)))) implies e.ev = {i: range4 | loop4 in (e.target.av)}
all e: used | e.fiber in (((E8 + (E19 + E30)) + ((E44 + E45) + (E61 + E62)))) implies e.ev = {i: range4 | loop4 in (range4 - e.target.av)}
all e: used | e.fiber in (((E9 + (E20 + E31)) + ((E46 + E47) + (E63 + E64)))) implies e.ev = {i: range4 | some (loop4 & (e.target.av))}
all e: used | e.fiber in (((E10 + (E21 + E32)) + ((E48 + E49) + (E65 + E66)))) implies e.ev = {i: range4 | some (loop4 & (range4 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range4 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range4 | some (i.future4 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range4 | i.future4 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range4 - left[a].ev) + right[a].ev)
}
fun range5: set Pos { ((((P0 + (P1 + P2)) + (P3 + (P4 + P5))) + ((P6 + (P7 + P8)) + ((P9 + P10) + (P11 + P12)))) + (((P13 + (P14 + P15)) + ((P16 + P17) + (P18 + P19))) + ((P20 + (P21 + P22)) + ((P23 + P24) + (P25 + P26))))) }
fun loop5: set Pos { (((P19 + P20) + (P21 + P22)) + ((P23 + P24) + (P25 + P26))) }
fun next5: Pos -> Pos { ((((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P6))) + ((P6->P7 + (P7->P8 + P8->P9)) + ((P9->P10 + P10->P11) + (P11->P12 + P12->P13)))) + (((P13->P14 + (P14->P15 + P15->P16)) + ((P16->P17 + P17->P18) + (P18->P19 + P19->P20))) + ((P20->P21 + (P21->P22 + P22->P23)) + ((P23->P24 + P24->P25) + (P25->P26 + P26->P19))))) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { ((((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) + ((P6->P6 + (P7->P7 + P8->P8)) + ((P9->P9 + P10->P10) + (P11->P11 + P12->P12)))) + (((P13->P13 + (P14->P14 + P15->P15)) + ((P16->P16 + P17->P17) + (P18->P18 + P19->P19))) + ((P20->P20 + (P21->P21 + P22->P22)) + ((P23->P23 + P24->P24) + (P25->P25 + P26->P26))))) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in ((((E0 + E1) + (E11 + (E12 + E22))) + ((E23 + E33) + (E34 + (E50 + E51))))) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E13) + (E24 + (E35 + E52)))) implies e.ev = {i: range5 | (i.shift5_0) in (range5 - e.target.av)}
all e: used | e.fiber in (((E3 + E14) + (E25 + (E36 + E53)))) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (e.target.av))}
all e: used | e.fiber in (((E4 + E15) + (E26 + (E37 + E54)))) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (((E5 + (E16 + E27)) + ((E38 + E39) + (E55 + E56)))) implies e.ev = {i: range5 | (i.shift5_0).future5 in (e.target.av)}
all e: used | e.fiber in (((E6 + (E17 + E28)) + ((E40 + E41) + (E57 + E58)))) implies e.ev = {i: range5 | (i.shift5_0).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (((E7 + (E18 + E29)) + ((E42 + E43) + (E59 + E60)))) implies e.ev = {i: range5 | loop5 in (e.target.av)}
all e: used | e.fiber in (((E8 + (E19 + E30)) + ((E44 + E45) + (E61 + E62)))) implies e.ev = {i: range5 | loop5 in (range5 - e.target.av)}
all e: used | e.fiber in (((E9 + (E20 + E31)) + ((E46 + E47) + (E63 + E64)))) implies e.ev = {i: range5 | some (loop5 & (e.target.av))}
all e: used | e.fiber in (((E10 + (E21 + E32)) + ((E48 + E49) + (E65 + E66)))) implies e.ev = {i: range5 | some (loop5 & (range5 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range5 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range5 | some (i.future5 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range5 | i.future5 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range5 - left[a].ev) + right[a].ev)
}
fun range6: set Pos { (((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) + (((P8 + P9) + (P10 + P11)) + ((P12 + P13) + (P14 + P15)))) + ((((P16 + P17) + (P18 + P19)) + ((P20 + P21) + (P22 + P23))) + (((P24 + P25) + (P26 + P27)) + ((P28 + P29) + (P30 + P31))))) }
fun loop6: set Pos { ((P28 + P29) + (P30 + P31)) }
fun next6: Pos -> Pos { (((((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P8))) + (((P8->P9 + P9->P10) + (P10->P11 + P11->P12)) + ((P12->P13 + P13->P14) + (P14->P15 + P15->P16)))) + ((((P16->P17 + P17->P18) + (P18->P19 + P19->P20)) + ((P20->P21 + P21->P22) + (P22->P23 + P23->P24))) + (((P24->P25 + P25->P26) + (P26->P27 + P27->P28)) + ((P28->P29 + P29->P30) + (P30->P31 + P31->P28))))) }
fun future6: Pos -> Pos { (*next6) & (range6->range6) }
fun shift6_0: Pos -> Pos { (((((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) + (((P8->P8 + P9->P9) + (P10->P10 + P11->P11)) + ((P12->P12 + P13->P13) + (P14->P14 + P15->P15)))) + ((((P16->P16 + P17->P17) + (P18->P18 + P19->P19)) + ((P20->P20 + P21->P21) + (P22->P22 + P23->P23))) + (((P24->P24 + P25->P25) + (P26->P26 + P27->P27)) + ((P28->P28 + P29->P29) + (P30->P30 + P31->P31))))) }
pred semantics6[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range6
ev in used->range6
all e: used | e.fiber in ((((E0 + E1) + (E11 + (E12 + E22))) + ((E23 + E33) + (E34 + (E50 + E51))))) implies e.ev = {i: range6 | (i.shift6_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E13) + (E24 + (E35 + E52)))) implies e.ev = {i: range6 | (i.shift6_0) in (range6 - e.target.av)}
all e: used | e.fiber in (((E3 + E14) + (E25 + (E36 + E53)))) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (e.target.av))}
all e: used | e.fiber in (((E4 + E15) + (E26 + (E37 + E54)))) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (((E5 + (E16 + E27)) + ((E38 + E39) + (E55 + E56)))) implies e.ev = {i: range6 | (i.shift6_0).future6 in (e.target.av)}
all e: used | e.fiber in (((E6 + (E17 + E28)) + ((E40 + E41) + (E57 + E58)))) implies e.ev = {i: range6 | (i.shift6_0).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (((E7 + (E18 + E29)) + ((E42 + E43) + (E59 + E60)))) implies e.ev = {i: range6 | loop6 in (e.target.av)}
all e: used | e.fiber in (((E8 + (E19 + E30)) + ((E44 + E45) + (E61 + E62)))) implies e.ev = {i: range6 | loop6 in (range6 - e.target.av)}
all e: used | e.fiber in (((E9 + (E20 + E31)) + ((E46 + E47) + (E63 + E64)))) implies e.ev = {i: range6 | some (loop6 & (e.target.av))}
all e: used | e.fiber in (((E10 + (E21 + E32)) + ((E48 + E49) + (E65 + E66)))) implies e.ev = {i: range6 | some (loop6 & (range6 - e.target.av))}
all a: active | a.lab = T15 implies a.av = (range6 - child[a].ev)
all a: active | a.lab = T16 implies a.av = ({i: range6 | some (i.future6 & child[a].ev)})
all a: active | a.lab = T17 implies a.av = ({i: range6 | i.future6 in child[a].ev})
all a: active | a.lab = T18 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T19 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T20 implies a.av = ((range6 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = ((((P7 + P8) + (P9 + P10)) + ((P11 + P12) + (P13 + P14))))
all a: lab.T1 | a.av0 = ((((P2 + P3) + (P4 + (P5 + P6))) + ((P7 + P8) + (P12 + (P13 + P14)))))
all a: lab.T2 | a.av0 = ((P1 + (P10 + P11)))
all a: lab.T3 | a.av0 = ((P2 + P12))
all a: lab.T4 | a.av0 = ((P3 + (P13 + P14)))
all a: lab.T5 | a.av0 = (((P5 + P6) + (P7 + P8)))
all a: lab.T6 | a.av0 = (((P8 + P9) + (P10 + (P11 + P12))))
all a: lab.T7 | a.av0 = ((P11 + (P12 + P13)))
all a: lab.T8 | a.av0 = (((P0 + (P1 + P2)) + (P3 + (P4 + P5))))
all a: lab.T9 | a.av0 = (P6)
all a: lab.T10 | a.av0 = (P7)
all a: lab.T11 | a.av0 = ((P8 + (P9 + P10)))
all a: lab.T12 | a.av0 = (P14)
all a: lab.T13 | a.av0 = (P4)
all a: lab.T14 | a.av0 = ((P0 + P9))
(R->P0 in ev0)
semantics1[av1, ev1]
all a: lab.T0 | a.av1 = (((P7 + P8) + (P9 + (P10 + P11))))
all a: lab.T1 | a.av1 = (((P2 + (P3 + P4)) + ((P5 + P6) + (P7 + P8))))
all a: lab.T2 | a.av1 = (P1)
all a: lab.T3 | a.av1 = (P2)
all a: lab.T4 | a.av1 = (P3)
all a: lab.T5 | a.av1 = (((P5 + P6) + (P7 + P8)))
all a: lab.T6 | a.av1 = (((P0 + (P1 + P2)) + ((P8 + P9) + (P10 + P11))))
all a: lab.T7 | a.av1 = (P10)
all a: lab.T8 | a.av1 = (((P0 + (P1 + P2)) + (P3 + (P4 + P5))))
all a: lab.T9 | a.av1 = (P6)
all a: lab.T10 | a.av1 = (P7)
all a: lab.T11 | a.av1 = ((P8 + P9))
all a: lab.T12 | a.av1 = (P11)
all a: lab.T13 | a.av1 = (P4)
all a: lab.T14 | a.av1 = (((P0 + P9) + (P10 + P11)))
(R->P0 in ev1)
semantics2[av2, ev2]
all a: lab.T0 | a.av2 = (((P6 + (P7 + P8)) + ((P9 + P10) + (P11 + P12))))
all a: lab.T1 | a.av2 = ((((P2 + P3) + (P4 + P5)) + ((P6 + P7) + (P8 + (P14 + P15)))))
all a: lab.T2 | a.av2 = (((P1 + P10) + (P11 + (P12 + P13))))
all a: lab.T3 | a.av2 = ((P2 + (P3 + P14)))
all a: lab.T4 | a.av2 = ((P4 + P15))
all a: lab.T5 | a.av2 = ((P7 + P8))
all a: lab.T6 | a.av2 = (((P8 + (P9 + P10)) + ((P11 + P12) + (P13 + P14))))
all a: lab.T7 | a.av2 = (P11)
all a: lab.T8 | a.av2 = (((P0 + (P1 + P2)) + (P13 + (P14 + P15))))
all a: lab.T9 | a.av2 = ((P3 + (P4 + P5)))
all a: lab.T10 | a.av2 = ((P6 + P7))
all a: lab.T11 | a.av2 = ((P8 + (P9 + P10)))
all a: lab.T12 | a.av2 = (P12)
all a: lab.T13 | a.av2 = ((P5 + P6))
all a: lab.T14 | a.av2 = ((P0 + P9))
(R->P0 in ev2)
semantics2[av3, ev3]
all a: lab.T0 | a.av3 = (((P3 + (P4 + P5)) + (P6 + (P14 + P15))))
all a: lab.T1 | a.av3 = (((P8 + P9) + (P10 + P11)))
all a: lab.T2 | a.av3 = (((P2 + (P3 + P4)) + (P5 + (P6 + P7))))
all a: lab.T3 | a.av3 = (P8)
all a: lab.T4 | a.av3 = (P9)
all a: lab.T5 | a.av3 = (P11)
all a: lab.T6 | a.av3 = (((P4 + (P5 + P6)) + (P7 + (P8 + P15))))
all a: lab.T7 | a.av3 = (P5)
all a: lab.T8 | a.av3 = (((P0 + (P7 + P8)) + ((P9 + P10) + (P11 + P12))))
all a: lab.T9 | a.av3 = ((P1 + (P2 + P13)))
all a: lab.T10 | a.av3 = ((P3 + P14))
all a: lab.T11 | a.av3 = ((P4 + P15))
all a: lab.T12 | a.av3 = (P6)
all a: lab.T13 | a.av3 = (P10)
all a: lab.T14 | a.av3 = (((P0 + (P1 + P12)) + (P13 + (P14 + P15))))
(R->P0 in ev3)
semantics2[av4, ev4]
all a: lab.T0 | a.av4 = ((((P6 + P7) + (P8 + P9)) + ((P10 + P11) + (P12 + P13))))
all a: lab.T1 | a.av4 = ((((P3 + P4) + (P5 + P6)) + ((P7 + P13) + (P14 + P15))))
all a: lab.T2 | a.av4 = (((P1 + P2) + (P11 + P12)))
all a: lab.T3 | a.av4 = (((P3 + P13) + (P14 + P15)))
all a: lab.T4 | a.av4 = (P4)
all a: lab.T5 | a.av4 = (P7)
all a: lab.T6 | a.av4 = (((P9 + (P10 + P11)) + ((P12 + P13) + (P14 + P15))))
all a: lab.T7 | a.av4 = ((P10 + P11))
all a: lab.T8 | a.av4 = ((P0 + (P1 + P14)))
all a: lab.T9 | a.av4 = (((P2 + P3) + (P4 + (P5 + P15))))
all a: lab.T10 | a.av4 = ((P6 + (P7 + P8)))
all a: lab.T11 | a.av4 = (P9)
all a: lab.T12 | a.av4 = ((P12 + P13))
all a: lab.T13 | a.av4 = ((P5 + P6))
all a: lab.T14 | a.av4 = (((P0 + P8) + (P9 + P10)))
(R->P0 in ev4)
semantics0[av5, ev5]
all a: lab.T0 | a.av5 = (((P8 + (P9 + P10)) + (P11 + (P12 + P13))))
all a: lab.T1 | a.av5 = ((((P2 + P3) + (P4 + P5)) + ((P6 + P12) + (P13 + P14))))
all a: lab.T2 | a.av5 = (((P1 + P9) + (P10 + P11)))
all a: lab.T3 | a.av5 = (((P2 + P12) + (P13 + P14)))
all a: lab.T4 | a.av5 = (P3)
all a: lab.T5 | a.av5 = (P6)
all a: lab.T6 | a.av5 = (((P10 + P11) + (P12 + (P13 + P14))))
all a: lab.T7 | a.av5 = ((P11 + P12))
all a: lab.T8 | a.av5 = (((P0 + (P1 + P2)) + (P3 + (P4 + P14))))
all a: lab.T9 | a.av5 = ((P5 + (P6 + P7)))
all a: lab.T10 | a.av5 = ((P8 + P9))
all a: lab.T11 | a.av5 = (P10)
all a: lab.T12 | a.av5 = (P13)
all a: lab.T13 | a.av5 = ((P4 + P5))
all a: lab.T14 | a.av5 = ((P0 + (P7 + P8)))
(R->P0 in ev5)
semantics2[av6, ev6]
all a: lab.T0 | a.av6 = (((P8 + P9) + (P10 + P11)))
all a: lab.T1 | a.av6 = (((P3 + (P4 + P5)) + (P6 + (P14 + P15))))
all a: lab.T2 | a.av6 = ((P2 + P13))
all a: lab.T3 | a.av6 = ((P3 + P14))
all a: lab.T4 | a.av6 = ((P4 + P15))
all a: lab.T5 | a.av6 = (P6)
all a: lab.T6 | a.av6 = ((((P0 + P1) + (P2 + (P3 + P9))) + ((P10 + P11) + (P12 + (P13 + P14)))))
all a: lab.T7 | a.av6 = (P10)
all a: lab.T8 | a.av6 = (((P0 + P12) + (P13 + (P14 + P15))))
all a: lab.T9 | a.av6 = (((P1 + (P2 + P3)) + ((P4 + P5) + (P6 + P7))))
all a: lab.T10 | a.av6 = (P8)
all a: lab.T11 | a.av6 = (P9)
all a: lab.T12 | a.av6 = (P11)
all a: lab.T13 | a.av6 = (P5)
all a: lab.T14 | a.av6 = ((((P0 + P1) + (P7 + P8)) + ((P9 + P10) + (P11 + P12))))
(R->P0 in ev6)
semantics1[av7, ev7]
all a: lab.T0 | a.av7 = (((P7 + P8) + (P9 + (P10 + P11))))
all a: lab.T1 | a.av7 = (((P2 + (P3 + P4)) + ((P5 + P6) + (P7 + P8))))
all a: lab.T2 | a.av7 = (P1)
all a: lab.T3 | a.av7 = (P2)
all a: lab.T4 | a.av7 = ((P3 + P4))
all a: lab.T5 | a.av7 = ((P6 + (P7 + P8)))
all a: lab.T6 | a.av7 = (((P0 + (P1 + P2)) + ((P8 + P9) + (P10 + P11))))
all a: lab.T7 | a.av7 = (P10)
all a: lab.T8 | a.av7 = (((P0 + P1) + (P2 + P3)))
all a: lab.T9 | a.av7 = ((P4 + (P5 + P6)))
all a: lab.T10 | a.av7 = (P7)
all a: lab.T11 | a.av7 = ((P8 + P9))
all a: lab.T12 | a.av7 = (P11)
all a: lab.T13 | a.av7 = (P5)
all a: lab.T14 | a.av7 = (((P0 + P9) + (P10 + P11)))
(R->P0 in ev7)
semantics3[av8, ev8]
all a: lab.T0 | a.av8 = (((((P5 + P6) + (P7 + P8)) + ((P9 + P10) + (P11 + P12))) + (((P16 + P17) + (P18 + P19)) + ((P20 + P21) + (P22 + (P23 + P24))))))
all a: lab.T1 | a.av8 = ((((P2 + (P3 + P4)) + ((P5 + P6) + (P7 + P8))) + (((P9 + P10) + (P17 + P18)) + ((P19 + P20) + (P21 + P24)))))
all a: lab.T2 | a.av8 = (((P1 + P15) + (P16 + P23)))
all a: lab.T3 | a.av8 = (((P2 + P17) + (P18 + P24)))
all a: lab.T4 | a.av8 = (((P3 + (P4 + P5)) + (P6 + (P7 + P19))))
all a: lab.T5 | a.av8 = ((P9 + (P10 + P21)))
all a: lab.T6 | a.av8 = (((((P6 + P7) + (P8 + P9)) + ((P10 + P11) + (P12 + (P13 + P14)))) + (((P15 + P16) + (P17 + (P18 + P19))) + ((P20 + P21) + (P22 + (P23 + P24))))))
all a: lab.T7 | a.av8 = (((P7 + P8) + (P9 + (P10 + P11))))
all a: lab.T8 | a.av8 = (((P0 + P1) + (P2 + (P3 + P13))))
all a: lab.T9 | a.av8 = ((P4 + (P14 + P15)))
all a: lab.T10 | a.av8 = ((P5 + (P16 + P17)))
all a: lab.T11 | a.av8 = ((((P6 + P18) + (P19 + P20)) + ((P21 + P22) + (P23 + P24))))
all a: lab.T12 | a.av8 = (P12)
all a: lab.T13 | a.av8 = ((P8 + P20))
all a: lab.T14 | a.av8 = (((P0 + (P11 + P12)) + (P13 + (P14 + P22))))
not (R->P0 in ev8)
semantics4[av9, ev9]
all a: lab.T0 | a.av9 = (((((P5 + P6) + (P7 + P8)) + ((P9 + P10) + (P11 + (P12 + P16)))) + (((P17 + P18) + (P19 + P20)) + ((P21 + P22) + (P23 + (P24 + P25))))))
all a: lab.T1 | a.av9 = (((((P2 + P3) + (P4 + P5)) + ((P6 + P7) + (P8 + P9))) + (((P10 + P17) + (P18 + P19)) + ((P20 + P21) + (P24 + P25)))))
all a: lab.T2 | a.av9 = (((P1 + P15) + (P16 + P23)))
all a: lab.T3 | a.av9 = (((P2 + P17) + (P18 + (P24 + P25))))
all a: lab.T4 | a.av9 = (((P3 + (P4 + P5)) + (P6 + (P7 + P19))))
all a: lab.T5 | a.av9 = ((P9 + (P10 + P21)))
all a: lab.T6 | a.av9 = ((((P6 + (P7 + P8)) + (P9 + (P10 + P11))) + ((P12 + (P13 + P14)) + ((P15 + P16) + (P17 + P18)))))
all a: lab.T7 | a.av9 = (((P7 + P8) + (P9 + (P10 + P11))))
all a: lab.T8 | a.av9 = (((P0 + P1) + (P2 + (P3 + P13))))
all a: lab.T9 | a.av9 = ((P4 + (P14 + P15)))
all a: lab.T10 | a.av9 = ((P5 + (P16 + P17)))
all a: lab.T11 | a.av9 = ((((P6 + P18) + (P19 + P20)) + ((P21 + P22) + (P23 + (P24 + P25)))))
all a: lab.T12 | a.av9 = (P12)
all a: lab.T13 | a.av9 = ((P8 + P20))
all a: lab.T14 | a.av9 = (((P0 + (P11 + P12)) + (P13 + (P14 + P22))))
not (R->P0 in ev9)
semantics5[av10, ev10]
all a: lab.T0 | a.av10 = (((((P5 + P6) + (P7 + P8)) + ((P9 + P10) + (P11 + (P12 + P16)))) + (((P17 + P18) + (P19 + (P20 + P21))) + ((P22 + P23) + (P24 + (P25 + P26))))))
all a: lab.T1 | a.av10 = (((((P2 + P3) + (P4 + P5)) + ((P6 + P7) + (P8 + P9))) + (((P10 + P17) + (P18 + P19)) + ((P20 + P21) + (P22 + (P25 + P26))))))
all a: lab.T2 | a.av10 = (((P1 + P15) + (P16 + P24)))
all a: lab.T3 | a.av10 = (((P2 + P17) + (P18 + (P25 + P26))))
all a: lab.T4 | a.av10 = (((P3 + (P4 + P5)) + ((P6 + P7) + (P19 + P20))))
all a: lab.T5 | a.av10 = ((P9 + (P10 + P22)))
all a: lab.T6 | a.av10 = ((((P6 + (P7 + P8)) + ((P9 + P10) + (P11 + P12))) + (((P13 + P14) + (P15 + P16)) + ((P17 + P18) + (P22 + P24)))))
all a: lab.T7 | a.av10 = (((P7 + P8) + (P9 + (P10 + P11))))
all a: lab.T8 | a.av10 = (((P0 + (P1 + P2)) + (P3 + (P13 + P20))))
all a: lab.T9 | a.av10 = (((P4 + P14) + (P15 + P20)))
all a: lab.T10 | a.av10 = (((P5 + P16) + (P17 + P20)))
all a: lab.T11 | a.av10 = ((((P6 + P18) + (P19 + (P20 + P21))) + ((P22 + P23) + (P24 + (P25 + P26)))))
all a: lab.T12 | a.av10 = (P12)
all a: lab.T13 | a.av10 = ((P8 + P21))
all a: lab.T14 | a.av10 = (((P0 + (P11 + P12)) + (P13 + (P14 + P23))))
not (R->P0 in ev10)
semantics6[av11, ev11]
all a: lab.T0 | a.av11 = (((((P5 + P6) + (P7 + (P8 + P9))) + ((P10 + (P11 + P12)) + (P16 + (P17 + P18)))) + (((P19 + P20) + (P21 + (P24 + P25))) + ((P26 + (P27 + P28)) + (P29 + (P30 + P31))))))
all a: lab.T1 | a.av11 = (((((P2 + P3) + (P4 + (P5 + P6))) + ((P7 + (P8 + P9)) + (P10 + (P17 + P18)))) + (((P19 + P20) + (P21 + (P22 + P23))) + ((P24 + (P25 + P26)) + (P27 + (P30 + P31))))))
all a: lab.T2 | a.av11 = (((P1 + P15) + (P16 + P29)))
all a: lab.T3 | a.av11 = (((P2 + P17) + (P18 + (P30 + P31))))
all a: lab.T4 | a.av11 = ((((P3 + (P4 + P5)) + (P6 + (P7 + P19))) + ((P20 + (P21 + P22)) + (P23 + (P24 + P25)))))
all a: lab.T5 | a.av11 = ((P9 + (P10 + P27)))
all a: lab.T6 | a.av11 = (((((P6 + P7) + (P8 + (P9 + P10))) + ((P11 + P12) + (P13 + (P14 + P15)))) + (((P16 + P17) + (P18 + (P25 + P26))) + ((P27 + P28) + (P29 + (P30 + P31))))))
all a: lab.T7 | a.av11 = (((P7 + (P8 + P9)) + (P10 + (P11 + P20))))
all a: lab.T8 | a.av11 = (((P0 + (P1 + P2)) + (P3 + (P13 + P22))))
all a: lab.T9 | a.av11 = (((P4 + P14) + (P15 + P23)))
all a: lab.T10 | a.av11 = (((P5 + P16) + (P17 + P24)))
all a: lab.T11 | a.av11 = ((((P6 + P18) + (P19 + (P25 + P26))) + ((P27 + P28) + (P29 + (P30 + P31)))))
all a: lab.T12 | a.av11 = ((P12 + P21))
all a: lab.T13 | a.av11 = ((P8 + P26))
all a: lab.T14 | a.av11 = (((P0 + (P11 + P12)) + (P13 + (P14 + P28))))
not (R->P0 in ev11)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int

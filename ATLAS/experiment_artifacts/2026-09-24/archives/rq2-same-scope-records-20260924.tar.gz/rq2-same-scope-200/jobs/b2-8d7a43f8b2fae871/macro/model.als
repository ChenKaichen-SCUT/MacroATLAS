abstract sig Unit {}
one sig U0, U1, U2, U3, U4 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6 extends Label {}
abstract sig Q {}
one sig Q0, Q1 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17, P18, P19, P20, P21, P22, P23, P24, P25, P26, P27, P28, P29, P30, P31, P32 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos }
one sig A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4, C5, L5, D5, C6, L6, D6, C7, L7, D7, C8, L8, D8, C9, L9, D9, C10, L10, D10 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (T0 + (T1 + T2)) }
fun un: set Label { (T3 + (T4 + T5)) }
fun bin: set Label { T6 }
fun nonempty: set Fiber { (((E1 + (E2 + E3)) + (E4 + (E5 + E6))) + ((E8 + (E9 + E10)) + (E11 + (E12 + E13)))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { ((U0->U1 + U1->U2) + (U2->U3 + U3->U4)) }
fun carrierNext: Carrier -> Carrier { (((((A0->A1 + A1->A2) + (A2->A3 + (A3->A4 + A4->A5))) + ((A5->A6 + (A6->A7 + A7->A8)) + (A8->A9 + (A9->A10 + A10->R)))) + (((R->C0 + C0->L0) + (L0->D0 + (D0->C1 + C1->L1))) + ((L1->D1 + (D1->C2 + C2->L2)) + (L2->D2 + (D2->C3 + C3->L3))))) + ((((L3->D3 + D3->C4) + (C4->L4 + (L4->D4 + D4->C5))) + ((C5->L5 + (L5->D5 + D5->C6)) + (C6->L6 + (L6->D6 + D6->C7)))) + (((C7->L7 + L7->D7) + (D7->C8 + (C8->L8 + L8->D8))) + ((D8->C9 + (C9->L9 + L9->D9)) + (D9->C10 + (C10->L10 + L10->D10)))))) }
fun child[a: Anchor]: set Port { a.((((A0->C0 + A1->C1) + (A2->C2 + (A3->C3 + A4->C4))) + ((A5->C5 + (A6->C6 + A7->C7)) + (A8->C8 + (A9->C9 + A10->C10))))) }
fun left[a: Anchor]: set Port { a.((((A0->L0 + A1->L1) + (A2->L2 + (A3->L3 + A4->L4))) + ((A5->L5 + (A6->L6 + A7->L7)) + (A8->L8 + (A9->L9 + A10->L10))))) }
fun right[a: Anchor]: set Port { a.((((A0->D0 + A1->D1) + (A2->D2 + (A3->D3 + A4->D4))) + ((A5->D5 + (A6->D6 + A7->D7)) + (A8->D8 + (A9->D9 + A10->D10))))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
C5.src = A5
L5.src = A5
D5.src = A5
(some C5.target iff A5.lab in un and some A5.lab)
(some L5.target iff A5.lab in bin and some A5.lab)
(some D5.target iff A5.lab in bin and some A5.lab)
C6.src = A6
L6.src = A6
D6.src = A6
(some C6.target iff A6.lab in un and some A6.lab)
(some L6.target iff A6.lab in bin and some A6.lab)
(some D6.target iff A6.lab in bin and some A6.lab)
C7.src = A7
L7.src = A7
D7.src = A7
(some C7.target iff A7.lab in un and some A7.lab)
(some L7.target iff A7.lab in bin and some A7.lab)
(some D7.target iff A7.lab in bin and some A7.lab)
C8.src = A8
L8.src = A8
D8.src = A8
(some C8.target iff A8.lab in un and some A8.lab)
(some L8.target iff A8.lab in bin and some A8.lab)
(some D8.target iff A8.lab in bin and some A8.lab)
C9.src = A9
L9.src = A9
D9.src = A9
(some C9.target iff A9.lab in un and some A9.lab)
(some L9.target iff A9.lab in bin and some A9.lab)
(some D9.target iff A9.lab in bin and some A9.lab)
C10.src = A10
L10.src = A10
D10.src = A10
(some C10.target iff A10.lab in un and some A10.lab)
(some L10.target iff A10.lab in bin and some A10.lab)
(some D10.target iff A10.lab in bin and some A10.lab)
no iden & ^graph
active = R.target.*graph
R.target in (((A6 + A7) + (A8 + (A9 + A10)))) implies R.target = A6
no A6.graph & (A6)
no A7.graph & ((A6 + A7))
no A8.graph & ((A6 + (A7 + A8)))
no A9.graph & (((A6 + A7) + (A8 + A9)))
no A10.graph & (((A6 + A7) + (A8 + (A9 + A10))))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
lone lab.T2
some A0.lab implies A0.lab = T6
some A1.lab implies A1.lab = T4
some A2.lab implies A2.lab = T5
some A3.lab implies A3.lab = T3
some A4.lab implies A4.lab = T0
some A5.lab implies A5.lab = T2
some A6.lab and A6.lab in un implies #(target.A6) > 1
some A7.lab and A7.lab in un implies #(target.A7) > 1
some A7.lab implies some A6.lab
some A8.lab and A8.lab in un implies #(target.A8) > 1
some A8.lab implies some A7.lab
some A9.lab and A9.lab in un implies #(target.A9) > 1
some A9.lab implies some A8.lab
some A10.lab and A10.lab in un implies #(target.A10) > 1
some A10.lab implies some A9.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q1
E7.qo = Q1
E8.qi = Q1
E8.qo = Q0
E9.qi = Q1
E9.qo = Q0
E10.qi = Q1
E10.qo = Q0
E11.qi = Q1
E11.qo = Q0
E12.qi = Q1
E12.qo = Q0
E13.qi = Q1
E13.qo = Q0
all e: used | e.fiber in ((E0 + E7)) implies #e.cost = 0
all e: used | e.fiber in (((E1 + (E4 + E6)) + (E8 + (E11 + E13)))) implies #e.cost = 2
all e: used | e.fiber in (((E2 + (E3 + E5)) + (E9 + (E10 + E12)))) implies #e.cost = 1
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q1)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 implies a.state = Q0
all a: active | a.lab = T3 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T3 and child[a].fiber.qo = Q1 implies a.state = Q0
all a: active | a.lab = T4 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T4 and child[a].fiber.qo = Q1 implies a.state = Q0
all a: active | a.lab = T5 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T5 and child[a].fiber.qo = Q1 implies a.state = Q0
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active - lab.lit | lone ({e: used | e.target = a and e.fiber in nonempty})
all a: active - lab.lit | lone ({e: used - R | e.target = a and e.fiber not in nonempty}.src)
all a: active - lab.lit | (some e: used | e.target = a and e.fiber in nonempty) implies no {e: used - R | e.target = a and e.fiber not in nonempty}
all a: lab.bin | not (left[a].target = right[a].target and no (left[a].fiber + right[a].fiber) & nonempty)
}
fun range0: set Pos { ((((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) + (((P7 + P8) + (P9 + P10)) + ((P11 + P12) + (P13 + P14)))) + (((P15 + (P16 + P17)) + ((P18 + P19) + (P20 + P21))) + (((P22 + P23) + (P24 + P25)) + ((P26 + P27) + (P28 + P29))))) }
fun loop0: set Pos { ((((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) + (((P7 + P8) + (P9 + P10)) + ((P11 + P12) + (P13 + P14)))) + (((P15 + (P16 + P17)) + ((P18 + P19) + (P20 + P21))) + (((P22 + P23) + (P24 + P25)) + ((P26 + P27) + (P28 + P29))))) }
fun next0: Pos -> Pos { ((((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P7))) + (((P7->P8 + P8->P9) + (P9->P10 + P10->P11)) + ((P11->P12 + P12->P13) + (P13->P14 + P14->P15)))) + (((P15->P16 + (P16->P17 + P17->P18)) + ((P18->P19 + P19->P20) + (P20->P21 + P21->P22))) + (((P22->P23 + P23->P24) + (P24->P25 + P25->P26)) + ((P26->P27 + P27->P28) + (P28->P29 + P29->P0))))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((((P0->P0 + (P1->P1 + P2->P2)) + ((P3->P3 + P4->P4) + (P5->P5 + P6->P6))) + (((P7->P7 + P8->P8) + (P9->P9 + P10->P10)) + ((P11->P11 + P12->P12) + (P13->P13 + P14->P14)))) + (((P15->P15 + (P16->P16 + P17->P17)) + ((P18->P18 + P19->P19) + (P20->P20 + P21->P21))) + (((P22->P22 + P23->P23) + (P24->P24 + P25->P25)) + ((P26->P26 + P27->P27) + (P28->P28 + P29->P29))))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in (((E0 + E1) + (E7 + E8))) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + E9)) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in ((E3 + E10)) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in ((E4 + E11)) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in ((E5 + E12)) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in ((E6 + E13)) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T4 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
}
fun range1: set Pos { (((P0 + (P1 + P2)) + (P3 + (P4 + P5))) + ((P6 + (P7 + P8)) + (P9 + (P10 + P11)))) }
fun loop1: set Pos { (((P0 + (P1 + P2)) + (P3 + (P4 + P5))) + ((P6 + (P7 + P8)) + (P9 + (P10 + P11)))) }
fun next1: Pos -> Pos { (((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P6))) + ((P6->P7 + (P7->P8 + P8->P9)) + (P9->P10 + (P10->P11 + P11->P0)))) }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { (((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) + ((P6->P6 + (P7->P7 + P8->P8)) + (P9->P9 + (P10->P10 + P11->P11)))) }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in (((E0 + E1) + (E7 + E8))) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + E9)) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in ((E3 + E10)) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in ((E4 + E11)) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in ((E5 + E12)) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in ((E6 + E13)) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T4 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
}
fun range2: set Pos { ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) + (((P9 + P10) + (P11 + P12)) + ((P13 + P14) + (P15 + (P16 + P17))))) }
fun loop2: set Pos { ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) + (((P9 + P10) + (P11 + P12)) + ((P13 + P14) + (P15 + (P16 + P17))))) }
fun next2: Pos -> Pos { ((((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P9)))) + (((P9->P10 + P10->P11) + (P11->P12 + P12->P13)) + ((P13->P14 + P14->P15) + (P15->P16 + (P16->P17 + P17->P0))))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) + (((P9->P9 + P10->P10) + (P11->P11 + P12->P12)) + ((P13->P13 + P14->P14) + (P15->P15 + (P16->P16 + P17->P17))))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in (((E0 + E1) + (E7 + E8))) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + E9)) implies e.ev = {i: range2 | (i.shift2_0) in (range2 - e.target.av)}
all e: used | e.fiber in ((E3 + E10)) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (e.target.av))}
all e: used | e.fiber in ((E4 + E11)) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (range2 - e.target.av))}
all e: used | e.fiber in ((E5 + E12)) implies e.ev = {i: range2 | (i.shift2_0).future2 in (e.target.av)}
all e: used | e.fiber in ((E6 + E13)) implies e.ev = {i: range2 | (i.shift2_0).future2 in (range2 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range2 - child[a].ev)
all a: active | a.lab = T4 implies a.av = ({i: range2 | some (i.future2 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range2 | i.future2 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
}
fun range3: set Pos { (((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) + (((P8 + P9) + (P10 + P11)) + ((P12 + P13) + (P14 + P15)))) + ((((P16 + P17) + (P18 + P19)) + ((P20 + P21) + (P22 + P23))) + (((P24 + P25) + (P26 + P27)) + ((P28 + P29) + (P30 + (P31 + P32)))))) }
fun loop3: set Pos { (((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) + (((P8 + P9) + (P10 + P11)) + ((P12 + P13) + (P14 + P15)))) + ((((P16 + P17) + (P18 + P19)) + ((P20 + P21) + (P22 + P23))) + (((P24 + P25) + (P26 + P27)) + ((P28 + P29) + (P30 + (P31 + P32)))))) }
fun next3: Pos -> Pos { (((((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P8))) + (((P8->P9 + P9->P10) + (P10->P11 + P11->P12)) + ((P12->P13 + P13->P14) + (P14->P15 + P15->P16)))) + ((((P16->P17 + P17->P18) + (P18->P19 + P19->P20)) + ((P20->P21 + P21->P22) + (P22->P23 + P23->P24))) + (((P24->P25 + P25->P26) + (P26->P27 + P27->P28)) + ((P28->P29 + P29->P30) + (P30->P31 + (P31->P32 + P32->P0)))))) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { (((((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) + (((P8->P8 + P9->P9) + (P10->P10 + P11->P11)) + ((P12->P12 + P13->P13) + (P14->P14 + P15->P15)))) + ((((P16->P16 + P17->P17) + (P18->P18 + P19->P19)) + ((P20->P20 + P21->P21) + (P22->P22 + P23->P23))) + (((P24->P24 + P25->P25) + (P26->P26 + P27->P27)) + ((P28->P28 + P29->P29) + (P30->P30 + (P31->P31 + P32->P32)))))) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in (((E0 + E1) + (E7 + E8))) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + E9)) implies e.ev = {i: range3 | (i.shift3_0) in (range3 - e.target.av)}
all e: used | e.fiber in ((E3 + E10)) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (e.target.av))}
all e: used | e.fiber in ((E4 + E11)) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (range3 - e.target.av))}
all e: used | e.fiber in ((E5 + E12)) implies e.ev = {i: range3 | (i.shift3_0).future3 in (e.target.av)}
all e: used | e.fiber in ((E6 + E13)) implies e.ev = {i: range3 | (i.shift3_0).future3 in (range3 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range3 - child[a].ev)
all a: active | a.lab = T4 implies a.av = ({i: range3 | some (i.future3 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range3 | i.future3 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
}
fun range4: set Pos { (((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) + (((P7 + P8) + (P9 + P10)) + ((P11 + P12) + (P13 + P14)))) }
fun loop4: set Pos { (((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) + (((P7 + P8) + (P9 + P10)) + ((P11 + P12) + (P13 + P14)))) }
fun next4: Pos -> Pos { (((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P7))) + (((P7->P8 + P8->P9) + (P9->P10 + P10->P11)) + ((P11->P12 + P12->P13) + (P13->P14 + P14->P0)))) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { (((P0->P0 + (P1->P1 + P2->P2)) + ((P3->P3 + P4->P4) + (P5->P5 + P6->P6))) + (((P7->P7 + P8->P8) + (P9->P9 + P10->P10)) + ((P11->P11 + P12->P12) + (P13->P13 + P14->P14)))) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in (((E0 + E1) + (E7 + E8))) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + E9)) implies e.ev = {i: range4 | (i.shift4_0) in (range4 - e.target.av)}
all e: used | e.fiber in ((E3 + E10)) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (e.target.av))}
all e: used | e.fiber in ((E4 + E11)) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (range4 - e.target.av))}
all e: used | e.fiber in ((E5 + E12)) implies e.ev = {i: range4 | (i.shift4_0).future4 in (e.target.av)}
all e: used | e.fiber in ((E6 + E13)) implies e.ev = {i: range4 | (i.shift4_0).future4 in (range4 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range4 - child[a].ev)
all a: active | a.lab = T4 implies a.av = ({i: range4 | some (i.future4 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range4 | i.future4 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = ((((P0 + P1) + (P2 + P3)) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T1 | a.av0 = (((P23 + P24) + (P25 + (P26 + P27))))
all a: lab.T2 | a.av0 = (none)
(R->P0 in ev0)
semantics0[av1, ev1]
all a: lab.T0 | a.av1 = (((P5 + P6) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av1 = (((P23 + P24) + (P25 + (P26 + P27))))
all a: lab.T2 | a.av1 = (none)
(R->P0 in ev1)
semantics0[av2, ev2]
all a: lab.T0 | a.av2 = (((P8 + P9) + (P10 + (P11 + P12))))
all a: lab.T1 | a.av2 = (((P26 + P27) + (P28 + P29)))
all a: lab.T2 | a.av2 = (none)
(R->P0 in ev2)
semantics0[av3, ev3]
all a: lab.T0 | a.av3 = (((P23 + P24) + (P25 + (P26 + P27))))
all a: lab.T1 | a.av3 = ((((P0 + P1) + (P2 + P3)) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T2 | a.av3 = (none)
(R->P0 in ev3)
semantics1[av4, ev4]
all a: lab.T0 | a.av4 = (((P5 + P6) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av4 = (none)
all a: lab.T2 | a.av4 = (none)
not (R->P0 in ev4)
semantics2[av5, ev5]
all a: lab.T0 | a.av5 = (none)
all a: lab.T1 | a.av5 = (((P11 + P12) + (P13 + (P14 + P15))))
all a: lab.T2 | a.av5 = (none)
not (R->P0 in ev5)
semantics3[av6, ev6]
all a: lab.T0 | a.av6 = (((P5 + P6) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av6 = (((P29 + P30) + (P31 + P32)))
all a: lab.T2 | a.av6 = (((P20 + P21) + (P22 + (P23 + P24))))
not (R->P0 in ev6)
semantics1[av7, ev7]
all a: lab.T0 | a.av7 = ((((P0 + P1) + (P2 + P3)) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T1 | a.av7 = (none)
all a: lab.T2 | a.av7 = (none)
not (R->P0 in ev7)
semantics4[av8, ev8]
all a: lab.T0 | a.av8 = (((P8 + P9) + (P10 + (P11 + P12))))
all a: lab.T1 | a.av8 = (none)
all a: lab.T2 | a.av8 = (none)
not (R->P0 in ev8)
}
fun kept: Anchor -> Anchor { (((A0->A1 + A0->A2) + (A1->A4 + (A2->A3 + A3->A5)))) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 7 Int

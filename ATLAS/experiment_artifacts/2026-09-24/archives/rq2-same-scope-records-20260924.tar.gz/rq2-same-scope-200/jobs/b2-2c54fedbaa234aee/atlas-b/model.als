open util/ordering[SeqIdx]

abstract sig DAGNode {
	l: set DAGNode,
	r: set DAGNode
}
fact {
	all n: DAGNode | n not in n.^(l + r)
}

sig And, Or, Imply extends DAGNode {} {
	one l
	one r
}

sig Neg, F, G, X extends DAGNode {} {
    one l
    no r
}
abstract sig Literal extends DAGNode {} {
	no l
	no r
}

abstract sig SeqIdx {}
abstract sig Trace {
	lasso: SeqIdx -> SeqIdx,
	valuation: DAGNode -> SeqIdx
} {
	// Negation
    all n: Neg, i: seqRange | n->i in valuation iff n.l->i not in valuation
	// Or
    all n: Or, i: seqRange | n->i in valuation iff (n.l->i in valuation or n.r->i in valuation)
	// And
    all n: And, i: seqRange | n->i in valuation iff (n.l->i in valuation and n.r->i in valuation)
	// Imply
    all n: Imply, i: seqRange | n->i in valuation iff (n.l->i not in valuation or n.r->i in valuation)
	// G
    all n: G, i: seqRange | n->i in valuation iff all i': futureIdx[i] | n.l->i' in valuation
    // X
    all n: X, i: seqRange | n->i in valuation iff n.l->i.((next :> seqRange) + lasso) in valuation
	// F
    all n: F, i: seqRange | n->i in valuation iff some i': futureIdx[i] | n.l->i' in valuation
	// Until
    
}
fun seqRange[t: Trace]: set SeqIdx {
	let lastOfTrace = t.lasso.SeqIdx | lastOfTrace.prevs + lastOfTrace
}
fun futureIdx[t: Trace, i: SeqIdx]: set SeqIdx {
	i.^((next :> seqRange[t]) + t.lasso) + i
}
abstract sig PositiveTrace extends Trace {}
abstract sig NegativeTrace extends Trace {}
one sig x0, x1, x2 extends Literal {}
one sig T0, T1, T2, T3, T4 extends SeqIdx {}
fact {
    first = T0
    next = T0->T1 + T1->T2 + T2->T3 + T3->T4
}

one sig PT0 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T2 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT1 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T2 + x2->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT2 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T4) & valuation
}

one sig PT3 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT4 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T3) & valuation
}

one sig PT5 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T2 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT6 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT7 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT8 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT9 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2) & valuation
}

one sig PT10 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT11 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig PT12 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T1 + x2->T2 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT13 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig PT14 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT15 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT16 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT17 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT18 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2) & valuation
}

one sig PT19 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x2->T2 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT20 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig PT21 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T1 + x0->T2 + x2->T2 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT22 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT23 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT24 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT25 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x1->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT26 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT27 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T4) & valuation
}

one sig PT28 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT29 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT30 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T3) & valuation
}

one sig PT31 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT32 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T1 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT33 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT34 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT35 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT36 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT37 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x2->T2 + x2->T3 + x2->T4) & valuation
}

one sig PT38 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x2->T3) & valuation
}

one sig PT39 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT40 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT41 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig PT42 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT43 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT44 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4) & valuation
}

one sig PT45 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT46 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig PT47 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT48 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT49 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT50 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT51 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4) & valuation
}

one sig PT52 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1) & valuation
}

one sig PT53 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T1 + x0->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT54 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT55 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x2->T1 + x0->T2 + x2->T2 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT56 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT57 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT58 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T4) & valuation
}

one sig PT59 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT60 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT61 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT62 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T4 + x2->T4) & valuation
}

one sig PT63 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T3 + x1->T4) & valuation
}

one sig PT64 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T2 + x2->T3) & valuation
}

one sig PT65 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT66 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x1->T2 + x1->T4) & valuation
}

one sig PT67 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT68 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T2 + x2->T3 + x1->T4) & valuation
}

one sig PT69 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T4) & valuation
}

one sig PT70 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT71 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT72 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT73 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T3 + x1->T4) & valuation
}

one sig PT74 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 + x2->T4) & valuation
}

one sig PT75 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T1 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT76 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig PT77 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT78 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT79 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT80 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T3 + x2->T4) & valuation
}

one sig PT81 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT82 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT83 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T4) & valuation
}

one sig PT84 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT85 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT86 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig PT87 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT88 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T4) & valuation
}

one sig PT89 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT90 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x2->T2 + x1->T3) & valuation
}

one sig PT91 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T1 + x0->T2 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT92 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T1 + x1->T2 + x2->T2 + x2->T4) & valuation
}

one sig PT93 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T1 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT94 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT95 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T4) & valuation
}

one sig PT96 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x2->T4) & valuation
}

one sig PT97 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T4 + x2->T4) & valuation
}

one sig PT98 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT99 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T2 + x0->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT100 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT101 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T1 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT102 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T4) & valuation
}

one sig PT103 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T2 + x2->T3) & valuation
}

one sig PT104 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT105 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT106 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4) & valuation
}

one sig PT107 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T2 + x2->T3 + x2->T4) & valuation
}

one sig PT108 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T3 + x1->T4) & valuation
}

one sig PT109 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x2->T2 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT110 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x2->T2 + x2->T3) & valuation
}

one sig PT111 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T2 + x0->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT112 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig PT113 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x2->T3 + x2->T4) & valuation
}

one sig PT114 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x2->T4) & valuation
}

one sig PT115 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3) & valuation
}

one sig PT116 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T2 + x2->T2 + x2->T3) & valuation
}

one sig PT117 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x2->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig PT118 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT119 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x2->T4) & valuation
}

one sig PT120 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT121 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT122 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT123 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT124 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x2->T3) & valuation
}

one sig PT125 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT126 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T4) & valuation
}

one sig PT127 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T4) & valuation
}

one sig PT128 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT129 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT130 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT131 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T4 + x2->T4) & valuation
}

one sig PT132 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3) & valuation
}

one sig PT133 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T3) & valuation
}

one sig PT134 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T2 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT135 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T3) & valuation
}

one sig PT136 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT137 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T3 + x1->T4) & valuation
}

one sig PT138 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x2->T1 + x0->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT139 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT140 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T1 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3) & valuation
}

one sig PT141 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2) & valuation
}

one sig PT142 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT143 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x2->T3) & valuation
}

one sig PT144 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT145 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3) & valuation
}

one sig PT146 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT147 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x2->T2 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT148 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT149 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T3 + x1->T4) & valuation
}

one sig PT150 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x2->T1 + x1->T3 + x2->T4) & valuation
}

one sig PT151 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T3 + x1->T4) & valuation
}

one sig PT152 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT153 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT154 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig PT155 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T2 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT156 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T4) & valuation
}

one sig PT157 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x2->T3 + x2->T4) & valuation
}

one sig PT158 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x2->T2 + x1->T3) & valuation
}

one sig PT159 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT160 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3) & valuation
}

one sig PT161 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT162 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT163 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T3 + x2->T4) & valuation
}

one sig PT164 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T3 + x2->T4) & valuation
}

one sig PT165 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT166 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x2->T2 + x2->T3 + x2->T4) & valuation
}

one sig PT167 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT168 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT169 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT170 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x2->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT171 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T1 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT172 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT173 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT174 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T2 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3) & valuation
}

one sig PT175 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T3) & valuation
}

one sig PT176 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T2) & valuation
}

one sig PT177 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig PT178 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x2->T1 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT179 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig PT180 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T1 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT181 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig PT182 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T1 + x2->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT183 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3) & valuation
}

one sig PT184 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T1 + x0->T2 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT185 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT186 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT187 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T3) & valuation
}

one sig PT188 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT189 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x2->T0 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT190 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT191 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3) & valuation
}

one sig PT192 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x2->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig PT193 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT194 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T4 + x2->T4) & valuation
}

one sig PT195 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT196 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT197 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T1 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT198 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T1 + x2->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT199 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT200 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3) & valuation
}

one sig PT201 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T2 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT202 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T2 + x0->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT203 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T1 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT204 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT205 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T2 + x2->T2 + x1->T3 + x2->T3) & valuation
}

one sig PT206 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x2->T4) & valuation
}

one sig PT207 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT208 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT209 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT210 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT211 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T4) & valuation
}

one sig PT212 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT213 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT214 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T1 + x1->T2 + x2->T2 + x2->T4) & valuation
}

one sig PT215 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3) & valuation
}

one sig PT216 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x2->T1 + x2->T4) & valuation
}

one sig PT217 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT218 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x2->T2 + x2->T4) & valuation
}

one sig PT219 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x2->T0 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT220 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T1 + x2->T1 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT221 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x2->T0 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT222 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T1 + x2->T1 + x2->T2 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT223 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T3 + x2->T4) & valuation
}

one sig PT224 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT225 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig PT226 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT227 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT228 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T3 + x2->T4) & valuation
}

one sig PT229 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT230 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT231 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x1->T2 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT232 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T1 + x2->T2 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT233 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T1 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT234 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x2->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT235 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT236 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT237 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT238 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x2->T1 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT239 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x2->T2 + x1->T4) & valuation
}

one sig PT240 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T4 + x2->T4) & valuation
}

one sig PT241 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3) & valuation
}

one sig PT242 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x2->T2 + x2->T3) & valuation
}

one sig PT243 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT244 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT245 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T1 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT246 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT247 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x2->T2 + x0->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT248 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T2 + x1->T4 + x2->T4) & valuation
}

one sig PT249 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT250 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 + x2->T4) & valuation
}

one sig PT251 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T2 + x2->T3 + x2->T4) & valuation
}

one sig PT252 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2) & valuation
}

one sig PT253 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T1 + x2->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT254 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT255 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x2->T1 + x2->T2 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT256 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T1 + x1->T2 + x2->T3 + x1->T4) & valuation
}

one sig PT257 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT258 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T4) & valuation
}

one sig PT259 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T2) & valuation
}

one sig PT260 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T2 + x1->T4) & valuation
}

one sig PT261 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT262 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T1 + x0->T2 + x0->T3 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT263 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT264 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig PT265 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT266 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T2 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT267 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT268 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT269 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x2->T1 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT270 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T2) & valuation
}

one sig PT271 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T1 + x0->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT272 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT273 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4) & valuation
}

one sig PT274 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x2->T1 + x0->T2 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT275 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T4) & valuation
}

one sig PT276 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT277 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T2 + x1->T4) & valuation
}

one sig PT278 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T1 + x0->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT279 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T3 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT280 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT281 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT282 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT283 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T2 + x2->T3) & valuation
}

one sig PT284 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig PT285 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT286 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT287 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT288 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT289 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x2->T1 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT290 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT291 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T4) & valuation
}

one sig PT292 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT293 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T3) & valuation
}

one sig PT294 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T1 + x2->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT295 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x1->T2 + x2->T3 + x1->T4) & valuation
}

one sig PT296 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x2->T0) & valuation
}

one sig PT297 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T2 + x1->T4) & valuation
}

one sig PT298 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT299 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT300 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT301 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 + x0->T2 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT302 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x2->T1 + x1->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT303 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T3 + x1->T4) & valuation
}

one sig PT304 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig PT305 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T1 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT306 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x2->T1 + x2->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT307 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT308 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT309 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x2->T1 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT310 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig PT311 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x2->T2 + x2->T3) & valuation
}

one sig PT312 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT313 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T4 + x2->T4) & valuation
}

one sig PT314 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T2 + x2->T3 + x1->T4) & valuation
}

one sig PT315 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig PT316 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1) & valuation
}

one sig PT317 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T3) & valuation
}

one sig PT318 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x2->T4) & valuation
}

one sig PT319 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT320 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT321 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT322 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x2->T2) & valuation
}

one sig PT323 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT324 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT325 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT326 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x2->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig PT327 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T3 + x1->T4) & valuation
}

one sig PT328 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T3) & valuation
}

one sig PT329 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x2->T1 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT330 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3) & valuation
}

one sig PT331 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2) & valuation
}

one sig PT332 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig PT333 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T2 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT334 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T3) & valuation
}

one sig PT335 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x2->T2 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT336 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T2) & valuation
}

one sig PT337 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT338 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T4) & valuation
}

one sig PT339 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT340 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT341 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT342 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT343 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T1 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT344 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT345 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT346 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x2->T1 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT347 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T2 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT348 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x2->T4) & valuation
}

one sig PT349 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x2->T1 + x2->T2 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}


one sig NT0 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT1 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT2 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT3 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T4 + x2->T4) & valuation
}

one sig NT4 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT5 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T1 + x0->T3 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT6 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x0->T2 + x2->T2 + x2->T3) & valuation
}

one sig NT7 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT8 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT9 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT10 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT11 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT12 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT13 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT14 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x2->T1 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT15 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT16 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T3 + x2->T4) & valuation
}

one sig NT17 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x2->T3 in valuation
    no (x2->T0 + x0->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT18 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT19 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT20 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT21 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T3 in valuation
    no (x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT22 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT23 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x2->T2 + x1->T3) & valuation
}

one sig NT24 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT25 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT26 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT27 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT28 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT29 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x2->T0 + x2->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT30 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T4 in valuation
    no (x0->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT31 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x0->T3 + x2->T3) & valuation
}

one sig NT32 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T1 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT33 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT34 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT35 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT36 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT37 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T2 + x1->T3) & valuation
}

one sig NT38 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T1 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT39 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T2 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT40 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT41 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT42 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT43 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT44 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig NT45 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT46 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT47 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT48 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT49 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT50 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT51 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x1->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT52 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x1->T1 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT53 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x2->T4) & valuation
}

one sig NT54 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T1 + x1->T2 + x2->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT55 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT56 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT57 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT58 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT59 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT60 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT61 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT62 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT63 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x2->T1 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT64 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT65 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT66 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT67 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT68 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3) & valuation
}

one sig NT69 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT70 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT71 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT72 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x2->T2 + x1->T3) & valuation
}

one sig NT73 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT74 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT75 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T4 in valuation
    no (x2->T0 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT76 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT77 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T1 + x0->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT78 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x2->T1 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT79 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT80 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x2->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT81 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT82 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT83 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT84 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T1 + x0->T3 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4) & valuation
}

one sig NT85 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x0->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT86 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x2->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT87 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT88 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT89 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT90 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT91 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT92 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T1 + x0->T2 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT93 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT94 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT95 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x2->T2 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT96 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT97 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT98 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT99 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT100 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT101 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x1->T2 + x2->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT102 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x2->T3 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT103 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT104 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT105 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT106 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT107 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT108 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT109 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT110 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T3 + x1->T4) & valuation
}

one sig NT111 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT112 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT113 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x2->T1 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT114 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT115 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T4) & valuation
}

one sig NT116 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3) & valuation
}

one sig NT117 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x1->T1 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT118 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT119 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT120 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT121 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT122 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT123 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT124 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT125 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT126 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T3) & valuation
}

one sig NT127 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT128 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT129 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T4) & valuation
}

one sig NT130 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT131 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT132 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT133 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT134 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T4) & valuation
}

one sig NT135 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x1->T4) & valuation
}

one sig NT136 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x2->T3) & valuation
}

one sig NT137 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x0->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT138 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x1->T1 + x2->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT139 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T3 + x2->T4 in valuation
    no (x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT140 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT141 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT142 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x2->T0 + x1->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT143 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT144 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT145 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT146 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT147 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T4 in valuation
    no (x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT148 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT149 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT150 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT151 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT152 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT153 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T1 + x2->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT154 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T3) & valuation
}

one sig NT155 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT156 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T4 + x2->T4) & valuation
}

one sig NT157 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T3 + x1->T4 in valuation
    no (x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT158 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT159 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT160 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T3 + x0->T4 in valuation
    no (x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT161 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT162 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T4 + x2->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT163 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT164 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT165 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x2->T3) & valuation
}

one sig NT166 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT167 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT168 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x1->T1 + x1->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT169 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x2->T1 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT170 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT171 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x1->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT172 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT173 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT174 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT175 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x2->T1 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT176 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT177 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT178 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT179 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT180 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 in valuation
    no (x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT181 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T4 + x2->T4) & valuation
}

one sig NT182 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT183 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT184 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3) & valuation
}

one sig NT185 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT186 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T3) & valuation
}

one sig NT187 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT188 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT189 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T4) & valuation
}

one sig NT190 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT191 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT192 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT193 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT194 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT195 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x2->T2 + x2->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT196 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T4) & valuation
}

one sig NT197 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T4) & valuation
}

one sig NT198 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x2->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT199 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT200 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x1->T2 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3) & valuation
}

one sig NT201 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT202 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x2->T1 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT203 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT204 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT205 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3) & valuation
}

one sig NT206 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT207 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT208 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x2->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT209 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT210 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT211 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT212 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT213 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT214 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT215 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT216 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT217 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT218 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T4) & valuation
}

one sig NT219 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT220 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT221 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x2->T3 + x0->T4) & valuation
}

one sig NT222 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT223 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT224 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x0->T1 + x0->T3 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT225 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T1 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x2->T3) & valuation
}

one sig NT226 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT227 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T2 + x0->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT228 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T3 + x1->T4) & valuation
}

one sig NT229 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x0->T2 + x0->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT230 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT231 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T1 + x0->T2 + x1->T2 + x2->T2 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT232 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT233 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT234 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x2->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT235 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT236 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig NT237 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T3 + x2->T4) & valuation
}

one sig NT238 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T3 + x0->T4) & valuation
}

one sig NT239 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T3 + x2->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT240 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT241 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x0->T2 + x0->T3 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT242 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x2->T1 + x0->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT243 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT244 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT245 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT246 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT247 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT248 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x2->T3 + x0->T4 in valuation
    no (x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT249 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT250 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x2->T3 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT251 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT252 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT253 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT254 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T4) & valuation
}

one sig NT255 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3) & valuation
}

one sig NT256 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT257 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT258 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT259 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT260 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T1 + x1->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT261 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x2->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT262 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT263 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T3 + x1->T4) & valuation
}

one sig NT264 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4) & valuation
}

one sig NT265 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT266 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT267 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT268 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT269 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT270 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT271 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x1->T1 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT272 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT273 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT274 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT275 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT276 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT277 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT278 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT279 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T2 + x0->T3) & valuation
}

one sig NT280 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT281 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT282 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT283 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT284 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT285 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT286 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT287 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T1 + x2->T2 + x2->T3 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT288 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT289 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x2->T1 + x0->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT290 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x1->T1 + x0->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT291 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T4) & valuation
}

one sig NT292 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT293 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT294 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT295 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT296 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT297 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T2 + x2->T2 + x2->T3) & valuation
}

one sig NT298 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT299 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT300 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T2 + x2->T2) & valuation
}

one sig NT301 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x2->T2 + x2->T3 + x0->T4) & valuation
}

one sig NT302 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT303 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT304 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT305 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T4) & valuation
}

one sig NT306 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T4 in valuation
    no (x2->T0 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT307 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT308 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT309 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T2 + x1->T4 in valuation
    no (x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT310 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT311 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT312 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x1->T1 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT313 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT314 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2) & valuation
}

one sig NT315 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T3 + x2->T4 in valuation
    no (x0->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT316 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT317 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT318 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT319 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT320 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T1 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT321 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT322 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT323 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT324 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT325 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT326 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T1 + x0->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT327 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3) & valuation
}

one sig NT328 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT329 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT330 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT331 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT332 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T4) & valuation
}

one sig NT333 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT334 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT335 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT336 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT337 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT338 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x2->T3) & valuation
}

one sig NT339 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT340 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT341 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x0->T3 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT342 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT343 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T2 + x0->T4 + x2->T4) & valuation
}

one sig NT344 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT345 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T2 + x1->T4 + x2->T4 in valuation
    no (x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT346 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T2 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT347 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT348 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT349 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig LearnedLTL {
    Root: DAGNode
}
fun root: one DAGNode { LearnedLTL.Root }
fun childrenOf[n: DAGNode]: set DAGNode { n.^(l+r) }
fun childrenAndSelfOf[n: DAGNode]: set DAGNode { n.*(l+r) }
fun ancestorsOf[n: DAGNode]: set DAGNode { n.~^(l+r) }
fun ancestorsAndSelfOf[n: DAGNode]: set DAGNode { n.~*(l+r) }
fun subDAG[n: DAGNode]: DAGNode -> DAGNode { n.*(l+r) <: (l+r) }



fun experimentReach: set DAGNode { childrenAndSelfOf[root] }
fun experimentKept: DAGNode -> DAGNode { (none->none) & subDAG[root] }
one sig ExperimentCost { used: set DAGNode }
fact { ExperimentCost.used = experimentReach }
fact ExperimentBounds {
  DAGNode = experimentReach + Literal + (none)
  #experimentReach <= 9
  #(experimentReach & (And + Or + Imply)) <= 2
  minsome ExperimentCost.used
}
run {
    all t: PositiveTrace | root->T0 in t.valuation
    all t: NegativeTrace | root->T0 not in t.valuation
    
} for 12 DAGNode, 5 Int
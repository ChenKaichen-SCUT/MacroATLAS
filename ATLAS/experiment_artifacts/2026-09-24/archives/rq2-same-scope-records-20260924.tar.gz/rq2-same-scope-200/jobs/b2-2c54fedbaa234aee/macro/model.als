abstract sig Unit {}
one sig U0, U1, U2, U3, U4, U5, U6, U7, U8 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9 extends Label {}
abstract sig Q {}
one sig Q0 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E26, E27, E28, E29, E30, E31, E32, E33, E34, E35, E36, E37 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos, av20: set Pos, av21: set Pos, av22: set Pos, av23: set Pos, av24: set Pos, av25: set Pos, av26: set Pos, av27: set Pos, av28: set Pos, av29: set Pos, av30: set Pos, av31: set Pos, av32: set Pos, av33: set Pos, av34: set Pos, av35: set Pos, av36: set Pos, av37: set Pos, av38: set Pos, av39: set Pos, av40: set Pos, av41: set Pos, av42: set Pos, av43: set Pos, av44: set Pos, av45: set Pos, av46: set Pos, av47: set Pos, av48: set Pos, av49: set Pos, av50: set Pos, av51: set Pos, av52: set Pos, av53: set Pos, av54: set Pos, av55: set Pos, av56: set Pos, av57: set Pos, av58: set Pos, av59: set Pos, av60: set Pos, av61: set Pos, av62: set Pos, av63: set Pos, av64: set Pos, av65: set Pos, av66: set Pos, av67: set Pos, av68: set Pos, av69: set Pos, av70: set Pos, av71: set Pos, av72: set Pos, av73: set Pos, av74: set Pos, av75: set Pos, av76: set Pos, av77: set Pos, av78: set Pos, av79: set Pos, av80: set Pos, av81: set Pos, av82: set Pos, av83: set Pos, av84: set Pos, av85: set Pos, av86: set Pos, av87: set Pos, av88: set Pos, av89: set Pos, av90: set Pos, av91: set Pos, av92: set Pos, av93: set Pos, av94: set Pos, av95: set Pos, av96: set Pos, av97: set Pos, av98: set Pos, av99: set Pos, av100: set Pos, av101: set Pos, av102: set Pos, av103: set Pos, av104: set Pos, av105: set Pos, av106: set Pos, av107: set Pos, av108: set Pos, av109: set Pos, av110: set Pos, av111: set Pos, av112: set Pos, av113: set Pos, av114: set Pos, av115: set Pos, av116: set Pos, av117: set Pos, av118: set Pos, av119: set Pos, av120: set Pos, av121: set Pos, av122: set Pos, av123: set Pos, av124: set Pos, av125: set Pos, av126: set Pos, av127: set Pos, av128: set Pos, av129: set Pos, av130: set Pos, av131: set Pos, av132: set Pos, av133: set Pos, av134: set Pos, av135: set Pos, av136: set Pos, av137: set Pos, av138: set Pos, av139: set Pos, av140: set Pos, av141: set Pos, av142: set Pos, av143: set Pos, av144: set Pos, av145: set Pos, av146: set Pos, av147: set Pos, av148: set Pos, av149: set Pos, av150: set Pos, av151: set Pos, av152: set Pos, av153: set Pos, av154: set Pos, av155: set Pos, av156: set Pos, av157: set Pos, av158: set Pos, av159: set Pos, av160: set Pos, av161: set Pos, av162: set Pos, av163: set Pos, av164: set Pos, av165: set Pos, av166: set Pos, av167: set Pos, av168: set Pos, av169: set Pos, av170: set Pos, av171: set Pos, av172: set Pos, av173: set Pos, av174: set Pos, av175: set Pos, av176: set Pos, av177: set Pos, av178: set Pos, av179: set Pos, av180: set Pos, av181: set Pos, av182: set Pos, av183: set Pos, av184: set Pos, av185: set Pos, av186: set Pos, av187: set Pos, av188: set Pos, av189: set Pos, av190: set Pos, av191: set Pos, av192: set Pos, av193: set Pos, av194: set Pos, av195: set Pos, av196: set Pos, av197: set Pos, av198: set Pos, av199: set Pos, av200: set Pos, av201: set Pos, av202: set Pos, av203: set Pos, av204: set Pos, av205: set Pos, av206: set Pos, av207: set Pos, av208: set Pos, av209: set Pos, av210: set Pos, av211: set Pos, av212: set Pos, av213: set Pos, av214: set Pos, av215: set Pos, av216: set Pos, av217: set Pos, av218: set Pos, av219: set Pos, av220: set Pos, av221: set Pos, av222: set Pos, av223: set Pos, av224: set Pos, av225: set Pos, av226: set Pos, av227: set Pos, av228: set Pos, av229: set Pos, av230: set Pos, av231: set Pos, av232: set Pos, av233: set Pos, av234: set Pos, av235: set Pos, av236: set Pos, av237: set Pos, av238: set Pos, av239: set Pos, av240: set Pos, av241: set Pos, av242: set Pos, av243: set Pos, av244: set Pos, av245: set Pos, av246: set Pos, av247: set Pos, av248: set Pos, av249: set Pos, av250: set Pos, av251: set Pos, av252: set Pos, av253: set Pos, av254: set Pos, av255: set Pos, av256: set Pos, av257: set Pos, av258: set Pos, av259: set Pos, av260: set Pos, av261: set Pos, av262: set Pos, av263: set Pos, av264: set Pos, av265: set Pos, av266: set Pos, av267: set Pos, av268: set Pos, av269: set Pos, av270: set Pos, av271: set Pos, av272: set Pos, av273: set Pos, av274: set Pos, av275: set Pos, av276: set Pos, av277: set Pos, av278: set Pos, av279: set Pos, av280: set Pos, av281: set Pos, av282: set Pos, av283: set Pos, av284: set Pos, av285: set Pos, av286: set Pos, av287: set Pos, av288: set Pos, av289: set Pos, av290: set Pos, av291: set Pos, av292: set Pos, av293: set Pos, av294: set Pos, av295: set Pos, av296: set Pos, av297: set Pos, av298: set Pos, av299: set Pos, av300: set Pos, av301: set Pos, av302: set Pos, av303: set Pos, av304: set Pos, av305: set Pos, av306: set Pos, av307: set Pos, av308: set Pos, av309: set Pos, av310: set Pos, av311: set Pos, av312: set Pos, av313: set Pos, av314: set Pos, av315: set Pos, av316: set Pos, av317: set Pos, av318: set Pos, av319: set Pos, av320: set Pos, av321: set Pos, av322: set Pos, av323: set Pos, av324: set Pos, av325: set Pos, av326: set Pos, av327: set Pos, av328: set Pos, av329: set Pos, av330: set Pos, av331: set Pos, av332: set Pos, av333: set Pos, av334: set Pos, av335: set Pos, av336: set Pos, av337: set Pos, av338: set Pos, av339: set Pos, av340: set Pos, av341: set Pos, av342: set Pos, av343: set Pos, av344: set Pos, av345: set Pos, av346: set Pos, av347: set Pos, av348: set Pos, av349: set Pos, av350: set Pos, av351: set Pos, av352: set Pos, av353: set Pos, av354: set Pos, av355: set Pos, av356: set Pos, av357: set Pos, av358: set Pos, av359: set Pos, av360: set Pos, av361: set Pos, av362: set Pos, av363: set Pos, av364: set Pos, av365: set Pos, av366: set Pos, av367: set Pos, av368: set Pos, av369: set Pos, av370: set Pos, av371: set Pos, av372: set Pos, av373: set Pos, av374: set Pos, av375: set Pos, av376: set Pos, av377: set Pos, av378: set Pos, av379: set Pos, av380: set Pos, av381: set Pos, av382: set Pos, av383: set Pos, av384: set Pos, av385: set Pos, av386: set Pos, av387: set Pos, av388: set Pos, av389: set Pos, av390: set Pos, av391: set Pos, av392: set Pos, av393: set Pos, av394: set Pos, av395: set Pos, av396: set Pos, av397: set Pos, av398: set Pos, av399: set Pos, av400: set Pos, av401: set Pos, av402: set Pos, av403: set Pos, av404: set Pos, av405: set Pos, av406: set Pos, av407: set Pos, av408: set Pos, av409: set Pos, av410: set Pos, av411: set Pos, av412: set Pos, av413: set Pos, av414: set Pos, av415: set Pos, av416: set Pos, av417: set Pos, av418: set Pos, av419: set Pos, av420: set Pos, av421: set Pos, av422: set Pos, av423: set Pos, av424: set Pos, av425: set Pos, av426: set Pos, av427: set Pos, av428: set Pos, av429: set Pos, av430: set Pos, av431: set Pos, av432: set Pos, av433: set Pos, av434: set Pos, av435: set Pos, av436: set Pos, av437: set Pos, av438: set Pos, av439: set Pos, av440: set Pos, av441: set Pos, av442: set Pos, av443: set Pos, av444: set Pos, av445: set Pos, av446: set Pos, av447: set Pos, av448: set Pos, av449: set Pos, av450: set Pos, av451: set Pos, av452: set Pos, av453: set Pos, av454: set Pos, av455: set Pos, av456: set Pos, av457: set Pos, av458: set Pos, av459: set Pos, av460: set Pos, av461: set Pos, av462: set Pos, av463: set Pos, av464: set Pos, av465: set Pos, av466: set Pos, av467: set Pos, av468: set Pos, av469: set Pos, av470: set Pos, av471: set Pos, av472: set Pos, av473: set Pos, av474: set Pos, av475: set Pos, av476: set Pos, av477: set Pos, av478: set Pos, av479: set Pos, av480: set Pos, av481: set Pos, av482: set Pos, av483: set Pos, av484: set Pos, av485: set Pos, av486: set Pos, av487: set Pos, av488: set Pos, av489: set Pos, av490: set Pos, av491: set Pos, av492: set Pos, av493: set Pos, av494: set Pos, av495: set Pos, av496: set Pos, av497: set Pos, av498: set Pos, av499: set Pos, av500: set Pos, av501: set Pos, av502: set Pos, av503: set Pos, av504: set Pos, av505: set Pos, av506: set Pos, av507: set Pos, av508: set Pos, av509: set Pos, av510: set Pos, av511: set Pos, av512: set Pos, av513: set Pos, av514: set Pos, av515: set Pos, av516: set Pos, av517: set Pos, av518: set Pos, av519: set Pos, av520: set Pos, av521: set Pos, av522: set Pos, av523: set Pos, av524: set Pos, av525: set Pos, av526: set Pos, av527: set Pos, av528: set Pos, av529: set Pos, av530: set Pos, av531: set Pos, av532: set Pos, av533: set Pos, av534: set Pos, av535: set Pos, av536: set Pos, av537: set Pos, av538: set Pos, av539: set Pos, av540: set Pos, av541: set Pos, av542: set Pos, av543: set Pos, av544: set Pos, av545: set Pos, av546: set Pos, av547: set Pos, av548: set Pos, av549: set Pos, av550: set Pos, av551: set Pos, av552: set Pos, av553: set Pos, av554: set Pos, av555: set Pos, av556: set Pos, av557: set Pos, av558: set Pos, av559: set Pos, av560: set Pos, av561: set Pos, av562: set Pos, av563: set Pos, av564: set Pos, av565: set Pos, av566: set Pos, av567: set Pos, av568: set Pos, av569: set Pos, av570: set Pos, av571: set Pos, av572: set Pos, av573: set Pos, av574: set Pos, av575: set Pos, av576: set Pos, av577: set Pos, av578: set Pos, av579: set Pos, av580: set Pos, av581: set Pos, av582: set Pos, av583: set Pos, av584: set Pos, av585: set Pos, av586: set Pos, av587: set Pos, av588: set Pos, av589: set Pos, av590: set Pos, av591: set Pos, av592: set Pos, av593: set Pos, av594: set Pos, av595: set Pos, av596: set Pos, av597: set Pos, av598: set Pos, av599: set Pos, av600: set Pos, av601: set Pos, av602: set Pos, av603: set Pos, av604: set Pos, av605: set Pos, av606: set Pos, av607: set Pos, av608: set Pos, av609: set Pos, av610: set Pos, av611: set Pos, av612: set Pos, av613: set Pos, av614: set Pos, av615: set Pos, av616: set Pos, av617: set Pos, av618: set Pos, av619: set Pos, av620: set Pos, av621: set Pos, av622: set Pos, av623: set Pos, av624: set Pos, av625: set Pos, av626: set Pos, av627: set Pos, av628: set Pos, av629: set Pos, av630: set Pos, av631: set Pos, av632: set Pos, av633: set Pos, av634: set Pos, av635: set Pos, av636: set Pos, av637: set Pos, av638: set Pos, av639: set Pos, av640: set Pos, av641: set Pos, av642: set Pos, av643: set Pos, av644: set Pos, av645: set Pos, av646: set Pos, av647: set Pos, av648: set Pos, av649: set Pos, av650: set Pos, av651: set Pos, av652: set Pos, av653: set Pos, av654: set Pos, av655: set Pos, av656: set Pos, av657: set Pos, av658: set Pos, av659: set Pos, av660: set Pos, av661: set Pos, av662: set Pos, av663: set Pos, av664: set Pos, av665: set Pos, av666: set Pos, av667: set Pos, av668: set Pos, av669: set Pos, av670: set Pos, av671: set Pos, av672: set Pos, av673: set Pos, av674: set Pos, av675: set Pos, av676: set Pos, av677: set Pos, av678: set Pos, av679: set Pos, av680: set Pos, av681: set Pos, av682: set Pos, av683: set Pos, av684: set Pos, av685: set Pos, av686: set Pos, av687: set Pos, av688: set Pos, av689: set Pos, av690: set Pos, av691: set Pos, av692: set Pos, av693: set Pos, av694: set Pos, av695: set Pos, av696: set Pos, av697: set Pos }
one sig A0, A1, A2, A3, A4, A5, A6, A7 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos, ev20: set Pos, ev21: set Pos, ev22: set Pos, ev23: set Pos, ev24: set Pos, ev25: set Pos, ev26: set Pos, ev27: set Pos, ev28: set Pos, ev29: set Pos, ev30: set Pos, ev31: set Pos, ev32: set Pos, ev33: set Pos, ev34: set Pos, ev35: set Pos, ev36: set Pos, ev37: set Pos, ev38: set Pos, ev39: set Pos, ev40: set Pos, ev41: set Pos, ev42: set Pos, ev43: set Pos, ev44: set Pos, ev45: set Pos, ev46: set Pos, ev47: set Pos, ev48: set Pos, ev49: set Pos, ev50: set Pos, ev51: set Pos, ev52: set Pos, ev53: set Pos, ev54: set Pos, ev55: set Pos, ev56: set Pos, ev57: set Pos, ev58: set Pos, ev59: set Pos, ev60: set Pos, ev61: set Pos, ev62: set Pos, ev63: set Pos, ev64: set Pos, ev65: set Pos, ev66: set Pos, ev67: set Pos, ev68: set Pos, ev69: set Pos, ev70: set Pos, ev71: set Pos, ev72: set Pos, ev73: set Pos, ev74: set Pos, ev75: set Pos, ev76: set Pos, ev77: set Pos, ev78: set Pos, ev79: set Pos, ev80: set Pos, ev81: set Pos, ev82: set Pos, ev83: set Pos, ev84: set Pos, ev85: set Pos, ev86: set Pos, ev87: set Pos, ev88: set Pos, ev89: set Pos, ev90: set Pos, ev91: set Pos, ev92: set Pos, ev93: set Pos, ev94: set Pos, ev95: set Pos, ev96: set Pos, ev97: set Pos, ev98: set Pos, ev99: set Pos, ev100: set Pos, ev101: set Pos, ev102: set Pos, ev103: set Pos, ev104: set Pos, ev105: set Pos, ev106: set Pos, ev107: set Pos, ev108: set Pos, ev109: set Pos, ev110: set Pos, ev111: set Pos, ev112: set Pos, ev113: set Pos, ev114: set Pos, ev115: set Pos, ev116: set Pos, ev117: set Pos, ev118: set Pos, ev119: set Pos, ev120: set Pos, ev121: set Pos, ev122: set Pos, ev123: set Pos, ev124: set Pos, ev125: set Pos, ev126: set Pos, ev127: set Pos, ev128: set Pos, ev129: set Pos, ev130: set Pos, ev131: set Pos, ev132: set Pos, ev133: set Pos, ev134: set Pos, ev135: set Pos, ev136: set Pos, ev137: set Pos, ev138: set Pos, ev139: set Pos, ev140: set Pos, ev141: set Pos, ev142: set Pos, ev143: set Pos, ev144: set Pos, ev145: set Pos, ev146: set Pos, ev147: set Pos, ev148: set Pos, ev149: set Pos, ev150: set Pos, ev151: set Pos, ev152: set Pos, ev153: set Pos, ev154: set Pos, ev155: set Pos, ev156: set Pos, ev157: set Pos, ev158: set Pos, ev159: set Pos, ev160: set Pos, ev161: set Pos, ev162: set Pos, ev163: set Pos, ev164: set Pos, ev165: set Pos, ev166: set Pos, ev167: set Pos, ev168: set Pos, ev169: set Pos, ev170: set Pos, ev171: set Pos, ev172: set Pos, ev173: set Pos, ev174: set Pos, ev175: set Pos, ev176: set Pos, ev177: set Pos, ev178: set Pos, ev179: set Pos, ev180: set Pos, ev181: set Pos, ev182: set Pos, ev183: set Pos, ev184: set Pos, ev185: set Pos, ev186: set Pos, ev187: set Pos, ev188: set Pos, ev189: set Pos, ev190: set Pos, ev191: set Pos, ev192: set Pos, ev193: set Pos, ev194: set Pos, ev195: set Pos, ev196: set Pos, ev197: set Pos, ev198: set Pos, ev199: set Pos, ev200: set Pos, ev201: set Pos, ev202: set Pos, ev203: set Pos, ev204: set Pos, ev205: set Pos, ev206: set Pos, ev207: set Pos, ev208: set Pos, ev209: set Pos, ev210: set Pos, ev211: set Pos, ev212: set Pos, ev213: set Pos, ev214: set Pos, ev215: set Pos, ev216: set Pos, ev217: set Pos, ev218: set Pos, ev219: set Pos, ev220: set Pos, ev221: set Pos, ev222: set Pos, ev223: set Pos, ev224: set Pos, ev225: set Pos, ev226: set Pos, ev227: set Pos, ev228: set Pos, ev229: set Pos, ev230: set Pos, ev231: set Pos, ev232: set Pos, ev233: set Pos, ev234: set Pos, ev235: set Pos, ev236: set Pos, ev237: set Pos, ev238: set Pos, ev239: set Pos, ev240: set Pos, ev241: set Pos, ev242: set Pos, ev243: set Pos, ev244: set Pos, ev245: set Pos, ev246: set Pos, ev247: set Pos, ev248: set Pos, ev249: set Pos, ev250: set Pos, ev251: set Pos, ev252: set Pos, ev253: set Pos, ev254: set Pos, ev255: set Pos, ev256: set Pos, ev257: set Pos, ev258: set Pos, ev259: set Pos, ev260: set Pos, ev261: set Pos, ev262: set Pos, ev263: set Pos, ev264: set Pos, ev265: set Pos, ev266: set Pos, ev267: set Pos, ev268: set Pos, ev269: set Pos, ev270: set Pos, ev271: set Pos, ev272: set Pos, ev273: set Pos, ev274: set Pos, ev275: set Pos, ev276: set Pos, ev277: set Pos, ev278: set Pos, ev279: set Pos, ev280: set Pos, ev281: set Pos, ev282: set Pos, ev283: set Pos, ev284: set Pos, ev285: set Pos, ev286: set Pos, ev287: set Pos, ev288: set Pos, ev289: set Pos, ev290: set Pos, ev291: set Pos, ev292: set Pos, ev293: set Pos, ev294: set Pos, ev295: set Pos, ev296: set Pos, ev297: set Pos, ev298: set Pos, ev299: set Pos, ev300: set Pos, ev301: set Pos, ev302: set Pos, ev303: set Pos, ev304: set Pos, ev305: set Pos, ev306: set Pos, ev307: set Pos, ev308: set Pos, ev309: set Pos, ev310: set Pos, ev311: set Pos, ev312: set Pos, ev313: set Pos, ev314: set Pos, ev315: set Pos, ev316: set Pos, ev317: set Pos, ev318: set Pos, ev319: set Pos, ev320: set Pos, ev321: set Pos, ev322: set Pos, ev323: set Pos, ev324: set Pos, ev325: set Pos, ev326: set Pos, ev327: set Pos, ev328: set Pos, ev329: set Pos, ev330: set Pos, ev331: set Pos, ev332: set Pos, ev333: set Pos, ev334: set Pos, ev335: set Pos, ev336: set Pos, ev337: set Pos, ev338: set Pos, ev339: set Pos, ev340: set Pos, ev341: set Pos, ev342: set Pos, ev343: set Pos, ev344: set Pos, ev345: set Pos, ev346: set Pos, ev347: set Pos, ev348: set Pos, ev349: set Pos, ev350: set Pos, ev351: set Pos, ev352: set Pos, ev353: set Pos, ev354: set Pos, ev355: set Pos, ev356: set Pos, ev357: set Pos, ev358: set Pos, ev359: set Pos, ev360: set Pos, ev361: set Pos, ev362: set Pos, ev363: set Pos, ev364: set Pos, ev365: set Pos, ev366: set Pos, ev367: set Pos, ev368: set Pos, ev369: set Pos, ev370: set Pos, ev371: set Pos, ev372: set Pos, ev373: set Pos, ev374: set Pos, ev375: set Pos, ev376: set Pos, ev377: set Pos, ev378: set Pos, ev379: set Pos, ev380: set Pos, ev381: set Pos, ev382: set Pos, ev383: set Pos, ev384: set Pos, ev385: set Pos, ev386: set Pos, ev387: set Pos, ev388: set Pos, ev389: set Pos, ev390: set Pos, ev391: set Pos, ev392: set Pos, ev393: set Pos, ev394: set Pos, ev395: set Pos, ev396: set Pos, ev397: set Pos, ev398: set Pos, ev399: set Pos, ev400: set Pos, ev401: set Pos, ev402: set Pos, ev403: set Pos, ev404: set Pos, ev405: set Pos, ev406: set Pos, ev407: set Pos, ev408: set Pos, ev409: set Pos, ev410: set Pos, ev411: set Pos, ev412: set Pos, ev413: set Pos, ev414: set Pos, ev415: set Pos, ev416: set Pos, ev417: set Pos, ev418: set Pos, ev419: set Pos, ev420: set Pos, ev421: set Pos, ev422: set Pos, ev423: set Pos, ev424: set Pos, ev425: set Pos, ev426: set Pos, ev427: set Pos, ev428: set Pos, ev429: set Pos, ev430: set Pos, ev431: set Pos, ev432: set Pos, ev433: set Pos, ev434: set Pos, ev435: set Pos, ev436: set Pos, ev437: set Pos, ev438: set Pos, ev439: set Pos, ev440: set Pos, ev441: set Pos, ev442: set Pos, ev443: set Pos, ev444: set Pos, ev445: set Pos, ev446: set Pos, ev447: set Pos, ev448: set Pos, ev449: set Pos, ev450: set Pos, ev451: set Pos, ev452: set Pos, ev453: set Pos, ev454: set Pos, ev455: set Pos, ev456: set Pos, ev457: set Pos, ev458: set Pos, ev459: set Pos, ev460: set Pos, ev461: set Pos, ev462: set Pos, ev463: set Pos, ev464: set Pos, ev465: set Pos, ev466: set Pos, ev467: set Pos, ev468: set Pos, ev469: set Pos, ev470: set Pos, ev471: set Pos, ev472: set Pos, ev473: set Pos, ev474: set Pos, ev475: set Pos, ev476: set Pos, ev477: set Pos, ev478: set Pos, ev479: set Pos, ev480: set Pos, ev481: set Pos, ev482: set Pos, ev483: set Pos, ev484: set Pos, ev485: set Pos, ev486: set Pos, ev487: set Pos, ev488: set Pos, ev489: set Pos, ev490: set Pos, ev491: set Pos, ev492: set Pos, ev493: set Pos, ev494: set Pos, ev495: set Pos, ev496: set Pos, ev497: set Pos, ev498: set Pos, ev499: set Pos, ev500: set Pos, ev501: set Pos, ev502: set Pos, ev503: set Pos, ev504: set Pos, ev505: set Pos, ev506: set Pos, ev507: set Pos, ev508: set Pos, ev509: set Pos, ev510: set Pos, ev511: set Pos, ev512: set Pos, ev513: set Pos, ev514: set Pos, ev515: set Pos, ev516: set Pos, ev517: set Pos, ev518: set Pos, ev519: set Pos, ev520: set Pos, ev521: set Pos, ev522: set Pos, ev523: set Pos, ev524: set Pos, ev525: set Pos, ev526: set Pos, ev527: set Pos, ev528: set Pos, ev529: set Pos, ev530: set Pos, ev531: set Pos, ev532: set Pos, ev533: set Pos, ev534: set Pos, ev535: set Pos, ev536: set Pos, ev537: set Pos, ev538: set Pos, ev539: set Pos, ev540: set Pos, ev541: set Pos, ev542: set Pos, ev543: set Pos, ev544: set Pos, ev545: set Pos, ev546: set Pos, ev547: set Pos, ev548: set Pos, ev549: set Pos, ev550: set Pos, ev551: set Pos, ev552: set Pos, ev553: set Pos, ev554: set Pos, ev555: set Pos, ev556: set Pos, ev557: set Pos, ev558: set Pos, ev559: set Pos, ev560: set Pos, ev561: set Pos, ev562: set Pos, ev563: set Pos, ev564: set Pos, ev565: set Pos, ev566: set Pos, ev567: set Pos, ev568: set Pos, ev569: set Pos, ev570: set Pos, ev571: set Pos, ev572: set Pos, ev573: set Pos, ev574: set Pos, ev575: set Pos, ev576: set Pos, ev577: set Pos, ev578: set Pos, ev579: set Pos, ev580: set Pos, ev581: set Pos, ev582: set Pos, ev583: set Pos, ev584: set Pos, ev585: set Pos, ev586: set Pos, ev587: set Pos, ev588: set Pos, ev589: set Pos, ev590: set Pos, ev591: set Pos, ev592: set Pos, ev593: set Pos, ev594: set Pos, ev595: set Pos, ev596: set Pos, ev597: set Pos, ev598: set Pos, ev599: set Pos, ev600: set Pos, ev601: set Pos, ev602: set Pos, ev603: set Pos, ev604: set Pos, ev605: set Pos, ev606: set Pos, ev607: set Pos, ev608: set Pos, ev609: set Pos, ev610: set Pos, ev611: set Pos, ev612: set Pos, ev613: set Pos, ev614: set Pos, ev615: set Pos, ev616: set Pos, ev617: set Pos, ev618: set Pos, ev619: set Pos, ev620: set Pos, ev621: set Pos, ev622: set Pos, ev623: set Pos, ev624: set Pos, ev625: set Pos, ev626: set Pos, ev627: set Pos, ev628: set Pos, ev629: set Pos, ev630: set Pos, ev631: set Pos, ev632: set Pos, ev633: set Pos, ev634: set Pos, ev635: set Pos, ev636: set Pos, ev637: set Pos, ev638: set Pos, ev639: set Pos, ev640: set Pos, ev641: set Pos, ev642: set Pos, ev643: set Pos, ev644: set Pos, ev645: set Pos, ev646: set Pos, ev647: set Pos, ev648: set Pos, ev649: set Pos, ev650: set Pos, ev651: set Pos, ev652: set Pos, ev653: set Pos, ev654: set Pos, ev655: set Pos, ev656: set Pos, ev657: set Pos, ev658: set Pos, ev659: set Pos, ev660: set Pos, ev661: set Pos, ev662: set Pos, ev663: set Pos, ev664: set Pos, ev665: set Pos, ev666: set Pos, ev667: set Pos, ev668: set Pos, ev669: set Pos, ev670: set Pos, ev671: set Pos, ev672: set Pos, ev673: set Pos, ev674: set Pos, ev675: set Pos, ev676: set Pos, ev677: set Pos, ev678: set Pos, ev679: set Pos, ev680: set Pos, ev681: set Pos, ev682: set Pos, ev683: set Pos, ev684: set Pos, ev685: set Pos, ev686: set Pos, ev687: set Pos, ev688: set Pos, ev689: set Pos, ev690: set Pos, ev691: set Pos, ev692: set Pos, ev693: set Pos, ev694: set Pos, ev695: set Pos, ev696: set Pos, ev697: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4, C5, L5, D5, C6, L6, D6, C7, L7, D7 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (T0 + (T1 + T2)) }
fun un: set Label { ((T3 + T4) + (T5 + T6)) }
fun bin: set Label { (T7 + (T8 + T9)) }
fun nonempty: set Fiber { (((((E1 + E2) + (E3 + E4)) + ((E5 + E6) + (E7 + (E8 + E9)))) + (((E10 + E11) + (E12 + E13)) + ((E14 + E15) + (E16 + (E17 + E18))))) + ((((E19 + E20) + (E21 + E22)) + ((E23 + E24) + (E25 + (E26 + E27)))) + (((E28 + E29) + (E30 + (E31 + E32))) + ((E33 + E34) + (E35 + (E36 + E37)))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { (((U0->U1 + U1->U2) + (U2->U3 + U3->U4)) + ((U4->U5 + U5->U6) + (U6->U7 + U7->U8))) }
fun carrierNext: Carrier -> Carrier { (((((A0->A1 + A1->A2) + (A2->A3 + A3->A4)) + ((A4->A5 + A5->A6) + (A6->A7 + A7->R))) + (((R->C0 + C0->L0) + (L0->D0 + D0->C1)) + ((C1->L1 + L1->D1) + (D1->C2 + C2->L2)))) + ((((L2->D2 + D2->C3) + (C3->L3 + L3->D3)) + ((D3->C4 + C4->L4) + (L4->D4 + D4->C5))) + (((C5->L5 + L5->D5) + (D5->C6 + C6->L6)) + ((L6->D6 + D6->C7) + (C7->L7 + L7->D7))))) }
fun child[a: Anchor]: set Port { a.((((A0->C0 + A1->C1) + (A2->C2 + A3->C3)) + ((A4->C4 + A5->C5) + (A6->C6 + A7->C7)))) }
fun left[a: Anchor]: set Port { a.((((A0->L0 + A1->L1) + (A2->L2 + A3->L3)) + ((A4->L4 + A5->L5) + (A6->L6 + A7->L7)))) }
fun right[a: Anchor]: set Port { a.((((A0->D0 + A1->D1) + (A2->D2 + A3->D3)) + ((A4->D4 + A5->D5) + (A6->D6 + A7->D7)))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
C5.src = A5
L5.src = A5
D5.src = A5
(some C5.target iff A5.lab in un and some A5.lab)
(some L5.target iff A5.lab in bin and some A5.lab)
(some D5.target iff A5.lab in bin and some A5.lab)
C6.src = A6
L6.src = A6
D6.src = A6
(some C6.target iff A6.lab in un and some A6.lab)
(some L6.target iff A6.lab in bin and some A6.lab)
(some D6.target iff A6.lab in bin and some A6.lab)
C7.src = A7
L7.src = A7
D7.src = A7
(some C7.target iff A7.lab in un and some A7.lab)
(some L7.target iff A7.lab in bin and some A7.lab)
(some D7.target iff A7.lab in bin and some A7.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
no A3.graph & (((A0 + A1) + (A2 + A3)))
no A4.graph & (((A0 + A1) + (A2 + (A3 + A4))))
no A5.graph & (((A0 + (A1 + A2)) + (A3 + (A4 + A5))))
no A6.graph & (((A0 + (A1 + A2)) + ((A3 + A4) + (A5 + A6))))
no A7.graph & ((((A0 + A1) + (A2 + A3)) + ((A4 + A5) + (A6 + A7))))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
lone lab.T2
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un implies #(target.A2) > 1
some A2.lab implies some A1.lab
some A3.lab and A3.lab in un implies #(target.A3) > 1
some A3.lab implies some A2.lab
some A4.lab and A4.lab in un implies #(target.A4) > 1
some A4.lab implies some A3.lab
some A5.lab and A5.lab in un implies #(target.A5) > 1
some A5.lab implies some A4.lab
some A6.lab and A6.lab in un implies #(target.A6) > 1
some A6.lab implies some A5.lab
some A7.lab and A7.lab in un implies #(target.A7) > 1
some A7.lab implies some A6.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q0
E7.qo = Q0
E8.qi = Q0
E8.qo = Q0
E9.qi = Q0
E9.qo = Q0
E10.qi = Q0
E10.qo = Q0
E11.qi = Q0
E11.qo = Q0
E12.qi = Q0
E12.qo = Q0
E13.qi = Q0
E13.qo = Q0
E14.qi = Q0
E14.qo = Q0
E15.qi = Q0
E15.qo = Q0
E16.qi = Q0
E16.qo = Q0
E17.qi = Q0
E17.qo = Q0
E18.qi = Q0
E18.qo = Q0
E19.qi = Q0
E19.qo = Q0
E20.qi = Q0
E20.qo = Q0
E21.qi = Q0
E21.qo = Q0
E22.qi = Q0
E22.qo = Q0
E23.qi = Q0
E23.qo = Q0
E24.qi = Q0
E24.qo = Q0
E25.qi = Q0
E25.qo = Q0
E26.qi = Q0
E26.qo = Q0
E27.qi = Q0
E27.qo = Q0
E28.qi = Q0
E28.qo = Q0
E29.qi = Q0
E29.qo = Q0
E30.qi = Q0
E30.qo = Q0
E31.qi = Q0
E31.qo = Q0
E32.qi = Q0
E32.qo = Q0
E33.qi = Q0
E33.qo = Q0
E34.qi = Q0
E34.qo = Q0
E35.qi = Q0
E35.qo = Q0
E36.qi = Q0
E36.qo = Q0
E37.qi = Q0
E37.qo = Q0
all e: used | e.fiber in (E0) implies #e.cost = 0
all e: used | e.fiber in ((((E1 + E4) + (E6 + E7)) + ((E9 + E12) + (E13 + (E15 + E17))))) implies #e.cost = 2
all e: used | e.fiber in (((E2 + E3) + (E5 + E11))) implies #e.cost = 1
all e: used | e.fiber in ((((E8 + E10) + (E14 + E16)) + ((E18 + E19) + (E21 + E23)))) implies #e.cost = 3
all e: used | e.fiber in (((E20 + (E22 + E24)) + (E25 + (E27 + E29)))) implies #e.cost = 4
all e: used | e.fiber in (((E26 + E28) + (E30 + E31))) implies #e.cost = 5
all e: used | e.fiber in ((E32 + E33)) implies #e.cost = 6
all e: used | e.fiber in ((E34 + E35)) implies #e.cost = 7
all e: used | e.fiber in ((E36 + E37)) implies #e.cost = 8
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q0)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 implies a.state = Q0
all a: active | a.lab = T3 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T4 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T5 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T6 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T8 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T9 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
}
fun range0: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop0: set Pos { (P3 + P4) }
fun next0: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift0_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun shift0_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P3 + P4->P4))) }
fun shift0_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P3 + (P3->P4 + P4->P3))) }
fun shift0_4: Pos -> Pos { ((P0->P4 + P1->P3) + (P2->P4 + (P3->P3 + P4->P4))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range0 | loop0 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range0 | loop0 in (range0 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range0 | some (loop0 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range0 | some (loop0 & (range0 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range0 | (i.shift0_1) in (range0 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range0 | (i.shift0_1).future0 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range0 | (i.shift0_1).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range0 | (i.shift0_2) in (range0 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range0 | (i.shift0_2).future0 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range0 | (i.shift0_2).future0 in (range0 - e.target.av)}
all e: used | e.fiber in ((E23 + (E31 + E35))) implies e.ev = {i: range0 | (i.shift0_3) in (e.target.av)}
all e: used | e.fiber in ((E24 + (E32 + E36))) implies e.ev = {i: range0 | (i.shift0_3) in (range0 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range0 | some ((i.shift0_3).future0 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range0 | some ((i.shift0_3).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range0 | (i.shift0_3).future0 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range0 | (i.shift0_3).future0 in (range0 - e.target.av)}
all e: used | e.fiber in ((E29 + (E33 + E37))) implies e.ev = {i: range0 | (i.shift0_4) in (e.target.av)}
all e: used | e.fiber in ((E30 + E34)) implies e.ev = {i: range0 | (i.shift0_4) in (range0 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next0.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop1: set Pos { P4 }
fun next1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift1_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun shift1_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift1_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift1_4: Pos -> Pos { ((P0->P4 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range1 | loop1 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range1 | loop1 in (range1 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range1 | some (loop1 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range1 | some (loop1 & (range1 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range1 | (i.shift1_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range1 | (i.shift1_1) in (range1 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range1 | (i.shift1_1).future1 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range1 | (i.shift1_1).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range1 | (i.shift1_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range1 | (i.shift1_2) in (range1 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range1 | (i.shift1_2).future1 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range1 | (i.shift1_2).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range1 | (i.shift1_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range1 | (i.shift1_3) in (range1 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range1 | some ((i.shift1_3).future1 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range1 | some ((i.shift1_3).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range1 | (i.shift1_3).future1 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range1 | (i.shift1_3).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (((E29 + E31) + (E33 + (E35 + E37)))) implies e.ev = {i: range1 | (i.shift1_4) in (e.target.av)}
all e: used | e.fiber in (((E30 + E32) + (E34 + E36))) implies e.ev = {i: range1 | (i.shift1_4) in (range1 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next1.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fun range2: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop2: set Pos { P3 }
fun next2: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift2_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun shift2_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P3 + P3->P3)) }
fun shift2_3: Pos -> Pos { ((P0->P3 + P1->P3) + (P2->P3 + P3->P3)) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range2 | (i.shift2_0) in (range2 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range2 | (i.shift2_0).future2 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range2 | (i.shift2_0).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range2 | loop2 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range2 | loop2 in (range2 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range2 | some (loop2 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range2 | some (loop2 & (range2 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range2 | (i.shift2_1) in (range2 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range2 | (i.shift2_1).future2 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range2 | (i.shift2_1).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range2 | (i.shift2_2) in (range2 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range2 | (i.shift2_2).future2 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range2 | (i.shift2_2).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (((E23 + (E29 + E31)) + (E33 + (E35 + E37)))) implies e.ev = {i: range2 | (i.shift2_3) in (e.target.av)}
all e: used | e.fiber in (((E24 + E30) + (E32 + (E34 + E36)))) implies e.ev = {i: range2 | (i.shift2_3) in (range2 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range2 | some ((i.shift2_3).future2 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range2 | some ((i.shift2_3).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range2 | (i.shift2_3).future2 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range2 | (i.shift2_3).future2 in (range2 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range2 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next2.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range2 | some (i.future2 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range2 | i.future2 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range2 - left[a].ev) + right[a].ev)
}
fun range3: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop3: set Pos { (P2 + (P3 + P4)) }
fun next3: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift3_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun shift3_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P2 + P4->P3))) }
fun shift3_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift3_4: Pos -> Pos { ((P0->P4 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range3 | (i.shift3_0) in (range3 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range3 | (i.shift3_0).future3 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range3 | (i.shift3_0).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range3 | loop3 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range3 | loop3 in (range3 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range3 | some (loop3 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range3 | some (loop3 & (range3 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range3 | (i.shift3_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range3 | (i.shift3_1) in (range3 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range3 | (i.shift3_1).future3 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range3 | (i.shift3_1).future3 in (range3 - e.target.av)}
all e: used | e.fiber in ((E17 + (E31 + E37))) implies e.ev = {i: range3 | (i.shift3_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + E32)) implies e.ev = {i: range3 | (i.shift3_2) in (range3 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range3 | (i.shift3_2).future3 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range3 | (i.shift3_2).future3 in (range3 - e.target.av)}
all e: used | e.fiber in ((E23 + E33)) implies e.ev = {i: range3 | (i.shift3_3) in (e.target.av)}
all e: used | e.fiber in ((E24 + E34)) implies e.ev = {i: range3 | (i.shift3_3) in (range3 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range3 | some ((i.shift3_3).future3 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range3 | some ((i.shift3_3).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range3 | (i.shift3_3).future3 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range3 | (i.shift3_3).future3 in (range3 - e.target.av)}
all e: used | e.fiber in ((E29 + E35)) implies e.ev = {i: range3 | (i.shift3_4) in (e.target.av)}
all e: used | e.fiber in ((E30 + E36)) implies e.ev = {i: range3 | (i.shift3_4) in (range3 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range3 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next3.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range3 | some (i.future3 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range3 | i.future3 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range3 - left[a].ev) + right[a].ev)
}
fun range4: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop4: set Pos { ((P0 + P1) + (P2 + P3)) }
fun next4: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift4_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun shift4_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P0 + P3->P1)) }
fun shift4_3: Pos -> Pos { ((P0->P3 + P1->P0) + (P2->P1 + P3->P2)) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in (((E0 + E1) + (E29 + E37))) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + E30)) implies e.ev = {i: range4 | (i.shift4_0) in (range4 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range4 | (i.shift4_0).future4 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range4 | (i.shift4_0).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range4 | loop4 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range4 | loop4 in (range4 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range4 | some (loop4 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range4 | some (loop4 & (range4 - e.target.av))}
all e: used | e.fiber in ((E11 + E31)) implies e.ev = {i: range4 | (i.shift4_1) in (e.target.av)}
all e: used | e.fiber in ((E12 + E32)) implies e.ev = {i: range4 | (i.shift4_1) in (range4 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range4 | (i.shift4_1).future4 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range4 | (i.shift4_1).future4 in (range4 - e.target.av)}
all e: used | e.fiber in ((E17 + E33)) implies e.ev = {i: range4 | (i.shift4_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + E34)) implies e.ev = {i: range4 | (i.shift4_2) in (range4 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range4 | (i.shift4_2).future4 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range4 | (i.shift4_2).future4 in (range4 - e.target.av)}
all e: used | e.fiber in ((E23 + E35)) implies e.ev = {i: range4 | (i.shift4_3) in (e.target.av)}
all e: used | e.fiber in ((E24 + E36)) implies e.ev = {i: range4 | (i.shift4_3) in (range4 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range4 | some ((i.shift4_3).future4 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range4 | some ((i.shift4_3).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range4 | (i.shift4_3).future4 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range4 | (i.shift4_3).future4 in (range4 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range4 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next4.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range4 | some (i.future4 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range4 | i.future4 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range4 - left[a].ev) + right[a].ev)
}
fun range5: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop5: set Pos { ((P1 + P2) + (P3 + P4)) }
fun next5: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift5_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun shift5_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P1 + P4->P2))) }
fun shift5_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P1 + (P3->P2 + P4->P3))) }
fun shift5_4: Pos -> Pos { ((P0->P4 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range5 | (i.shift5_0) in (range5 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range5 | (i.shift5_0).future5 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range5 | (i.shift5_0).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range5 | loop5 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range5 | loop5 in (range5 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range5 | some (loop5 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range5 | some (loop5 & (range5 - e.target.av))}
all e: used | e.fiber in ((E11 + E31)) implies e.ev = {i: range5 | (i.shift5_1) in (e.target.av)}
all e: used | e.fiber in ((E12 + E32)) implies e.ev = {i: range5 | (i.shift5_1) in (range5 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range5 | (i.shift5_1).future5 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range5 | (i.shift5_1).future5 in (range5 - e.target.av)}
all e: used | e.fiber in ((E17 + E33)) implies e.ev = {i: range5 | (i.shift5_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + E34)) implies e.ev = {i: range5 | (i.shift5_2) in (range5 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range5 | (i.shift5_2).future5 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range5 | (i.shift5_2).future5 in (range5 - e.target.av)}
all e: used | e.fiber in ((E23 + E35)) implies e.ev = {i: range5 | (i.shift5_3) in (e.target.av)}
all e: used | e.fiber in ((E24 + E36)) implies e.ev = {i: range5 | (i.shift5_3) in (range5 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range5 | some ((i.shift5_3).future5 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range5 | some ((i.shift5_3).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range5 | (i.shift5_3).future5 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range5 | (i.shift5_3).future5 in (range5 - e.target.av)}
all e: used | e.fiber in ((E29 + E37)) implies e.ev = {i: range5 | (i.shift5_4) in (e.target.av)}
all e: used | e.fiber in (E30) implies e.ev = {i: range5 | (i.shift5_4) in (range5 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range5 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next5.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range5 | some (i.future5 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range5 | i.future5 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range5 - left[a].ev) + right[a].ev)
}
fun range6: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop6: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun next6: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun future6: Pos -> Pos { (*next6) & (range6->range6) }
fun shift6_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift6_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun shift6_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P0 + P4->P1))) }
fun shift6_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P0 + (P3->P1 + P4->P2))) }
fun shift6_4: Pos -> Pos { ((P0->P4 + P1->P0) + (P2->P1 + (P3->P2 + P4->P3))) }
pred semantics6[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range6
ev in used->range6
all e: used | e.fiber in ((E0 + (E1 + E31))) implies e.ev = {i: range6 | (i.shift6_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + E32)) implies e.ev = {i: range6 | (i.shift6_0) in (range6 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range6 | (i.shift6_0).future6 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range6 | (i.shift6_0).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range6 | loop6 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range6 | loop6 in (range6 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range6 | some (loop6 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range6 | some (loop6 & (range6 - e.target.av))}
all e: used | e.fiber in ((E11 + E33)) implies e.ev = {i: range6 | (i.shift6_1) in (e.target.av)}
all e: used | e.fiber in ((E12 + E34)) implies e.ev = {i: range6 | (i.shift6_1) in (range6 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range6 | (i.shift6_1).future6 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range6 | (i.shift6_1).future6 in (range6 - e.target.av)}
all e: used | e.fiber in ((E17 + E35)) implies e.ev = {i: range6 | (i.shift6_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + E36)) implies e.ev = {i: range6 | (i.shift6_2) in (range6 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range6 | (i.shift6_2).future6 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range6 | (i.shift6_2).future6 in (range6 - e.target.av)}
all e: used | e.fiber in ((E23 + E37)) implies e.ev = {i: range6 | (i.shift6_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range6 | (i.shift6_3) in (range6 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range6 | some ((i.shift6_3).future6 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range6 | some ((i.shift6_3).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range6 | (i.shift6_3).future6 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range6 | (i.shift6_3).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range6 | (i.shift6_4) in (e.target.av)}
all e: used | e.fiber in (E30) implies e.ev = {i: range6 | (i.shift6_4) in (range6 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range6 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next6.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range6 | some (i.future6 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range6 | i.future6 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range6 - left[a].ev) + right[a].ev)
}
fun range7: set Pos { (P0 + (P1 + P2)) }
fun loop7: set Pos { (P0 + (P1 + P2)) }
fun next7: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P0)) }
fun future7: Pos -> Pos { (*next7) & (range7->range7) }
fun shift7_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift7_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P0)) }
fun shift7_2: Pos -> Pos { (P0->P2 + (P1->P0 + P2->P1)) }
pred semantics7[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range7
ev in used->range7
all e: used | e.fiber in (((E0 + E1) + (E23 + E33))) implies e.ev = {i: range7 | (i.shift7_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + (E24 + E34))) implies e.ev = {i: range7 | (i.shift7_0) in (range7 - e.target.av)}
all e: used | e.fiber in ((E3 + E25)) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (e.target.av))}
all e: used | e.fiber in ((E4 + E26)) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (range7 - e.target.av))}
all e: used | e.fiber in ((E5 + E27)) implies e.ev = {i: range7 | (i.shift7_0).future7 in (e.target.av)}
all e: used | e.fiber in ((E6 + E28)) implies e.ev = {i: range7 | (i.shift7_0).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range7 | loop7 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range7 | loop7 in (range7 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range7 | some (loop7 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range7 | some (loop7 & (range7 - e.target.av))}
all e: used | e.fiber in ((E11 + (E29 + E35))) implies e.ev = {i: range7 | (i.shift7_1) in (e.target.av)}
all e: used | e.fiber in ((E12 + (E30 + E36))) implies e.ev = {i: range7 | (i.shift7_1) in (range7 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range7 | (i.shift7_1).future7 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range7 | (i.shift7_1).future7 in (range7 - e.target.av)}
all e: used | e.fiber in ((E17 + (E31 + E37))) implies e.ev = {i: range7 | (i.shift7_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + E32)) implies e.ev = {i: range7 | (i.shift7_2) in (range7 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range7 | some ((i.shift7_2).future7 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range7 | some ((i.shift7_2).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range7 | (i.shift7_2).future7 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range7 | (i.shift7_2).future7 in (range7 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range7 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next7.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range7 | some (i.future7 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range7 | i.future7 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range7 - left[a].ev) + right[a].ev)
}
fun range8: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop8: set Pos { (P1 + (P2 + P3)) }
fun next8: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P1)) }
fun future8: Pos -> Pos { (*next8) & (range8->range8) }
fun shift8_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift8_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P1)) }
fun shift8_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P1 + P3->P2)) }
fun shift8_3: Pos -> Pos { ((P0->P3 + P1->P1) + (P2->P2 + P3->P3)) }
pred semantics8[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range8
ev in used->range8
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range8 | (i.shift8_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range8 | (i.shift8_0) in (range8 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range8 | (i.shift8_0).future8 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range8 | (i.shift8_0).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range8 | loop8 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range8 | loop8 in (range8 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range8 | some (loop8 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range8 | some (loop8 & (range8 - e.target.av))}
all e: used | e.fiber in ((E11 + (E29 + E35))) implies e.ev = {i: range8 | (i.shift8_1) in (e.target.av)}
all e: used | e.fiber in ((E12 + (E30 + E36))) implies e.ev = {i: range8 | (i.shift8_1) in (range8 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range8 | (i.shift8_1).future8 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range8 | (i.shift8_1).future8 in (range8 - e.target.av)}
all e: used | e.fiber in ((E17 + (E31 + E37))) implies e.ev = {i: range8 | (i.shift8_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + E32)) implies e.ev = {i: range8 | (i.shift8_2) in (range8 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range8 | some ((i.shift8_2).future8 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range8 | some ((i.shift8_2).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range8 | (i.shift8_2).future8 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range8 | (i.shift8_2).future8 in (range8 - e.target.av)}
all e: used | e.fiber in ((E23 + E33)) implies e.ev = {i: range8 | (i.shift8_3) in (e.target.av)}
all e: used | e.fiber in ((E24 + E34)) implies e.ev = {i: range8 | (i.shift8_3) in (range8 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range8 | some ((i.shift8_3).future8 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range8 | some ((i.shift8_3).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range8 | (i.shift8_3).future8 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range8 | (i.shift8_3).future8 in (range8 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range8 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next8.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range8 | some (i.future8 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range8 | i.future8 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range8 - left[a].ev) + right[a].ev)
}
fun range9: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop9: set Pos { (P2 + P3) }
fun next9: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P2)) }
fun future9: Pos -> Pos { (*next9) & (range9->range9) }
fun shift9_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift9_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P2)) }
fun shift9_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P2 + P3->P3)) }
fun shift9_3: Pos -> Pos { ((P0->P3 + P1->P2) + (P2->P3 + P3->P2)) }
pred semantics9[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range9
ev in used->range9
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range9 | (i.shift9_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range9 | (i.shift9_0) in (range9 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range9 | (i.shift9_0).future9 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range9 | (i.shift9_0).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range9 | loop9 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range9 | loop9 in (range9 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range9 | some (loop9 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range9 | some (loop9 & (range9 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range9 | (i.shift9_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range9 | (i.shift9_1) in (range9 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range9 | (i.shift9_1).future9 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range9 | (i.shift9_1).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (((E17 + E29) + (E33 + E37))) implies e.ev = {i: range9 | (i.shift9_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + (E30 + E34))) implies e.ev = {i: range9 | (i.shift9_2) in (range9 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range9 | some ((i.shift9_2).future9 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range9 | some ((i.shift9_2).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range9 | (i.shift9_2).future9 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range9 | (i.shift9_2).future9 in (range9 - e.target.av)}
all e: used | e.fiber in ((E23 + (E31 + E35))) implies e.ev = {i: range9 | (i.shift9_3) in (e.target.av)}
all e: used | e.fiber in ((E24 + (E32 + E36))) implies e.ev = {i: range9 | (i.shift9_3) in (range9 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range9 | some ((i.shift9_3).future9 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range9 | some ((i.shift9_3).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range9 | (i.shift9_3).future9 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range9 | (i.shift9_3).future9 in (range9 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range9 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next9.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range9 | some (i.future9 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range9 | i.future9 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range9 - left[a].ev) + right[a].ev)
}
fun range10: set Pos { (P0 + (P1 + P2)) }
fun loop10: set Pos { P2 }
fun next10: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun future10: Pos -> Pos { (*next10) & (range10->range10) }
fun shift10_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift10_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun shift10_2: Pos -> Pos { (P0->P2 + (P1->P2 + P2->P2)) }
pred semantics10[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range10
ev in used->range10
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range10 | (i.shift10_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range10 | (i.shift10_0) in (range10 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range10 | (i.shift10_0).future10 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range10 | (i.shift10_0).future10 in (range10 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range10 | loop10 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range10 | loop10 in (range10 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range10 | some (loop10 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range10 | some (loop10 & (range10 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range10 | (i.shift10_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range10 | (i.shift10_1) in (range10 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range10 | some ((i.shift10_1).future10 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range10 | some ((i.shift10_1).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range10 | (i.shift10_1).future10 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range10 | (i.shift10_1).future10 in (range10 - e.target.av)}
all e: used | e.fiber in (((E17 + (E23 + E29)) + ((E31 + E33) + (E35 + E37)))) implies e.ev = {i: range10 | (i.shift10_2) in (e.target.av)}
all e: used | e.fiber in (((E18 + (E24 + E30)) + (E32 + (E34 + E36)))) implies e.ev = {i: range10 | (i.shift10_2) in (range10 - e.target.av)}
all e: used | e.fiber in ((E19 + E25)) implies e.ev = {i: range10 | some ((i.shift10_2).future10 & (e.target.av))}
all e: used | e.fiber in ((E20 + E26)) implies e.ev = {i: range10 | some ((i.shift10_2).future10 & (range10 - e.target.av))}
all e: used | e.fiber in ((E21 + E27)) implies e.ev = {i: range10 | (i.shift10_2).future10 in (e.target.av)}
all e: used | e.fiber in ((E22 + E28)) implies e.ev = {i: range10 | (i.shift10_2).future10 in (range10 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range10 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next10.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range10 | some (i.future10 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range10 | i.future10 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range10 - left[a].ev) + right[a].ev)
}
fun range11: set Pos { (P0 + P1) }
fun loop11: set Pos { (P0 + P1) }
fun next11: Pos -> Pos { (P0->P1 + P1->P0) }
fun future11: Pos -> Pos { (*next11) & (range11->range11) }
fun shift11_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift11_1: Pos -> Pos { (P0->P1 + P1->P0) }
pred semantics11[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range11
ev in used->range11
all e: used | e.fiber in (((E0 + (E1 + E17)) + (E29 + (E33 + E37)))) implies e.ev = {i: range11 | (i.shift11_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E18) + (E30 + E34))) implies e.ev = {i: range11 | (i.shift11_0) in (range11 - e.target.av)}
all e: used | e.fiber in ((E3 + E19)) implies e.ev = {i: range11 | some ((i.shift11_0).future11 & (e.target.av))}
all e: used | e.fiber in ((E4 + E20)) implies e.ev = {i: range11 | some ((i.shift11_0).future11 & (range11 - e.target.av))}
all e: used | e.fiber in ((E5 + E21)) implies e.ev = {i: range11 | (i.shift11_0).future11 in (e.target.av)}
all e: used | e.fiber in ((E6 + E22)) implies e.ev = {i: range11 | (i.shift11_0).future11 in (range11 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range11 | loop11 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range11 | loop11 in (range11 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range11 | some (loop11 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range11 | some (loop11 & (range11 - e.target.av))}
all e: used | e.fiber in (((E11 + E23) + (E31 + E35))) implies e.ev = {i: range11 | (i.shift11_1) in (e.target.av)}
all e: used | e.fiber in (((E12 + E24) + (E32 + E36))) implies e.ev = {i: range11 | (i.shift11_1) in (range11 - e.target.av)}
all e: used | e.fiber in ((E13 + E25)) implies e.ev = {i: range11 | some ((i.shift11_1).future11 & (e.target.av))}
all e: used | e.fiber in ((E14 + E26)) implies e.ev = {i: range11 | some ((i.shift11_1).future11 & (range11 - e.target.av))}
all e: used | e.fiber in ((E15 + E27)) implies e.ev = {i: range11 | (i.shift11_1).future11 in (e.target.av)}
all e: used | e.fiber in ((E16 + E28)) implies e.ev = {i: range11 | (i.shift11_1).future11 in (range11 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range11 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next11.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range11 | some (i.future11 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range11 | i.future11 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range11 - left[a].ev) + right[a].ev)
}
fun range12: set Pos { (P0 + P1) }
fun loop12: set Pos { P1 }
fun next12: Pos -> Pos { (P0->P1 + P1->P1) }
fun future12: Pos -> Pos { (*next12) & (range12->range12) }
fun shift12_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift12_1: Pos -> Pos { (P0->P1 + P1->P1) }
pred semantics12[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range12
ev in used->range12
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range12 | (i.shift12_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range12 | (i.shift12_0) in (range12 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range12 | some ((i.shift12_0).future12 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range12 | some ((i.shift12_0).future12 & (range12 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range12 | (i.shift12_0).future12 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range12 | (i.shift12_0).future12 in (range12 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range12 | loop12 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range12 | loop12 in (range12 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range12 | some (loop12 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range12 | some (loop12 & (range12 - e.target.av))}
all e: used | e.fiber in ((((E11 + E17) + (E23 + E29)) + ((E31 + E33) + (E35 + E37)))) implies e.ev = {i: range12 | (i.shift12_1) in (e.target.av)}
all e: used | e.fiber in (((E12 + (E18 + E24)) + ((E30 + E32) + (E34 + E36)))) implies e.ev = {i: range12 | (i.shift12_1) in (range12 - e.target.av)}
all e: used | e.fiber in ((E13 + (E19 + E25))) implies e.ev = {i: range12 | some ((i.shift12_1).future12 & (e.target.av))}
all e: used | e.fiber in ((E14 + (E20 + E26))) implies e.ev = {i: range12 | some ((i.shift12_1).future12 & (range12 - e.target.av))}
all e: used | e.fiber in ((E15 + (E21 + E27))) implies e.ev = {i: range12 | (i.shift12_1).future12 in (e.target.av)}
all e: used | e.fiber in ((E16 + (E22 + E28))) implies e.ev = {i: range12 | (i.shift12_1).future12 in (range12 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range12 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next12.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range12 | some (i.future12 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range12 | i.future12 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range12 - left[a].ev) + right[a].ev)
}
fun range13: set Pos { (P0 + (P1 + P2)) }
fun loop13: set Pos { (P1 + P2) }
fun next13: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P1)) }
fun future13: Pos -> Pos { (*next13) & (range13->range13) }
fun shift13_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift13_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P1)) }
fun shift13_2: Pos -> Pos { (P0->P2 + (P1->P1 + P2->P2)) }
pred semantics13[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range13
ev in used->range13
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range13 | (i.shift13_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range13 | (i.shift13_0) in (range13 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range13 | some ((i.shift13_0).future13 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range13 | some ((i.shift13_0).future13 & (range13 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range13 | (i.shift13_0).future13 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range13 | (i.shift13_0).future13 in (range13 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range13 | loop13 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range13 | loop13 in (range13 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range13 | some (loop13 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range13 | some (loop13 & (range13 - e.target.av))}
all e: used | e.fiber in (((E11 + E23) + (E31 + E35))) implies e.ev = {i: range13 | (i.shift13_1) in (e.target.av)}
all e: used | e.fiber in (((E12 + E24) + (E32 + E36))) implies e.ev = {i: range13 | (i.shift13_1) in (range13 - e.target.av)}
all e: used | e.fiber in ((E13 + E25)) implies e.ev = {i: range13 | some ((i.shift13_1).future13 & (e.target.av))}
all e: used | e.fiber in ((E14 + E26)) implies e.ev = {i: range13 | some ((i.shift13_1).future13 & (range13 - e.target.av))}
all e: used | e.fiber in ((E15 + E27)) implies e.ev = {i: range13 | (i.shift13_1).future13 in (e.target.av)}
all e: used | e.fiber in ((E16 + E28)) implies e.ev = {i: range13 | (i.shift13_1).future13 in (range13 - e.target.av)}
all e: used | e.fiber in (((E17 + E29) + (E33 + E37))) implies e.ev = {i: range13 | (i.shift13_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + (E30 + E34))) implies e.ev = {i: range13 | (i.shift13_2) in (range13 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range13 | some ((i.shift13_2).future13 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range13 | some ((i.shift13_2).future13 & (range13 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range13 | (i.shift13_2).future13 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range13 | (i.shift13_2).future13 in (range13 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range13 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next13.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range13 | some (i.future13 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range13 | i.future13 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range13 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = ((P2 + P3))
all a: lab.T1 | a.av0 = (none)
all a: lab.T2 | a.av0 = (P3)
(R->P0 in ev0)
semantics1[av1, ev1]
all a: lab.T0 | a.av1 = ((P2 + P3))
all a: lab.T1 | a.av1 = (none)
all a: lab.T2 | a.av1 = (P2)
(R->P0 in ev1)
semantics1[av2, ev2]
all a: lab.T0 | a.av2 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av2 = ((P3 + P4))
all a: lab.T2 | a.av2 = ((P1 + P3))
(R->P0 in ev2)
semantics2[av3, ev3]
all a: lab.T0 | a.av3 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av3 = ((P0 + P2))
all a: lab.T2 | a.av3 = (P0)
(R->P0 in ev3)
semantics3[av4, ev4]
all a: lab.T0 | a.av4 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av4 = ((P3 + P4))
all a: lab.T2 | a.av4 = ((P2 + P4))
(R->P0 in ev4)
semantics3[av5, ev5]
all a: lab.T0 | a.av5 = ((P2 + P4))
all a: lab.T1 | a.av5 = (none)
all a: lab.T2 | a.av5 = (P3)
(R->P0 in ev5)
semantics3[av6, ev6]
all a: lab.T0 | a.av6 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av6 = (none)
all a: lab.T2 | a.av6 = ((P2 + P4))
(R->P0 in ev6)
semantics1[av7, ev7]
all a: lab.T0 | a.av7 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av7 = (P4)
all a: lab.T2 | a.av7 = ((P0 + P3))
(R->P0 in ev7)
semantics4[av8, ev8]
all a: lab.T0 | a.av8 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av8 = (P1)
all a: lab.T2 | a.av8 = ((P0 + P3))
(R->P0 in ev8)
semantics5[av9, ev9]
all a: lab.T0 | a.av9 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av9 = ((P3 + P4))
all a: lab.T2 | a.av9 = ((P1 + (P3 + P4)))
(R->P0 in ev9)
semantics2[av10, ev10]
all a: lab.T0 | a.av10 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av10 = (none)
all a: lab.T2 | a.av10 = ((P1 + P3))
(R->P0 in ev10)
semantics0[av11, ev11]
all a: lab.T0 | a.av11 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av11 = ((P0 + P4))
all a: lab.T2 | a.av11 = (P2)
(R->P0 in ev11)
semantics3[av12, ev12]
all a: lab.T0 | a.av12 = ((P0 + P4))
all a: lab.T1 | a.av12 = (none)
all a: lab.T2 | a.av12 = ((P1 + (P2 + P3)))
(R->P0 in ev12)
semantics1[av13, ev13]
all a: lab.T0 | a.av13 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av13 = (P3)
all a: lab.T2 | a.av13 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev13)
semantics5[av14, ev14]
all a: lab.T0 | a.av14 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av14 = (none)
all a: lab.T2 | a.av14 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev14)
semantics0[av15, ev15]
all a: lab.T0 | a.av15 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av15 = (none)
all a: lab.T2 | a.av15 = ((P0 + (P3 + P4)))
(R->P0 in ev15)
semantics6[av16, ev16]
all a: lab.T0 | a.av16 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av16 = (none)
all a: lab.T2 | a.av16 = (P3)
(R->P0 in ev16)
semantics3[av17, ev17]
all a: lab.T0 | a.av17 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av17 = (none)
all a: lab.T2 | a.av17 = ((P0 + (P1 + P4)))
(R->P0 in ev17)
semantics2[av18, ev18]
all a: lab.T0 | a.av18 = ((P2 + P3))
all a: lab.T1 | a.av18 = (P3)
all a: lab.T2 | a.av18 = ((P1 + P3))
(R->P0 in ev18)
semantics7[av19, ev19]
all a: lab.T0 | a.av19 = (P1)
all a: lab.T1 | a.av19 = (none)
all a: lab.T2 | a.av19 = ((P0 + P2))
(R->P0 in ev19)
semantics1[av20, ev20]
all a: lab.T0 | a.av20 = ((P3 + P4))
all a: lab.T1 | a.av20 = (P3)
all a: lab.T2 | a.av20 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev20)
semantics8[av21, ev21]
all a: lab.T0 | a.av21 = (P2)
all a: lab.T1 | a.av21 = (none)
all a: lab.T2 | a.av21 = ((P1 + (P2 + P3)))
(R->P0 in ev21)
semantics0[av22, ev22]
all a: lab.T0 | a.av22 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av22 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av22 = ((P0 + P4))
(R->P0 in ev22)
semantics6[av23, ev23]
all a: lab.T0 | a.av23 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av23 = (none)
all a: lab.T2 | a.av23 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev23)
semantics3[av24, ev24]
all a: lab.T0 | a.av24 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av24 = (P4)
all a: lab.T2 | a.av24 = ((P1 + P3))
(R->P0 in ev24)
semantics3[av25, ev25]
all a: lab.T0 | a.av25 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av25 = ((P1 + P3))
all a: lab.T2 | a.av25 = ((P0 + P2))
(R->P0 in ev25)
semantics6[av26, ev26]
all a: lab.T0 | a.av26 = ((P2 + P4))
all a: lab.T1 | a.av26 = (none)
all a: lab.T2 | a.av26 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev26)
semantics0[av27, ev27]
all a: lab.T0 | a.av27 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av27 = (P3)
all a: lab.T2 | a.av27 = ((P1 + (P3 + P4)))
(R->P0 in ev27)
semantics3[av28, ev28]
all a: lab.T0 | a.av28 = ((P1 + P3))
all a: lab.T1 | a.av28 = (none)
all a: lab.T2 | a.av28 = ((P3 + P4))
(R->P0 in ev28)
semantics0[av29, ev29]
all a: lab.T0 | a.av29 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av29 = (none)
all a: lab.T2 | a.av29 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev29)
semantics9[av30, ev30]
all a: lab.T0 | a.av30 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av30 = ((P1 + P2))
all a: lab.T2 | a.av30 = ((P1 + (P2 + P3)))
(R->P0 in ev30)
semantics3[av31, ev31]
all a: lab.T0 | a.av31 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av31 = (P2)
all a: lab.T2 | a.av31 = ((P0 + (P1 + P2)))
(R->P0 in ev31)
semantics0[av32, ev32]
all a: lab.T0 | a.av32 = (P4)
all a: lab.T1 | a.av32 = (none)
all a: lab.T2 | a.av32 = ((P1 + (P3 + P4)))
(R->P0 in ev32)
semantics5[av33, ev33]
all a: lab.T0 | a.av33 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av33 = (none)
all a: lab.T2 | a.av33 = ((P0 + (P1 + P2)))
(R->P0 in ev33)
semantics2[av34, ev34]
all a: lab.T0 | a.av34 = ((P2 + P3))
all a: lab.T1 | a.av34 = (none)
all a: lab.T2 | a.av34 = ((P0 + (P1 + P2)))
(R->P0 in ev34)
semantics0[av35, ev35]
all a: lab.T0 | a.av35 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av35 = ((P1 + P2))
all a: lab.T2 | a.av35 = ((P1 + P3))
(R->P0 in ev35)
semantics1[av36, ev36]
all a: lab.T0 | a.av36 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av36 = (none)
all a: lab.T2 | a.av36 = ((P2 + (P3 + P4)))
(R->P0 in ev36)
semantics2[av37, ev37]
all a: lab.T0 | a.av37 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av37 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av37 = ((P0 + P1))
(R->P0 in ev37)
semantics0[av38, ev38]
all a: lab.T0 | a.av38 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av38 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av38 = ((P1 + P4))
(R->P0 in ev38)
semantics2[av39, ev39]
all a: lab.T0 | a.av39 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av39 = (P2)
all a: lab.T2 | a.av39 = (P1)
(R->P0 in ev39)
semantics8[av40, ev40]
all a: lab.T0 | a.av40 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av40 = (none)
all a: lab.T2 | a.av40 = ((P0 + (P1 + P2)))
(R->P0 in ev40)
semantics1[av41, ev41]
all a: lab.T0 | a.av41 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av41 = (P3)
all a: lab.T2 | a.av41 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev41)
semantics6[av42, ev42]
all a: lab.T0 | a.av42 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av42 = ((P0 + P2))
all a: lab.T2 | a.av42 = ((P0 + (P1 + P2)))
(R->P0 in ev42)
semantics3[av43, ev43]
all a: lab.T0 | a.av43 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av43 = ((P1 + P2))
all a: lab.T2 | a.av43 = ((P1 + P4))
(R->P0 in ev43)
semantics3[av44, ev44]
all a: lab.T0 | a.av44 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av44 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av44 = ((P0 + P4))
(R->P0 in ev44)
semantics1[av45, ev45]
all a: lab.T0 | a.av45 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av45 = (P2)
all a: lab.T2 | a.av45 = ((P1 + P3))
(R->P0 in ev45)
semantics0[av46, ev46]
all a: lab.T0 | a.av46 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av46 = ((P2 + P4))
all a: lab.T2 | a.av46 = ((P0 + (P1 + P2)))
(R->P0 in ev46)
semantics1[av47, ev47]
all a: lab.T0 | a.av47 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av47 = (P3)
all a: lab.T2 | a.av47 = (P0)
(R->P0 in ev47)
semantics0[av48, ev48]
all a: lab.T0 | a.av48 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av48 = (none)
all a: lab.T2 | a.av48 = (P4)
(R->P0 in ev48)
semantics1[av49, ev49]
all a: lab.T0 | a.av49 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av49 = (P4)
all a: lab.T2 | a.av49 = ((P1 + (P2 + P3)))
(R->P0 in ev49)
semantics3[av50, ev50]
all a: lab.T0 | a.av50 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av50 = (none)
all a: lab.T2 | a.av50 = ((P3 + P4))
(R->P0 in ev50)
semantics8[av51, ev51]
all a: lab.T0 | a.av51 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av51 = (P3)
all a: lab.T2 | a.av51 = (P1)
(R->P0 in ev51)
semantics10[av52, ev52]
all a: lab.T0 | a.av52 = ((P1 + P2))
all a: lab.T1 | a.av52 = ((P1 + P2))
all a: lab.T2 | a.av52 = ((P0 + P2))
(R->P0 in ev52)
semantics5[av53, ev53]
all a: lab.T0 | a.av53 = ((P2 + P3))
all a: lab.T1 | a.av53 = (none)
all a: lab.T2 | a.av53 = ((P1 + (P3 + P4)))
(R->P0 in ev53)
semantics1[av54, ev54]
all a: lab.T0 | a.av54 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av54 = (none)
all a: lab.T2 | a.av54 = (P0)
(R->P0 in ev54)
semantics2[av55, ev55]
all a: lab.T0 | a.av55 = ((P1 + P2))
all a: lab.T1 | a.av55 = (none)
all a: lab.T2 | a.av55 = ((P1 + P2))
(R->P0 in ev55)
semantics6[av56, ev56]
all a: lab.T0 | a.av56 = ((P3 + P4))
all a: lab.T1 | a.av56 = (none)
all a: lab.T2 | a.av56 = (P2)
(R->P0 in ev56)
semantics0[av57, ev57]
all a: lab.T0 | a.av57 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av57 = (P4)
all a: lab.T2 | a.av57 = ((P0 + (P2 + P3)))
(R->P0 in ev57)
semantics3[av58, ev58]
all a: lab.T0 | a.av58 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av58 = ((P2 + P3))
all a: lab.T2 | a.av58 = ((P3 + P4))
(R->P0 in ev58)
semantics1[av59, ev59]
all a: lab.T0 | a.av59 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av59 = (none)
all a: lab.T2 | a.av59 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev59)
semantics1[av60, ev60]
all a: lab.T0 | a.av60 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av60 = (P2)
all a: lab.T2 | a.av60 = ((P0 + (P1 + P4)))
(R->P0 in ev60)
semantics0[av61, ev61]
all a: lab.T0 | a.av61 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av61 = (P4)
all a: lab.T2 | a.av61 = ((P1 + P3))
(R->P0 in ev61)
semantics5[av62, ev62]
all a: lab.T0 | a.av62 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av62 = ((P2 + P3))
all a: lab.T2 | a.av62 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev62)
semantics1[av63, ev63]
all a: lab.T0 | a.av63 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av63 = ((P2 + P3))
all a: lab.T2 | a.av63 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev63)
semantics3[av64, ev64]
all a: lab.T0 | a.av64 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av64 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av64 = ((P0 + (P1 + P4)))
(R->P0 in ev64)
semantics0[av65, ev65]
all a: lab.T0 | a.av65 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av65 = ((P1 + P2))
all a: lab.T2 | a.av65 = ((P0 + (P2 + P4)))
(R->P0 in ev65)
semantics3[av66, ev66]
all a: lab.T0 | a.av66 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av66 = ((P1 + P3))
all a: lab.T2 | a.av66 = ((P2 + (P3 + P4)))
(R->P0 in ev66)
semantics5[av67, ev67]
all a: lab.T0 | a.av67 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av67 = (none)
all a: lab.T2 | a.av67 = ((P2 + (P3 + P4)))
(R->P0 in ev67)
semantics4[av68, ev68]
all a: lab.T0 | a.av68 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av68 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av68 = ((P0 + P1))
(R->P0 in ev68)
semantics6[av69, ev69]
all a: lab.T0 | a.av69 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av69 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av69 = ((P0 + P3))
(R->P0 in ev69)
semantics6[av70, ev70]
all a: lab.T0 | a.av70 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av70 = (P0)
all a: lab.T2 | a.av70 = ((P2 + (P3 + P4)))
(R->P0 in ev70)
semantics6[av71, ev71]
all a: lab.T0 | a.av71 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av71 = (none)
all a: lab.T2 | a.av71 = ((P0 + P2))
(R->P0 in ev71)
semantics3[av72, ev72]
all a: lab.T0 | a.av72 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av72 = (none)
all a: lab.T2 | a.av72 = ((P3 + P4))
(R->P0 in ev72)
semantics1[av73, ev73]
all a: lab.T0 | a.av73 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av73 = ((P2 + P3))
all a: lab.T2 | a.av73 = ((P1 + (P2 + P4)))
(R->P0 in ev73)
semantics0[av74, ev74]
all a: lab.T0 | a.av74 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av74 = (P3)
all a: lab.T2 | a.av74 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev74)
semantics1[av75, ev75]
all a: lab.T0 | a.av75 = (P4)
all a: lab.T1 | a.av75 = (none)
all a: lab.T2 | a.av75 = ((P1 + P3))
(R->P0 in ev75)
semantics0[av76, ev76]
all a: lab.T0 | a.av76 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av76 = (P3)
all a: lab.T2 | a.av76 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev76)
semantics5[av77, ev77]
all a: lab.T0 | a.av77 = (P4)
all a: lab.T1 | a.av77 = (none)
all a: lab.T2 | a.av77 = ((P0 + (P3 + P4)))
(R->P0 in ev77)
semantics2[av78, ev78]
all a: lab.T0 | a.av78 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av78 = (P2)
all a: lab.T2 | a.av78 = (none)
(R->P0 in ev78)
semantics2[av79, ev79]
all a: lab.T0 | a.av79 = ((P2 + P3))
all a: lab.T1 | a.av79 = (P2)
all a: lab.T2 | a.av79 = ((P0 + P1))
(R->P0 in ev79)
semantics2[av80, ev80]
all a: lab.T0 | a.av80 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av80 = ((P2 + P3))
all a: lab.T2 | a.av80 = ((P1 + P2))
(R->P0 in ev80)
semantics5[av81, ev81]
all a: lab.T0 | a.av81 = ((P0 + P1))
all a: lab.T1 | a.av81 = (none)
all a: lab.T2 | a.av81 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev81)
semantics1[av82, ev82]
all a: lab.T0 | a.av82 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av82 = (P0)
all a: lab.T2 | a.av82 = ((P1 + P3))
(R->P0 in ev82)
semantics1[av83, ev83]
all a: lab.T0 | a.av83 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av83 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av83 = ((P2 + P3))
(R->P0 in ev83)
semantics6[av84, ev84]
all a: lab.T0 | a.av84 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av84 = ((P2 + P3))
all a: lab.T2 | a.av84 = ((P0 + P2))
(R->P0 in ev84)
semantics1[av85, ev85]
all a: lab.T0 | a.av85 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av85 = (P1)
all a: lab.T2 | a.av85 = ((P0 + P4))
(R->P0 in ev85)
semantics3[av86, ev86]
all a: lab.T0 | a.av86 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av86 = ((P2 + P4))
all a: lab.T2 | a.av86 = (P0)
(R->P0 in ev86)
semantics3[av87, ev87]
all a: lab.T0 | a.av87 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av87 = (none)
all a: lab.T2 | a.av87 = ((P1 + (P2 + P4)))
(R->P0 in ev87)
semantics0[av88, ev88]
all a: lab.T0 | a.av88 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av88 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av88 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev88)
semantics3[av89, ev89]
all a: lab.T0 | a.av89 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av89 = ((P0 + P2))
all a: lab.T2 | a.av89 = ((P1 + P3))
(R->P0 in ev89)
semantics5[av90, ev90]
all a: lab.T0 | a.av90 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av90 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av90 = ((P1 + (P3 + P4)))
(R->P0 in ev90)
semantics6[av91, ev91]
all a: lab.T0 | a.av91 = ((P2 + P4))
all a: lab.T1 | a.av91 = (none)
all a: lab.T2 | a.av91 = ((P1 + (P2 + P4)))
(R->P0 in ev91)
semantics5[av92, ev92]
all a: lab.T0 | a.av92 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av92 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av92 = ((P0 + P3))
(R->P0 in ev92)
semantics2[av93, ev93]
all a: lab.T0 | a.av93 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av93 = ((P0 + P2))
all a: lab.T2 | a.av93 = ((P0 + (P1 + P3)))
(R->P0 in ev93)
semantics6[av94, ev94]
all a: lab.T0 | a.av94 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av94 = ((P1 + P2))
all a: lab.T2 | a.av94 = ((P3 + P4))
(R->P0 in ev94)
semantics0[av95, ev95]
all a: lab.T0 | a.av95 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av95 = (P3)
all a: lab.T2 | a.av95 = ((P3 + P4))
(R->P0 in ev95)
semantics4[av96, ev96]
all a: lab.T0 | a.av96 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av96 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av96 = ((P2 + P3))
(R->P0 in ev96)
semantics8[av97, ev97]
all a: lab.T0 | a.av97 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av97 = ((P2 + P3))
all a: lab.T2 | a.av97 = (P3)
(R->P0 in ev97)
semantics0[av98, ev98]
all a: lab.T0 | a.av98 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av98 = (P2)
all a: lab.T2 | a.av98 = ((P0 + (P1 + P3)))
(R->P0 in ev98)
semantics4[av99, ev99]
all a: lab.T0 | a.av99 = ((P2 + P3))
all a: lab.T1 | a.av99 = (none)
all a: lab.T2 | a.av99 = (P0)
(R->P0 in ev99)
semantics0[av100, ev100]
all a: lab.T0 | a.av100 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av100 = (none)
all a: lab.T2 | a.av100 = (P4)
(R->P0 in ev100)
semantics1[av101, ev101]
all a: lab.T0 | a.av101 = (P0)
all a: lab.T1 | a.av101 = (none)
all a: lab.T2 | a.av101 = ((P1 + P4))
(R->P0 in ev101)
semantics3[av102, ev102]
all a: lab.T0 | a.av102 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av102 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av102 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev102)
semantics3[av103, ev103]
all a: lab.T0 | a.av103 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av103 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av103 = ((P0 + (P1 + P4)))
(R->P0 in ev103)
semantics1[av104, ev104]
all a: lab.T0 | a.av104 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av104 = (P1)
all a: lab.T2 | a.av104 = ((P0 + (P2 + P4)))
(R->P0 in ev104)
semantics6[av105, ev105]
all a: lab.T0 | a.av105 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av105 = (none)
all a: lab.T2 | a.av105 = (P3)
(R->P0 in ev105)
semantics0[av106, ev106]
all a: lab.T0 | a.av106 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av106 = (P3)
all a: lab.T2 | a.av106 = ((P0 + (P1 + P4)))
(R->P0 in ev106)
semantics6[av107, ev107]
all a: lab.T0 | a.av107 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av107 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av107 = (P1)
(R->P0 in ev107)
semantics0[av108, ev108]
all a: lab.T0 | a.av108 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av108 = ((P2 + P3))
all a: lab.T2 | a.av108 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev108)
semantics1[av109, ev109]
all a: lab.T0 | a.av109 = ((P0 + P2))
all a: lab.T1 | a.av109 = (none)
all a: lab.T2 | a.av109 = ((P2 + P3))
(R->P0 in ev109)
semantics3[av110, ev110]
all a: lab.T0 | a.av110 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av110 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av110 = ((P0 + P4))
(R->P0 in ev110)
semantics0[av111, ev111]
all a: lab.T0 | a.av111 = ((P2 + P3))
all a: lab.T1 | a.av111 = (none)
all a: lab.T2 | a.av111 = (P4)
(R->P0 in ev111)
semantics1[av112, ev112]
all a: lab.T0 | a.av112 = (P4)
all a: lab.T1 | a.av112 = (P4)
all a: lab.T2 | a.av112 = ((P0 + P3))
(R->P0 in ev112)
semantics3[av113, ev113]
all a: lab.T0 | a.av113 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av113 = ((P3 + P4))
all a: lab.T2 | a.av113 = (P1)
(R->P0 in ev113)
semantics3[av114, ev114]
all a: lab.T0 | a.av114 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av114 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av114 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev114)
semantics5[av115, ev115]
all a: lab.T0 | a.av115 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av115 = (P4)
all a: lab.T2 | a.av115 = ((P2 + (P3 + P4)))
(R->P0 in ev115)
semantics4[av116, ev116]
all a: lab.T0 | a.av116 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av116 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av116 = ((P0 + P1))
(R->P0 in ev116)
semantics0[av117, ev117]
all a: lab.T0 | a.av117 = ((P3 + P4))
all a: lab.T1 | a.av117 = (P4)
all a: lab.T2 | a.av117 = ((P0 + P1))
(R->P0 in ev117)
semantics9[av118, ev118]
all a: lab.T0 | a.av118 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av118 = ((P1 + P3))
all a: lab.T2 | a.av118 = ((P0 + P1))
(R->P0 in ev118)
semantics0[av119, ev119]
all a: lab.T0 | a.av119 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av119 = ((P3 + P4))
all a: lab.T2 | a.av119 = ((P0 + (P1 + P3)))
(R->P0 in ev119)
semantics2[av120, ev120]
all a: lab.T0 | a.av120 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av120 = (P1)
all a: lab.T2 | a.av120 = (P3)
(R->P0 in ev120)
semantics1[av121, ev121]
all a: lab.T0 | a.av121 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av121 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av121 = ((P0 + P3))
(R->P0 in ev121)
semantics0[av122, ev122]
all a: lab.T0 | a.av122 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av122 = (P2)
all a: lab.T2 | a.av122 = ((P0 + (P2 + P4)))
(R->P0 in ev122)
semantics1[av123, ev123]
all a: lab.T0 | a.av123 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av123 = ((P2 + P3))
all a: lab.T2 | a.av123 = (P0)
(R->P0 in ev123)
semantics9[av124, ev124]
all a: lab.T0 | a.av124 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av124 = ((P2 + P3))
all a: lab.T2 | a.av124 = ((P0 + P2))
(R->P0 in ev124)
semantics2[av125, ev125]
all a: lab.T0 | a.av125 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av125 = ((P1 + P2))
all a: lab.T2 | a.av125 = ((P1 + P3))
(R->P0 in ev125)
semantics1[av126, ev126]
all a: lab.T0 | a.av126 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av126 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av126 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev126)
semantics0[av127, ev127]
all a: lab.T0 | a.av127 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av127 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av127 = ((P2 + P3))
(R->P0 in ev127)
semantics3[av128, ev128]
all a: lab.T0 | a.av128 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av128 = ((P1 + P2))
all a: lab.T2 | a.av128 = (none)
(R->P0 in ev128)
semantics1[av129, ev129]
all a: lab.T0 | a.av129 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av129 = (P3)
all a: lab.T2 | a.av129 = ((P0 + P2))
(R->P0 in ev129)
semantics2[av130, ev130]
all a: lab.T0 | a.av130 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av130 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av130 = ((P0 + (P1 + P2)))
(R->P0 in ev130)
semantics3[av131, ev131]
all a: lab.T0 | a.av131 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av131 = ((P2 + P3))
all a: lab.T2 | a.av131 = ((P2 + P3))
(R->P0 in ev131)
semantics1[av132, ev132]
all a: lab.T0 | a.av132 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av132 = ((P0 + P4))
all a: lab.T2 | a.av132 = ((P1 + (P3 + P4)))
(R->P0 in ev132)
semantics3[av133, ev133]
all a: lab.T0 | a.av133 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av133 = ((P3 + P4))
all a: lab.T2 | a.av133 = ((P0 + (P2 + P4)))
(R->P0 in ev133)
semantics6[av134, ev134]
all a: lab.T0 | a.av134 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av134 = (none)
all a: lab.T2 | a.av134 = ((P0 + (P2 + P3)))
(R->P0 in ev134)
semantics0[av135, ev135]
all a: lab.T0 | a.av135 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av135 = ((P2 + P4))
all a: lab.T2 | a.av135 = ((P3 + P4))
(R->P0 in ev135)
semantics6[av136, ev136]
all a: lab.T0 | a.av136 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av136 = (none)
all a: lab.T2 | a.av136 = ((P0 + (P2 + P4)))
(R->P0 in ev136)
semantics8[av137, ev137]
all a: lab.T0 | a.av137 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av137 = ((P2 + P3))
all a: lab.T2 | a.av137 = ((P0 + (P1 + P2)))
(R->P0 in ev137)
semantics1[av138, ev138]
all a: lab.T0 | a.av138 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av138 = (none)
all a: lab.T2 | a.av138 = ((P1 + P4))
(R->P0 in ev138)
semantics3[av139, ev139]
all a: lab.T0 | a.av139 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av139 = (none)
all a: lab.T2 | a.av139 = (P0)
(R->P0 in ev139)
semantics1[av140, ev140]
all a: lab.T0 | a.av140 = ((P3 + P4))
all a: lab.T1 | a.av140 = (P4)
all a: lab.T2 | a.av140 = ((P1 + (P2 + P4)))
(R->P0 in ev140)
semantics2[av141, ev141]
all a: lab.T0 | a.av141 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av141 = (P3)
all a: lab.T2 | a.av141 = ((P2 + P3))
(R->P0 in ev141)
semantics3[av142, ev142]
all a: lab.T0 | a.av142 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av142 = (none)
all a: lab.T2 | a.av142 = ((P0 + (P1 + P3)))
(R->P0 in ev142)
semantics1[av143, ev143]
all a: lab.T0 | a.av143 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av143 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av143 = (P4)
(R->P0 in ev143)
semantics1[av144, ev144]
all a: lab.T0 | a.av144 = ((P1 + P3))
all a: lab.T1 | a.av144 = (none)
all a: lab.T2 | a.av144 = ((P0 + (P2 + P4)))
(R->P0 in ev144)
semantics3[av145, ev145]
all a: lab.T0 | a.av145 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av145 = ((P2 + P4))
all a: lab.T2 | a.av145 = ((P0 + (P3 + P4)))
(R->P0 in ev145)
semantics6[av146, ev146]
all a: lab.T0 | a.av146 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av146 = (none)
all a: lab.T2 | a.av146 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev146)
semantics6[av147, ev147]
all a: lab.T0 | a.av147 = ((P1 + P4))
all a: lab.T1 | a.av147 = (none)
all a: lab.T2 | a.av147 = ((P0 + (P2 + P3)))
(R->P0 in ev147)
semantics2[av148, ev148]
all a: lab.T0 | a.av148 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av148 = ((P1 + P2))
all a: lab.T2 | a.av148 = ((P0 + (P1 + P3)))
(R->P0 in ev148)
semantics4[av149, ev149]
all a: lab.T0 | a.av149 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av149 = ((P2 + P3))
all a: lab.T2 | a.av149 = ((P0 + (P1 + P2)))
(R->P0 in ev149)
semantics1[av150, ev150]
all a: lab.T0 | a.av150 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av150 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av150 = ((P2 + P3))
(R->P0 in ev150)
semantics0[av151, ev151]
all a: lab.T0 | a.av151 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av151 = (P3)
all a: lab.T2 | a.av151 = ((P1 + (P2 + P4)))
(R->P0 in ev151)
semantics9[av152, ev152]
all a: lab.T0 | a.av152 = ((P0 + P3))
all a: lab.T1 | a.av152 = (none)
all a: lab.T2 | a.av152 = (none)
(R->P0 in ev152)
semantics1[av153, ev153]
all a: lab.T0 | a.av153 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av153 = (none)
all a: lab.T2 | a.av153 = ((P0 + P4))
(R->P0 in ev153)
semantics5[av154, ev154]
all a: lab.T0 | a.av154 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av154 = ((P2 + P4))
all a: lab.T2 | a.av154 = (P2)
(R->P0 in ev154)
semantics9[av155, ev155]
all a: lab.T0 | a.av155 = (P1)
all a: lab.T1 | a.av155 = (none)
all a: lab.T2 | a.av155 = (P2)
(R->P0 in ev155)
semantics1[av156, ev156]
all a: lab.T0 | a.av156 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av156 = ((P3 + P4))
all a: lab.T2 | a.av156 = ((P0 + (P2 + P3)))
(R->P0 in ev156)
semantics10[av157, ev157]
all a: lab.T0 | a.av157 = (P2)
all a: lab.T1 | a.av157 = (P2)
all a: lab.T2 | a.av157 = (none)
(R->P0 in ev157)
semantics3[av158, ev158]
all a: lab.T0 | a.av158 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av158 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av158 = ((P0 + (P3 + P4)))
(R->P0 in ev158)
semantics8[av159, ev159]
all a: lab.T0 | a.av159 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av159 = ((P0 + P2))
all a: lab.T2 | a.av159 = ((P0 + P1))
(R->P0 in ev159)
semantics0[av160, ev160]
all a: lab.T0 | a.av160 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av160 = ((P2 + P4))
all a: lab.T2 | a.av160 = (P4)
(R->P0 in ev160)
semantics3[av161, ev161]
all a: lab.T0 | a.av161 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av161 = (none)
all a: lab.T2 | a.av161 = ((P1 + (P2 + P3)))
(R->P0 in ev161)
semantics3[av162, ev162]
all a: lab.T0 | a.av162 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av162 = (P1)
all a: lab.T2 | a.av162 = ((P0 + (P2 + P3)))
(R->P0 in ev162)
semantics5[av163, ev163]
all a: lab.T0 | a.av163 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av163 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av163 = ((P1 + (P2 + P3)))
(R->P0 in ev163)
semantics2[av164, ev164]
all a: lab.T0 | a.av164 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av164 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av164 = ((P1 + P2))
(R->P0 in ev164)
semantics3[av165, ev165]
all a: lab.T0 | a.av165 = ((P1 + P3))
all a: lab.T1 | a.av165 = (none)
all a: lab.T2 | a.av165 = (none)
(R->P0 in ev165)
semantics10[av166, ev166]
all a: lab.T0 | a.av166 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av166 = (P2)
all a: lab.T2 | a.av166 = (P0)
(R->P0 in ev166)
semantics0[av167, ev167]
all a: lab.T0 | a.av167 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av167 = (none)
all a: lab.T2 | a.av167 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev167)
semantics5[av168, ev168]
all a: lab.T0 | a.av168 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av168 = (none)
all a: lab.T2 | a.av168 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev168)
semantics5[av169, ev169]
all a: lab.T0 | a.av169 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av169 = ((P1 + P2))
all a: lab.T2 | a.av169 = ((P2 + P3))
(R->P0 in ev169)
semantics6[av170, ev170]
all a: lab.T0 | a.av170 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av170 = (none)
all a: lab.T2 | a.av170 = ((P0 + P1))
(R->P0 in ev170)
semantics1[av171, ev171]
all a: lab.T0 | a.av171 = ((P0 + P4))
all a: lab.T1 | a.av171 = (none)
all a: lab.T2 | a.av171 = (P1)
(R->P0 in ev171)
semantics0[av172, ev172]
all a: lab.T0 | a.av172 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av172 = (P2)
all a: lab.T2 | a.av172 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev172)
semantics3[av173, ev173]
all a: lab.T0 | a.av173 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av173 = (P3)
all a: lab.T2 | a.av173 = (P0)
(R->P0 in ev173)
semantics1[av174, ev174]
all a: lab.T0 | a.av174 = ((P1 + P4))
all a: lab.T1 | a.av174 = (P4)
all a: lab.T2 | a.av174 = ((P0 + (P2 + P4)))
(R->P0 in ev174)
semantics3[av175, ev175]
all a: lab.T0 | a.av175 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av175 = (P4)
all a: lab.T2 | a.av175 = ((P2 + (P3 + P4)))
(R->P0 in ev175)
semantics2[av176, ev176]
all a: lab.T0 | a.av176 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av176 = ((P2 + P3))
all a: lab.T2 | a.av176 = ((P1 + P3))
(R->P0 in ev176)
semantics2[av177, ev177]
all a: lab.T0 | a.av177 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av177 = (P2)
all a: lab.T2 | a.av177 = ((P1 + (P2 + P3)))
(R->P0 in ev177)
semantics6[av178, ev178]
all a: lab.T0 | a.av178 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av178 = (none)
all a: lab.T2 | a.av178 = ((P0 + (P1 + P2)))
(R->P0 in ev178)
semantics0[av179, ev179]
all a: lab.T0 | a.av179 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av179 = (P4)
all a: lab.T2 | a.av179 = (P1)
(R->P0 in ev179)
semantics1[av180, ev180]
all a: lab.T0 | a.av180 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av180 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av180 = ((P0 + P3))
(R->P0 in ev180)
semantics11[av181, ev181]
all a: lab.T0 | a.av181 = ((P0 + P1))
all a: lab.T1 | a.av181 = (P1)
all a: lab.T2 | a.av181 = ((P0 + P1))
(R->P0 in ev181)
semantics5[av182, ev182]
all a: lab.T0 | a.av182 = ((P1 + P4))
all a: lab.T1 | a.av182 = (none)
all a: lab.T2 | a.av182 = (P2)
(R->P0 in ev182)
semantics1[av183, ev183]
all a: lab.T0 | a.av183 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av183 = (P4)
all a: lab.T2 | a.av183 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev183)
semantics6[av184, ev184]
all a: lab.T0 | a.av184 = ((P2 + P4))
all a: lab.T1 | a.av184 = (none)
all a: lab.T2 | a.av184 = ((P1 + P3))
(R->P0 in ev184)
semantics6[av185, ev185]
all a: lab.T0 | a.av185 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av185 = (none)
all a: lab.T2 | a.av185 = ((P3 + P4))
(R->P0 in ev185)
semantics1[av186, ev186]
all a: lab.T0 | a.av186 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av186 = ((P1 + P3))
all a: lab.T2 | a.av186 = (none)
(R->P0 in ev186)
semantics9[av187, ev187]
all a: lab.T0 | a.av187 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av187 = (P2)
all a: lab.T2 | a.av187 = ((P0 + (P2 + P3)))
(R->P0 in ev187)
semantics1[av188, ev188]
all a: lab.T0 | a.av188 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av188 = ((P2 + P3))
all a: lab.T2 | a.av188 = ((P0 + P2))
(R->P0 in ev188)
semantics1[av189, ev189]
all a: lab.T0 | a.av189 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av189 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av189 = (P1)
(R->P0 in ev189)
semantics9[av190, ev190]
all a: lab.T0 | a.av190 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av190 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av190 = ((P1 + P3))
(R->P0 in ev190)
semantics1[av191, ev191]
all a: lab.T0 | a.av191 = ((P1 + P4))
all a: lab.T1 | a.av191 = (P4)
all a: lab.T2 | a.av191 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev191)
semantics0[av192, ev192]
all a: lab.T0 | a.av192 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av192 = (P4)
all a: lab.T2 | a.av192 = ((P0 + P1))
(R->P0 in ev192)
semantics5[av193, ev193]
all a: lab.T0 | a.av193 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av193 = ((P1 + P2))
all a: lab.T2 | a.av193 = ((P1 + (P3 + P4)))
(R->P0 in ev193)
semantics0[av194, ev194]
all a: lab.T0 | a.av194 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av194 = (P3)
all a: lab.T2 | a.av194 = ((P0 + (P2 + P3)))
(R->P0 in ev194)
semantics1[av195, ev195]
all a: lab.T0 | a.av195 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av195 = (P1)
all a: lab.T2 | a.av195 = ((P1 + (P2 + P3)))
(R->P0 in ev195)
semantics1[av196, ev196]
all a: lab.T0 | a.av196 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av196 = (none)
all a: lab.T2 | a.av196 = (P3)
(R->P0 in ev196)
semantics8[av197, ev197]
all a: lab.T0 | a.av197 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av197 = ((P0 + P2))
all a: lab.T2 | a.av197 = ((P0 + (P1 + P3)))
(R->P0 in ev197)
semantics6[av198, ev198]
all a: lab.T0 | a.av198 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av198 = (none)
all a: lab.T2 | a.av198 = (P1)
(R->P0 in ev198)
semantics5[av199, ev199]
all a: lab.T0 | a.av199 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av199 = (none)
all a: lab.T2 | a.av199 = ((P0 + P2))
(R->P0 in ev199)
semantics3[av200, ev200]
all a: lab.T0 | a.av200 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av200 = ((P2 + P4))
all a: lab.T2 | a.av200 = ((P3 + P4))
(R->P0 in ev200)
semantics1[av201, ev201]
all a: lab.T0 | a.av201 = ((P2 + P4))
all a: lab.T1 | a.av201 = (none)
all a: lab.T2 | a.av201 = ((P2 + P4))
(R->P0 in ev201)
semantics3[av202, ev202]
all a: lab.T0 | a.av202 = ((P2 + P3))
all a: lab.T1 | a.av202 = (none)
all a: lab.T2 | a.av202 = (P4)
(R->P0 in ev202)
semantics6[av203, ev203]
all a: lab.T0 | a.av203 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av203 = (none)
all a: lab.T2 | a.av203 = ((P1 + P3))
(R->P0 in ev203)
semantics4[av204, ev204]
all a: lab.T0 | a.av204 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av204 = (P1)
all a: lab.T2 | a.av204 = (P0)
(R->P0 in ev204)
semantics0[av205, ev205]
all a: lab.T0 | a.av205 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av205 = ((P1 + P4))
all a: lab.T2 | a.av205 = ((P1 + P4))
(R->P0 in ev205)
semantics2[av206, ev206]
all a: lab.T0 | a.av206 = (P3)
all a: lab.T1 | a.av206 = (P3)
all a: lab.T2 | a.av206 = (P1)
(R->P0 in ev206)
semantics10[av207, ev207]
all a: lab.T0 | a.av207 = (P1)
all a: lab.T1 | a.av207 = (none)
all a: lab.T2 | a.av207 = (P1)
(R->P0 in ev207)
semantics1[av208, ev208]
all a: lab.T0 | a.av208 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av208 = (none)
all a: lab.T2 | a.av208 = (P3)
(R->P0 in ev208)
semantics1[av209, ev209]
all a: lab.T0 | a.av209 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av209 = (P0)
all a: lab.T2 | a.av209 = ((P0 + P4))
(R->P0 in ev209)
semantics5[av210, ev210]
all a: lab.T0 | a.av210 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av210 = (none)
all a: lab.T2 | a.av210 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev210)
semantics6[av211, ev211]
all a: lab.T0 | a.av211 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av211 = (P3)
all a: lab.T2 | a.av211 = ((P0 + (P3 + P4)))
(R->P0 in ev211)
semantics0[av212, ev212]
all a: lab.T0 | a.av212 = ((P0 + P4))
all a: lab.T1 | a.av212 = (none)
all a: lab.T2 | a.av212 = ((P0 + (P2 + P4)))
(R->P0 in ev212)
semantics4[av213, ev213]
all a: lab.T0 | a.av213 = (P3)
all a: lab.T1 | a.av213 = (none)
all a: lab.T2 | a.av213 = ((P0 + (P2 + P3)))
(R->P0 in ev213)
semantics6[av214, ev214]
all a: lab.T0 | a.av214 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av214 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av214 = ((P0 + P3))
(R->P0 in ev214)
semantics1[av215, ev215]
all a: lab.T0 | a.av215 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av215 = (P4)
all a: lab.T2 | a.av215 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev215)
semantics5[av216, ev216]
all a: lab.T0 | a.av216 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av216 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av216 = ((P0 + (P2 + P3)))
(R->P0 in ev216)
semantics1[av217, ev217]
all a: lab.T0 | a.av217 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av217 = (P4)
all a: lab.T2 | a.av217 = ((P1 + (P2 + P3)))
(R->P0 in ev217)
semantics1[av218, ev218]
all a: lab.T0 | a.av218 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av218 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av218 = ((P0 + (P1 + P3)))
(R->P0 in ev218)
semantics3[av219, ev219]
all a: lab.T0 | a.av219 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av219 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av219 = (none)
(R->P0 in ev219)
semantics6[av220, ev220]
all a: lab.T0 | a.av220 = ((P1 + P4))
all a: lab.T1 | a.av220 = (none)
all a: lab.T2 | a.av220 = ((P1 + (P3 + P4)))
(R->P0 in ev220)
semantics3[av221, ev221]
all a: lab.T0 | a.av221 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av221 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av221 = (P1)
(R->P0 in ev221)
semantics6[av222, ev222]
all a: lab.T0 | a.av222 = (P1)
all a: lab.T1 | a.av222 = (none)
all a: lab.T2 | a.av222 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev222)
semantics2[av223, ev223]
all a: lab.T0 | a.av223 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av223 = (P3)
all a: lab.T2 | a.av223 = ((P0 + P2))
(R->P0 in ev223)
semantics1[av224, ev224]
all a: lab.T0 | a.av224 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av224 = ((P1 + P2))
all a: lab.T2 | a.av224 = ((P0 + (P1 + P4)))
(R->P0 in ev224)
semantics1[av225, ev225]
all a: lab.T0 | a.av225 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av225 = (P4)
all a: lab.T2 | a.av225 = ((P0 + (P1 + P2)))
(R->P0 in ev225)
semantics2[av226, ev226]
all a: lab.T0 | a.av226 = ((P1 + P3))
all a: lab.T1 | a.av226 = (none)
all a: lab.T2 | a.av226 = ((P0 + P3))
(R->P0 in ev226)
semantics1[av227, ev227]
all a: lab.T0 | a.av227 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av227 = (none)
all a: lab.T2 | a.av227 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev227)
semantics5[av228, ev228]
all a: lab.T0 | a.av228 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av228 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av228 = ((P0 + (P1 + P2)))
(R->P0 in ev228)
semantics1[av229, ev229]
all a: lab.T0 | a.av229 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av229 = (none)
all a: lab.T2 | a.av229 = ((P0 + (P1 + P2)))
(R->P0 in ev229)
semantics6[av230, ev230]
all a: lab.T0 | a.av230 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av230 = (P0)
all a: lab.T2 | a.av230 = ((P0 + P3))
(R->P0 in ev230)
semantics0[av231, ev231]
all a: lab.T0 | a.av231 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av231 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av231 = ((P1 + P3))
(R->P0 in ev231)
semantics4[av232, ev232]
all a: lab.T0 | a.av232 = (none)
all a: lab.T1 | a.av232 = (none)
all a: lab.T2 | a.av232 = ((P1 + P2))
(R->P0 in ev232)
semantics5[av233, ev233]
all a: lab.T0 | a.av233 = ((P1 + P4))
all a: lab.T1 | a.av233 = (none)
all a: lab.T2 | a.av233 = ((P3 + P4))
(R->P0 in ev233)
semantics3[av234, ev234]
all a: lab.T0 | a.av234 = ((P0 + P4))
all a: lab.T1 | a.av234 = (none)
all a: lab.T2 | a.av234 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev234)
semantics4[av235, ev235]
all a: lab.T0 | a.av235 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av235 = (none)
all a: lab.T2 | a.av235 = (P2)
(R->P0 in ev235)
semantics5[av236, ev236]
all a: lab.T0 | a.av236 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av236 = (none)
all a: lab.T2 | a.av236 = ((P2 + P3))
(R->P0 in ev236)
semantics6[av237, ev237]
all a: lab.T0 | a.av237 = ((P1 + P3))
all a: lab.T1 | a.av237 = (none)
all a: lab.T2 | a.av237 = ((P0 + (P2 + P3)))
(R->P0 in ev237)
semantics6[av238, ev238]
all a: lab.T0 | a.av238 = (P3)
all a: lab.T1 | a.av238 = (none)
all a: lab.T2 | a.av238 = ((P0 + (P1 + P3)))
(R->P0 in ev238)
semantics3[av239, ev239]
all a: lab.T0 | a.av239 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av239 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av239 = ((P3 + P4))
(R->P0 in ev239)
semantics5[av240, ev240]
all a: lab.T0 | a.av240 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av240 = ((P0 + P3))
all a: lab.T2 | a.av240 = ((P0 + P3))
(R->P0 in ev240)
semantics3[av241, ev241]
all a: lab.T0 | a.av241 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av241 = (P4)
all a: lab.T2 | a.av241 = ((P0 + P4))
(R->P0 in ev241)
semantics8[av242, ev242]
all a: lab.T0 | a.av242 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av242 = ((P1 + P3))
all a: lab.T2 | a.av242 = ((P0 + P1))
(R->P0 in ev242)
semantics3[av243, ev243]
all a: lab.T0 | a.av243 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av243 = ((P2 + P4))
all a: lab.T2 | a.av243 = ((P1 + P3))
(R->P0 in ev243)
semantics0[av244, ev244]
all a: lab.T0 | a.av244 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av244 = ((P0 + P2))
all a: lab.T2 | a.av244 = ((P1 + (P2 + P4)))
(R->P0 in ev244)
semantics1[av245, ev245]
all a: lab.T0 | a.av245 = (P0)
all a: lab.T1 | a.av245 = (none)
all a: lab.T2 | a.av245 = ((P1 + P3))
(R->P0 in ev245)
semantics1[av246, ev246]
all a: lab.T0 | a.av246 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av246 = (none)
all a: lab.T2 | a.av246 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev246)
semantics7[av247, ev247]
all a: lab.T0 | a.av247 = ((P0 + P2))
all a: lab.T1 | a.av247 = (none)
all a: lab.T2 | a.av247 = (P2)
(R->P0 in ev247)
semantics0[av248, ev248]
all a: lab.T0 | a.av248 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av248 = ((P1 + P3))
all a: lab.T2 | a.av248 = ((P1 + (P2 + P3)))
(R->P0 in ev248)
semantics12[av249, ev249]
all a: lab.T0 | a.av249 = ((P0 + P1))
all a: lab.T1 | a.av249 = (P0)
all a: lab.T2 | a.av249 = (P0)
(R->P0 in ev249)
semantics0[av250, ev250]
all a: lab.T0 | a.av250 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av250 = (P3)
all a: lab.T2 | a.av250 = ((P1 + (P2 + P3)))
(R->P0 in ev250)
semantics5[av251, ev251]
all a: lab.T0 | a.av251 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av251 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av251 = (P1)
(R->P0 in ev251)
semantics2[av252, ev252]
all a: lab.T0 | a.av252 = ((P0 + P3))
all a: lab.T1 | a.av252 = (P3)
all a: lab.T2 | a.av252 = ((P2 + P3))
(R->P0 in ev252)
semantics0[av253, ev253]
all a: lab.T0 | a.av253 = (P4)
all a: lab.T1 | a.av253 = (none)
all a: lab.T2 | a.av253 = ((P1 + P2))
(R->P0 in ev253)
semantics6[av254, ev254]
all a: lab.T0 | a.av254 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av254 = (none)
all a: lab.T2 | a.av254 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev254)
semantics3[av255, ev255]
all a: lab.T0 | a.av255 = ((P0 + P4))
all a: lab.T1 | a.av255 = (none)
all a: lab.T2 | a.av255 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev255)
semantics6[av256, ev256]
all a: lab.T0 | a.av256 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av256 = ((P0 + P3))
all a: lab.T2 | a.av256 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev256)
semantics3[av257, ev257]
all a: lab.T0 | a.av257 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av257 = (P4)
all a: lab.T2 | a.av257 = (P3)
(R->P0 in ev257)
semantics8[av258, ev258]
all a: lab.T0 | a.av258 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av258 = ((P1 + P3))
all a: lab.T2 | a.av258 = ((P2 + P3))
(R->P0 in ev258)
semantics5[av259, ev259]
all a: lab.T0 | a.av259 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av259 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av259 = ((P3 + P4))
(R->P0 in ev259)
semantics6[av260, ev260]
all a: lab.T0 | a.av260 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av260 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av260 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev260)
semantics4[av261, ev261]
all a: lab.T0 | a.av261 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av261 = (none)
all a: lab.T2 | a.av261 = (P3)
(R->P0 in ev261)
semantics0[av262, ev262]
all a: lab.T0 | a.av262 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av262 = (none)
all a: lab.T2 | a.av262 = ((P1 + P3))
(R->P0 in ev262)
semantics6[av263, ev263]
all a: lab.T0 | a.av263 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av263 = (none)
all a: lab.T2 | a.av263 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev263)
semantics5[av264, ev264]
all a: lab.T0 | a.av264 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av264 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av264 = (P2)
(R->P0 in ev264)
semantics6[av265, ev265]
all a: lab.T0 | a.av265 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av265 = (none)
all a: lab.T2 | a.av265 = ((P2 + P4))
(R->P0 in ev265)
semantics13[av266, ev266]
all a: lab.T0 | a.av266 = (P2)
all a: lab.T1 | a.av266 = (none)
all a: lab.T2 | a.av266 = (P2)
(R->P0 in ev266)
semantics6[av267, ev267]
all a: lab.T0 | a.av267 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av267 = ((P0 + P4))
all a: lab.T2 | a.av267 = ((P2 + P3))
(R->P0 in ev267)
semantics0[av268, ev268]
all a: lab.T0 | a.av268 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av268 = (none)
all a: lab.T2 | a.av268 = ((P0 + (P1 + P4)))
(R->P0 in ev268)
semantics6[av269, ev269]
all a: lab.T0 | a.av269 = (P0)
all a: lab.T1 | a.av269 = (none)
all a: lab.T2 | a.av269 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev269)
semantics2[av270, ev270]
all a: lab.T0 | a.av270 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av270 = ((P2 + P3))
all a: lab.T2 | a.av270 = ((P1 + P3))
(R->P0 in ev270)
semantics5[av271, ev271]
all a: lab.T0 | a.av271 = ((P0 + P4))
all a: lab.T1 | a.av271 = (none)
all a: lab.T2 | a.av271 = ((P2 + (P3 + P4)))
(R->P0 in ev271)
semantics1[av272, ev272]
all a: lab.T0 | a.av272 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av272 = (P3)
all a: lab.T2 | a.av272 = ((P0 + (P1 + P4)))
(R->P0 in ev272)
semantics6[av273, ev273]
all a: lab.T0 | a.av273 = ((P2 + P3))
all a: lab.T1 | a.av273 = (none)
all a: lab.T2 | a.av273 = ((P0 + (P1 + P3)))
(R->P0 in ev273)
semantics1[av274, ev274]
all a: lab.T0 | a.av274 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av274 = ((P0 + P3))
all a: lab.T2 | a.av274 = ((P0 + (P3 + P4)))
(R->P0 in ev274)
semantics3[av275, ev275]
all a: lab.T0 | a.av275 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av275 = ((P0 + P4))
all a: lab.T2 | a.av275 = ((P1 + (P2 + P3)))
(R->P0 in ev275)
semantics8[av276, ev276]
all a: lab.T0 | a.av276 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av276 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av276 = ((P1 + P3))
(R->P0 in ev276)
semantics1[av277, ev277]
all a: lab.T0 | a.av277 = ((P2 + P4))
all a: lab.T1 | a.av277 = (none)
all a: lab.T2 | a.av277 = ((P1 + (P3 + P4)))
(R->P0 in ev277)
semantics9[av278, ev278]
all a: lab.T0 | a.av278 = ((P0 + P3))
all a: lab.T1 | a.av278 = (none)
all a: lab.T2 | a.av278 = (P3)
(R->P0 in ev278)
semantics3[av279, ev279]
all a: lab.T0 | a.av279 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av279 = ((P1 + P2))
all a: lab.T2 | a.av279 = (P3)
(R->P0 in ev279)
semantics2[av280, ev280]
all a: lab.T0 | a.av280 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av280 = (P1)
all a: lab.T2 | a.av280 = ((P0 + P2))
(R->P0 in ev280)
semantics5[av281, ev281]
all a: lab.T0 | a.av281 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av281 = ((P1 + P2))
all a: lab.T2 | a.av281 = (P0)
(R->P0 in ev281)
semantics6[av282, ev282]
all a: lab.T0 | a.av282 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av282 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av282 = (P4)
(R->P0 in ev282)
semantics5[av283, ev283]
all a: lab.T0 | a.av283 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av283 = ((P1 + P4))
all a: lab.T2 | a.av283 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev283)
semantics10[av284, ev284]
all a: lab.T0 | a.av284 = ((P1 + P2))
all a: lab.T1 | a.av284 = (P1)
all a: lab.T2 | a.av284 = ((P0 + (P1 + P2)))
(R->P0 in ev284)
semantics5[av285, ev285]
all a: lab.T0 | a.av285 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av285 = (none)
all a: lab.T2 | a.av285 = ((P3 + P4))
(R->P0 in ev285)
semantics6[av286, ev286]
all a: lab.T0 | a.av286 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av286 = (none)
all a: lab.T2 | a.av286 = (P4)
(R->P0 in ev286)
semantics6[av287, ev287]
all a: lab.T0 | a.av287 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av287 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av287 = ((P1 + P3))
(R->P0 in ev287)
semantics7[av288, ev288]
all a: lab.T0 | a.av288 = ((P0 + P1))
all a: lab.T1 | a.av288 = (none)
all a: lab.T2 | a.av288 = (P1)
(R->P0 in ev288)
semantics0[av289, ev289]
all a: lab.T0 | a.av289 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av289 = ((P2 + P3))
all a: lab.T2 | a.av289 = ((P0 + P2))
(R->P0 in ev289)
semantics0[av290, ev290]
all a: lab.T0 | a.av290 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av290 = ((P3 + P4))
all a: lab.T2 | a.av290 = ((P0 + P3))
(R->P0 in ev290)
semantics1[av291, ev291]
all a: lab.T0 | a.av291 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av291 = (none)
all a: lab.T2 | a.av291 = ((P0 + (P2 + P4)))
(R->P0 in ev291)
semantics9[av292, ev292]
all a: lab.T0 | a.av292 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av292 = ((P2 + P3))
all a: lab.T2 | a.av292 = ((P0 + (P1 + P2)))
(R->P0 in ev292)
semantics3[av293, ev293]
all a: lab.T0 | a.av293 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av293 = (none)
all a: lab.T2 | a.av293 = (P1)
(R->P0 in ev293)
semantics13[av294, ev294]
all a: lab.T0 | a.av294 = ((P1 + P2))
all a: lab.T1 | a.av294 = (P1)
all a: lab.T2 | a.av294 = ((P0 + P2))
(R->P0 in ev294)
semantics6[av295, ev295]
all a: lab.T0 | a.av295 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av295 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av295 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev295)
semantics5[av296, ev296]
all a: lab.T0 | a.av296 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av296 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av296 = ((P1 + (P3 + P4)))
(R->P0 in ev296)
semantics0[av297, ev297]
all a: lab.T0 | a.av297 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av297 = (none)
all a: lab.T2 | a.av297 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev297)
semantics5[av298, ev298]
all a: lab.T0 | a.av298 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av298 = (none)
all a: lab.T2 | a.av298 = (P2)
(R->P0 in ev298)
semantics9[av299, ev299]
all a: lab.T0 | a.av299 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av299 = (P1)
all a: lab.T2 | a.av299 = ((P1 + P2))
(R->P0 in ev299)
semantics0[av300, ev300]
all a: lab.T0 | a.av300 = ((P1 + P2))
all a: lab.T1 | a.av300 = (none)
all a: lab.T2 | a.av300 = ((P1 + P3))
(R->P0 in ev300)
semantics6[av301, ev301]
all a: lab.T0 | a.av301 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av301 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av301 = ((P0 + P2))
(R->P0 in ev301)
semantics1[av302, ev302]
all a: lab.T0 | a.av302 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av302 = ((P2 + P3))
all a: lab.T2 | a.av302 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev302)
semantics1[av303, ev303]
all a: lab.T0 | a.av303 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av303 = (P4)
all a: lab.T2 | a.av303 = (none)
(R->P0 in ev303)
semantics3[av304, ev304]
all a: lab.T0 | a.av304 = (P3)
all a: lab.T1 | a.av304 = (none)
all a: lab.T2 | a.av304 = ((P1 + P3))
(R->P0 in ev304)
semantics3[av305, ev305]
all a: lab.T0 | a.av305 = ((P0 + P3))
all a: lab.T1 | a.av305 = (none)
all a: lab.T2 | a.av305 = ((P0 + (P1 + P2)))
(R->P0 in ev305)
semantics5[av306, ev306]
all a: lab.T0 | a.av306 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av306 = (P0)
all a: lab.T2 | a.av306 = ((P0 + P2))
(R->P0 in ev306)
semantics6[av307, ev307]
all a: lab.T0 | a.av307 = (P4)
all a: lab.T1 | a.av307 = (none)
all a: lab.T2 | a.av307 = ((P2 + (P3 + P4)))
(R->P0 in ev307)
semantics0[av308, ev308]
all a: lab.T0 | a.av308 = (P4)
all a: lab.T1 | a.av308 = (none)
all a: lab.T2 | a.av308 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev308)
semantics0[av309, ev309]
all a: lab.T0 | a.av309 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av309 = ((P1 + P4))
all a: lab.T2 | a.av309 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev309)
semantics3[av310, ev310]
all a: lab.T0 | a.av310 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av310 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av310 = (P4)
(R->P0 in ev310)
semantics0[av311, ev311]
all a: lab.T0 | a.av311 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av311 = (none)
all a: lab.T2 | a.av311 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev311)
semantics3[av312, ev312]
all a: lab.T0 | a.av312 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av312 = ((P2 + P3))
all a: lab.T2 | a.av312 = ((P0 + (P2 + P3)))
(R->P0 in ev312)
semantics0[av313, ev313]
all a: lab.T0 | a.av313 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av313 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av313 = ((P1 + P4))
(R->P0 in ev313)
semantics1[av314, ev314]
all a: lab.T0 | a.av314 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av314 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av314 = (P1)
(R->P0 in ev314)
semantics6[av315, ev315]
all a: lab.T0 | a.av315 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av315 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av315 = ((P2 + (P3 + P4)))
(R->P0 in ev315)
semantics3[av316, ev316]
all a: lab.T0 | a.av316 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av316 = ((P2 + P4))
all a: lab.T2 | a.av316 = ((P0 + (P3 + P4)))
(R->P0 in ev316)
semantics5[av317, ev317]
all a: lab.T0 | a.av317 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av317 = ((P0 + P4))
all a: lab.T2 | a.av317 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev317)
semantics0[av318, ev318]
all a: lab.T0 | a.av318 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av318 = (P2)
all a: lab.T2 | a.av318 = ((P0 + (P2 + P3)))
(R->P0 in ev318)
semantics7[av319, ev319]
all a: lab.T0 | a.av319 = ((P0 + P1))
all a: lab.T1 | a.av319 = (none)
all a: lab.T2 | a.av319 = ((P0 + P2))
(R->P0 in ev319)
semantics3[av320, ev320]
all a: lab.T0 | a.av320 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av320 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av320 = ((P0 + (P3 + P4)))
(R->P0 in ev320)
semantics3[av321, ev321]
all a: lab.T0 | a.av321 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av321 = (P2)
all a: lab.T2 | a.av321 = (P0)
(R->P0 in ev321)
semantics5[av322, ev322]
all a: lab.T0 | a.av322 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av322 = (none)
all a: lab.T2 | a.av322 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev322)
semantics6[av323, ev323]
all a: lab.T0 | a.av323 = ((P0 + P1))
all a: lab.T1 | a.av323 = (none)
all a: lab.T2 | a.av323 = ((P0 + (P1 + P3)))
(R->P0 in ev323)
semantics1[av324, ev324]
all a: lab.T0 | a.av324 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av324 = (P4)
all a: lab.T2 | a.av324 = ((P0 + P1))
(R->P0 in ev324)
semantics0[av325, ev325]
all a: lab.T0 | a.av325 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av325 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av325 = ((P1 + (P2 + P4)))
(R->P0 in ev325)
semantics0[av326, ev326]
all a: lab.T0 | a.av326 = ((P3 + P4))
all a: lab.T1 | a.av326 = ((P3 + P4))
all a: lab.T2 | a.av326 = ((P2 + P4))
(R->P0 in ev326)
semantics2[av327, ev327]
all a: lab.T0 | a.av327 = ((P1 + P3))
all a: lab.T1 | a.av327 = (none)
all a: lab.T2 | a.av327 = ((P1 + P3))
(R->P0 in ev327)
semantics1[av328, ev328]
all a: lab.T0 | a.av328 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av328 = ((P0 + P4))
all a: lab.T2 | a.av328 = (P4)
(R->P0 in ev328)
semantics2[av329, ev329]
all a: lab.T0 | a.av329 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av329 = ((P2 + P3))
all a: lab.T2 | a.av329 = ((P1 + P3))
(R->P0 in ev329)
semantics1[av330, ev330]
all a: lab.T0 | a.av330 = ((P1 + P4))
all a: lab.T1 | a.av330 = (P4)
all a: lab.T2 | a.av330 = ((P0 + P2))
(R->P0 in ev330)
semantics6[av331, ev331]
all a: lab.T0 | a.av331 = ((P0 + P1))
all a: lab.T1 | a.av331 = (none)
all a: lab.T2 | a.av331 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev331)
semantics3[av332, ev332]
all a: lab.T0 | a.av332 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av332 = ((P2 + P4))
all a: lab.T2 | a.av332 = ((P0 + (P1 + P4)))
(R->P0 in ev332)
semantics6[av333, ev333]
all a: lab.T0 | a.av333 = (P0)
all a: lab.T1 | a.av333 = (none)
all a: lab.T2 | a.av333 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev333)
semantics2[av334, ev334]
all a: lab.T0 | a.av334 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av334 = ((P1 + P3))
all a: lab.T2 | a.av334 = (P3)
(R->P0 in ev334)
semantics6[av335, ev335]
all a: lab.T0 | a.av335 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av335 = (none)
all a: lab.T2 | a.av335 = ((P2 + P4))
(R->P0 in ev335)
semantics0[av336, ev336]
all a: lab.T0 | a.av336 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av336 = ((P2 + P3))
all a: lab.T2 | a.av336 = ((P3 + P4))
(R->P0 in ev336)
semantics4[av337, ev337]
all a: lab.T0 | a.av337 = ((P0 + P3))
all a: lab.T1 | a.av337 = (none)
all a: lab.T2 | a.av337 = ((P0 + (P2 + P3)))
(R->P0 in ev337)
semantics6[av338, ev338]
all a: lab.T0 | a.av338 = ((P0 + P1))
all a: lab.T1 | a.av338 = (none)
all a: lab.T2 | a.av338 = ((P0 + (P1 + P2)))
(R->P0 in ev338)
semantics3[av339, ev339]
all a: lab.T0 | a.av339 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av339 = ((P1 + P2))
all a: lab.T2 | a.av339 = ((P0 + P3))
(R->P0 in ev339)
semantics3[av340, ev340]
all a: lab.T0 | a.av340 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av340 = ((P1 + P2))
all a: lab.T2 | a.av340 = ((P1 + P3))
(R->P0 in ev340)
semantics5[av341, ev341]
all a: lab.T0 | a.av341 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av341 = (none)
all a: lab.T2 | a.av341 = ((P1 + P4))
(R->P0 in ev341)
semantics0[av342, ev342]
all a: lab.T0 | a.av342 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av342 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av342 = (P2)
(R->P0 in ev342)
semantics0[av343, ev343]
all a: lab.T0 | a.av343 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av343 = (none)
all a: lab.T2 | a.av343 = ((P2 + P3))
(R->P0 in ev343)
semantics6[av344, ev344]
all a: lab.T0 | a.av344 = (P0)
all a: lab.T1 | a.av344 = (none)
all a: lab.T2 | a.av344 = ((P0 + (P1 + P4)))
(R->P0 in ev344)
semantics5[av345, ev345]
all a: lab.T0 | a.av345 = ((P2 + P3))
all a: lab.T1 | a.av345 = (none)
all a: lab.T2 | a.av345 = ((P0 + (P2 + P3)))
(R->P0 in ev345)
semantics3[av346, ev346]
all a: lab.T0 | a.av346 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av346 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av346 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev346)
semantics5[av347, ev347]
all a: lab.T0 | a.av347 = (P1)
all a: lab.T1 | a.av347 = (none)
all a: lab.T2 | a.av347 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev347)
semantics0[av348, ev348]
all a: lab.T0 | a.av348 = ((P0 + P4))
all a: lab.T1 | a.av348 = (P1)
all a: lab.T2 | a.av348 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev348)
semantics3[av349, ev349]
all a: lab.T0 | a.av349 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av349 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av349 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev349)
semantics0[av350, ev350]
all a: lab.T0 | a.av350 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av350 = ((P2 + P4))
all a: lab.T2 | a.av350 = (P0)
not (R->P0 in ev350)
semantics1[av351, ev351]
all a: lab.T0 | a.av351 = ((P2 + P3))
all a: lab.T1 | a.av351 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av351 = ((P1 + P3))
not (R->P0 in ev351)
semantics6[av352, ev352]
all a: lab.T0 | a.av352 = ((P2 + P3))
all a: lab.T1 | a.av352 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av352 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev352)
semantics6[av353, ev353]
all a: lab.T0 | a.av353 = (P3)
all a: lab.T1 | a.av353 = (P0)
all a: lab.T2 | a.av353 = (P1)
not (R->P0 in ev353)
semantics5[av354, ev354]
all a: lab.T0 | a.av354 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av354 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av354 = ((P0 + P4))
not (R->P0 in ev354)
semantics5[av355, ev355]
all a: lab.T0 | a.av355 = (P3)
all a: lab.T1 | a.av355 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av355 = ((P2 + (P3 + P4)))
not (R->P0 in ev355)
semantics2[av356, ev356]
all a: lab.T0 | a.av356 = ((P1 + P2))
all a: lab.T1 | a.av356 = (P3)
all a: lab.T2 | a.av356 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev356)
semantics0[av357, ev357]
all a: lab.T0 | a.av357 = (none)
all a: lab.T1 | a.av357 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av357 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev357)
semantics3[av358, ev358]
all a: lab.T0 | a.av358 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av358 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av358 = (P0)
not (R->P0 in ev358)
semantics1[av359, ev359]
all a: lab.T0 | a.av359 = (P3)
all a: lab.T1 | a.av359 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av359 = ((P2 + (P3 + P4)))
not (R->P0 in ev359)
semantics0[av360, ev360]
all a: lab.T0 | a.av360 = ((P2 + P3))
all a: lab.T1 | a.av360 = ((P0 + P2))
all a: lab.T2 | a.av360 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev360)
semantics9[av361, ev361]
all a: lab.T0 | a.av361 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av361 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av361 = (P0)
not (R->P0 in ev361)
semantics0[av362, ev362]
all a: lab.T0 | a.av362 = ((P0 + P1))
all a: lab.T1 | a.av362 = (P4)
all a: lab.T2 | a.av362 = (P1)
not (R->P0 in ev362)
semantics1[av363, ev363]
all a: lab.T0 | a.av363 = ((P0 + P2))
all a: lab.T1 | a.av363 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av363 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev363)
semantics0[av364, ev364]
all a: lab.T0 | a.av364 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av364 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av364 = ((P0 + (P2 + P3)))
not (R->P0 in ev364)
semantics5[av365, ev365]
all a: lab.T0 | a.av365 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av365 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av365 = ((P1 + P3))
not (R->P0 in ev365)
semantics1[av366, ev366]
all a: lab.T0 | a.av366 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av366 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av366 = ((P2 + P4))
not (R->P0 in ev366)
semantics5[av367, ev367]
all a: lab.T0 | a.av367 = ((P2 + P3))
all a: lab.T1 | a.av367 = (P2)
all a: lab.T2 | a.av367 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev367)
semantics1[av368, ev368]
all a: lab.T0 | a.av368 = ((P0 + P2))
all a: lab.T1 | a.av368 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av368 = ((P0 + (P2 + P3)))
not (R->P0 in ev368)
semantics0[av369, ev369]
all a: lab.T0 | a.av369 = ((P0 + P1))
all a: lab.T1 | a.av369 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av369 = ((P0 + P3))
not (R->P0 in ev369)
semantics0[av370, ev370]
all a: lab.T0 | a.av370 = ((P0 + P1))
all a: lab.T1 | a.av370 = ((P0 + P4))
all a: lab.T2 | a.av370 = ((P0 + (P1 + P3)))
not (R->P0 in ev370)
semantics5[av371, ev371]
all a: lab.T0 | a.av371 = ((P3 + P4))
all a: lab.T1 | a.av371 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av371 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev371)
semantics3[av372, ev372]
all a: lab.T0 | a.av372 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av372 = ((P0 + P3))
all a: lab.T2 | a.av372 = (P2)
not (R->P0 in ev372)
semantics0[av373, ev373]
all a: lab.T0 | a.av373 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av373 = (P4)
all a: lab.T2 | a.av373 = ((P0 + (P1 + P3)))
not (R->P0 in ev373)
semantics0[av374, ev374]
all a: lab.T0 | a.av374 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av374 = ((P1 + P2))
all a: lab.T2 | a.av374 = ((P0 + (P1 + P4)))
not (R->P0 in ev374)
semantics10[av375, ev375]
all a: lab.T0 | a.av375 = (P1)
all a: lab.T1 | a.av375 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av375 = (P0)
not (R->P0 in ev375)
semantics3[av376, ev376]
all a: lab.T0 | a.av376 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av376 = (P0)
all a: lab.T2 | a.av376 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev376)
semantics5[av377, ev377]
all a: lab.T0 | a.av377 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av377 = ((P0 + P1))
all a: lab.T2 | a.av377 = ((P2 + P3))
not (R->P0 in ev377)
semantics5[av378, ev378]
all a: lab.T0 | a.av378 = (P0)
all a: lab.T1 | a.av378 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av378 = ((P0 + (P1 + P4)))
not (R->P0 in ev378)
semantics5[av379, ev379]
all a: lab.T0 | a.av379 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av379 = ((P3 + P4))
all a: lab.T2 | a.av379 = ((P1 + (P2 + P4)))
not (R->P0 in ev379)
semantics6[av380, ev380]
all a: lab.T0 | a.av380 = ((P0 + P3))
all a: lab.T1 | a.av380 = ((P1 + P4))
all a: lab.T2 | a.av380 = ((P0 + P4))
not (R->P0 in ev380)
semantics5[av381, ev381]
all a: lab.T0 | a.av381 = ((P3 + P4))
all a: lab.T1 | a.av381 = (P0)
all a: lab.T2 | a.av381 = ((P3 + P4))
not (R->P0 in ev381)
semantics5[av382, ev382]
all a: lab.T0 | a.av382 = ((P2 + P4))
all a: lab.T1 | a.av382 = (P2)
all a: lab.T2 | a.av382 = (P0)
not (R->P0 in ev382)
semantics6[av383, ev383]
all a: lab.T0 | a.av383 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av383 = ((P1 + P4))
all a: lab.T2 | a.av383 = ((P0 + P3))
not (R->P0 in ev383)
semantics1[av384, ev384]
all a: lab.T0 | a.av384 = ((P0 + P4))
all a: lab.T1 | a.av384 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av384 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev384)
semantics3[av385, ev385]
all a: lab.T0 | a.av385 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av385 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av385 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev385)
semantics6[av386, ev386]
all a: lab.T0 | a.av386 = ((P3 + P4))
all a: lab.T1 | a.av386 = ((P0 + P2))
all a: lab.T2 | a.av386 = ((P1 + (P3 + P4)))
not (R->P0 in ev386)
semantics1[av387, ev387]
all a: lab.T0 | a.av387 = ((P2 + P4))
all a: lab.T1 | a.av387 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av387 = ((P0 + (P1 + P4)))
not (R->P0 in ev387)
semantics1[av388, ev388]
all a: lab.T0 | a.av388 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av388 = (P0)
all a: lab.T2 | a.av388 = ((P1 + P2))
not (R->P0 in ev388)
semantics3[av389, ev389]
all a: lab.T0 | a.av389 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av389 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av389 = (P1)
not (R->P0 in ev389)
semantics3[av390, ev390]
all a: lab.T0 | a.av390 = (P1)
all a: lab.T1 | a.av390 = (P0)
all a: lab.T2 | a.av390 = (P4)
not (R->P0 in ev390)
semantics4[av391, ev391]
all a: lab.T0 | a.av391 = (none)
all a: lab.T1 | a.av391 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av391 = (P1)
not (R->P0 in ev391)
semantics3[av392, ev392]
all a: lab.T0 | a.av392 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av392 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av392 = ((P0 + P3))
not (R->P0 in ev392)
semantics5[av393, ev393]
all a: lab.T0 | a.av393 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av393 = ((P0 + P3))
all a: lab.T2 | a.av393 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev393)
semantics3[av394, ev394]
all a: lab.T0 | a.av394 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av394 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av394 = ((P2 + (P3 + P4)))
not (R->P0 in ev394)
semantics6[av395, ev395]
all a: lab.T0 | a.av395 = ((P0 + P1))
all a: lab.T1 | a.av395 = ((P2 + P4))
all a: lab.T2 | a.av395 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev395)
semantics0[av396, ev396]
all a: lab.T0 | a.av396 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av396 = (P1)
all a: lab.T2 | a.av396 = (P4)
not (R->P0 in ev396)
semantics5[av397, ev397]
all a: lab.T0 | a.av397 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av397 = (P1)
all a: lab.T2 | a.av397 = ((P0 + P3))
not (R->P0 in ev397)
semantics6[av398, ev398]
all a: lab.T0 | a.av398 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av398 = ((P3 + P4))
all a: lab.T2 | a.av398 = (none)
not (R->P0 in ev398)
semantics0[av399, ev399]
all a: lab.T0 | a.av399 = ((P0 + P3))
all a: lab.T1 | a.av399 = ((P2 + P3))
all a: lab.T2 | a.av399 = ((P0 + P4))
not (R->P0 in ev399)
semantics1[av400, ev400]
all a: lab.T0 | a.av400 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av400 = (P1)
all a: lab.T2 | a.av400 = ((P0 + P3))
not (R->P0 in ev400)
semantics5[av401, ev401]
all a: lab.T0 | a.av401 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av401 = ((P3 + P4))
all a: lab.T2 | a.av401 = (none)
not (R->P0 in ev401)
semantics1[av402, ev402]
all a: lab.T0 | a.av402 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av402 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av402 = ((P0 + P3))
not (R->P0 in ev402)
semantics3[av403, ev403]
all a: lab.T0 | a.av403 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av403 = ((P1 + P3))
all a: lab.T2 | a.av403 = ((P1 + P2))
not (R->P0 in ev403)
semantics1[av404, ev404]
all a: lab.T0 | a.av404 = (P4)
all a: lab.T1 | a.av404 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av404 = ((P0 + (P1 + P2)))
not (R->P0 in ev404)
semantics6[av405, ev405]
all a: lab.T0 | a.av405 = (P2)
all a: lab.T1 | a.av405 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av405 = ((P1 + P3))
not (R->P0 in ev405)
semantics4[av406, ev406]
all a: lab.T0 | a.av406 = ((P1 + P3))
all a: lab.T1 | a.av406 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av406 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev406)
semantics5[av407, ev407]
all a: lab.T0 | a.av407 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av407 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av407 = ((P1 + (P2 + P4)))
not (R->P0 in ev407)
semantics1[av408, ev408]
all a: lab.T0 | a.av408 = (P4)
all a: lab.T1 | a.av408 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av408 = (none)
not (R->P0 in ev408)
semantics1[av409, ev409]
all a: lab.T0 | a.av409 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av409 = ((P0 + P1))
all a: lab.T2 | a.av409 = (P4)
not (R->P0 in ev409)
semantics1[av410, ev410]
all a: lab.T0 | a.av410 = ((P0 + P3))
all a: lab.T1 | a.av410 = ((P2 + P3))
all a: lab.T2 | a.av410 = ((P0 + (P1 + P4)))
not (R->P0 in ev410)
semantics0[av411, ev411]
all a: lab.T0 | a.av411 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av411 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av411 = ((P0 + P2))
not (R->P0 in ev411)
semantics5[av412, ev412]
all a: lab.T0 | a.av412 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av412 = ((P1 + P4))
all a: lab.T2 | a.av412 = (P2)
not (R->P0 in ev412)
semantics1[av413, ev413]
all a: lab.T0 | a.av413 = ((P0 + P2))
all a: lab.T1 | a.av413 = ((P1 + P3))
all a: lab.T2 | a.av413 = ((P0 + (P2 + P3)))
not (R->P0 in ev413)
semantics6[av414, ev414]
all a: lab.T0 | a.av414 = ((P2 + P4))
all a: lab.T1 | a.av414 = (P1)
all a: lab.T2 | a.av414 = ((P0 + (P1 + P4)))
not (R->P0 in ev414)
semantics1[av415, ev415]
all a: lab.T0 | a.av415 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av415 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av415 = ((P0 + P1))
not (R->P0 in ev415)
semantics6[av416, ev416]
all a: lab.T0 | a.av416 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av416 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av416 = (P4)
not (R->P0 in ev416)
semantics0[av417, ev417]
all a: lab.T0 | a.av417 = (P4)
all a: lab.T1 | a.av417 = ((P0 + P1))
all a: lab.T2 | a.av417 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev417)
semantics3[av418, ev418]
all a: lab.T0 | a.av418 = ((P0 + P3))
all a: lab.T1 | a.av418 = ((P0 + P4))
all a: lab.T2 | a.av418 = (P0)
not (R->P0 in ev418)
semantics0[av419, ev419]
all a: lab.T0 | a.av419 = ((P1 + P3))
all a: lab.T1 | a.av419 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av419 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev419)
semantics6[av420, ev420]
all a: lab.T0 | a.av420 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av420 = ((P1 + P4))
all a: lab.T2 | a.av420 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev420)
semantics6[av421, ev421]
all a: lab.T0 | a.av421 = ((P1 + P3))
all a: lab.T1 | a.av421 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av421 = (P4)
not (R->P0 in ev421)
semantics3[av422, ev422]
all a: lab.T0 | a.av422 = ((P1 + P2))
all a: lab.T1 | a.av422 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av422 = ((P1 + (P2 + P3)))
not (R->P0 in ev422)
semantics3[av423, ev423]
all a: lab.T0 | a.av423 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av423 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av423 = (P4)
not (R->P0 in ev423)
semantics0[av424, ev424]
all a: lab.T0 | a.av424 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av424 = ((P1 + P3))
all a: lab.T2 | a.av424 = ((P0 + P2))
not (R->P0 in ev424)
semantics9[av425, ev425]
all a: lab.T0 | a.av425 = (P2)
all a: lab.T1 | a.av425 = (P3)
all a: lab.T2 | a.av425 = ((P1 + P2))
not (R->P0 in ev425)
semantics6[av426, ev426]
all a: lab.T0 | a.av426 = ((P1 + P4))
all a: lab.T1 | a.av426 = ((P1 + P4))
all a: lab.T2 | a.av426 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev426)
semantics4[av427, ev427]
all a: lab.T0 | a.av427 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av427 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av427 = (P2)
not (R->P0 in ev427)
semantics5[av428, ev428]
all a: lab.T0 | a.av428 = ((P1 + P4))
all a: lab.T1 | a.av428 = (P3)
all a: lab.T2 | a.av428 = (P2)
not (R->P0 in ev428)
semantics6[av429, ev429]
all a: lab.T0 | a.av429 = (P0)
all a: lab.T1 | a.av429 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av429 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev429)
semantics0[av430, ev430]
all a: lab.T0 | a.av430 = ((P2 + P3))
all a: lab.T1 | a.av430 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av430 = ((P0 + P1))
not (R->P0 in ev430)
semantics6[av431, ev431]
all a: lab.T0 | a.av431 = ((P1 + P4))
all a: lab.T1 | a.av431 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av431 = ((P0 + (P1 + P4)))
not (R->P0 in ev431)
semantics1[av432, ev432]
all a: lab.T0 | a.av432 = ((P1 + P3))
all a: lab.T1 | a.av432 = ((P3 + P4))
all a: lab.T2 | a.av432 = ((P0 + (P1 + P4)))
not (R->P0 in ev432)
semantics1[av433, ev433]
all a: lab.T0 | a.av433 = ((P2 + P4))
all a: lab.T1 | a.av433 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av433 = (P2)
not (R->P0 in ev433)
semantics0[av434, ev434]
all a: lab.T0 | a.av434 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av434 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av434 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev434)
semantics4[av435, ev435]
all a: lab.T0 | a.av435 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av435 = (P0)
all a: lab.T2 | a.av435 = (P3)
not (R->P0 in ev435)
semantics3[av436, ev436]
all a: lab.T0 | a.av436 = (P1)
all a: lab.T1 | a.av436 = (P1)
all a: lab.T2 | a.av436 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev436)
semantics0[av437, ev437]
all a: lab.T0 | a.av437 = ((P1 + P3))
all a: lab.T1 | a.av437 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av437 = ((P0 + P2))
not (R->P0 in ev437)
semantics1[av438, ev438]
all a: lab.T0 | a.av438 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av438 = ((P0 + P4))
all a: lab.T2 | a.av438 = (P1)
not (R->P0 in ev438)
semantics3[av439, ev439]
all a: lab.T0 | a.av439 = ((P1 + P4))
all a: lab.T1 | a.av439 = (P0)
all a: lab.T2 | a.av439 = ((P1 + P2))
not (R->P0 in ev439)
semantics6[av440, ev440]
all a: lab.T0 | a.av440 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av440 = (P3)
all a: lab.T2 | a.av440 = ((P1 + P3))
not (R->P0 in ev440)
semantics6[av441, ev441]
all a: lab.T0 | a.av441 = ((P0 + P3))
all a: lab.T1 | a.av441 = ((P0 + P4))
all a: lab.T2 | a.av441 = (P3)
not (R->P0 in ev441)
semantics5[av442, ev442]
all a: lab.T0 | a.av442 = (P1)
all a: lab.T1 | a.av442 = ((P0 + P2))
all a: lab.T2 | a.av442 = ((P1 + (P3 + P4)))
not (R->P0 in ev442)
semantics0[av443, ev443]
all a: lab.T0 | a.av443 = (P2)
all a: lab.T1 | a.av443 = ((P0 + P2))
all a: lab.T2 | a.av443 = ((P2 + P4))
not (R->P0 in ev443)
semantics2[av444, ev444]
all a: lab.T0 | a.av444 = ((P1 + P2))
all a: lab.T1 | a.av444 = ((P1 + P3))
all a: lab.T2 | a.av444 = (P0)
not (R->P0 in ev444)
semantics3[av445, ev445]
all a: lab.T0 | a.av445 = ((P2 + P3))
all a: lab.T1 | a.av445 = (P3)
all a: lab.T2 | a.av445 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev445)
semantics0[av446, ev446]
all a: lab.T0 | a.av446 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av446 = ((P2 + P4))
all a: lab.T2 | a.av446 = ((P2 + (P3 + P4)))
not (R->P0 in ev446)
semantics5[av447, ev447]
all a: lab.T0 | a.av447 = ((P0 + P4))
all a: lab.T1 | a.av447 = (P3)
all a: lab.T2 | a.av447 = ((P0 + P3))
not (R->P0 in ev447)
semantics6[av448, ev448]
all a: lab.T0 | a.av448 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av448 = ((P1 + P2))
all a: lab.T2 | a.av448 = ((P0 + (P2 + P4)))
not (R->P0 in ev448)
semantics5[av449, ev449]
all a: lab.T0 | a.av449 = ((P0 + P4))
all a: lab.T1 | a.av449 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av449 = ((P0 + P2))
not (R->P0 in ev449)
semantics6[av450, ev450]
all a: lab.T0 | a.av450 = ((P0 + P2))
all a: lab.T1 | a.av450 = ((P0 + P1))
all a: lab.T2 | a.av450 = ((P3 + P4))
not (R->P0 in ev450)
semantics3[av451, ev451]
all a: lab.T0 | a.av451 = ((P0 + P3))
all a: lab.T1 | a.av451 = (P0)
all a: lab.T2 | a.av451 = ((P0 + (P3 + P4)))
not (R->P0 in ev451)
semantics6[av452, ev452]
all a: lab.T0 | a.av452 = ((P1 + P3))
all a: lab.T1 | a.av452 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av452 = (P3)
not (R->P0 in ev452)
semantics4[av453, ev453]
all a: lab.T0 | a.av453 = (P2)
all a: lab.T1 | a.av453 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av453 = (P1)
not (R->P0 in ev453)
semantics4[av454, ev454]
all a: lab.T0 | a.av454 = ((P1 + P2))
all a: lab.T1 | a.av454 = ((P0 + P1))
all a: lab.T2 | a.av454 = (P2)
not (R->P0 in ev454)
semantics0[av455, ev455]
all a: lab.T0 | a.av455 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av455 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av455 = ((P0 + (P1 + P2)))
not (R->P0 in ev455)
semantics0[av456, ev456]
all a: lab.T0 | a.av456 = (P4)
all a: lab.T1 | a.av456 = ((P2 + P3))
all a: lab.T2 | a.av456 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev456)
semantics6[av457, ev457]
all a: lab.T0 | a.av457 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av457 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av457 = ((P0 + (P1 + P2)))
not (R->P0 in ev457)
semantics6[av458, ev458]
all a: lab.T0 | a.av458 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av458 = ((P2 + P3))
all a: lab.T2 | a.av458 = ((P2 + P4))
not (R->P0 in ev458)
semantics0[av459, ev459]
all a: lab.T0 | a.av459 = ((P0 + P1))
all a: lab.T1 | a.av459 = ((P1 + P2))
all a: lab.T2 | a.av459 = ((P0 + P4))
not (R->P0 in ev459)
semantics3[av460, ev460]
all a: lab.T0 | a.av460 = ((P2 + P3))
all a: lab.T1 | a.av460 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av460 = ((P0 + P3))
not (R->P0 in ev460)
semantics1[av461, ev461]
all a: lab.T0 | a.av461 = ((P0 + P4))
all a: lab.T1 | a.av461 = (P1)
all a: lab.T2 | a.av461 = (P1)
not (R->P0 in ev461)
semantics1[av462, ev462]
all a: lab.T0 | a.av462 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av462 = (P4)
all a: lab.T2 | a.av462 = ((P0 + (P1 + P4)))
not (R->P0 in ev462)
semantics5[av463, ev463]
all a: lab.T0 | a.av463 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av463 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av463 = ((P0 + (P3 + P4)))
not (R->P0 in ev463)
semantics1[av464, ev464]
all a: lab.T0 | a.av464 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av464 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av464 = (P4)
not (R->P0 in ev464)
semantics10[av465, ev465]
all a: lab.T0 | a.av465 = (none)
all a: lab.T1 | a.av465 = ((P0 + P1))
all a: lab.T2 | a.av465 = (P0)
not (R->P0 in ev465)
semantics1[av466, ev466]
all a: lab.T0 | a.av466 = ((P0 + P1))
all a: lab.T1 | a.av466 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av466 = ((P1 + (P2 + P4)))
not (R->P0 in ev466)
semantics1[av467, ev467]
all a: lab.T0 | a.av467 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av467 = (P4)
all a: lab.T2 | a.av467 = ((P1 + (P3 + P4)))
not (R->P0 in ev467)
semantics9[av468, ev468]
all a: lab.T0 | a.av468 = ((P0 + P3))
all a: lab.T1 | a.av468 = ((P1 + P3))
all a: lab.T2 | a.av468 = ((P1 + P3))
not (R->P0 in ev468)
semantics3[av469, ev469]
all a: lab.T0 | a.av469 = (P4)
all a: lab.T1 | a.av469 = (P0)
all a: lab.T2 | a.av469 = (P3)
not (R->P0 in ev469)
semantics3[av470, ev470]
all a: lab.T0 | a.av470 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av470 = (P3)
all a: lab.T2 | a.av470 = ((P1 + (P2 + P3)))
not (R->P0 in ev470)
semantics5[av471, ev471]
all a: lab.T0 | a.av471 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av471 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av471 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev471)
semantics2[av472, ev472]
all a: lab.T0 | a.av472 = ((P1 + P2))
all a: lab.T1 | a.av472 = (P0)
all a: lab.T2 | a.av472 = ((P1 + P2))
not (R->P0 in ev472)
semantics1[av473, ev473]
all a: lab.T0 | a.av473 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av473 = (P0)
all a: lab.T2 | a.av473 = ((P0 + P4))
not (R->P0 in ev473)
semantics6[av474, ev474]
all a: lab.T0 | a.av474 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av474 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av474 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev474)
semantics1[av475, ev475]
all a: lab.T0 | a.av475 = ((P2 + P4))
all a: lab.T1 | a.av475 = ((P0 + P1))
all a: lab.T2 | a.av475 = ((P0 + (P2 + P3)))
not (R->P0 in ev475)
semantics1[av476, ev476]
all a: lab.T0 | a.av476 = ((P0 + P3))
all a: lab.T1 | a.av476 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av476 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev476)
semantics0[av477, ev477]
all a: lab.T0 | a.av477 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av477 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av477 = ((P1 + (P2 + P3)))
not (R->P0 in ev477)
semantics3[av478, ev478]
all a: lab.T0 | a.av478 = (P0)
all a: lab.T1 | a.av478 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av478 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev478)
semantics6[av479, ev479]
all a: lab.T0 | a.av479 = (P2)
all a: lab.T1 | a.av479 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av479 = ((P0 + (P3 + P4)))
not (R->P0 in ev479)
semantics2[av480, ev480]
all a: lab.T0 | a.av480 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av480 = ((P0 + P3))
all a: lab.T2 | a.av480 = ((P1 + (P2 + P3)))
not (R->P0 in ev480)
semantics0[av481, ev481]
all a: lab.T0 | a.av481 = ((P3 + P4))
all a: lab.T1 | a.av481 = ((P2 + P3))
all a: lab.T2 | a.av481 = ((P0 + (P1 + P3)))
not (R->P0 in ev481)
semantics0[av482, ev482]
all a: lab.T0 | a.av482 = ((P0 + P3))
all a: lab.T1 | a.av482 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av482 = ((P3 + P4))
not (R->P0 in ev482)
semantics5[av483, ev483]
all a: lab.T0 | a.av483 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av483 = ((P1 + P3))
all a: lab.T2 | a.av483 = ((P1 + (P3 + P4)))
not (R->P0 in ev483)
semantics6[av484, ev484]
all a: lab.T0 | a.av484 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av484 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av484 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev484)
semantics1[av485, ev485]
all a: lab.T0 | a.av485 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av485 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av485 = ((P0 + P2))
not (R->P0 in ev485)
semantics8[av486, ev486]
all a: lab.T0 | a.av486 = (none)
all a: lab.T1 | a.av486 = ((P0 + P1))
all a: lab.T2 | a.av486 = ((P0 + P2))
not (R->P0 in ev486)
semantics2[av487, ev487]
all a: lab.T0 | a.av487 = ((P0 + P1))
all a: lab.T1 | a.av487 = ((P0 + P2))
all a: lab.T2 | a.av487 = ((P0 + (P1 + P3)))
not (R->P0 in ev487)
semantics1[av488, ev488]
all a: lab.T0 | a.av488 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av488 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av488 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev488)
semantics0[av489, ev489]
all a: lab.T0 | a.av489 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av489 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av489 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev489)
semantics3[av490, ev490]
all a: lab.T0 | a.av490 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av490 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av490 = ((P1 + (P2 + P3)))
not (R->P0 in ev490)
semantics3[av491, ev491]
all a: lab.T0 | a.av491 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av491 = ((P2 + P4))
all a: lab.T2 | a.av491 = ((P0 + (P2 + P3)))
not (R->P0 in ev491)
semantics1[av492, ev492]
all a: lab.T0 | a.av492 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av492 = (P1)
all a: lab.T2 | a.av492 = ((P1 + (P3 + P4)))
not (R->P0 in ev492)
semantics1[av493, ev493]
all a: lab.T0 | a.av493 = ((P2 + P3))
all a: lab.T1 | a.av493 = ((P0 + P2))
all a: lab.T2 | a.av493 = ((P0 + (P2 + P4)))
not (R->P0 in ev493)
semantics1[av494, ev494]
all a: lab.T0 | a.av494 = ((P2 + P4))
all a: lab.T1 | a.av494 = (P2)
all a: lab.T2 | a.av494 = ((P0 + (P3 + P4)))
not (R->P0 in ev494)
semantics9[av495, ev495]
all a: lab.T0 | a.av495 = ((P0 + P1))
all a: lab.T1 | a.av495 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av495 = ((P0 + P2))
not (R->P0 in ev495)
semantics6[av496, ev496]
all a: lab.T0 | a.av496 = ((P3 + P4))
all a: lab.T1 | a.av496 = (P1)
all a: lab.T2 | a.av496 = ((P2 + P3))
not (R->P0 in ev496)
semantics0[av497, ev497]
all a: lab.T0 | a.av497 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av497 = ((P1 + P4))
all a: lab.T2 | a.av497 = (P3)
not (R->P0 in ev497)
semantics4[av498, ev498]
all a: lab.T0 | a.av498 = ((P0 + P1))
all a: lab.T1 | a.av498 = ((P1 + P3))
all a: lab.T2 | a.av498 = ((P0 + P2))
not (R->P0 in ev498)
semantics3[av499, ev499]
all a: lab.T0 | a.av499 = ((P2 + P3))
all a: lab.T1 | a.av499 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av499 = ((P3 + P4))
not (R->P0 in ev499)
semantics0[av500, ev500]
all a: lab.T0 | a.av500 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av500 = ((P1 + P4))
all a: lab.T2 | a.av500 = (none)
not (R->P0 in ev500)
semantics0[av501, ev501]
all a: lab.T0 | a.av501 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av501 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av501 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev501)
semantics1[av502, ev502]
all a: lab.T0 | a.av502 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av502 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av502 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev502)
semantics3[av503, ev503]
all a: lab.T0 | a.av503 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av503 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av503 = (P3)
not (R->P0 in ev503)
semantics5[av504, ev504]
all a: lab.T0 | a.av504 = (P3)
all a: lab.T1 | a.av504 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av504 = ((P0 + (P1 + P3)))
not (R->P0 in ev504)
semantics5[av505, ev505]
all a: lab.T0 | a.av505 = ((P0 + P1))
all a: lab.T1 | a.av505 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av505 = (P1)
not (R->P0 in ev505)
semantics1[av506, ev506]
all a: lab.T0 | a.av506 = (P2)
all a: lab.T1 | a.av506 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av506 = ((P0 + P2))
not (R->P0 in ev506)
semantics6[av507, ev507]
all a: lab.T0 | a.av507 = ((P0 + P1))
all a: lab.T1 | a.av507 = ((P2 + P4))
all a: lab.T2 | a.av507 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev507)
semantics6[av508, ev508]
all a: lab.T0 | a.av508 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av508 = ((P0 + P2))
all a: lab.T2 | a.av508 = ((P0 + P3))
not (R->P0 in ev508)
semantics3[av509, ev509]
all a: lab.T0 | a.av509 = ((P0 + P3))
all a: lab.T1 | a.av509 = ((P0 + P1))
all a: lab.T2 | a.av509 = ((P2 + P4))
not (R->P0 in ev509)
semantics6[av510, ev510]
all a: lab.T0 | a.av510 = ((P0 + P2))
all a: lab.T1 | a.av510 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av510 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev510)
semantics3[av511, ev511]
all a: lab.T0 | a.av511 = ((P2 + P4))
all a: lab.T1 | a.av511 = (P0)
all a: lab.T2 | a.av511 = (P4)
not (R->P0 in ev511)
semantics5[av512, ev512]
all a: lab.T0 | a.av512 = ((P0 + P1))
all a: lab.T1 | a.av512 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av512 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev512)
semantics6[av513, ev513]
all a: lab.T0 | a.av513 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av513 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av513 = (P4)
not (R->P0 in ev513)
semantics2[av514, ev514]
all a: lab.T0 | a.av514 = ((P0 + P3))
all a: lab.T1 | a.av514 = ((P0 + P2))
all a: lab.T2 | a.av514 = ((P0 + (P1 + P3)))
not (R->P0 in ev514)
semantics2[av515, ev515]
all a: lab.T0 | a.av515 = (P1)
all a: lab.T1 | a.av515 = ((P0 + P2))
all a: lab.T2 | a.av515 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev515)
semantics0[av516, ev516]
all a: lab.T0 | a.av516 = (P4)
all a: lab.T1 | a.av516 = ((P1 + P2))
all a: lab.T2 | a.av516 = ((P0 + P4))
not (R->P0 in ev516)
semantics3[av517, ev517]
all a: lab.T0 | a.av517 = (none)
all a: lab.T1 | a.av517 = ((P0 + P3))
all a: lab.T2 | a.av517 = ((P0 + P1))
not (R->P0 in ev517)
semantics5[av518, ev518]
all a: lab.T0 | a.av518 = (P4)
all a: lab.T1 | a.av518 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av518 = ((P1 + P2))
not (R->P0 in ev518)
semantics2[av519, ev519]
all a: lab.T0 | a.av519 = (P3)
all a: lab.T1 | a.av519 = ((P1 + P3))
all a: lab.T2 | a.av519 = ((P0 + (P2 + P3)))
not (R->P0 in ev519)
semantics0[av520, ev520]
all a: lab.T0 | a.av520 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av520 = (P1)
all a: lab.T2 | a.av520 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev520)
semantics6[av521, ev521]
all a: lab.T0 | a.av521 = ((P0 + P1))
all a: lab.T1 | a.av521 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av521 = ((P1 + P4))
not (R->P0 in ev521)
semantics5[av522, ev522]
all a: lab.T0 | a.av522 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av522 = ((P0 + P4))
all a: lab.T2 | a.av522 = ((P0 + P2))
not (R->P0 in ev522)
semantics3[av523, ev523]
all a: lab.T0 | a.av523 = ((P3 + P4))
all a: lab.T1 | a.av523 = ((P0 + P4))
all a: lab.T2 | a.av523 = ((P0 + (P1 + P2)))
not (R->P0 in ev523)
semantics5[av524, ev524]
all a: lab.T0 | a.av524 = ((P1 + P3))
all a: lab.T1 | a.av524 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av524 = ((P0 + (P2 + P3)))
not (R->P0 in ev524)
semantics9[av525, ev525]
all a: lab.T0 | a.av525 = ((P0 + P3))
all a: lab.T1 | a.av525 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av525 = (P1)
not (R->P0 in ev525)
semantics1[av526, ev526]
all a: lab.T0 | a.av526 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av526 = (P2)
all a: lab.T2 | a.av526 = ((P1 + (P2 + P4)))
not (R->P0 in ev526)
semantics5[av527, ev527]
all a: lab.T0 | a.av527 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av527 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av527 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev527)
semantics6[av528, ev528]
all a: lab.T0 | a.av528 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av528 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av528 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev528)
semantics3[av529, ev529]
all a: lab.T0 | a.av529 = (P3)
all a: lab.T1 | a.av529 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av529 = ((P2 + P3))
not (R->P0 in ev529)
semantics3[av530, ev530]
all a: lab.T0 | a.av530 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av530 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av530 = ((P0 + (P3 + P4)))
not (R->P0 in ev530)
semantics5[av531, ev531]
all a: lab.T0 | a.av531 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av531 = ((P0 + P2))
all a: lab.T2 | a.av531 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev531)
semantics1[av532, ev532]
all a: lab.T0 | a.av532 = (P4)
all a: lab.T1 | a.av532 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av532 = (P4)
not (R->P0 in ev532)
semantics6[av533, ev533]
all a: lab.T0 | a.av533 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av533 = ((P0 + P3))
all a: lab.T2 | a.av533 = ((P2 + (P3 + P4)))
not (R->P0 in ev533)
semantics1[av534, ev534]
all a: lab.T0 | a.av534 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av534 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av534 = ((P2 + P4))
not (R->P0 in ev534)
semantics3[av535, ev535]
all a: lab.T0 | a.av535 = ((P0 + P4))
all a: lab.T1 | a.av535 = ((P1 + P4))
all a: lab.T2 | a.av535 = ((P0 + P1))
not (R->P0 in ev535)
semantics1[av536, ev536]
all a: lab.T0 | a.av536 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av536 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av536 = ((P0 + (P1 + P4)))
not (R->P0 in ev536)
semantics5[av537, ev537]
all a: lab.T0 | a.av537 = ((P3 + P4))
all a: lab.T1 | a.av537 = ((P3 + P4))
all a: lab.T2 | a.av537 = ((P0 + (P2 + P3)))
not (R->P0 in ev537)
semantics3[av538, ev538]
all a: lab.T0 | a.av538 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av538 = ((P2 + P3))
all a: lab.T2 | a.av538 = ((P0 + (P2 + P4)))
not (R->P0 in ev538)
semantics3[av539, ev539]
all a: lab.T0 | a.av539 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av539 = (P0)
all a: lab.T2 | a.av539 = ((P0 + P1))
not (R->P0 in ev539)
semantics5[av540, ev540]
all a: lab.T0 | a.av540 = (none)
all a: lab.T1 | a.av540 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av540 = ((P0 + P3))
not (R->P0 in ev540)
semantics5[av541, ev541]
all a: lab.T0 | a.av541 = (P0)
all a: lab.T1 | a.av541 = (P2)
all a: lab.T2 | a.av541 = (P4)
not (R->P0 in ev541)
semantics3[av542, ev542]
all a: lab.T0 | a.av542 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av542 = ((P0 + P2))
all a: lab.T2 | a.av542 = (P2)
not (R->P0 in ev542)
semantics6[av543, ev543]
all a: lab.T0 | a.av543 = (P0)
all a: lab.T1 | a.av543 = (P0)
all a: lab.T2 | a.av543 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev543)
semantics3[av544, ev544]
all a: lab.T0 | a.av544 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av544 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av544 = ((P0 + P3))
not (R->P0 in ev544)
semantics6[av545, ev545]
all a: lab.T0 | a.av545 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av545 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av545 = (P3)
not (R->P0 in ev545)
semantics6[av546, ev546]
all a: lab.T0 | a.av546 = (none)
all a: lab.T1 | a.av546 = ((P0 + P1))
all a: lab.T2 | a.av546 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev546)
semantics1[av547, ev547]
all a: lab.T0 | a.av547 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av547 = ((P0 + P2))
all a: lab.T2 | a.av547 = ((P0 + (P1 + P4)))
not (R->P0 in ev547)
semantics6[av548, ev548]
all a: lab.T0 | a.av548 = (P4)
all a: lab.T1 | a.av548 = ((P2 + P4))
all a: lab.T2 | a.av548 = ((P0 + P4))
not (R->P0 in ev548)
semantics6[av549, ev549]
all a: lab.T0 | a.av549 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av549 = (P1)
all a: lab.T2 | a.av549 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev549)
semantics0[av550, ev550]
all a: lab.T0 | a.av550 = (none)
all a: lab.T1 | a.av550 = (P4)
all a: lab.T2 | a.av550 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev550)
semantics1[av551, ev551]
all a: lab.T0 | a.av551 = ((P2 + P3))
all a: lab.T1 | a.av551 = (P2)
all a: lab.T2 | a.av551 = (P1)
not (R->P0 in ev551)
semantics1[av552, ev552]
all a: lab.T0 | a.av552 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av552 = (P3)
all a: lab.T2 | a.av552 = ((P2 + (P3 + P4)))
not (R->P0 in ev552)
semantics5[av553, ev553]
all a: lab.T0 | a.av553 = ((P1 + P4))
all a: lab.T1 | a.av553 = ((P1 + P4))
all a: lab.T2 | a.av553 = ((P0 + (P1 + P4)))
not (R->P0 in ev553)
semantics0[av554, ev554]
all a: lab.T0 | a.av554 = ((P0 + P3))
all a: lab.T1 | a.av554 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av554 = (P3)
not (R->P0 in ev554)
semantics1[av555, ev555]
all a: lab.T0 | a.av555 = (P1)
all a: lab.T1 | a.av555 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av555 = ((P0 + (P2 + P3)))
not (R->P0 in ev555)
semantics5[av556, ev556]
all a: lab.T0 | a.av556 = (P2)
all a: lab.T1 | a.av556 = ((P2 + P4))
all a: lab.T2 | a.av556 = (P2)
not (R->P0 in ev556)
semantics1[av557, ev557]
all a: lab.T0 | a.av557 = ((P1 + P3))
all a: lab.T1 | a.av557 = (P4)
all a: lab.T2 | a.av557 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev557)
semantics1[av558, ev558]
all a: lab.T0 | a.av558 = (P3)
all a: lab.T1 | a.av558 = (P4)
all a: lab.T2 | a.av558 = ((P3 + P4))
not (R->P0 in ev558)
semantics5[av559, ev559]
all a: lab.T0 | a.av559 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av559 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av559 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev559)
semantics1[av560, ev560]
all a: lab.T0 | a.av560 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av560 = (P0)
all a: lab.T2 | a.av560 = ((P0 + (P3 + P4)))
not (R->P0 in ev560)
semantics3[av561, ev561]
all a: lab.T0 | a.av561 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av561 = ((P0 + P2))
all a: lab.T2 | a.av561 = ((P0 + P1))
not (R->P0 in ev561)
semantics1[av562, ev562]
all a: lab.T0 | a.av562 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av562 = (P0)
all a: lab.T2 | a.av562 = ((P1 + (P2 + P3)))
not (R->P0 in ev562)
semantics0[av563, ev563]
all a: lab.T0 | a.av563 = ((P2 + P3))
all a: lab.T1 | a.av563 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av563 = ((P0 + P4))
not (R->P0 in ev563)
semantics1[av564, ev564]
all a: lab.T0 | a.av564 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av564 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av564 = ((P0 + (P2 + P3)))
not (R->P0 in ev564)
semantics1[av565, ev565]
all a: lab.T0 | a.av565 = ((P0 + P1))
all a: lab.T1 | a.av565 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av565 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev565)
semantics1[av566, ev566]
all a: lab.T0 | a.av566 = (P3)
all a: lab.T1 | a.av566 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av566 = ((P0 + (P3 + P4)))
not (R->P0 in ev566)
semantics5[av567, ev567]
all a: lab.T0 | a.av567 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av567 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av567 = ((P1 + (P2 + P4)))
not (R->P0 in ev567)
semantics0[av568, ev568]
all a: lab.T0 | a.av568 = ((P0 + P1))
all a: lab.T1 | a.av568 = (P2)
all a: lab.T2 | a.av568 = ((P1 + (P2 + P3)))
not (R->P0 in ev568)
semantics0[av569, ev569]
all a: lab.T0 | a.av569 = ((P1 + P3))
all a: lab.T1 | a.av569 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av569 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev569)
semantics5[av570, ev570]
all a: lab.T0 | a.av570 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av570 = (P3)
all a: lab.T2 | a.av570 = ((P1 + P3))
not (R->P0 in ev570)
semantics5[av571, ev571]
all a: lab.T0 | a.av571 = (P0)
all a: lab.T1 | a.av571 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av571 = ((P0 + P3))
not (R->P0 in ev571)
semantics5[av572, ev572]
all a: lab.T0 | a.av572 = ((P1 + P3))
all a: lab.T1 | a.av572 = ((P0 + P3))
all a: lab.T2 | a.av572 = ((P0 + (P3 + P4)))
not (R->P0 in ev572)
semantics6[av573, ev573]
all a: lab.T0 | a.av573 = ((P3 + P4))
all a: lab.T1 | a.av573 = ((P2 + P4))
all a: lab.T2 | a.av573 = ((P1 + (P2 + P4)))
not (R->P0 in ev573)
semantics3[av574, ev574]
all a: lab.T0 | a.av574 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av574 = ((P0 + P2))
all a: lab.T2 | a.av574 = (P1)
not (R->P0 in ev574)
semantics0[av575, ev575]
all a: lab.T0 | a.av575 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av575 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av575 = ((P1 + (P2 + P3)))
not (R->P0 in ev575)
semantics6[av576, ev576]
all a: lab.T0 | a.av576 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av576 = (P3)
all a: lab.T2 | a.av576 = ((P0 + (P2 + P4)))
not (R->P0 in ev576)
semantics4[av577, ev577]
all a: lab.T0 | a.av577 = ((P0 + P1))
all a: lab.T1 | a.av577 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av577 = ((P1 + P2))
not (R->P0 in ev577)
semantics6[av578, ev578]
all a: lab.T0 | a.av578 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av578 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av578 = (P3)
not (R->P0 in ev578)
semantics4[av579, ev579]
all a: lab.T0 | a.av579 = (P2)
all a: lab.T1 | a.av579 = (P2)
all a: lab.T2 | a.av579 = ((P1 + P2))
not (R->P0 in ev579)
semantics6[av580, ev580]
all a: lab.T0 | a.av580 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av580 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av580 = ((P2 + P3))
not (R->P0 in ev580)
semantics5[av581, ev581]
all a: lab.T0 | a.av581 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av581 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av581 = ((P0 + P1))
not (R->P0 in ev581)
semantics0[av582, ev582]
all a: lab.T0 | a.av582 = (P4)
all a: lab.T1 | a.av582 = ((P0 + P4))
all a: lab.T2 | a.av582 = ((P0 + P2))
not (R->P0 in ev582)
semantics0[av583, ev583]
all a: lab.T0 | a.av583 = ((P0 + P3))
all a: lab.T1 | a.av583 = (P1)
all a: lab.T2 | a.av583 = ((P3 + P4))
not (R->P0 in ev583)
semantics6[av584, ev584]
all a: lab.T0 | a.av584 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av584 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av584 = ((P1 + P3))
not (R->P0 in ev584)
semantics5[av585, ev585]
all a: lab.T0 | a.av585 = ((P3 + P4))
all a: lab.T1 | a.av585 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av585 = ((P1 + P2))
not (R->P0 in ev585)
semantics3[av586, ev586]
all a: lab.T0 | a.av586 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av586 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av586 = ((P1 + (P2 + P4)))
not (R->P0 in ev586)
semantics6[av587, ev587]
all a: lab.T0 | a.av587 = (P0)
all a: lab.T1 | a.av587 = ((P1 + P3))
all a: lab.T2 | a.av587 = ((P0 + (P1 + P3)))
not (R->P0 in ev587)
semantics8[av588, ev588]
all a: lab.T0 | a.av588 = ((P2 + P3))
all a: lab.T1 | a.av588 = ((P0 + P3))
all a: lab.T2 | a.av588 = ((P0 + (P2 + P3)))
not (R->P0 in ev588)
semantics5[av589, ev589]
all a: lab.T0 | a.av589 = ((P2 + P3))
all a: lab.T1 | a.av589 = ((P0 + P3))
all a: lab.T2 | a.av589 = ((P0 + P3))
not (R->P0 in ev589)
semantics0[av590, ev590]
all a: lab.T0 | a.av590 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av590 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av590 = ((P0 + (P2 + P3)))
not (R->P0 in ev590)
semantics2[av591, ev591]
all a: lab.T0 | a.av591 = (P1)
all a: lab.T1 | a.av591 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av591 = (P3)
not (R->P0 in ev591)
semantics3[av592, ev592]
all a: lab.T0 | a.av592 = ((P0 + P2))
all a: lab.T1 | a.av592 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av592 = (none)
not (R->P0 in ev592)
semantics6[av593, ev593]
all a: lab.T0 | a.av593 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av593 = ((P0 + P1))
all a: lab.T2 | a.av593 = ((P1 + (P2 + P4)))
not (R->P0 in ev593)
semantics0[av594, ev594]
all a: lab.T0 | a.av594 = ((P2 + P3))
all a: lab.T1 | a.av594 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av594 = (none)
not (R->P0 in ev594)
semantics3[av595, ev595]
all a: lab.T0 | a.av595 = ((P0 + P1))
all a: lab.T1 | a.av595 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av595 = ((P0 + P4))
not (R->P0 in ev595)
semantics1[av596, ev596]
all a: lab.T0 | a.av596 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av596 = ((P0 + P1))
all a: lab.T2 | a.av596 = ((P0 + (P2 + P3)))
not (R->P0 in ev596)
semantics6[av597, ev597]
all a: lab.T0 | a.av597 = ((P0 + P3))
all a: lab.T1 | a.av597 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av597 = ((P1 + (P3 + P4)))
not (R->P0 in ev597)
semantics3[av598, ev598]
all a: lab.T0 | a.av598 = (P0)
all a: lab.T1 | a.av598 = ((P0 + P1))
all a: lab.T2 | a.av598 = ((P1 + (P3 + P4)))
not (R->P0 in ev598)
semantics4[av599, ev599]
all a: lab.T0 | a.av599 = (P2)
all a: lab.T1 | a.av599 = ((P2 + P3))
all a: lab.T2 | a.av599 = ((P2 + P3))
not (R->P0 in ev599)
semantics4[av600, ev600]
all a: lab.T0 | a.av600 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av600 = (P1)
all a: lab.T2 | a.av600 = ((P0 + (P2 + P3)))
not (R->P0 in ev600)
semantics10[av601, ev601]
all a: lab.T0 | a.av601 = (P1)
all a: lab.T1 | a.av601 = ((P1 + P2))
all a: lab.T2 | a.av601 = (P2)
not (R->P0 in ev601)
semantics1[av602, ev602]
all a: lab.T0 | a.av602 = ((P3 + P4))
all a: lab.T1 | a.av602 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av602 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev602)
semantics0[av603, ev603]
all a: lab.T0 | a.av603 = ((P0 + P4))
all a: lab.T1 | a.av603 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av603 = ((P0 + (P1 + P4)))
not (R->P0 in ev603)
semantics1[av604, ev604]
all a: lab.T0 | a.av604 = (P0)
all a: lab.T1 | a.av604 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av604 = ((P1 + (P2 + P3)))
not (R->P0 in ev604)
semantics1[av605, ev605]
all a: lab.T0 | a.av605 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av605 = ((P0 + P4))
all a: lab.T2 | a.av605 = ((P0 + P3))
not (R->P0 in ev605)
semantics5[av606, ev606]
all a: lab.T0 | a.av606 = (P3)
all a: lab.T1 | a.av606 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av606 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev606)
semantics6[av607, ev607]
all a: lab.T0 | a.av607 = (P2)
all a: lab.T1 | a.av607 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av607 = ((P2 + P3))
not (R->P0 in ev607)
semantics3[av608, ev608]
all a: lab.T0 | a.av608 = ((P0 + P3))
all a: lab.T1 | a.av608 = ((P2 + P4))
all a: lab.T2 | a.av608 = ((P1 + P4))
not (R->P0 in ev608)
semantics6[av609, ev609]
all a: lab.T0 | a.av609 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av609 = (P0)
all a: lab.T2 | a.av609 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev609)
semantics5[av610, ev610]
all a: lab.T0 | a.av610 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av610 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av610 = ((P0 + (P1 + P2)))
not (R->P0 in ev610)
semantics6[av611, ev611]
all a: lab.T0 | a.av611 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av611 = ((P1 + P3))
all a: lab.T2 | a.av611 = ((P0 + (P2 + P4)))
not (R->P0 in ev611)
semantics6[av612, ev612]
all a: lab.T0 | a.av612 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av612 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av612 = ((P1 + P4))
not (R->P0 in ev612)
semantics0[av613, ev613]
all a: lab.T0 | a.av613 = ((P0 + P2))
all a: lab.T1 | a.av613 = (P3)
all a: lab.T2 | a.av613 = (P1)
not (R->P0 in ev613)
semantics6[av614, ev614]
all a: lab.T0 | a.av614 = ((P0 + P4))
all a: lab.T1 | a.av614 = (P0)
all a: lab.T2 | a.av614 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev614)
semantics1[av615, ev615]
all a: lab.T0 | a.av615 = ((P1 + P3))
all a: lab.T1 | a.av615 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av615 = (P1)
not (R->P0 in ev615)
semantics1[av616, ev616]
all a: lab.T0 | a.av616 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av616 = (P4)
all a: lab.T2 | a.av616 = ((P0 + (P1 + P2)))
not (R->P0 in ev616)
semantics5[av617, ev617]
all a: lab.T0 | a.av617 = ((P0 + P2))
all a: lab.T1 | a.av617 = ((P1 + P2))
all a: lab.T2 | a.av617 = (P0)
not (R->P0 in ev617)
semantics1[av618, ev618]
all a: lab.T0 | a.av618 = ((P1 + P2))
all a: lab.T1 | a.av618 = (P4)
all a: lab.T2 | a.av618 = ((P0 + P1))
not (R->P0 in ev618)
semantics0[av619, ev619]
all a: lab.T0 | a.av619 = (P0)
all a: lab.T1 | a.av619 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av619 = ((P0 + P3))
not (R->P0 in ev619)
semantics5[av620, ev620]
all a: lab.T0 | a.av620 = ((P0 + P3))
all a: lab.T1 | a.av620 = ((P0 + P4))
all a: lab.T2 | a.av620 = ((P1 + (P2 + P3)))
not (R->P0 in ev620)
semantics3[av621, ev621]
all a: lab.T0 | a.av621 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av621 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av621 = (P3)
not (R->P0 in ev621)
semantics5[av622, ev622]
all a: lab.T0 | a.av622 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av622 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av622 = ((P1 + P2))
not (R->P0 in ev622)
semantics0[av623, ev623]
all a: lab.T0 | a.av623 = ((P0 + P4))
all a: lab.T1 | a.av623 = (P2)
all a: lab.T2 | a.av623 = (P0)
not (R->P0 in ev623)
semantics3[av624, ev624]
all a: lab.T0 | a.av624 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av624 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av624 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev624)
semantics6[av625, ev625]
all a: lab.T0 | a.av625 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av625 = ((P2 + P4))
all a: lab.T2 | a.av625 = ((P0 + P3))
not (R->P0 in ev625)
semantics5[av626, ev626]
all a: lab.T0 | a.av626 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av626 = ((P1 + P3))
all a: lab.T2 | a.av626 = ((P0 + P3))
not (R->P0 in ev626)
semantics3[av627, ev627]
all a: lab.T0 | a.av627 = ((P2 + P4))
all a: lab.T1 | a.av627 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av627 = ((P1 + (P3 + P4)))
not (R->P0 in ev627)
semantics5[av628, ev628]
all a: lab.T0 | a.av628 = ((P0 + P3))
all a: lab.T1 | a.av628 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av628 = ((P1 + (P2 + P4)))
not (R->P0 in ev628)
semantics5[av629, ev629]
all a: lab.T0 | a.av629 = ((P0 + P3))
all a: lab.T1 | a.av629 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av629 = ((P0 + (P2 + P4)))
not (R->P0 in ev629)
semantics5[av630, ev630]
all a: lab.T0 | a.av630 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av630 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av630 = ((P1 + P2))
not (R->P0 in ev630)
semantics5[av631, ev631]
all a: lab.T0 | a.av631 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av631 = ((P0 + P2))
all a: lab.T2 | a.av631 = (none)
not (R->P0 in ev631)
semantics3[av632, ev632]
all a: lab.T0 | a.av632 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av632 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av632 = ((P0 + P1))
not (R->P0 in ev632)
semantics3[av633, ev633]
all a: lab.T0 | a.av633 = ((P1 + P4))
all a: lab.T1 | a.av633 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av633 = (P0)
not (R->P0 in ev633)
semantics3[av634, ev634]
all a: lab.T0 | a.av634 = ((P0 + P1))
all a: lab.T1 | a.av634 = ((P2 + P3))
all a: lab.T2 | a.av634 = ((P0 + (P2 + P4)))
not (R->P0 in ev634)
semantics5[av635, ev635]
all a: lab.T0 | a.av635 = (P0)
all a: lab.T1 | a.av635 = (P0)
all a: lab.T2 | a.av635 = ((P1 + (P2 + P3)))
not (R->P0 in ev635)
semantics6[av636, ev636]
all a: lab.T0 | a.av636 = (P2)
all a: lab.T1 | a.av636 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av636 = ((P0 + P4))
not (R->P0 in ev636)
semantics3[av637, ev637]
all a: lab.T0 | a.av637 = ((P2 + P4))
all a: lab.T1 | a.av637 = ((P1 + P4))
all a: lab.T2 | a.av637 = ((P1 + P3))
not (R->P0 in ev637)
semantics1[av638, ev638]
all a: lab.T0 | a.av638 = ((P2 + P4))
all a: lab.T1 | a.av638 = ((P1 + P3))
all a: lab.T2 | a.av638 = ((P0 + (P3 + P4)))
not (R->P0 in ev638)
semantics0[av639, ev639]
all a: lab.T0 | a.av639 = ((P2 + P3))
all a: lab.T1 | a.av639 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av639 = ((P3 + P4))
not (R->P0 in ev639)
semantics3[av640, ev640]
all a: lab.T0 | a.av640 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av640 = ((P1 + P4))
all a: lab.T2 | a.av640 = (P2)
not (R->P0 in ev640)
semantics3[av641, ev641]
all a: lab.T0 | a.av641 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av641 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av641 = ((P1 + (P2 + P3)))
not (R->P0 in ev641)
semantics5[av642, ev642]
all a: lab.T0 | a.av642 = ((P1 + P4))
all a: lab.T1 | a.av642 = (P4)
all a: lab.T2 | a.av642 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev642)
semantics1[av643, ev643]
all a: lab.T0 | a.av643 = (P0)
all a: lab.T1 | a.av643 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av643 = ((P0 + (P1 + P3)))
not (R->P0 in ev643)
semantics5[av644, ev644]
all a: lab.T0 | a.av644 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av644 = ((P0 + P2))
all a: lab.T2 | a.av644 = (P2)
not (R->P0 in ev644)
semantics4[av645, ev645]
all a: lab.T0 | a.av645 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av645 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av645 = ((P0 + P1))
not (R->P0 in ev645)
semantics1[av646, ev646]
all a: lab.T0 | a.av646 = (P2)
all a: lab.T1 | a.av646 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av646 = ((P0 + (P2 + P3)))
not (R->P0 in ev646)
semantics6[av647, ev647]
all a: lab.T0 | a.av647 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av647 = ((P0 + P2))
all a: lab.T2 | a.av647 = ((P0 + (P1 + P4)))
not (R->P0 in ev647)
semantics2[av648, ev648]
all a: lab.T0 | a.av648 = ((P1 + P3))
all a: lab.T1 | a.av648 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av648 = ((P0 + (P1 + P3)))
not (R->P0 in ev648)
semantics0[av649, ev649]
all a: lab.T0 | a.av649 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av649 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av649 = ((P0 + P4))
not (R->P0 in ev649)
semantics5[av650, ev650]
all a: lab.T0 | a.av650 = ((P2 + P3))
all a: lab.T1 | a.av650 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av650 = ((P0 + P2))
not (R->P0 in ev650)
semantics1[av651, ev651]
all a: lab.T0 | a.av651 = (P1)
all a: lab.T1 | a.av651 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av651 = ((P1 + P3))
not (R->P0 in ev651)
semantics6[av652, ev652]
all a: lab.T0 | a.av652 = ((P2 + P3))
all a: lab.T1 | a.av652 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av652 = ((P2 + P4))
not (R->P0 in ev652)
semantics6[av653, ev653]
all a: lab.T0 | a.av653 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av653 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av653 = ((P2 + P3))
not (R->P0 in ev653)
semantics6[av654, ev654]
all a: lab.T0 | a.av654 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av654 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av654 = (P2)
not (R->P0 in ev654)
semantics6[av655, ev655]
all a: lab.T0 | a.av655 = ((P0 + P1))
all a: lab.T1 | a.av655 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av655 = ((P0 + (P1 + P2)))
not (R->P0 in ev655)
semantics12[av656, ev656]
all a: lab.T0 | a.av656 = (P0)
all a: lab.T1 | a.av656 = ((P0 + P1))
all a: lab.T2 | a.av656 = ((P0 + P1))
not (R->P0 in ev656)
semantics5[av657, ev657]
all a: lab.T0 | a.av657 = ((P0 + P1))
all a: lab.T1 | a.av657 = ((P0 + P4))
all a: lab.T2 | a.av657 = ((P0 + P2))
not (R->P0 in ev657)
semantics8[av658, ev658]
all a: lab.T0 | a.av658 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av658 = (P3)
all a: lab.T2 | a.av658 = ((P0 + P2))
not (R->P0 in ev658)
semantics0[av659, ev659]
all a: lab.T0 | a.av659 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av659 = (P1)
all a: lab.T2 | a.av659 = ((P1 + (P2 + P3)))
not (R->P0 in ev659)
semantics1[av660, ev660]
all a: lab.T0 | a.av660 = (P3)
all a: lab.T1 | a.av660 = ((P1 + P4))
all a: lab.T2 | a.av660 = ((P0 + P4))
not (R->P0 in ev660)
semantics3[av661, ev661]
all a: lab.T0 | a.av661 = ((P0 + P2))
all a: lab.T1 | a.av661 = (P4)
all a: lab.T2 | a.av661 = ((P0 + (P1 + P4)))
not (R->P0 in ev661)
semantics2[av662, ev662]
all a: lab.T0 | a.av662 = ((P2 + P3))
all a: lab.T1 | a.av662 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av662 = ((P1 + P3))
not (R->P0 in ev662)
semantics5[av663, ev663]
all a: lab.T0 | a.av663 = ((P0 + P2))
all a: lab.T1 | a.av663 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av663 = ((P0 + (P1 + P4)))
not (R->P0 in ev663)
semantics6[av664, ev664]
all a: lab.T0 | a.av664 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av664 = ((P2 + P3))
all a: lab.T2 | a.av664 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev664)
semantics5[av665, ev665]
all a: lab.T0 | a.av665 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av665 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av665 = ((P3 + P4))
not (R->P0 in ev665)
semantics6[av666, ev666]
all a: lab.T0 | a.av666 = ((P2 + P4))
all a: lab.T1 | a.av666 = ((P0 + P2))
all a: lab.T2 | a.av666 = (P3)
not (R->P0 in ev666)
semantics4[av667, ev667]
all a: lab.T0 | a.av667 = (P1)
all a: lab.T1 | a.av667 = ((P1 + P2))
all a: lab.T2 | a.av667 = (P3)
not (R->P0 in ev667)
semantics3[av668, ev668]
all a: lab.T0 | a.av668 = (P4)
all a: lab.T1 | a.av668 = (P0)
all a: lab.T2 | a.av668 = ((P1 + (P3 + P4)))
not (R->P0 in ev668)
semantics1[av669, ev669]
all a: lab.T0 | a.av669 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av669 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av669 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev669)
semantics0[av670, ev670]
all a: lab.T0 | a.av670 = ((P1 + P2))
all a: lab.T1 | a.av670 = ((P1 + P3))
all a: lab.T2 | a.av670 = ((P3 + P4))
not (R->P0 in ev670)
semantics0[av671, ev671]
all a: lab.T0 | a.av671 = ((P1 + P4))
all a: lab.T1 | a.av671 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av671 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev671)
semantics2[av672, ev672]
all a: lab.T0 | a.av672 = ((P0 + P3))
all a: lab.T1 | a.av672 = ((P2 + P3))
all a: lab.T2 | a.av672 = ((P1 + (P2 + P3)))
not (R->P0 in ev672)
semantics1[av673, ev673]
all a: lab.T0 | a.av673 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av673 = (P3)
all a: lab.T2 | a.av673 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev673)
semantics0[av674, ev674]
all a: lab.T0 | a.av674 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av674 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av674 = ((P0 + (P2 + P3)))
not (R->P0 in ev674)
semantics3[av675, ev675]
all a: lab.T0 | a.av675 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av675 = (P4)
all a: lab.T2 | a.av675 = (P4)
not (R->P0 in ev675)
semantics3[av676, ev676]
all a: lab.T0 | a.av676 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av676 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av676 = ((P1 + P4))
not (R->P0 in ev676)
semantics1[av677, ev677]
all a: lab.T0 | a.av677 = (P1)
all a: lab.T1 | a.av677 = (P3)
all a: lab.T2 | a.av677 = ((P1 + (P2 + P3)))
not (R->P0 in ev677)
semantics3[av678, ev678]
all a: lab.T0 | a.av678 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av678 = ((P0 + P2))
all a: lab.T2 | a.av678 = ((P0 + (P2 + P4)))
not (R->P0 in ev678)
semantics3[av679, ev679]
all a: lab.T0 | a.av679 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av679 = (P1)
all a: lab.T2 | a.av679 = ((P0 + (P1 + P3)))
not (R->P0 in ev679)
semantics0[av680, ev680]
all a: lab.T0 | a.av680 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av680 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av680 = ((P0 + (P1 + P3)))
not (R->P0 in ev680)
semantics5[av681, ev681]
all a: lab.T0 | a.av681 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av681 = (P0)
all a: lab.T2 | a.av681 = ((P0 + (P2 + P4)))
not (R->P0 in ev681)
semantics3[av682, ev682]
all a: lab.T0 | a.av682 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av682 = (P1)
all a: lab.T2 | a.av682 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev682)
semantics5[av683, ev683]
all a: lab.T0 | a.av683 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av683 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av683 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev683)
semantics5[av684, ev684]
all a: lab.T0 | a.av684 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av684 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av684 = (none)
not (R->P0 in ev684)
semantics5[av685, ev685]
all a: lab.T0 | a.av685 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av685 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av685 = ((P0 + P4))
not (R->P0 in ev685)
semantics6[av686, ev686]
all a: lab.T0 | a.av686 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av686 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av686 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev686)
semantics6[av687, ev687]
all a: lab.T0 | a.av687 = ((P1 + P2))
all a: lab.T1 | a.av687 = ((P2 + P4))
all a: lab.T2 | a.av687 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev687)
semantics3[av688, ev688]
all a: lab.T0 | a.av688 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av688 = ((P2 + P4))
all a: lab.T2 | a.av688 = (none)
not (R->P0 in ev688)
semantics3[av689, ev689]
all a: lab.T0 | a.av689 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av689 = (P2)
all a: lab.T2 | a.av689 = ((P0 + (P1 + P4)))
not (R->P0 in ev689)
semantics5[av690, ev690]
all a: lab.T0 | a.av690 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av690 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av690 = ((P0 + (P2 + P4)))
not (R->P0 in ev690)
semantics0[av691, ev691]
all a: lab.T0 | a.av691 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av691 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av691 = ((P1 + P3))
not (R->P0 in ev691)
semantics6[av692, ev692]
all a: lab.T0 | a.av692 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av692 = (P3)
all a: lab.T2 | a.av692 = ((P1 + P3))
not (R->P0 in ev692)
semantics3[av693, ev693]
all a: lab.T0 | a.av693 = (P0)
all a: lab.T1 | a.av693 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av693 = ((P0 + (P2 + P4)))
not (R->P0 in ev693)
semantics0[av694, ev694]
all a: lab.T0 | a.av694 = (P2)
all a: lab.T1 | a.av694 = ((P0 + P4))
all a: lab.T2 | a.av694 = ((P0 + (P2 + P3)))
not (R->P0 in ev694)
semantics1[av695, ev695]
all a: lab.T0 | a.av695 = ((P2 + P3))
all a: lab.T1 | a.av695 = (P0)
all a: lab.T2 | a.av695 = ((P0 + (P1 + P2)))
not (R->P0 in ev695)
semantics2[av696, ev696]
all a: lab.T0 | a.av696 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av696 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av696 = ((P1 + P2))
not (R->P0 in ev696)
semantics0[av697, ev697]
all a: lab.T0 | a.av697 = (P0)
all a: lab.T1 | a.av697 = ((P0 + P4))
all a: lab.T2 | a.av697 = ((P0 + (P2 + P3)))
not (R->P0 in ev697)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int

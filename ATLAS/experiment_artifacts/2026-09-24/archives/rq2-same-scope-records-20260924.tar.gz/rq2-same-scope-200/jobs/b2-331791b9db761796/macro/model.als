abstract sig Unit {}
one sig U0, U1, U2, U3, U4, U5, U6, U7, U8 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7 extends Label {}
abstract sig Q {}
one sig Q0, Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10, Q11, Q12, Q13, Q14 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E26, E27, E28, E29, E30, E31, E32, E33, E34, E35, E36, E37, E38, E39, E40, E41, E42, E43, E44, E45, E46, E47, E48, E49, E50, E51, E52, E53, E54, E55, E56, E57, E58, E59, E60, E61, E62, E63, E64, E65, E66, E67, E68, E69, E70, E71, E72, E73, E74, E75, E76, E77, E78, E79, E80, E81, E82, E83, E84, E85, E86, E87, E88, E89, E90, E91, E92, E93, E94, E95, E96, E97, E98, E99, E100, E101, E102, E103, E104, E105, E106, E107, E108 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, P16, P17, P18, P19 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos }
one sig A0, A1, A2, A3, A4, A5, A6, A7 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4, C5, L5, D5, C6, L6, D6, C7, L7, D7 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (T0 + (T1 + T2)) }
fun un: set Label { (T3 + T4) }
fun bin: set Label { (T5 + (T6 + T7)) }
fun nonempty: set Fiber { ((((((E1 + E2) + (E3 + (E4 + E5))) + ((E6 + (E7 + E9)) + (E10 + (E11 + E12)))) + (((E13 + (E14 + E15)) + (E17 + (E18 + E19))) + ((E20 + (E21 + E22)) + (E23 + (E25 + E26))))) + ((((E27 + (E28 + E29)) + (E30 + (E32 + E33))) + ((E34 + (E35 + E36)) + (E37 + (E39 + E40)))) + (((E41 + (E42 + E43)) + (E44 + (E46 + E47))) + ((E48 + (E49 + E50)) + (E51 + (E53 + E54)))))) + (((((E55 + E56) + (E57 + (E58 + E59))) + ((E61 + (E62 + E63)) + (E64 + (E65 + E66)))) + (((E68 + (E69 + E70)) + (E71 + (E72 + E73))) + ((E75 + (E76 + E77)) + (E78 + (E79 + E80))))) + ((((E82 + (E83 + E84)) + (E85 + (E86 + E87))) + ((E89 + (E90 + E91)) + (E92 + (E93 + E94)))) + (((E96 + (E97 + E98)) + (E99 + (E100 + E101))) + ((E103 + (E104 + E105)) + (E106 + (E107 + E108))))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { (((U0->U1 + U1->U2) + (U2->U3 + U3->U4)) + ((U4->U5 + U5->U6) + (U6->U7 + U7->U8))) }
fun carrierNext: Carrier -> Carrier { (((((A0->A1 + A1->A2) + (A2->A3 + A3->A4)) + ((A4->A5 + A5->A6) + (A6->A7 + A7->R))) + (((R->C0 + C0->L0) + (L0->D0 + D0->C1)) + ((C1->L1 + L1->D1) + (D1->C2 + C2->L2)))) + ((((L2->D2 + D2->C3) + (C3->L3 + L3->D3)) + ((D3->C4 + C4->L4) + (L4->D4 + D4->C5))) + (((C5->L5 + L5->D5) + (D5->C6 + C6->L6)) + ((L6->D6 + D6->C7) + (C7->L7 + L7->D7))))) }
fun child[a: Anchor]: set Port { a.((((A0->C0 + A1->C1) + (A2->C2 + A3->C3)) + ((A4->C4 + A5->C5) + (A6->C6 + A7->C7)))) }
fun left[a: Anchor]: set Port { a.((((A0->L0 + A1->L1) + (A2->L2 + A3->L3)) + ((A4->L4 + A5->L5) + (A6->L6 + A7->L7)))) }
fun right[a: Anchor]: set Port { a.((((A0->D0 + A1->D1) + (A2->D2 + A3->D3)) + ((A4->D4 + A5->D5) + (A6->D6 + A7->D7)))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
C5.src = A5
L5.src = A5
D5.src = A5
(some C5.target iff A5.lab in un and some A5.lab)
(some L5.target iff A5.lab in bin and some A5.lab)
(some D5.target iff A5.lab in bin and some A5.lab)
C6.src = A6
L6.src = A6
D6.src = A6
(some C6.target iff A6.lab in un and some A6.lab)
(some L6.target iff A6.lab in bin and some A6.lab)
(some D6.target iff A6.lab in bin and some A6.lab)
C7.src = A7
L7.src = A7
D7.src = A7
(some C7.target iff A7.lab in un and some A7.lab)
(some L7.target iff A7.lab in bin and some A7.lab)
(some D7.target iff A7.lab in bin and some A7.lab)
no iden & ^graph
active = R.target.*graph
R.fiber not in nonempty
R.target.lab = T4
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
no A3.graph & (((A0 + A1) + (A2 + A3)))
no A4.graph & (((A0 + A1) + (A2 + (A3 + A4))))
no A5.graph & (((A0 + (A1 + A2)) + (A3 + (A4 + A5))))
no A6.graph & (((A0 + (A1 + A2)) + ((A3 + A4) + (A5 + A6))))
no A7.graph & ((((A0 + A1) + (A2 + A3)) + ((A4 + A5) + (A6 + A7))))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
lone lab.T2
some A0.lab and A0.lab in un and R.target != A0 implies #(target.A0) > 1
some A1.lab and A1.lab in un and R.target != A1 implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un and R.target != A2 implies #(target.A2) > 1
some A2.lab implies some A1.lab
some A3.lab and A3.lab in un and R.target != A3 implies #(target.A3) > 1
some A3.lab implies some A2.lab
some A4.lab and A4.lab in un and R.target != A4 implies #(target.A4) > 1
some A4.lab implies some A3.lab
some A5.lab and A5.lab in un and R.target != A5 implies #(target.A5) > 1
some A5.lab implies some A4.lab
some A6.lab and A6.lab in un and R.target != A6 implies #(target.A6) > 1
some A6.lab implies some A5.lab
some A7.lab and A7.lab in un and R.target != A7 implies #(target.A7) > 1
some A7.lab implies some A6.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q4
E2.qi = Q0
E2.qo = Q3
E3.qi = Q0
E3.qo = Q4
E4.qi = Q0
E4.qo = Q4
E5.qi = Q0
E5.qo = Q4
E6.qi = Q0
E6.qo = Q4
E7.qi = Q0
E7.qo = Q4
E8.qi = Q1
E8.qo = Q1
E9.qi = Q1
E9.qo = Q4
E10.qi = Q1
E10.qo = Q3
E11.qi = Q1
E11.qo = Q4
E12.qi = Q1
E12.qo = Q4
E13.qi = Q1
E13.qo = Q4
E14.qi = Q1
E14.qo = Q4
E15.qi = Q1
E15.qo = Q4
E16.qi = Q2
E16.qo = Q2
E17.qi = Q2
E17.qo = Q4
E18.qi = Q2
E18.qo = Q3
E19.qi = Q2
E19.qo = Q4
E20.qi = Q2
E20.qo = Q4
E21.qi = Q2
E21.qo = Q4
E22.qi = Q2
E22.qo = Q4
E23.qi = Q2
E23.qo = Q4
E24.qi = Q3
E24.qo = Q3
E25.qi = Q3
E25.qo = Q4
E26.qi = Q3
E26.qo = Q4
E27.qi = Q3
E27.qo = Q4
E28.qi = Q3
E28.qo = Q4
E29.qi = Q3
E29.qo = Q4
E30.qi = Q3
E30.qo = Q4
E31.qi = Q4
E31.qo = Q4
E32.qi = Q4
E32.qo = Q4
E33.qi = Q4
E33.qo = Q4
E34.qi = Q4
E34.qo = Q4
E35.qi = Q4
E35.qo = Q4
E36.qi = Q4
E36.qo = Q4
E37.qi = Q4
E37.qo = Q4
E38.qi = Q5
E38.qo = Q5
E39.qi = Q5
E39.qo = Q4
E40.qi = Q5
E40.qo = Q4
E41.qi = Q5
E41.qo = Q4
E42.qi = Q5
E42.qo = Q4
E43.qi = Q5
E43.qo = Q4
E44.qi = Q5
E44.qo = Q4
E45.qi = Q6
E45.qo = Q6
E46.qi = Q6
E46.qo = Q4
E47.qi = Q6
E47.qo = Q4
E48.qi = Q6
E48.qo = Q4
E49.qi = Q6
E49.qo = Q4
E50.qi = Q6
E50.qo = Q4
E51.qi = Q6
E51.qo = Q4
E52.qi = Q7
E52.qo = Q7
E53.qi = Q7
E53.qo = Q4
E54.qi = Q7
E54.qo = Q4
E55.qi = Q7
E55.qo = Q4
E56.qi = Q7
E56.qo = Q4
E57.qi = Q7
E57.qo = Q4
E58.qi = Q7
E58.qo = Q10
E59.qi = Q7
E59.qo = Q4
E60.qi = Q8
E60.qo = Q8
E61.qi = Q8
E61.qo = Q4
E62.qi = Q8
E62.qo = Q4
E63.qi = Q8
E63.qo = Q4
E64.qi = Q8
E64.qo = Q4
E65.qi = Q8
E65.qo = Q4
E66.qi = Q8
E66.qo = Q4
E67.qi = Q9
E67.qo = Q9
E68.qi = Q9
E68.qo = Q4
E69.qi = Q9
E69.qo = Q4
E70.qi = Q9
E70.qo = Q4
E71.qi = Q9
E71.qo = Q4
E72.qi = Q9
E72.qo = Q4
E73.qi = Q9
E73.qo = Q4
E74.qi = Q10
E74.qo = Q10
E75.qi = Q10
E75.qo = Q4
E76.qi = Q10
E76.qo = Q4
E77.qi = Q10
E77.qo = Q4
E78.qi = Q10
E78.qo = Q4
E79.qi = Q10
E79.qo = Q4
E80.qi = Q10
E80.qo = Q4
E81.qi = Q11
E81.qo = Q11
E82.qi = Q11
E82.qo = Q4
E83.qi = Q11
E83.qo = Q4
E84.qi = Q11
E84.qo = Q4
E85.qi = Q11
E85.qo = Q4
E86.qi = Q11
E86.qo = Q4
E87.qi = Q11
E87.qo = Q4
E88.qi = Q12
E88.qo = Q12
E89.qi = Q12
E89.qo = Q4
E90.qi = Q12
E90.qo = Q4
E91.qi = Q12
E91.qo = Q4
E92.qi = Q12
E92.qo = Q4
E93.qi = Q12
E93.qo = Q4
E94.qi = Q12
E94.qo = Q4
E95.qi = Q13
E95.qo = Q13
E96.qi = Q13
E96.qo = Q4
E97.qi = Q13
E97.qo = Q4
E98.qi = Q13
E98.qo = Q4
E99.qi = Q13
E99.qo = Q4
E100.qi = Q13
E100.qo = Q4
E101.qi = Q13
E101.qo = Q4
E102.qi = Q14
E102.qo = Q14
E103.qi = Q14
E103.qo = Q4
E104.qi = Q14
E104.qo = Q4
E105.qi = Q14
E105.qo = Q4
E106.qi = Q14
E106.qo = Q4
E107.qi = Q14
E107.qo = Q4
E108.qi = Q14
E108.qo = Q4
all e: used | e.fiber in ((((E0 + (E8 + E16)) + ((E24 + E31) + (E38 + E45))) + (((E52 + E60) + (E67 + E74)) + ((E81 + E88) + (E95 + E102))))) implies #e.cost = 0
all e: used | e.fiber in ((((((E1 + E5) + (E7 + (E9 + E13))) + ((E15 + (E17 + E21)) + (E23 + (E25 + E28)))) + (((E30 + (E32 + E35)) + (E37 + (E39 + E42))) + ((E44 + (E46 + E49)) + (E51 + (E53 + E56))))) + ((((E57 + E59) + (E61 + (E64 + E66))) + ((E68 + (E71 + E73)) + (E75 + (E78 + E80)))) + (((E82 + (E85 + E87)) + (E89 + (E92 + E94))) + ((E96 + (E99 + E101)) + (E103 + (E106 + E108))))))) implies #e.cost = 2
all e: used | e.fiber in (((((E2 + (E6 + E10)) + ((E14 + E18) + (E22 + E26))) + (((E29 + E33) + (E36 + E40)) + ((E43 + E47) + (E50 + E54)))) + (((E58 + (E62 + E65)) + ((E69 + E72) + (E76 + E79))) + (((E83 + E86) + (E90 + E93)) + ((E97 + E100) + (E104 + E107)))))) implies #e.cost = 1
all e: used | e.fiber in (((((E3 + E4) + (E11 + E12)) + ((E19 + E20) + (E27 + (E34 + E41)))) + (((E48 + E55) + (E63 + E70)) + ((E77 + E84) + (E91 + (E98 + E105)))))) implies #e.cost = 3
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q10)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q1
all a: active | a.lab = T2 implies a.state = Q2
all a: active | a.lab = T3 and child[a].fiber.qo = Q0 implies a.state = Q3
all a: active | a.lab = T3 and child[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T3 and child[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T3 and child[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q7 implies a.state = Q10
all a: active | a.lab = T4 and child[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q5
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q5
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q5
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q5
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q5 implies a.state = Q5
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q6 implies a.state = Q12
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q8 implies a.state = Q5
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q9 implies a.state = Q12
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q12 implies a.state = Q12
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q14 implies a.state = Q12
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q8 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q8 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q8 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q0 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q1 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q2 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q8 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q0 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q1 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q2 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q3 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q5 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q8 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q0 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q1 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q2 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q8 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q0 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q1 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q2 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q3 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q5 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q8 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q0 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q1 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q2 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q3 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q5 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q8 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q0 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q1 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q2 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q3 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q5 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q8 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q9
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q9
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q9
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q9
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q5 implies a.state = Q13
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q6 implies a.state = Q9
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q8 implies a.state = Q13
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q9 implies a.state = Q9
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q11 implies a.state = Q13
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q13 implies a.state = Q13
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q0 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q1 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q2 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q3 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q6 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q9 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q0 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q1 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q2 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q3 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q6 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q9 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q0 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q1 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q2 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q3 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q6 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q9 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q0 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q1 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q2 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q3 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q6 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q9 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q9 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q13 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q1 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q9 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q13 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q1 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q9 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q13 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q14 implies a.state = Q4
}
fun range0: set Pos { ((((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) + (((P10 + P11) + (P12 + (P13 + P14))) + ((P15 + P16) + (P17 + (P18 + P19))))) }
fun loop0: set Pos { ((((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) + (((P10 + P11) + (P12 + (P13 + P14))) + ((P15 + P16) + (P17 + (P18 + P19))))) }
fun next0: Pos -> Pos { ((((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P10)))) + (((P10->P11 + P11->P12) + (P12->P13 + (P13->P14 + P14->P15))) + ((P15->P16 + P16->P17) + (P17->P18 + (P18->P19 + P19->P0))))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) + (((P10->P10 + P11->P11) + (P12->P12 + (P13->P13 + P14->P14))) + ((P15->P15 + P16->P16) + (P17->P17 + (P18->P18 + P19->P19))))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in (((((E0 + (E1 + E8)) + ((E9 + E16) + (E17 + E24))) + (((E25 + E31) + (E32 + E38)) + ((E39 + E45) + (E46 + E52)))) + (((E53 + (E60 + E61)) + ((E67 + E68) + (E74 + E75))) + (((E81 + E82) + (E88 + E89)) + ((E95 + E96) + (E102 + E103)))))) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (((((E2 + E3) + (E10 + E11)) + ((E18 + E19) + (E26 + (E33 + E40)))) + (((E47 + E54) + (E62 + E69)) + ((E76 + E83) + (E90 + (E97 + E104)))))) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in ((((E4 + (E12 + E20)) + ((E27 + E34) + (E41 + E48))) + (((E55 + E63) + (E70 + E77)) + ((E84 + E91) + (E98 + E105))))) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in ((((E5 + (E13 + E21)) + ((E28 + E35) + (E42 + E49))) + (((E56 + E64) + (E71 + E78)) + ((E85 + E92) + (E99 + E106))))) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (((((E6 + E14) + (E22 + E29)) + ((E36 + E43) + (E50 + E57))) + (((E58 + E65) + (E72 + E79)) + ((E86 + E93) + (E100 + E107))))) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in ((((E7 + (E15 + E23)) + ((E30 + E37) + (E44 + E51))) + (((E59 + E66) + (E73 + E80)) + ((E87 + E94) + (E101 + E108))))) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T4 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T5 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T6 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T7 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = ((((P2 + P3) + (P6 + P7)) + ((P9 + P13) + (P14 + (P16 + P19)))))
all a: lab.T1 | a.av0 = ((((P0 + P2) + (P3 + (P8 + P9))) + ((P11 + (P13 + P15)) + (P16 + (P17 + P18)))))
all a: lab.T2 | a.av0 = ((((P1 + P2) + (P4 + P8)) + ((P11 + P12) + (P16 + P17))))
(R->P0 in ev0)
semantics0[av1, ev1]
all a: lab.T0 | a.av1 = (((P0 + (P4 + P8)) + (P9 + (P10 + P16))))
all a: lab.T1 | a.av1 = ((((P0 + P3) + (P6 + P8)) + ((P9 + P10) + (P13 + (P15 + P16)))))
all a: lab.T2 | a.av1 = ((((P0 + P1) + (P2 + (P3 + P7))) + ((P8 + P12) + (P13 + (P16 + P18)))))
(R->P0 in ev1)
semantics0[av2, ev2]
all a: lab.T0 | a.av2 = ((((P1 + P2) + (P3 + (P4 + P6))) + ((P8 + (P14 + P15)) + (P16 + (P17 + P19)))))
all a: lab.T1 | a.av2 = ((((P1 + P3) + (P4 + (P6 + P7))) + ((P8 + (P11 + P13)) + (P15 + (P16 + P19)))))
all a: lab.T2 | a.av2 = ((((P0 + P3) + (P6 + P7)) + ((P8 + P9) + (P12 + (P13 + P16)))))
(R->P0 in ev2)
semantics0[av3, ev3]
all a: lab.T0 | a.av3 = (((P2 + (P8 + P12)) + ((P14 + P15) + (P16 + P19))))
all a: lab.T1 | a.av3 = ((((P1 + P5) + (P6 + (P8 + P9))) + ((P11 + P12) + (P13 + (P14 + P15)))))
all a: lab.T2 | a.av3 = ((((P3 + P6) + (P8 + P11)) + ((P12 + P14) + (P15 + (P17 + P18)))))
(R->P0 in ev3)
semantics0[av4, ev4]
all a: lab.T0 | a.av4 = ((((P0 + P1) + (P4 + (P5 + P6))) + ((P9 + (P10 + P14)) + (P17 + (P18 + P19)))))
all a: lab.T1 | a.av4 = ((((P1 + P4) + (P10 + P11)) + ((P14 + P15) + (P16 + P17))))
all a: lab.T2 | a.av4 = ((((P1 + P3) + (P4 + (P7 + P8))) + ((P10 + (P11 + P13)) + (P14 + (P15 + P17)))))
(R->P0 in ev4)
semantics0[av5, ev5]
all a: lab.T0 | a.av5 = ((((P1 + P5) + (P6 + P7)) + ((P12 + P15) + (P17 + P18))))
all a: lab.T1 | a.av5 = ((((P1 + P2) + (P6 + (P7 + P9))) + ((P11 + (P12 + P14)) + (P16 + (P17 + P18)))))
all a: lab.T2 | a.av5 = ((((P0 + (P2 + P3)) + (P4 + (P8 + P10))) + ((P11 + (P12 + P13)) + (P16 + (P18 + P19)))))
(R->P0 in ev5)
semantics0[av6, ev6]
all a: lab.T0 | a.av6 = (((P4 + (P5 + P6)) + (P14 + (P18 + P19))))
all a: lab.T1 | a.av6 = ((((P0 + P2) + (P3 + (P4 + P5))) + ((P7 + (P10 + P14)) + (P15 + (P17 + P18)))))
all a: lab.T2 | a.av6 = ((((P3 + P4) + (P5 + (P7 + P8))) + ((P9 + P10) + (P11 + (P12 + P17)))))
(R->P0 in ev6)
semantics0[av7, ev7]
all a: lab.T0 | a.av7 = ((((P1 + (P2 + P4)) + (P5 + (P7 + P9))) + ((P10 + (P12 + P16)) + (P17 + (P18 + P19)))))
all a: lab.T1 | a.av7 = ((((P1 + (P2 + P4)) + (P6 + (P7 + P8))) + ((P9 + (P12 + P13)) + ((P14 + P16) + (P17 + P19)))))
all a: lab.T2 | a.av7 = ((((P0 + P2) + (P3 + (P4 + P6))) + ((P8 + (P9 + P11)) + (P14 + (P15 + P16)))))
(R->P0 in ev7)
semantics0[av8, ev8]
all a: lab.T0 | a.av8 = ((((P4 + P6) + (P7 + P9)) + ((P12 + P13) + (P17 + P18))))
all a: lab.T1 | a.av8 = ((((P1 + P2) + (P5 + (P6 + P7))) + ((P9 + (P10 + P12)) + (P14 + (P16 + P17)))))
all a: lab.T2 | a.av8 = ((((P0 + P1) + (P2 + (P5 + P6))) + ((P8 + P9) + (P11 + (P15 + P16)))))
(R->P0 in ev8)
semantics0[av9, ev9]
all a: lab.T0 | a.av9 = ((((P2 + P3) + (P6 + P7)) + ((P13 + P15) + (P17 + P18))))
all a: lab.T1 | a.av9 = ((((P1 + P2) + (P4 + (P5 + P6))) + ((P7 + (P11 + P12)) + (P14 + (P15 + P16)))))
all a: lab.T2 | a.av9 = (((P1 + P2) + (P8 + (P11 + P15))))
(R->P0 in ev9)
semantics0[av10, ev10]
all a: lab.T0 | a.av10 = (((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) + (((P9 + P11) + (P12 + P14)) + ((P15 + P16) + (P17 + (P18 + P19))))))
all a: lab.T1 | a.av10 = ((P10 + (P13 + P16)))
all a: lab.T2 | a.av10 = (((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) + (((P8 + P9) + (P11 + P14)) + ((P15 + P17) + (P18 + P19)))))
not (R->P0 in ev10)
semantics0[av11, ev11]
all a: lab.T0 | a.av11 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P6) + (P10 + P12))))
all a: lab.T1 | a.av11 = ((((P1 + P2) + (P4 + (P6 + P8))) + ((P9 + (P10 + P11)) + (P13 + (P16 + P18)))))
all a: lab.T2 | a.av11 = (((P3 + (P4 + P5)) + (P9 + (P15 + P17))))
not (R->P0 in ev11)
semantics0[av12, ev12]
all a: lab.T0 | a.av12 = ((((P2 + (P4 + P9)) + (P10 + (P11 + P12))) + ((P13 + (P14 + P15)) + (P17 + (P18 + P19)))))
all a: lab.T1 | a.av12 = (((P1 + (P3 + P5)) + (P7 + (P15 + P16))))
all a: lab.T2 | a.av12 = ((((P1 + (P2 + P4)) + (P7 + (P9 + P10))) + ((P11 + (P12 + P13)) + ((P14 + P17) + (P18 + P19)))))
not (R->P0 in ev12)
semantics0[av13, ev13]
all a: lab.T0 | a.av13 = (((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P8 + P9)))) + (((P10 + P11) + (P12 + (P13 + P14))) + ((P15 + P16) + (P17 + (P18 + P19))))))
all a: lab.T1 | a.av13 = (P16)
all a: lab.T2 | a.av13 = (((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) + (((P9 + P10) + (P11 + (P12 + P13))) + ((P14 + P15) + (P17 + (P18 + P19))))))
not (R->P0 in ev13)
semantics0[av14, ev14]
all a: lab.T0 | a.av14 = (((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) + (((P9 + P10) + (P12 + (P13 + P14))) + ((P15 + P16) + (P17 + (P18 + P19))))))
all a: lab.T1 | a.av14 = ((P11 + P18))
all a: lab.T2 | a.av14 = (((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) + (((P8 + P10) + (P11 + P12)) + ((P13 + P14) + (P15 + P17)))))
not (R->P0 in ev14)
semantics0[av15, ev15]
all a: lab.T0 | a.av15 = ((((P0 + P1) + (P6 + (P7 + P8))) + ((P9 + (P11 + P12)) + (P13 + (P14 + P18)))))
all a: lab.T1 | a.av15 = (((P0 + (P1 + P5)) + (P10 + (P18 + P19))))
all a: lab.T2 | a.av15 = ((((P1 + P3) + (P4 + (P5 + P7))) + ((P10 + (P11 + P12)) + (P14 + (P15 + P18)))))
not (R->P0 in ev15)
semantics0[av16, ev16]
all a: lab.T0 | a.av16 = (((((P1 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + P8))) + (((P9 + P11) + (P13 + P14)) + ((P15 + P16) + (P17 + (P18 + P19))))))
all a: lab.T1 | a.av16 = (P3)
all a: lab.T2 | a.av16 = (((((P1 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + P8))) + (((P9 + P10) + (P13 + P14)) + ((P15 + P16) + (P17 + (P18 + P19))))))
not (R->P0 in ev16)
semantics0[av17, ev17]
all a: lab.T0 | a.av17 = (((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P8))) + (((P10 + P11) + (P12 + P14)) + ((P15 + P16) + (P17 + (P18 + P19))))))
all a: lab.T1 | a.av17 = (P13)
all a: lab.T2 | a.av17 = (((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) + (((P9 + P10) + (P11 + (P12 + P13))) + ((P15 + P16) + (P17 + (P18 + P19))))))
not (R->P0 in ev17)
semantics0[av18, ev18]
all a: lab.T0 | a.av18 = ((((P0 + P4) + (P5 + (P6 + P7))) + ((P9 + (P10 + P11)) + (P13 + (P16 + P19)))))
all a: lab.T1 | a.av18 = (((P0 + (P6 + P7)) + ((P8 + P15) + (P17 + P18))))
all a: lab.T2 | a.av18 = ((((P1 + (P3 + P4)) + (P5 + (P7 + P8))) + ((P9 + (P11 + P12)) + (P14 + (P16 + P19)))))
not (R->P0 in ev18)
semantics0[av19, ev19]
all a: lab.T0 | a.av19 = ((((P0 + P1) + (P2 + (P3 + P4))) + ((P8 + (P10 + P11)) + (P15 + (P16 + P19)))))
all a: lab.T1 | a.av19 = ((P2 + (P6 + P13)))
all a: lab.T2 | a.av19 = (((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P8 + P9))) + (((P10 + P11) + (P12 + P13)) + ((P14 + P15) + (P16 + (P18 + P19))))))
not (R->P0 in ev19)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int

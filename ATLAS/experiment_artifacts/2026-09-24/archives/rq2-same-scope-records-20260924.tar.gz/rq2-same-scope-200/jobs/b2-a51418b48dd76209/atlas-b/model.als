open util/ordering[SeqIdx]

abstract sig DAGNode {
	l: set DAGNode,
	r: set DAGNode
}
fact {
	all n: DAGNode | n not in n.^(l + r)
}

sig And, Or, Imply extends DAGNode {} {
	one l
	one r
}

sig Neg, F, G extends DAGNode {} {
    one l
    no r
}
abstract sig Literal extends DAGNode {} {
	no l
	no r
}

abstract sig SeqIdx {}
abstract sig Trace {
	lasso: SeqIdx -> SeqIdx,
	valuation: DAGNode -> SeqIdx
} {
	// Negation
    all n: Neg, i: seqRange | n->i in valuation iff n.l->i not in valuation
	// Or
    all n: Or, i: seqRange | n->i in valuation iff (n.l->i in valuation or n.r->i in valuation)
	// And
    all n: And, i: seqRange | n->i in valuation iff (n.l->i in valuation and n.r->i in valuation)
	// Imply
    all n: Imply, i: seqRange | n->i in valuation iff (n.l->i not in valuation or n.r->i in valuation)
	// G
    all n: G, i: seqRange | n->i in valuation iff all i': futureIdx[i] | n.l->i' in valuation
    // X
    
	// F
    all n: F, i: seqRange | n->i in valuation iff some i': futureIdx[i] | n.l->i' in valuation
	// Until
    
}
fun seqRange[t: Trace]: set SeqIdx {
	let lastOfTrace = t.lasso.SeqIdx | lastOfTrace.prevs + lastOfTrace
}
fun futureIdx[t: Trace, i: SeqIdx]: set SeqIdx {
	i.^((next :> seqRange[t]) + t.lasso) + i
}
abstract sig PositiveTrace extends Trace {}
abstract sig NegativeTrace extends Trace {}
one sig x0, x1, x2, x3, x4, x5, x6, x7, x8, x9 extends Literal {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15 extends SeqIdx {}
fact {
    first = T0
    next = T0->T1 + T1->T2 + T2->T3 + T3->T4 + T4->T5 + T5->T6 + T6->T7 + T7->T8 + T8->T9 + T9->T10 + T10->T11 + T11->T12 + T12->T13 + T13->T14 + T14->T15
}

one sig PT0 extends PositiveTrace {} {
    lasso = T5->T0
    x4->T0 + x4->T1 + x8->T1 + x0->T2 + x5->T2 + x8->T2 + x0->T3 + x6->T3 + x8->T3 + x0->T4 + x7->T4 + x8->T4 + x0->T5 + x7->T5 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x5->T0 + x6->T0 + x7->T0 + x8->T0 + x9->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x5->T1 + x6->T1 + x7->T1 + x9->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x6->T2 + x7->T2 + x9->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x5->T3 + x7->T3 + x9->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 + x5->T4 + x6->T4 + x9->T4 + x1->T5 + x2->T5 + x3->T5 + x4->T5 + x5->T5 + x6->T5 + x8->T5 + x9->T5) & valuation
}

one sig PT1 extends PositiveTrace {} {
    lasso = T6->T0
    x4->T0 + x4->T1 + x8->T1 + x0->T2 + x5->T2 + x8->T2 + x0->T3 + x6->T3 + x8->T3 + x0->T4 + x7->T4 + x8->T4 + x0->T5 + x2->T5 + x7->T5 + x8->T5 + x0->T6 + x2->T6 + x7->T6 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x5->T0 + x6->T0 + x7->T0 + x8->T0 + x9->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x5->T1 + x6->T1 + x7->T1 + x9->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x6->T2 + x7->T2 + x9->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x5->T3 + x7->T3 + x9->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 + x5->T4 + x6->T4 + x9->T4 + x1->T5 + x3->T5 + x4->T5 + x5->T5 + x6->T5 + x9->T5 + x1->T6 + x3->T6 + x4->T6 + x5->T6 + x6->T6 + x8->T6 + x9->T6) & valuation
}

one sig PT2 extends PositiveTrace {} {
    lasso = T5->T5
    x4->T0 + x4->T1 + x8->T1 + x1->T2 + x4->T2 + x1->T3 + x6->T3 + x8->T3 + x1->T4 + x7->T4 + x8->T4 + x1->T5 + x7->T5 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x5->T0 + x6->T0 + x7->T0 + x8->T0 + x9->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x5->T1 + x6->T1 + x7->T1 + x9->T1 + x0->T2 + x2->T2 + x3->T2 + x5->T2 + x6->T2 + x7->T2 + x8->T2 + x9->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x5->T3 + x7->T3 + x9->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 + x5->T4 + x6->T4 + x9->T4 + x0->T5 + x2->T5 + x3->T5 + x4->T5 + x5->T5 + x6->T5 + x8->T5 + x9->T5) & valuation
}

one sig PT3 extends PositiveTrace {} {
    lasso = T4->T0
    x4->T0 + x4->T1 + x8->T1 + x0->T2 + x5->T2 + x8->T2 + x0->T3 + x6->T3 + x8->T3 + x0->T4 + x6->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x5->T0 + x6->T0 + x7->T0 + x8->T0 + x9->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x5->T1 + x6->T1 + x7->T1 + x9->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x6->T2 + x7->T2 + x9->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x5->T3 + x7->T3 + x9->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 + x5->T4 + x7->T4 + x8->T4 + x9->T4) & valuation
}

one sig PT4 extends PositiveTrace {} {
    lasso = T4->T4
    x4->T0 + x4->T1 + x8->T1 + x1->T2 + x5->T2 + x8->T2 + x1->T3 + x6->T3 + x8->T3 + x1->T4 + x6->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x5->T0 + x6->T0 + x7->T0 + x8->T0 + x9->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x5->T1 + x6->T1 + x7->T1 + x9->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x6->T2 + x7->T2 + x9->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x5->T3 + x7->T3 + x9->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 + x5->T4 + x7->T4 + x8->T4 + x9->T4) & valuation
}

one sig PT5 extends PositiveTrace {} {
    lasso = T8->T0
    x4->T0 + x4->T1 + x9->T1 + x4->T2 + x4->T3 + x8->T3 + x0->T4 + x5->T4 + x8->T4 + x0->T5 + x6->T5 + x8->T5 + x0->T6 + x7->T6 + x8->T6 + x0->T7 + x2->T7 + x7->T7 + x8->T7 + x0->T8 + x2->T8 + x7->T8 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x5->T0 + x6->T0 + x7->T0 + x8->T0 + x9->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x5->T1 + x6->T1 + x7->T1 + x8->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x5->T2 + x6->T2 + x7->T2 + x8->T2 + x9->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x5->T3 + x6->T3 + x7->T3 + x9->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 + x6->T4 + x7->T4 + x9->T4 + x1->T5 + x2->T5 + x3->T5 + x4->T5 + x5->T5 + x7->T5 + x9->T5 + x1->T6 + x2->T6 + x3->T6 + x4->T6 + x5->T6 + x6->T6 + x9->T6 + x1->T7 + x3->T7 + x4->T7 + x5->T7 + x6->T7 + x9->T7 + x1->T8 + x3->T8 + x4->T8 + x5->T8 + x6->T8 + x8->T8 + x9->T8) & valuation
}

one sig PT6 extends PositiveTrace {} {
    lasso = T7->T2
    x4->T0 + x4->T1 + x9->T1 + x4->T2 + x4->T3 + x8->T3 + x0->T4 + x5->T4 + x8->T4 + x0->T5 + x6->T5 + x8->T5 + x0->T6 + x7->T6 + x8->T6 + x0->T7 + x7->T7 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x5->T0 + x6->T0 + x7->T0 + x8->T0 + x9->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x5->T1 + x6->T1 + x7->T1 + x8->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x5->T2 + x6->T2 + x7->T2 + x8->T2 + x9->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x5->T3 + x6->T3 + x7->T3 + x9->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 + x6->T4 + x7->T4 + x9->T4 + x1->T5 + x2->T5 + x3->T5 + x4->T5 + x5->T5 + x7->T5 + x9->T5 + x1->T6 + x2->T6 + x3->T6 + x4->T6 + x5->T6 + x6->T6 + x9->T6 + x1->T7 + x2->T7 + x3->T7 + x4->T7 + x5->T7 + x6->T7 + x8->T7 + x9->T7) & valuation
}

one sig PT7 extends PositiveTrace {} {
    lasso = T7->T7
    x4->T0 + x4->T1 + x9->T1 + x4->T2 + x4->T3 + x8->T3 + x1->T4 + x5->T4 + x8->T4 + x1->T5 + x6->T5 + x8->T5 + x1->T6 + x7->T6 + x8->T6 + x1->T7 + x7->T7 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x5->T0 + x6->T0 + x7->T0 + x8->T0 + x9->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x5->T1 + x6->T1 + x7->T1 + x8->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x5->T2 + x6->T2 + x7->T2 + x8->T2 + x9->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x5->T3 + x6->T3 + x7->T3 + x9->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 + x6->T4 + x7->T4 + x9->T4 + x0->T5 + x2->T5 + x3->T5 + x4->T5 + x5->T5 + x7->T5 + x9->T5 + x0->T6 + x2->T6 + x3->T6 + x4->T6 + x5->T6 + x6->T6 + x9->T6 + x0->T7 + x2->T7 + x3->T7 + x4->T7 + x5->T7 + x6->T7 + x8->T7 + x9->T7) & valuation
}

one sig PT8 extends PositiveTrace {} {
    lasso = T10->T0
    x4->T0 + x4->T1 + x9->T1 + x4->T2 + x4->T3 + x8->T3 + x0->T4 + x5->T4 + x8->T4 + x0->T5 + x6->T5 + x8->T5 + x0->T6 + x7->T6 + x8->T6 + x0->T7 + x7->T7 + x8->T7 + x0->T8 + x2->T8 + x7->T8 + x0->T9 + x2->T9 + x7->T9 + x9->T9 + x0->T10 + x2->T10 + x7->T10 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x5->T0 + x6->T0 + x7->T0 + x8->T0 + x9->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x5->T1 + x6->T1 + x7->T1 + x8->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x5->T2 + x6->T2 + x7->T2 + x8->T2 + x9->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x5->T3 + x6->T3 + x7->T3 + x9->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 + x6->T4 + x7->T4 + x9->T4 + x1->T5 + x2->T5 + x3->T5 + x4->T5 + x5->T5 + x7->T5 + x9->T5 + x1->T6 + x2->T6 + x3->T6 + x4->T6 + x5->T6 + x6->T6 + x9->T6 + x1->T7 + x2->T7 + x3->T7 + x4->T7 + x5->T7 + x6->T7 + x9->T7 + x1->T8 + x3->T8 + x4->T8 + x5->T8 + x6->T8 + x8->T8 + x9->T8 + x1->T9 + x3->T9 + x4->T9 + x5->T9 + x6->T9 + x8->T9 + x1->T10 + x3->T10 + x4->T10 + x5->T10 + x6->T10 + x8->T10 + x9->T10) & valuation
}

one sig PT9 extends PositiveTrace {} {
    lasso = T10->T5
    x4->T0 + x4->T1 + x9->T1 + x4->T2 + x4->T3 + x8->T3 + x1->T4 + x5->T4 + x8->T4 + x1->T5 + x6->T5 + x8->T5 + x1->T6 + x7->T6 + x8->T6 + x1->T7 + x7->T7 + x8->T7 + x1->T8 + x3->T8 + x7->T8 + x1->T9 + x3->T9 + x7->T9 + x9->T9 + x1->T10 + x3->T10 + x7->T10 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x5->T0 + x6->T0 + x7->T0 + x8->T0 + x9->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x5->T1 + x6->T1 + x7->T1 + x8->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x5->T2 + x6->T2 + x7->T2 + x8->T2 + x9->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x5->T3 + x6->T3 + x7->T3 + x9->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 + x6->T4 + x7->T4 + x9->T4 + x0->T5 + x2->T5 + x3->T5 + x4->T5 + x5->T5 + x7->T5 + x9->T5 + x0->T6 + x2->T6 + x3->T6 + x4->T6 + x5->T6 + x6->T6 + x9->T6 + x0->T7 + x2->T7 + x3->T7 + x4->T7 + x5->T7 + x6->T7 + x9->T7 + x0->T8 + x2->T8 + x4->T8 + x5->T8 + x6->T8 + x8->T8 + x9->T8 + x0->T9 + x2->T9 + x4->T9 + x5->T9 + x6->T9 + x8->T9 + x0->T10 + x2->T10 + x4->T10 + x5->T10 + x6->T10 + x8->T10 + x9->T10) & valuation
}


one sig NT0 extends NegativeTrace {} {
    lasso = T10->T0
    x4->T0 + x4->T1 + x8->T1 + x1->T2 + x5->T2 + x8->T2 + x1->T3 + x6->T3 + x8->T3 + x1->T4 + x6->T4 + x1->T5 + x6->T5 + x9->T5 + x0->T6 + x5->T6 + x9->T6 + x0->T7 + x6->T7 + x9->T7 + x0->T8 + x7->T8 + x9->T8 + x0->T9 + x2->T9 + x7->T9 + x9->T9 + x0->T10 + x2->T10 + x7->T10 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x5->T0 + x6->T0 + x7->T0 + x8->T0 + x9->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x5->T1 + x6->T1 + x7->T1 + x9->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x6->T2 + x7->T2 + x9->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x5->T3 + x7->T3 + x9->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 + x5->T4 + x7->T4 + x8->T4 + x9->T4 + x0->T5 + x2->T5 + x3->T5 + x4->T5 + x5->T5 + x7->T5 + x8->T5 + x1->T6 + x2->T6 + x3->T6 + x4->T6 + x6->T6 + x7->T6 + x8->T6 + x1->T7 + x2->T7 + x3->T7 + x4->T7 + x5->T7 + x7->T7 + x8->T7 + x1->T8 + x2->T8 + x3->T8 + x4->T8 + x5->T8 + x6->T8 + x8->T8 + x1->T9 + x3->T9 + x4->T9 + x5->T9 + x6->T9 + x8->T9 + x1->T10 + x3->T10 + x4->T10 + x5->T10 + x6->T10 + x8->T10 + x9->T10) & valuation
}

one sig NT1 extends NegativeTrace {} {
    lasso = T10->T9
    x4->T0 + x4->T1 + x8->T1 + x0->T2 + x5->T2 + x8->T2 + x0->T3 + x6->T3 + x8->T3 + x0->T4 + x6->T4 + x0->T5 + x6->T5 + x9->T5 + x1->T6 + x5->T6 + x9->T6 + x1->T7 + x6->T7 + x9->T7 + x1->T8 + x7->T8 + x9->T8 + x1->T9 + x3->T9 + x7->T9 + x9->T9 + x1->T10 + x3->T10 + x7->T10 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x5->T0 + x6->T0 + x7->T0 + x8->T0 + x9->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x5->T1 + x6->T1 + x7->T1 + x9->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x6->T2 + x7->T2 + x9->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x5->T3 + x7->T3 + x9->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 + x5->T4 + x7->T4 + x8->T4 + x9->T4 + x1->T5 + x2->T5 + x3->T5 + x4->T5 + x5->T5 + x7->T5 + x8->T5 + x0->T6 + x2->T6 + x3->T6 + x4->T6 + x6->T6 + x7->T6 + x8->T6 + x0->T7 + x2->T7 + x3->T7 + x4->T7 + x5->T7 + x7->T7 + x8->T7 + x0->T8 + x2->T8 + x3->T8 + x4->T8 + x5->T8 + x6->T8 + x8->T8 + x0->T9 + x2->T9 + x4->T9 + x5->T9 + x6->T9 + x8->T9 + x0->T10 + x2->T10 + x4->T10 + x5->T10 + x6->T10 + x8->T10 + x9->T10) & valuation
}

one sig NT2 extends NegativeTrace {} {
    lasso = T15->T7
    x4->T0 + x4->T1 + x9->T1 + x4->T2 + x4->T3 + x8->T3 + x1->T4 + x5->T4 + x8->T4 + x1->T5 + x6->T5 + x8->T5 + x1->T6 + x7->T6 + x8->T6 + x1->T7 + x7->T7 + x1->T8 + x7->T8 + x9->T8 + x1->T9 + x6->T9 + x1->T10 + x6->T10 + x0->T11 + x5->T11 + x9->T11 + x0->T12 + x6->T12 + x9->T12 + x0->T13 + x7->T13 + x9->T13 + x0->T14 + x2->T14 + x7->T14 + x9->T14 + x0->T15 + x2->T15 + x7->T15 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x5->T0 + x6->T0 + x7->T0 + x8->T0 + x9->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x5->T1 + x6->T1 + x7->T1 + x8->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x5->T2 + x6->T2 + x7->T2 + x8->T2 + x9->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x5->T3 + x6->T3 + x7->T3 + x9->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 + x6->T4 + x7->T4 + x9->T4 + x0->T5 + x2->T5 + x3->T5 + x4->T5 + x5->T5 + x7->T5 + x9->T5 + x0->T6 + x2->T6 + x3->T6 + x4->T6 + x5->T6 + x6->T6 + x9->T6 + x0->T7 + x2->T7 + x3->T7 + x4->T7 + x5->T7 + x6->T7 + x8->T7 + x9->T7 + x0->T8 + x2->T8 + x3->T8 + x4->T8 + x5->T8 + x6->T8 + x8->T8 + x0->T9 + x2->T9 + x3->T9 + x4->T9 + x5->T9 + x7->T9 + x8->T9 + x9->T9 + x0->T10 + x2->T10 + x3->T10 + x4->T10 + x5->T10 + x7->T10 + x8->T10 + x9->T10 + x1->T11 + x2->T11 + x3->T11 + x4->T11 + x6->T11 + x7->T11 + x8->T11 + x1->T12 + x2->T12 + x3->T12 + x4->T12 + x5->T12 + x7->T12 + x8->T12 + x1->T13 + x2->T13 + x3->T13 + x4->T13 + x5->T13 + x6->T13 + x8->T13 + x1->T14 + x3->T14 + x4->T14 + x5->T14 + x6->T14 + x8->T14 + x1->T15 + x3->T15 + x4->T15 + x5->T15 + x6->T15 + x8->T15 + x9->T15) & valuation
}

one sig LearnedLTL {
    Root: DAGNode
}
fun root: one DAGNode { LearnedLTL.Root }
fun childrenOf[n: DAGNode]: set DAGNode { n.^(l+r) }
fun childrenAndSelfOf[n: DAGNode]: set DAGNode { n.*(l+r) }
fun ancestorsOf[n: DAGNode]: set DAGNode { n.~^(l+r) }
fun ancestorsAndSelfOf[n: DAGNode]: set DAGNode { n.~*(l+r) }
fun subDAG[n: DAGNode]: DAGNode -> DAGNode { n.*(l+r) <: (l+r) }

fact {
    root in G
    all n: Neg | n.l in Literal  
}

fun experimentReach: set DAGNode { childrenAndSelfOf[root] }
fun experimentKept: DAGNode -> DAGNode { (none->none) & subDAG[root] }
one sig ExperimentCost { used: set DAGNode }
fact { ExperimentCost.used = experimentReach }
fact ExperimentBounds {
  DAGNode = experimentReach + Literal + (none)
  #experimentReach <= 5
  #(experimentReach & (And + Or + Imply)) <= 2
  minsome ExperimentCost.used
}
run {
    all t: PositiveTrace | root->T0 in t.valuation
    all t: NegativeTrace | root->T0 not in t.valuation
    
} for 15 DAGNode, 5 Int
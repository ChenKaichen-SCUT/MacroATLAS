abstract sig Unit {}
one sig U0, U1, U2, U3, U4 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15 extends Label {}
abstract sig Q {}
one sig Q0, Q1, Q2, Q3 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E26, E27, E28, E29, E30, E31, E32, E33, E34, E35, E36, E37, E38, E39, E40, E41, E42, E43, E44, E45, E46, E47, E48, E49, E50, E51, E52, E53, E54, E55, E56, E57, E58, E59, E60, E61, E62, E63, E64, E65, E66, E67, E68 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4, P5, P6, P7, P8, P9, P10 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos }
one sig A0, A1, A2, A3, A4 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (((T0 + T1) + (T2 + (T3 + T4))) + ((T5 + T6) + (T7 + (T8 + T9)))) }
fun un: set Label { (T10 + (T11 + T12)) }
fun bin: set Label { (T13 + (T14 + T15)) }
fun nonempty: set Fiber { ((((((E1 + E2) + (E3 + E4)) + ((E5 + E6) + (E7 + E8))) + (((E9 + E10) + (E11 + E12)) + ((E13 + E14) + (E15 + E16)))) + ((((E17 + E18) + (E19 + E20)) + ((E21 + E22) + (E23 + E25))) + (((E26 + E27) + (E28 + E29)) + ((E30 + E31) + (E32 + E33))))) + (((((E34 + E35) + (E36 + E37)) + ((E38 + E39) + (E40 + E42))) + (((E43 + E44) + (E45 + E46)) + ((E47 + E48) + (E49 + E50)))) + ((((E51 + E52) + (E53 + E54)) + ((E55 + E56) + (E57 + E59))) + (((E60 + E61) + (E62 + E63)) + ((E64 + E65) + (E66 + (E67 + E68))))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { ((U0->U1 + U1->U2) + (U2->U3 + U3->U4)) }
fun carrierNext: Carrier -> Carrier { ((((A0->A1 + A1->A2) + (A2->A3 + (A3->A4 + A4->R))) + ((R->C0 + C0->L0) + (L0->D0 + (D0->C1 + C1->L1)))) + (((L1->D1 + D1->C2) + (C2->L2 + (L2->D2 + D2->C3))) + ((C3->L3 + L3->D3) + (D3->C4 + (C4->L4 + L4->D4))))) }
fun child[a: Anchor]: set Port { a.(((A0->C0 + A1->C1) + (A2->C2 + (A3->C3 + A4->C4)))) }
fun left[a: Anchor]: set Port { a.(((A0->L0 + A1->L1) + (A2->L2 + (A3->L3 + A4->L4)))) }
fun right[a: Anchor]: set Port { a.(((A0->D0 + A1->D1) + (A2->D2 + (A3->D3 + A4->D4)))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
no iden & ^graph
active = R.target.*graph
R.fiber not in nonempty
R.target.lab = T12
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
no A3.graph & (((A0 + A1) + (A2 + A3)))
no A4.graph & (((A0 + A1) + (A2 + (A3 + A4))))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
lone lab.T2
lone lab.T3
lone lab.T4
lone lab.T5
lone lab.T6
lone lab.T7
lone lab.T8
lone lab.T9
some A0.lab and A0.lab in un and R.target != A0 implies #(target.A0) > 1
some A1.lab and A1.lab in un and R.target != A1 implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un and R.target != A2 implies #(target.A2) > 1
some A2.lab implies some A1.lab
some A3.lab and A3.lab in un and R.target != A3 implies #(target.A3) > 1
some A3.lab implies some A2.lab
some A4.lab and A4.lab in un and R.target != A4 implies #(target.A4) > 1
some A4.lab implies some A3.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q3
E2.qi = Q0
E2.qo = Q1
E3.qi = Q0
E3.qo = Q3
E4.qi = Q0
E4.qo = Q1
E5.qi = Q0
E5.qo = Q3
E6.qi = Q0
E6.qo = Q1
E7.qi = Q0
E7.qo = Q3
E8.qi = Q0
E8.qo = Q2
E9.qi = Q0
E9.qo = Q3
E10.qi = Q0
E10.qo = Q2
E11.qi = Q0
E11.qo = Q3
E12.qi = Q0
E12.qo = Q1
E13.qi = Q0
E13.qo = Q2
E14.qi = Q0
E14.qo = Q3
E15.qi = Q0
E15.qo = Q1
E16.qi = Q0
E16.qo = Q2
E17.qi = Q0
E17.qo = Q3
E18.qi = Q0
E18.qo = Q1
E19.qi = Q0
E19.qo = Q2
E20.qi = Q0
E20.qo = Q3
E21.qi = Q0
E21.qo = Q1
E22.qi = Q0
E22.qo = Q2
E23.qi = Q0
E23.qo = Q3
E24.qi = Q1
E24.qo = Q1
E25.qi = Q1
E25.qo = Q3
E26.qi = Q1
E26.qo = Q3
E27.qi = Q1
E27.qo = Q1
E28.qi = Q1
E28.qo = Q3
E29.qi = Q1
E29.qo = Q3
E30.qi = Q1
E30.qo = Q2
E31.qi = Q1
E31.qo = Q3
E32.qi = Q1
E32.qo = Q3
E33.qi = Q1
E33.qo = Q1
E34.qi = Q1
E34.qo = Q2
E35.qi = Q1
E35.qo = Q3
E36.qi = Q1
E36.qo = Q3
E37.qi = Q1
E37.qo = Q1
E38.qi = Q1
E38.qo = Q2
E39.qi = Q1
E39.qo = Q3
E40.qi = Q1
E40.qo = Q3
E41.qi = Q2
E41.qo = Q2
E42.qi = Q2
E42.qo = Q3
E43.qi = Q2
E43.qo = Q3
E44.qi = Q2
E44.qo = Q1
E45.qi = Q2
E45.qo = Q3
E46.qi = Q2
E46.qo = Q3
E47.qi = Q2
E47.qo = Q2
E48.qi = Q2
E48.qo = Q3
E49.qi = Q2
E49.qo = Q3
E50.qi = Q2
E50.qo = Q1
E51.qi = Q2
E51.qo = Q2
E52.qi = Q2
E52.qo = Q3
E53.qi = Q2
E53.qo = Q3
E54.qi = Q2
E54.qo = Q1
E55.qi = Q2
E55.qo = Q2
E56.qi = Q2
E56.qo = Q3
E57.qi = Q2
E57.qo = Q3
E58.qi = Q3
E58.qo = Q3
E59.qi = Q3
E59.qo = Q3
E60.qi = Q3
E60.qo = Q3
E61.qi = Q3
E61.qo = Q3
E62.qi = Q3
E62.qo = Q3
E63.qi = Q3
E63.qo = Q3
E64.qi = Q3
E64.qo = Q3
E65.qi = Q3
E65.qo = Q3
E66.qi = Q3
E66.qo = Q3
E67.qi = Q3
E67.qo = Q3
E68.qi = Q3
E68.qo = Q3
all e: used | e.fiber in (((E0 + E24) + (E41 + E58))) implies #e.cost = 0
all e: used | e.fiber in (((((E1 + E6) + (E7 + (E10 + E11))) + ((E12 + (E19 + E25)) + (E29 + (E32 + E33)))) + (((E38 + E42) + (E46 + (E49 + E50))) + ((E55 + (E59 + E62)) + (E64 + (E65 + E67)))))) implies #e.cost = 2
all e: used | e.fiber in ((((E2 + (E4 + E8)) + (E26 + (E27 + E30))) + ((E43 + (E44 + E47)) + (E60 + (E61 + E63))))) implies #e.cost = 1
all e: used | e.fiber in (((((E3 + E5) + (E9 + (E13 + E15))) + ((E17 + (E18 + E22)) + (E23 + (E28 + E31)))) + (((E34 + (E36 + E37)) + (E40 + (E45 + E48))) + ((E51 + (E53 + E54)) + (E57 + (E66 + E68)))))) implies #e.cost = 3
all e: used | e.fiber in ((((E14 + E16) + (E20 + E21)) + ((E35 + E39) + (E52 + E56)))) implies #e.cost = 4
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q2)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 implies a.state = Q0
all a: active | a.lab = T3 implies a.state = Q0
all a: active | a.lab = T4 implies a.state = Q0
all a: active | a.lab = T5 implies a.state = Q0
all a: active | a.lab = T6 implies a.state = Q0
all a: active | a.lab = T7 implies a.state = Q0
all a: active | a.lab = T8 implies a.state = Q0
all a: active | a.lab = T9 implies a.state = Q0
all a: active | a.lab = T10 and child[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T10 and child[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T10 and child[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T10 and child[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T11 and child[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T11 and child[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T11 and child[a].fiber.qo = Q2 implies a.state = Q1
all a: active | a.lab = T11 and child[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T12 and child[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T12 and child[a].fiber.qo = Q1 implies a.state = Q2
all a: active | a.lab = T12 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T12 and child[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T13 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T13 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T13 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q1
all a: active | a.lab = T13 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T13 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T13 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T13 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q1
all a: active | a.lab = T13 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T13 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T13 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T13 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q1
all a: active | a.lab = T13 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T13 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q3
all a: active | a.lab = T13 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T13 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T13 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T14 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T14 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T14 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q1
all a: active | a.lab = T14 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T14 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T14 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T14 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q1
all a: active | a.lab = T14 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T14 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T14 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T14 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q1
all a: active | a.lab = T14 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T14 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q3
all a: active | a.lab = T14 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T14 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T14 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T15 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T15 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T15 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q1
all a: active | a.lab = T15 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T15 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T15 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T15 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q1
all a: active | a.lab = T15 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T15 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T15 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T15 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q1
all a: active | a.lab = T15 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q3
all a: active | a.lab = T15 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q3
all a: active | a.lab = T15 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T15 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T15 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q3
}
fun range0: set Pos { ((P0 + (P1 + P2)) + (P3 + (P4 + P5))) }
fun loop0: set Pos { ((P0 + (P1 + P2)) + (P3 + (P4 + P5))) }
fun next0: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P0))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in ((((E0 + E1) + (E24 + E25)) + ((E41 + E42) + (E58 + E59)))) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E3) + (E26 + (E43 + E60)))) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in (((E4 + (E5 + E27)) + ((E28 + E44) + (E45 + E61)))) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in (((E6 + E7) + (E29 + (E46 + E62)))) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (((E8 + (E9 + E30)) + ((E31 + E47) + (E48 + E63)))) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in (((E10 + E11) + (E32 + (E49 + E64)))) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all e: used | e.fiber in ((((E12 + E13) + (E14 + (E33 + E34))) + ((E35 + E50) + (E51 + (E52 + E65))))) implies e.ev = {i: range0 | loop0 in (e.target.av)}
all e: used | e.fiber in (((E15 + (E16 + E17)) + (E36 + (E53 + E66)))) implies e.ev = {i: range0 | loop0 in (range0 - e.target.av)}
all e: used | e.fiber in ((((E18 + E19) + (E20 + (E37 + E38))) + ((E39 + E54) + (E55 + (E56 + E67))))) implies e.ev = {i: range0 | some (loop0 & (e.target.av))}
all e: used | e.fiber in (((E21 + (E22 + E23)) + (E40 + (E57 + E68)))) implies e.ev = {i: range0 | some (loop0 & (range0 - e.target.av))}
all a: active | a.lab = T10 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T11 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T12 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T13 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T14 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T15 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { ((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) }
fun loop1: set Pos { ((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) }
fun next1: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P0))) }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { ((P0->P0 + (P1->P1 + P2->P2)) + ((P3->P3 + P4->P4) + (P5->P5 + P6->P6))) }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in ((((E0 + E1) + (E24 + E25)) + ((E41 + E42) + (E58 + E59)))) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E3) + (E26 + (E43 + E60)))) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in (((E4 + (E5 + E27)) + ((E28 + E44) + (E45 + E61)))) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in (((E6 + E7) + (E29 + (E46 + E62)))) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (((E8 + (E9 + E30)) + ((E31 + E47) + (E48 + E63)))) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in (((E10 + E11) + (E32 + (E49 + E64)))) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all e: used | e.fiber in ((((E12 + E13) + (E14 + (E33 + E34))) + ((E35 + E50) + (E51 + (E52 + E65))))) implies e.ev = {i: range1 | loop1 in (e.target.av)}
all e: used | e.fiber in (((E15 + (E16 + E17)) + (E36 + (E53 + E66)))) implies e.ev = {i: range1 | loop1 in (range1 - e.target.av)}
all e: used | e.fiber in ((((E18 + E19) + (E20 + (E37 + E38))) + ((E39 + E54) + (E55 + (E56 + E67))))) implies e.ev = {i: range1 | some (loop1 & (e.target.av))}
all e: used | e.fiber in (((E21 + (E22 + E23)) + (E40 + (E57 + E68)))) implies e.ev = {i: range1 | some (loop1 & (range1 - e.target.av))}
all a: active | a.lab = T10 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T11 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T12 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T13 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T14 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T15 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fun range2: set Pos { ((P0 + (P1 + P2)) + (P3 + (P4 + P5))) }
fun loop2: set Pos { P5 }
fun next2: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P5))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in ((((E0 + E1) + (E24 + E25)) + ((E41 + E42) + (E58 + E59)))) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E3) + (E26 + (E43 + E60)))) implies e.ev = {i: range2 | (i.shift2_0) in (range2 - e.target.av)}
all e: used | e.fiber in (((E4 + (E5 + E27)) + ((E28 + E44) + (E45 + E61)))) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (e.target.av))}
all e: used | e.fiber in (((E6 + E7) + (E29 + (E46 + E62)))) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (((E8 + (E9 + E30)) + ((E31 + E47) + (E48 + E63)))) implies e.ev = {i: range2 | (i.shift2_0).future2 in (e.target.av)}
all e: used | e.fiber in (((E10 + E11) + (E32 + (E49 + E64)))) implies e.ev = {i: range2 | (i.shift2_0).future2 in (range2 - e.target.av)}
all e: used | e.fiber in ((((E12 + E13) + (E14 + (E33 + E34))) + ((E35 + E50) + (E51 + (E52 + E65))))) implies e.ev = {i: range2 | loop2 in (e.target.av)}
all e: used | e.fiber in (((E15 + (E16 + E17)) + (E36 + (E53 + E66)))) implies e.ev = {i: range2 | loop2 in (range2 - e.target.av)}
all e: used | e.fiber in ((((E18 + E19) + (E20 + (E37 + E38))) + ((E39 + E54) + (E55 + (E56 + E67))))) implies e.ev = {i: range2 | some (loop2 & (e.target.av))}
all e: used | e.fiber in (((E21 + (E22 + E23)) + (E40 + (E57 + E68)))) implies e.ev = {i: range2 | some (loop2 & (range2 - e.target.av))}
all a: active | a.lab = T10 implies a.av = (range2 - child[a].ev)
all a: active | a.lab = T11 implies a.av = ({i: range2 | some (i.future2 & child[a].ev)})
all a: active | a.lab = T12 implies a.av = ({i: range2 | i.future2 in child[a].ev})
all a: active | a.lab = T13 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T14 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T15 implies a.av = ((range2 - left[a].ev) + right[a].ev)
}
fun range3: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop3: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun next3: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in ((((E0 + E1) + (E24 + E25)) + ((E41 + E42) + (E58 + E59)))) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E3) + (E26 + (E43 + E60)))) implies e.ev = {i: range3 | (i.shift3_0) in (range3 - e.target.av)}
all e: used | e.fiber in (((E4 + (E5 + E27)) + ((E28 + E44) + (E45 + E61)))) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (e.target.av))}
all e: used | e.fiber in (((E6 + E7) + (E29 + (E46 + E62)))) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (((E8 + (E9 + E30)) + ((E31 + E47) + (E48 + E63)))) implies e.ev = {i: range3 | (i.shift3_0).future3 in (e.target.av)}
all e: used | e.fiber in (((E10 + E11) + (E32 + (E49 + E64)))) implies e.ev = {i: range3 | (i.shift3_0).future3 in (range3 - e.target.av)}
all e: used | e.fiber in ((((E12 + E13) + (E14 + (E33 + E34))) + ((E35 + E50) + (E51 + (E52 + E65))))) implies e.ev = {i: range3 | loop3 in (e.target.av)}
all e: used | e.fiber in (((E15 + (E16 + E17)) + (E36 + (E53 + E66)))) implies e.ev = {i: range3 | loop3 in (range3 - e.target.av)}
all e: used | e.fiber in ((((E18 + E19) + (E20 + (E37 + E38))) + ((E39 + E54) + (E55 + (E56 + E67))))) implies e.ev = {i: range3 | some (loop3 & (e.target.av))}
all e: used | e.fiber in (((E21 + (E22 + E23)) + (E40 + (E57 + E68)))) implies e.ev = {i: range3 | some (loop3 & (range3 - e.target.av))}
all a: active | a.lab = T10 implies a.av = (range3 - child[a].ev)
all a: active | a.lab = T11 implies a.av = ({i: range3 | some (i.future3 & child[a].ev)})
all a: active | a.lab = T12 implies a.av = ({i: range3 | i.future3 in child[a].ev})
all a: active | a.lab = T13 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T14 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T15 implies a.av = ((range3 - left[a].ev) + right[a].ev)
}
fun range4: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop4: set Pos { P4 }
fun next4: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in ((((E0 + E1) + (E24 + E25)) + ((E41 + E42) + (E58 + E59)))) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E3) + (E26 + (E43 + E60)))) implies e.ev = {i: range4 | (i.shift4_0) in (range4 - e.target.av)}
all e: used | e.fiber in (((E4 + (E5 + E27)) + ((E28 + E44) + (E45 + E61)))) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (e.target.av))}
all e: used | e.fiber in (((E6 + E7) + (E29 + (E46 + E62)))) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (((E8 + (E9 + E30)) + ((E31 + E47) + (E48 + E63)))) implies e.ev = {i: range4 | (i.shift4_0).future4 in (e.target.av)}
all e: used | e.fiber in (((E10 + E11) + (E32 + (E49 + E64)))) implies e.ev = {i: range4 | (i.shift4_0).future4 in (range4 - e.target.av)}
all e: used | e.fiber in ((((E12 + E13) + (E14 + (E33 + E34))) + ((E35 + E50) + (E51 + (E52 + E65))))) implies e.ev = {i: range4 | loop4 in (e.target.av)}
all e: used | e.fiber in (((E15 + (E16 + E17)) + (E36 + (E53 + E66)))) implies e.ev = {i: range4 | loop4 in (range4 - e.target.av)}
all e: used | e.fiber in ((((E18 + E19) + (E20 + (E37 + E38))) + ((E39 + E54) + (E55 + (E56 + E67))))) implies e.ev = {i: range4 | some (loop4 & (e.target.av))}
all e: used | e.fiber in (((E21 + (E22 + E23)) + (E40 + (E57 + E68)))) implies e.ev = {i: range4 | some (loop4 & (range4 - e.target.av))}
all a: active | a.lab = T10 implies a.av = (range4 - child[a].ev)
all a: active | a.lab = T11 implies a.av = ({i: range4 | some (i.future4 & child[a].ev)})
all a: active | a.lab = T12 implies a.av = ({i: range4 | i.future4 in child[a].ev})
all a: active | a.lab = T13 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T14 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T15 implies a.av = ((range4 - left[a].ev) + right[a].ev)
}
fun range5: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop5: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun next5: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P0)))) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in ((((E0 + E1) + (E24 + E25)) + ((E41 + E42) + (E58 + E59)))) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E3) + (E26 + (E43 + E60)))) implies e.ev = {i: range5 | (i.shift5_0) in (range5 - e.target.av)}
all e: used | e.fiber in (((E4 + (E5 + E27)) + ((E28 + E44) + (E45 + E61)))) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (e.target.av))}
all e: used | e.fiber in (((E6 + E7) + (E29 + (E46 + E62)))) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (((E8 + (E9 + E30)) + ((E31 + E47) + (E48 + E63)))) implies e.ev = {i: range5 | (i.shift5_0).future5 in (e.target.av)}
all e: used | e.fiber in (((E10 + E11) + (E32 + (E49 + E64)))) implies e.ev = {i: range5 | (i.shift5_0).future5 in (range5 - e.target.av)}
all e: used | e.fiber in ((((E12 + E13) + (E14 + (E33 + E34))) + ((E35 + E50) + (E51 + (E52 + E65))))) implies e.ev = {i: range5 | loop5 in (e.target.av)}
all e: used | e.fiber in (((E15 + (E16 + E17)) + (E36 + (E53 + E66)))) implies e.ev = {i: range5 | loop5 in (range5 - e.target.av)}
all e: used | e.fiber in ((((E18 + E19) + (E20 + (E37 + E38))) + ((E39 + E54) + (E55 + (E56 + E67))))) implies e.ev = {i: range5 | some (loop5 & (e.target.av))}
all e: used | e.fiber in (((E21 + (E22 + E23)) + (E40 + (E57 + E68)))) implies e.ev = {i: range5 | some (loop5 & (range5 - e.target.av))}
all a: active | a.lab = T10 implies a.av = (range5 - child[a].ev)
all a: active | a.lab = T11 implies a.av = ({i: range5 | some (i.future5 & child[a].ev)})
all a: active | a.lab = T12 implies a.av = ({i: range5 | i.future5 in child[a].ev})
all a: active | a.lab = T13 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T14 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T15 implies a.av = ((range5 - left[a].ev) + right[a].ev)
}
fun range6: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) }
fun loop6: set Pos { ((P2 + (P3 + P4)) + (P5 + (P6 + P7))) }
fun next6: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P2))) }
fun future6: Pos -> Pos { (*next6) & (range6->range6) }
fun shift6_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) }
pred semantics6[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range6
ev in used->range6
all e: used | e.fiber in ((((E0 + E1) + (E24 + E25)) + ((E41 + E42) + (E58 + E59)))) implies e.ev = {i: range6 | (i.shift6_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E3) + (E26 + (E43 + E60)))) implies e.ev = {i: range6 | (i.shift6_0) in (range6 - e.target.av)}
all e: used | e.fiber in (((E4 + (E5 + E27)) + ((E28 + E44) + (E45 + E61)))) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (e.target.av))}
all e: used | e.fiber in (((E6 + E7) + (E29 + (E46 + E62)))) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (((E8 + (E9 + E30)) + ((E31 + E47) + (E48 + E63)))) implies e.ev = {i: range6 | (i.shift6_0).future6 in (e.target.av)}
all e: used | e.fiber in (((E10 + E11) + (E32 + (E49 + E64)))) implies e.ev = {i: range6 | (i.shift6_0).future6 in (range6 - e.target.av)}
all e: used | e.fiber in ((((E12 + E13) + (E14 + (E33 + E34))) + ((E35 + E50) + (E51 + (E52 + E65))))) implies e.ev = {i: range6 | loop6 in (e.target.av)}
all e: used | e.fiber in (((E15 + (E16 + E17)) + (E36 + (E53 + E66)))) implies e.ev = {i: range6 | loop6 in (range6 - e.target.av)}
all e: used | e.fiber in ((((E18 + E19) + (E20 + (E37 + E38))) + ((E39 + E54) + (E55 + (E56 + E67))))) implies e.ev = {i: range6 | some (loop6 & (e.target.av))}
all e: used | e.fiber in (((E21 + (E22 + E23)) + (E40 + (E57 + E68)))) implies e.ev = {i: range6 | some (loop6 & (range6 - e.target.av))}
all a: active | a.lab = T10 implies a.av = (range6 - child[a].ev)
all a: active | a.lab = T11 implies a.av = ({i: range6 | some (i.future6 & child[a].ev)})
all a: active | a.lab = T12 implies a.av = ({i: range6 | i.future6 in child[a].ev})
all a: active | a.lab = T13 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T14 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T15 implies a.av = ((range6 - left[a].ev) + right[a].ev)
}
fun range7: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) }
fun loop7: set Pos { P7 }
fun next7: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P7))) }
fun future7: Pos -> Pos { (*next7) & (range7->range7) }
fun shift7_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) }
pred semantics7[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range7
ev in used->range7
all e: used | e.fiber in ((((E0 + E1) + (E24 + E25)) + ((E41 + E42) + (E58 + E59)))) implies e.ev = {i: range7 | (i.shift7_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E3) + (E26 + (E43 + E60)))) implies e.ev = {i: range7 | (i.shift7_0) in (range7 - e.target.av)}
all e: used | e.fiber in (((E4 + (E5 + E27)) + ((E28 + E44) + (E45 + E61)))) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (e.target.av))}
all e: used | e.fiber in (((E6 + E7) + (E29 + (E46 + E62)))) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (((E8 + (E9 + E30)) + ((E31 + E47) + (E48 + E63)))) implies e.ev = {i: range7 | (i.shift7_0).future7 in (e.target.av)}
all e: used | e.fiber in (((E10 + E11) + (E32 + (E49 + E64)))) implies e.ev = {i: range7 | (i.shift7_0).future7 in (range7 - e.target.av)}
all e: used | e.fiber in ((((E12 + E13) + (E14 + (E33 + E34))) + ((E35 + E50) + (E51 + (E52 + E65))))) implies e.ev = {i: range7 | loop7 in (e.target.av)}
all e: used | e.fiber in (((E15 + (E16 + E17)) + (E36 + (E53 + E66)))) implies e.ev = {i: range7 | loop7 in (range7 - e.target.av)}
all e: used | e.fiber in ((((E18 + E19) + (E20 + (E37 + E38))) + ((E39 + E54) + (E55 + (E56 + E67))))) implies e.ev = {i: range7 | some (loop7 & (e.target.av))}
all e: used | e.fiber in (((E21 + (E22 + E23)) + (E40 + (E57 + E68)))) implies e.ev = {i: range7 | some (loop7 & (range7 - e.target.av))}
all a: active | a.lab = T10 implies a.av = (range7 - child[a].ev)
all a: active | a.lab = T11 implies a.av = ({i: range7 | some (i.future7 & child[a].ev)})
all a: active | a.lab = T12 implies a.av = ({i: range7 | i.future7 in child[a].ev})
all a: active | a.lab = T13 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T14 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T15 implies a.av = ((range7 - left[a].ev) + right[a].ev)
}
fun range8: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + (P6 + P7)) + (P8 + (P9 + P10)))) }
fun loop8: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + (P6 + P7)) + (P8 + (P9 + P10)))) }
fun next8: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + (P6->P7 + P7->P8)) + (P8->P9 + (P9->P10 + P10->P0)))) }
fun future8: Pos -> Pos { (*next8) & (range8->range8) }
fun shift8_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + (P6->P6 + P7->P7)) + (P8->P8 + (P9->P9 + P10->P10)))) }
pred semantics8[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range8
ev in used->range8
all e: used | e.fiber in ((((E0 + E1) + (E24 + E25)) + ((E41 + E42) + (E58 + E59)))) implies e.ev = {i: range8 | (i.shift8_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E3) + (E26 + (E43 + E60)))) implies e.ev = {i: range8 | (i.shift8_0) in (range8 - e.target.av)}
all e: used | e.fiber in (((E4 + (E5 + E27)) + ((E28 + E44) + (E45 + E61)))) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (e.target.av))}
all e: used | e.fiber in (((E6 + E7) + (E29 + (E46 + E62)))) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (((E8 + (E9 + E30)) + ((E31 + E47) + (E48 + E63)))) implies e.ev = {i: range8 | (i.shift8_0).future8 in (e.target.av)}
all e: used | e.fiber in (((E10 + E11) + (E32 + (E49 + E64)))) implies e.ev = {i: range8 | (i.shift8_0).future8 in (range8 - e.target.av)}
all e: used | e.fiber in ((((E12 + E13) + (E14 + (E33 + E34))) + ((E35 + E50) + (E51 + (E52 + E65))))) implies e.ev = {i: range8 | loop8 in (e.target.av)}
all e: used | e.fiber in (((E15 + (E16 + E17)) + (E36 + (E53 + E66)))) implies e.ev = {i: range8 | loop8 in (range8 - e.target.av)}
all e: used | e.fiber in ((((E18 + E19) + (E20 + (E37 + E38))) + ((E39 + E54) + (E55 + (E56 + E67))))) implies e.ev = {i: range8 | some (loop8 & (e.target.av))}
all e: used | e.fiber in (((E21 + (E22 + E23)) + (E40 + (E57 + E68)))) implies e.ev = {i: range8 | some (loop8 & (range8 - e.target.av))}
all a: active | a.lab = T10 implies a.av = (range8 - child[a].ev)
all a: active | a.lab = T11 implies a.av = ({i: range8 | some (i.future8 & child[a].ev)})
all a: active | a.lab = T12 implies a.av = ({i: range8 | i.future8 in child[a].ev})
all a: active | a.lab = T13 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T14 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T15 implies a.av = ((range8 - left[a].ev) + right[a].ev)
}
fun range9: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + (P6 + P7)) + (P8 + (P9 + P10)))) }
fun loop9: set Pos { ((P5 + (P6 + P7)) + (P8 + (P9 + P10))) }
fun next9: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + (P6->P7 + P7->P8)) + (P8->P9 + (P9->P10 + P10->P5)))) }
fun future9: Pos -> Pos { (*next9) & (range9->range9) }
fun shift9_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + (P6->P6 + P7->P7)) + (P8->P8 + (P9->P9 + P10->P10)))) }
pred semantics9[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range9
ev in used->range9
all e: used | e.fiber in ((((E0 + E1) + (E24 + E25)) + ((E41 + E42) + (E58 + E59)))) implies e.ev = {i: range9 | (i.shift9_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E3) + (E26 + (E43 + E60)))) implies e.ev = {i: range9 | (i.shift9_0) in (range9 - e.target.av)}
all e: used | e.fiber in (((E4 + (E5 + E27)) + ((E28 + E44) + (E45 + E61)))) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (e.target.av))}
all e: used | e.fiber in (((E6 + E7) + (E29 + (E46 + E62)))) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (((E8 + (E9 + E30)) + ((E31 + E47) + (E48 + E63)))) implies e.ev = {i: range9 | (i.shift9_0).future9 in (e.target.av)}
all e: used | e.fiber in (((E10 + E11) + (E32 + (E49 + E64)))) implies e.ev = {i: range9 | (i.shift9_0).future9 in (range9 - e.target.av)}
all e: used | e.fiber in ((((E12 + E13) + (E14 + (E33 + E34))) + ((E35 + E50) + (E51 + (E52 + E65))))) implies e.ev = {i: range9 | loop9 in (e.target.av)}
all e: used | e.fiber in (((E15 + (E16 + E17)) + (E36 + (E53 + E66)))) implies e.ev = {i: range9 | loop9 in (range9 - e.target.av)}
all e: used | e.fiber in ((((E18 + E19) + (E20 + (E37 + E38))) + ((E39 + E54) + (E55 + (E56 + E67))))) implies e.ev = {i: range9 | some (loop9 & (e.target.av))}
all e: used | e.fiber in (((E21 + (E22 + E23)) + (E40 + (E57 + E68)))) implies e.ev = {i: range9 | some (loop9 & (range9 - e.target.av))}
all a: active | a.lab = T10 implies a.av = (range9 - child[a].ev)
all a: active | a.lab = T11 implies a.av = ({i: range9 | some (i.future9 & child[a].ev)})
all a: active | a.lab = T12 implies a.av = ({i: range9 | i.future9 in child[a].ev})
all a: active | a.lab = T13 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T14 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T15 implies a.av = ((range9 - left[a].ev) + right[a].ev)
}
fun range10: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + (P6 + P7)) + (P8 + (P9 + P10)))) }
fun loop10: set Pos { (P9 + P10) }
fun next10: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + (P6->P7 + P7->P8)) + (P8->P9 + (P9->P10 + P10->P9)))) }
fun future10: Pos -> Pos { (*next10) & (range10->range10) }
fun shift10_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + (P6->P6 + P7->P7)) + (P8->P8 + (P9->P9 + P10->P10)))) }
pred semantics10[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range10
ev in used->range10
all e: used | e.fiber in ((((E0 + E1) + (E24 + E25)) + ((E41 + E42) + (E58 + E59)))) implies e.ev = {i: range10 | (i.shift10_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E3) + (E26 + (E43 + E60)))) implies e.ev = {i: range10 | (i.shift10_0) in (range10 - e.target.av)}
all e: used | e.fiber in (((E4 + (E5 + E27)) + ((E28 + E44) + (E45 + E61)))) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (e.target.av))}
all e: used | e.fiber in (((E6 + E7) + (E29 + (E46 + E62)))) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (((E8 + (E9 + E30)) + ((E31 + E47) + (E48 + E63)))) implies e.ev = {i: range10 | (i.shift10_0).future10 in (e.target.av)}
all e: used | e.fiber in (((E10 + E11) + (E32 + (E49 + E64)))) implies e.ev = {i: range10 | (i.shift10_0).future10 in (range10 - e.target.av)}
all e: used | e.fiber in ((((E12 + E13) + (E14 + (E33 + E34))) + ((E35 + E50) + (E51 + (E52 + E65))))) implies e.ev = {i: range10 | loop10 in (e.target.av)}
all e: used | e.fiber in (((E15 + (E16 + E17)) + (E36 + (E53 + E66)))) implies e.ev = {i: range10 | loop10 in (range10 - e.target.av)}
all e: used | e.fiber in ((((E18 + E19) + (E20 + (E37 + E38))) + ((E39 + E54) + (E55 + (E56 + E67))))) implies e.ev = {i: range10 | some (loop10 & (e.target.av))}
all e: used | e.fiber in (((E21 + (E22 + E23)) + (E40 + (E57 + E68)))) implies e.ev = {i: range10 | some (loop10 & (range10 - e.target.av))}
all a: active | a.lab = T10 implies a.av = (range10 - child[a].ev)
all a: active | a.lab = T11 implies a.av = ({i: range10 | some (i.future10 & child[a].ev)})
all a: active | a.lab = T12 implies a.av = ({i: range10 | i.future10 in child[a].ev})
all a: active | a.lab = T13 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T14 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T15 implies a.av = ((range10 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (((P2 + P3) + (P4 + P5)))
all a: lab.T1 | a.av0 = (none)
all a: lab.T2 | a.av0 = (none)
all a: lab.T3 | a.av0 = (none)
all a: lab.T4 | a.av0 = ((P0 + P1))
all a: lab.T5 | a.av0 = (P2)
all a: lab.T6 | a.av0 = (P3)
all a: lab.T7 | a.av0 = ((P4 + P5))
all a: lab.T8 | a.av0 = (((P1 + P2) + (P3 + P4)))
all a: lab.T9 | a.av0 = (none)
(R->P0 in ev0)
semantics1[av1, ev1]
all a: lab.T0 | a.av1 = (((P2 + P3) + (P4 + (P5 + P6))))
all a: lab.T1 | a.av1 = (none)
all a: lab.T2 | a.av1 = ((P5 + P6))
all a: lab.T3 | a.av1 = (none)
all a: lab.T4 | a.av1 = ((P0 + P1))
all a: lab.T5 | a.av1 = (P2)
all a: lab.T6 | a.av1 = (P3)
all a: lab.T7 | a.av1 = ((P4 + (P5 + P6)))
all a: lab.T8 | a.av1 = (((P1 + P2) + (P3 + (P4 + P5))))
all a: lab.T9 | a.av1 = (none)
(R->P0 in ev1)
semantics2[av2, ev2]
all a: lab.T0 | a.av2 = (none)
all a: lab.T1 | a.av2 = (((P2 + P3) + (P4 + P5)))
all a: lab.T2 | a.av2 = (none)
all a: lab.T3 | a.av2 = (none)
all a: lab.T4 | a.av2 = ((P0 + (P1 + P2)))
all a: lab.T5 | a.av2 = (none)
all a: lab.T6 | a.av2 = (P3)
all a: lab.T7 | a.av2 = ((P4 + P5))
all a: lab.T8 | a.av2 = ((P1 + (P3 + P4)))
all a: lab.T9 | a.av2 = (none)
(R->P0 in ev2)
semantics3[av3, ev3]
all a: lab.T0 | a.av3 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av3 = (none)
all a: lab.T2 | a.av3 = (none)
all a: lab.T3 | a.av3 = (none)
all a: lab.T4 | a.av3 = ((P0 + P1))
all a: lab.T5 | a.av3 = (P2)
all a: lab.T6 | a.av3 = ((P3 + P4))
all a: lab.T7 | a.av3 = (none)
all a: lab.T8 | a.av3 = ((P1 + (P2 + P3)))
all a: lab.T9 | a.av3 = (none)
(R->P0 in ev3)
semantics4[av4, ev4]
all a: lab.T0 | a.av4 = (none)
all a: lab.T1 | a.av4 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av4 = (none)
all a: lab.T3 | a.av4 = (none)
all a: lab.T4 | a.av4 = ((P0 + P1))
all a: lab.T5 | a.av4 = (P2)
all a: lab.T6 | a.av4 = ((P3 + P4))
all a: lab.T7 | a.av4 = (none)
all a: lab.T8 | a.av4 = ((P1 + (P2 + P3)))
all a: lab.T9 | a.av4 = (none)
(R->P0 in ev4)
semantics5[av5, ev5]
all a: lab.T0 | a.av5 = (((P4 + P5) + (P6 + (P7 + P8))))
all a: lab.T1 | a.av5 = (none)
all a: lab.T2 | a.av5 = ((P7 + P8))
all a: lab.T3 | a.av5 = (none)
all a: lab.T4 | a.av5 = (((P0 + P1) + (P2 + P3)))
all a: lab.T5 | a.av5 = (P4)
all a: lab.T6 | a.av5 = (P5)
all a: lab.T7 | a.av5 = ((P6 + (P7 + P8)))
all a: lab.T8 | a.av5 = (((P3 + P4) + (P5 + (P6 + P7))))
all a: lab.T9 | a.av5 = (P1)
(R->P0 in ev5)
semantics6[av6, ev6]
all a: lab.T0 | a.av6 = (((P4 + P5) + (P6 + P7)))
all a: lab.T1 | a.av6 = (none)
all a: lab.T2 | a.av6 = (none)
all a: lab.T3 | a.av6 = (none)
all a: lab.T4 | a.av6 = (((P0 + P1) + (P2 + P3)))
all a: lab.T5 | a.av6 = (P4)
all a: lab.T6 | a.av6 = (P5)
all a: lab.T7 | a.av6 = ((P6 + P7))
all a: lab.T8 | a.av6 = (((P3 + P4) + (P5 + P6)))
all a: lab.T9 | a.av6 = (P1)
(R->P0 in ev6)
semantics7[av7, ev7]
all a: lab.T0 | a.av7 = (none)
all a: lab.T1 | a.av7 = (((P4 + P5) + (P6 + P7)))
all a: lab.T2 | a.av7 = (none)
all a: lab.T3 | a.av7 = (none)
all a: lab.T4 | a.av7 = (((P0 + P1) + (P2 + P3)))
all a: lab.T5 | a.av7 = (P4)
all a: lab.T6 | a.av7 = (P5)
all a: lab.T7 | a.av7 = ((P6 + P7))
all a: lab.T8 | a.av7 = (((P3 + P4) + (P5 + P6)))
all a: lab.T9 | a.av7 = (P1)
(R->P0 in ev7)
semantics8[av8, ev8]
all a: lab.T0 | a.av8 = (((P4 + (P5 + P6)) + ((P7 + P8) + (P9 + P10))))
all a: lab.T1 | a.av8 = (none)
all a: lab.T2 | a.av8 = ((P8 + (P9 + P10)))
all a: lab.T3 | a.av8 = (none)
all a: lab.T4 | a.av8 = (((P0 + P1) + (P2 + P3)))
all a: lab.T5 | a.av8 = (P4)
all a: lab.T6 | a.av8 = (P5)
all a: lab.T7 | a.av8 = (((P6 + P7) + (P8 + (P9 + P10))))
all a: lab.T8 | a.av8 = (((P3 + P4) + (P5 + (P6 + P7))))
all a: lab.T9 | a.av8 = ((P1 + P9))
(R->P0 in ev8)
semantics9[av9, ev9]
all a: lab.T0 | a.av9 = (none)
all a: lab.T1 | a.av9 = (((P4 + (P5 + P6)) + ((P7 + P8) + (P9 + P10))))
all a: lab.T2 | a.av9 = (none)
all a: lab.T3 | a.av9 = ((P8 + (P9 + P10)))
all a: lab.T4 | a.av9 = (((P0 + P1) + (P2 + P3)))
all a: lab.T5 | a.av9 = (P4)
all a: lab.T6 | a.av9 = (P5)
all a: lab.T7 | a.av9 = (((P6 + P7) + (P8 + (P9 + P10))))
all a: lab.T8 | a.av9 = (((P3 + P4) + (P5 + (P6 + P7))))
all a: lab.T9 | a.av9 = ((P1 + P9))
(R->P0 in ev9)
semantics8[av10, ev10]
all a: lab.T0 | a.av10 = (((P6 + P7) + (P8 + (P9 + P10))))
all a: lab.T1 | a.av10 = (((P2 + P3) + (P4 + P5)))
all a: lab.T2 | a.av10 = ((P9 + P10))
all a: lab.T3 | a.av10 = (none)
all a: lab.T4 | a.av10 = ((P0 + P1))
all a: lab.T5 | a.av10 = ((P2 + P6))
all a: lab.T6 | a.av10 = (((P3 + P4) + (P5 + P7)))
all a: lab.T7 | a.av10 = ((P8 + (P9 + P10)))
all a: lab.T8 | a.av10 = ((P1 + (P2 + P3)))
all a: lab.T9 | a.av10 = (((P5 + P6) + (P7 + (P8 + P9))))
not (R->P0 in ev10)
semantics10[av11, ev11]
all a: lab.T0 | a.av11 = (((P2 + P3) + (P4 + P5)))
all a: lab.T1 | a.av11 = (((P6 + P7) + (P8 + (P9 + P10))))
all a: lab.T2 | a.av11 = (none)
all a: lab.T3 | a.av11 = ((P9 + P10))
all a: lab.T4 | a.av11 = ((P0 + P1))
all a: lab.T5 | a.av11 = ((P2 + P6))
all a: lab.T6 | a.av11 = (((P3 + P4) + (P5 + P7)))
all a: lab.T7 | a.av11 = ((P8 + (P9 + P10)))
all a: lab.T8 | a.av11 = ((P1 + (P2 + P3)))
all a: lab.T9 | a.av11 = (((P5 + P6) + (P7 + (P8 + P9))))
not (R->P0 in ev11)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int

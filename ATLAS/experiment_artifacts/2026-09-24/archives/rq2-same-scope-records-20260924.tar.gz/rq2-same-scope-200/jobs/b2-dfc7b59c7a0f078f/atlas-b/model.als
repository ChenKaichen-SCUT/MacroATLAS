open util/ordering[SeqIdx]

abstract sig DAGNode {
	l: set DAGNode,
	r: set DAGNode
}
fact {
	all n: DAGNode | n not in n.^(l + r)
}

sig And, Or, Imply extends DAGNode {} {
	one l
	one r
}

sig Neg, F, G, X extends DAGNode {} {
    one l
    no r
}
abstract sig Literal extends DAGNode {} {
	no l
	no r
}

abstract sig SeqIdx {}
abstract sig Trace {
	lasso: SeqIdx -> SeqIdx,
	valuation: DAGNode -> SeqIdx
} {
	// Negation
    all n: Neg, i: seqRange | n->i in valuation iff n.l->i not in valuation
	// Or
    all n: Or, i: seqRange | n->i in valuation iff (n.l->i in valuation or n.r->i in valuation)
	// And
    all n: And, i: seqRange | n->i in valuation iff (n.l->i in valuation and n.r->i in valuation)
	// Imply
    all n: Imply, i: seqRange | n->i in valuation iff (n.l->i not in valuation or n.r->i in valuation)
	// G
    all n: G, i: seqRange | n->i in valuation iff all i': futureIdx[i] | n.l->i' in valuation
    // X
    all n: X, i: seqRange | n->i in valuation iff n.l->i.((next :> seqRange) + lasso) in valuation
	// F
    all n: F, i: seqRange | n->i in valuation iff some i': futureIdx[i] | n.l->i' in valuation
	// Until
    
}
fun seqRange[t: Trace]: set SeqIdx {
	let lastOfTrace = t.lasso.SeqIdx | lastOfTrace.prevs + lastOfTrace
}
fun futureIdx[t: Trace, i: SeqIdx]: set SeqIdx {
	i.^((next :> seqRange[t]) + t.lasso) + i
}
abstract sig PositiveTrace extends Trace {}
abstract sig NegativeTrace extends Trace {}
one sig x0, x1, x2 extends Literal {}
one sig T0, T1, T2, T3, T4 extends SeqIdx {}
fact {
    first = T0
    next = T0->T1 + T1->T2 + T2->T3 + T3->T4
}

one sig PT0 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig PT1 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x1->T1 + x2->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT2 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT3 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x2->T1 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT4 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x2->T1 + x2->T2 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT5 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x2->T1 + x1->T2 + x2->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT6 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T1 + x2->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT7 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x2->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4) & valuation
}

one sig PT8 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT9 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT10 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x1->T1 + x2->T2 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT11 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T1 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT12 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T1 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig PT13 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT14 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT15 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT16 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT17 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T1 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT18 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT19 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT20 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT21 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x2->T2 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT22 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT23 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T1 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT24 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig PT25 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x2->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig PT26 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT27 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x1->T1 + x2->T2 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT28 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x1->T1 + x1->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT29 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT30 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT31 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4) & valuation
}

one sig PT32 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT33 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x2->T1 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig PT34 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT35 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x2->T1 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT36 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x2->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT37 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT38 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT39 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT40 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT41 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}


one sig NT0 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x2->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT2 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T4) & valuation
}

one sig NT3 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x2->T2 + x2->T3) & valuation
}

one sig NT4 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT5 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T4) & valuation
}

one sig NT6 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT7 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT8 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4) & valuation
}

one sig NT9 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT10 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT11 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x2->T4) & valuation
}

one sig NT12 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT13 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x2->T4) & valuation
}

one sig NT14 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT15 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT16 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT17 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x2->T4) & valuation
}

one sig NT18 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT19 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT20 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT21 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 in valuation
    no (x2->T0 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT22 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT23 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT24 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT25 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T2 + x0->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT26 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T4 + x2->T4) & valuation
}

one sig NT27 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT28 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T2 + x0->T3 + x2->T4) & valuation
}

one sig NT29 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T1 + x0->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT30 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT31 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT32 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4) & valuation
}

one sig NT33 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT34 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x2->T1 + x1->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT35 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT36 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x2->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT37 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT38 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x2->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT39 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x0->T1 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT40 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT41 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT42 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT43 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT44 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT45 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT46 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT47 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x1->T1 + x0->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT48 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT49 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T2 + x1->T2 + x2->T2 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT50 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT51 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT52 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT53 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x1->T3) & valuation
}

one sig NT54 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT55 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT56 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x2->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT57 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT58 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT59 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T3 + x0->T4) & valuation
}

one sig NT60 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT61 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT62 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT63 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT64 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT65 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3) & valuation
}

one sig NT66 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T4) & valuation
}

one sig NT67 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3) & valuation
}

one sig NT68 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT69 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT70 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x2->T3 + x2->T4) & valuation
}

one sig NT71 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT72 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x2->T0 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT73 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT74 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT75 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT76 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT77 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT78 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T2 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT79 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT80 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT81 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT82 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT83 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x2->T1 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT84 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT85 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x0->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT86 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T2 + x1->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT87 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3) & valuation
}

one sig NT88 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT89 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT90 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT91 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT92 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x2->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT93 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x2->T1 + x0->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT94 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT95 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT96 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T4) & valuation
}

one sig NT97 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T2 + x2->T2 + x2->T3) & valuation
}

one sig NT98 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T3 + x1->T4 in valuation
    no (x2->T0 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT99 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T4) & valuation
}

one sig NT100 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x2->T1 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT101 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT102 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T3 + x2->T4) & valuation
}

one sig NT103 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x2->T3) & valuation
}

one sig NT104 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x1->T2 + x2->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT105 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT106 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT107 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT108 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT109 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT110 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT111 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT112 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 in valuation
    no (x0->T0 + x2->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT113 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT114 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3) & valuation
}

one sig NT115 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x2->T0 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT116 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T3 in valuation
    no (x2->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT117 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT118 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T3 + x2->T4) & valuation
}

one sig NT119 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT120 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT121 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig NT122 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT123 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT124 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT125 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT126 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT127 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT128 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x2->T3 + x2->T4 in valuation
    no (x2->T0 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT129 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT130 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT131 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT132 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT133 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT134 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT135 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT136 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x2->T4) & valuation
}

one sig NT137 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT138 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT139 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT140 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT141 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT142 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig NT143 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x1->T1 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT144 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT145 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT146 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT147 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3) & valuation
}

one sig NT148 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT149 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT150 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x2->T0 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT151 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT152 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x2->T0 + x0->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT153 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT154 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT155 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x2->T4) & valuation
}

one sig NT156 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT157 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT158 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4) & valuation
}

one sig NT159 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT160 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT161 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3) & valuation
}

one sig NT162 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT163 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x2->T3 + x0->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT164 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT165 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT166 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3) & valuation
}

one sig NT167 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT168 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4) & valuation
}

one sig NT169 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x1->T2 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT170 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4) & valuation
}

one sig NT171 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT172 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x2->T2 + x2->T4) & valuation
}

one sig NT173 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T2 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT174 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T3 + x2->T3) & valuation
}

one sig NT175 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT176 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T2 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT177 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x2->T1 + x1->T2 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT178 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT179 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x2->T1 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4) & valuation
}

one sig NT180 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T2 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT181 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT182 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT183 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3) & valuation
}

one sig NT184 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT185 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT186 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T2 + x2->T4) & valuation
}

one sig NT187 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT188 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT189 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT190 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1) & valuation
}

one sig NT191 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT192 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT193 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT194 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT195 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT196 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT197 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT198 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4) & valuation
}

one sig NT199 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT200 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT201 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT202 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT203 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT204 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT205 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T4 + x2->T4) & valuation
}

one sig NT206 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T4) & valuation
}

one sig NT207 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT208 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x2->T2 + x1->T3) & valuation
}

one sig NT209 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT210 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2) & valuation
}

one sig NT211 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT212 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x0->T1 + x2->T1 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT213 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT214 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT215 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x2->T4) & valuation
}

one sig NT216 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT217 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x2->T0 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT218 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT219 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x2->T2 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT220 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x0->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT221 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT222 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T4) & valuation
}

one sig NT223 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x2->T3 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT224 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT225 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT226 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT227 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x2->T2 + x2->T4) & valuation
}

one sig NT228 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT229 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T4 + x2->T4) & valuation
}

one sig NT230 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT231 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3) & valuation
}

one sig NT232 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT233 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT234 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT235 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT236 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT237 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T3) & valuation
}

one sig NT238 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT239 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT240 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT241 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x2->T2 + x0->T3 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT242 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT243 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x2->T2 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT244 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT245 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT246 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x2->T1 + x0->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT247 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x2->T3 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT248 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x2->T1 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT249 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T1 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT250 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT251 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT252 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT253 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT254 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T4) & valuation
}

one sig NT255 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig NT256 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT257 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T2 + x2->T2 + x1->T3 + x2->T3) & valuation
}

one sig NT258 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT259 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT260 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT261 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x1->T1 + x2->T1 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT262 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x1->T1 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT263 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT264 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT265 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT266 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T1 + x2->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT267 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT268 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3) & valuation
}

one sig NT269 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x2->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT270 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT271 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT272 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T3) & valuation
}

one sig NT273 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT274 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T4) & valuation
}

one sig NT275 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT276 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT277 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT278 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x2->T1 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT279 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x0->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT280 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT281 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT282 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 in valuation
    no (x2->T0 + x0->T1 + x0->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT283 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT284 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT285 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T4) & valuation
}

one sig NT286 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT287 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x2->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT288 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT289 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT290 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT291 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T1 + x2->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT292 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT293 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT294 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT295 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT296 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x2->T1 + x2->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT297 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T1 + x2->T1 + x1->T2 + x0->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT298 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT299 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT300 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT301 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T4) & valuation
}

one sig NT302 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT303 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x2->T1 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT304 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT305 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT306 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT307 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T2 + x2->T2 + x1->T3) & valuation
}

one sig NT308 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT309 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x0->T2 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT310 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT311 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T3 + x2->T4) & valuation
}

one sig NT312 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3) & valuation
}

one sig NT313 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T2 + x1->T3 + x2->T3 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT314 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x2->T2) & valuation
}

one sig NT315 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT316 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x2->T3 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT317 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T2 + x2->T3 + x2->T4) & valuation
}

one sig NT318 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT319 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T4 in valuation
    no (x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT320 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT321 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x2->T1 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT322 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT323 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x2->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT324 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT325 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T4) & valuation
}

one sig NT326 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT327 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T4) & valuation
}

one sig NT328 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T4) & valuation
}

one sig NT329 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT330 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT331 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT332 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T3) & valuation
}

one sig NT333 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x2->T1 + x0->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT334 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x2->T1 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig NT335 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3) & valuation
}

one sig NT336 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT337 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x2->T4) & valuation
}

one sig NT338 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT339 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT340 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT341 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig NT342 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT343 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT344 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT345 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T2 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3) & valuation
}

one sig NT346 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT347 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T3 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT348 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T1 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3) & valuation
}

one sig NT349 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT350 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT351 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x0->T2 + x2->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT352 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x1->T3 + x2->T4) & valuation
}

one sig NT353 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T4) & valuation
}

one sig NT354 extends NegativeTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT355 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4) & valuation
}

one sig NT356 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT357 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3) & valuation
}

one sig NT358 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT359 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT360 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT361 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT362 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT363 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT364 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT365 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT366 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T4) & valuation
}

one sig NT367 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT368 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT369 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT370 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T4 in valuation
    no (x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT371 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT372 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2) & valuation
}

one sig NT373 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x2->T2 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT374 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT375 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT376 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T2 + x2->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT377 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T3 + x2->T4 in valuation
    no (x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT378 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT379 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT380 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T4 + x2->T4) & valuation
}

one sig NT381 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT382 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T1 + x2->T2 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT383 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x1->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT384 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT385 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x2->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3) & valuation
}

one sig NT386 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT387 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT388 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT389 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T4 + x2->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT390 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT391 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT392 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT393 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T4) & valuation
}

one sig NT394 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T3 + x0->T4) & valuation
}

one sig NT395 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT396 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT397 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T4) & valuation
}

one sig NT398 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT399 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T2 + x1->T3 + x2->T3) & valuation
}

one sig NT400 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT401 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x2->T2 + x2->T3 + x2->T4) & valuation
}

one sig NT402 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT403 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T2 + x1->T2 + x0->T3 + x2->T3) & valuation
}

one sig NT404 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T4 in valuation
    no (x2->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT405 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT406 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T3 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT407 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT408 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x2->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT409 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT410 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT411 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x0->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x2->T3) & valuation
}

one sig NT412 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x0->T0 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT413 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT414 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T2 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT415 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T1 + x2->T2 + x2->T3 + x0->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT416 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT417 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x2->T1 + x0->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT418 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T1 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT419 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4) & valuation
}

one sig NT420 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT421 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T1 + x0->T2 + x2->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT422 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT423 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T1 + x2->T3 + x1->T4) & valuation
}

one sig NT424 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT425 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4) & valuation
}

one sig NT426 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT427 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3) & valuation
}

one sig NT428 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4) & valuation
}

one sig NT429 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T4) & valuation
}

one sig NT430 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x2->T4) & valuation
}

one sig NT431 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT432 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT433 extends NegativeTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x2->T2 + x0->T3) & valuation
}

one sig NT434 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT435 extends NegativeTrace {} {
    lasso = T4->T4
    x2->T0 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT436 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT437 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT438 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x2->T3) & valuation
}

one sig NT439 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T4 in valuation
    no (x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT440 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT441 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 in valuation
    no (x1->T1 + x2->T2 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT442 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x1->T2 + x1->T4 + x2->T4) & valuation
}

one sig NT443 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT444 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT445 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig NT446 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT447 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT448 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x1->T1 + x2->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT449 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT450 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T2 + x1->T3) & valuation
}

one sig NT451 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT452 extends NegativeTrace {} {
    lasso = T4->T0
    x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT453 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T2 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT454 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT455 extends NegativeTrace {} {
    lasso = T4->T3
    x2->T0 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig NT456 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig NT457 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4) & valuation
}

one sig LearnedLTL {
    Root: DAGNode
}
fun root: one DAGNode { LearnedLTL.Root }
fun childrenOf[n: DAGNode]: set DAGNode { n.^(l+r) }
fun childrenAndSelfOf[n: DAGNode]: set DAGNode { n.*(l+r) }
fun ancestorsOf[n: DAGNode]: set DAGNode { n.~^(l+r) }
fun ancestorsAndSelfOf[n: DAGNode]: set DAGNode { n.~*(l+r) }
fun subDAG[n: DAGNode]: DAGNode -> DAGNode { n.*(l+r) <: (l+r) }



fun experimentReach: set DAGNode { childrenAndSelfOf[root] }
fun experimentKept: DAGNode -> DAGNode { (none->none) & subDAG[root] }
one sig ExperimentCost { used: set DAGNode }
fact { ExperimentCost.used = experimentReach }
fact ExperimentBounds {
  DAGNode = experimentReach + Literal + (none)
  #experimentReach <= 15
  #(experimentReach & (And + Or + Imply)) <= 2
  minsome ExperimentCost.used
}
run {
    all t: PositiveTrace | root->T0 in t.valuation
    all t: NegativeTrace | root->T0 not in t.valuation
    
} for 18 DAGNode, 6 Int
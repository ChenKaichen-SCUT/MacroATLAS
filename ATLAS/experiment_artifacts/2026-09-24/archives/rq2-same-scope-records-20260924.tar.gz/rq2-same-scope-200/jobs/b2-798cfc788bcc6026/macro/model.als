abstract sig Unit {}
one sig U0, U1, U2, U3, U4, U5, U6, U7, U8 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13 extends Label {}
abstract sig Q {}
one sig Q0 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E26, E27, E28, E29, E30, E31, E32, E33, E34, E35, E36, E37 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos, av20: set Pos, av21: set Pos, av22: set Pos, av23: set Pos, av24: set Pos, av25: set Pos, av26: set Pos, av27: set Pos, av28: set Pos, av29: set Pos, av30: set Pos, av31: set Pos, av32: set Pos, av33: set Pos, av34: set Pos, av35: set Pos, av36: set Pos, av37: set Pos, av38: set Pos, av39: set Pos, av40: set Pos, av41: set Pos, av42: set Pos, av43: set Pos, av44: set Pos, av45: set Pos, av46: set Pos, av47: set Pos, av48: set Pos, av49: set Pos, av50: set Pos, av51: set Pos, av52: set Pos, av53: set Pos, av54: set Pos, av55: set Pos, av56: set Pos, av57: set Pos, av58: set Pos, av59: set Pos, av60: set Pos, av61: set Pos, av62: set Pos, av63: set Pos, av64: set Pos, av65: set Pos, av66: set Pos, av67: set Pos, av68: set Pos, av69: set Pos, av70: set Pos, av71: set Pos, av72: set Pos, av73: set Pos, av74: set Pos, av75: set Pos, av76: set Pos, av77: set Pos, av78: set Pos, av79: set Pos, av80: set Pos, av81: set Pos, av82: set Pos, av83: set Pos, av84: set Pos, av85: set Pos, av86: set Pos, av87: set Pos, av88: set Pos, av89: set Pos, av90: set Pos, av91: set Pos, av92: set Pos, av93: set Pos, av94: set Pos, av95: set Pos, av96: set Pos, av97: set Pos, av98: set Pos, av99: set Pos }
one sig A0, A1, A2, A3, A4, A5, A6, A7 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos, ev20: set Pos, ev21: set Pos, ev22: set Pos, ev23: set Pos, ev24: set Pos, ev25: set Pos, ev26: set Pos, ev27: set Pos, ev28: set Pos, ev29: set Pos, ev30: set Pos, ev31: set Pos, ev32: set Pos, ev33: set Pos, ev34: set Pos, ev35: set Pos, ev36: set Pos, ev37: set Pos, ev38: set Pos, ev39: set Pos, ev40: set Pos, ev41: set Pos, ev42: set Pos, ev43: set Pos, ev44: set Pos, ev45: set Pos, ev46: set Pos, ev47: set Pos, ev48: set Pos, ev49: set Pos, ev50: set Pos, ev51: set Pos, ev52: set Pos, ev53: set Pos, ev54: set Pos, ev55: set Pos, ev56: set Pos, ev57: set Pos, ev58: set Pos, ev59: set Pos, ev60: set Pos, ev61: set Pos, ev62: set Pos, ev63: set Pos, ev64: set Pos, ev65: set Pos, ev66: set Pos, ev67: set Pos, ev68: set Pos, ev69: set Pos, ev70: set Pos, ev71: set Pos, ev72: set Pos, ev73: set Pos, ev74: set Pos, ev75: set Pos, ev76: set Pos, ev77: set Pos, ev78: set Pos, ev79: set Pos, ev80: set Pos, ev81: set Pos, ev82: set Pos, ev83: set Pos, ev84: set Pos, ev85: set Pos, ev86: set Pos, ev87: set Pos, ev88: set Pos, ev89: set Pos, ev90: set Pos, ev91: set Pos, ev92: set Pos, ev93: set Pos, ev94: set Pos, ev95: set Pos, ev96: set Pos, ev97: set Pos, ev98: set Pos, ev99: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4, C5, L5, D5, C6, L6, D6, C7, L7, D7 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { ((T0 + (T1 + T2)) + ((T3 + T4) + (T5 + T6))) }
fun un: set Label { ((T7 + T8) + (T9 + T10)) }
fun bin: set Label { (T11 + (T12 + T13)) }
fun nonempty: set Fiber { (((((E1 + E2) + (E3 + E4)) + ((E5 + E6) + (E7 + (E8 + E9)))) + (((E10 + E11) + (E12 + E13)) + ((E14 + E15) + (E16 + (E17 + E18))))) + ((((E19 + E20) + (E21 + E22)) + ((E23 + E24) + (E25 + (E26 + E27)))) + (((E28 + E29) + (E30 + (E31 + E32))) + ((E33 + E34) + (E35 + (E36 + E37)))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { (((U0->U1 + U1->U2) + (U2->U3 + U3->U4)) + ((U4->U5 + U5->U6) + (U6->U7 + U7->U8))) }
fun carrierNext: Carrier -> Carrier { (((((A0->A1 + A1->A2) + (A2->A3 + A3->A4)) + ((A4->A5 + A5->A6) + (A6->A7 + A7->R))) + (((R->C0 + C0->L0) + (L0->D0 + D0->C1)) + ((C1->L1 + L1->D1) + (D1->C2 + C2->L2)))) + ((((L2->D2 + D2->C3) + (C3->L3 + L3->D3)) + ((D3->C4 + C4->L4) + (L4->D4 + D4->C5))) + (((C5->L5 + L5->D5) + (D5->C6 + C6->L6)) + ((L6->D6 + D6->C7) + (C7->L7 + L7->D7))))) }
fun child[a: Anchor]: set Port { a.((((A0->C0 + A1->C1) + (A2->C2 + A3->C3)) + ((A4->C4 + A5->C5) + (A6->C6 + A7->C7)))) }
fun left[a: Anchor]: set Port { a.((((A0->L0 + A1->L1) + (A2->L2 + A3->L3)) + ((A4->L4 + A5->L5) + (A6->L6 + A7->L7)))) }
fun right[a: Anchor]: set Port { a.((((A0->D0 + A1->D1) + (A2->D2 + A3->D3)) + ((A4->D4 + A5->D5) + (A6->D6 + A7->D7)))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
C5.src = A5
L5.src = A5
D5.src = A5
(some C5.target iff A5.lab in un and some A5.lab)
(some L5.target iff A5.lab in bin and some A5.lab)
(some D5.target iff A5.lab in bin and some A5.lab)
C6.src = A6
L6.src = A6
D6.src = A6
(some C6.target iff A6.lab in un and some A6.lab)
(some L6.target iff A6.lab in bin and some A6.lab)
(some D6.target iff A6.lab in bin and some A6.lab)
C7.src = A7
L7.src = A7
D7.src = A7
(some C7.target iff A7.lab in un and some A7.lab)
(some L7.target iff A7.lab in bin and some A7.lab)
(some D7.target iff A7.lab in bin and some A7.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
no A3.graph & (((A0 + A1) + (A2 + A3)))
no A4.graph & (((A0 + A1) + (A2 + (A3 + A4))))
no A5.graph & (((A0 + (A1 + A2)) + (A3 + (A4 + A5))))
no A6.graph & (((A0 + (A1 + A2)) + ((A3 + A4) + (A5 + A6))))
no A7.graph & ((((A0 + A1) + (A2 + A3)) + ((A4 + A5) + (A6 + A7))))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
lone lab.T2
lone lab.T3
lone lab.T4
lone lab.T5
lone lab.T6
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un implies #(target.A2) > 1
some A2.lab implies some A1.lab
some A3.lab and A3.lab in un implies #(target.A3) > 1
some A3.lab implies some A2.lab
some A4.lab and A4.lab in un implies #(target.A4) > 1
some A4.lab implies some A3.lab
some A5.lab and A5.lab in un implies #(target.A5) > 1
some A5.lab implies some A4.lab
some A6.lab and A6.lab in un implies #(target.A6) > 1
some A6.lab implies some A5.lab
some A7.lab and A7.lab in un implies #(target.A7) > 1
some A7.lab implies some A6.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q0
E7.qo = Q0
E8.qi = Q0
E8.qo = Q0
E9.qi = Q0
E9.qo = Q0
E10.qi = Q0
E10.qo = Q0
E11.qi = Q0
E11.qo = Q0
E12.qi = Q0
E12.qo = Q0
E13.qi = Q0
E13.qo = Q0
E14.qi = Q0
E14.qo = Q0
E15.qi = Q0
E15.qo = Q0
E16.qi = Q0
E16.qo = Q0
E17.qi = Q0
E17.qo = Q0
E18.qi = Q0
E18.qo = Q0
E19.qi = Q0
E19.qo = Q0
E20.qi = Q0
E20.qo = Q0
E21.qi = Q0
E21.qo = Q0
E22.qi = Q0
E22.qo = Q0
E23.qi = Q0
E23.qo = Q0
E24.qi = Q0
E24.qo = Q0
E25.qi = Q0
E25.qo = Q0
E26.qi = Q0
E26.qo = Q0
E27.qi = Q0
E27.qo = Q0
E28.qi = Q0
E28.qo = Q0
E29.qi = Q0
E29.qo = Q0
E30.qi = Q0
E30.qo = Q0
E31.qi = Q0
E31.qo = Q0
E32.qi = Q0
E32.qo = Q0
E33.qi = Q0
E33.qo = Q0
E34.qi = Q0
E34.qo = Q0
E35.qi = Q0
E35.qo = Q0
E36.qi = Q0
E36.qo = Q0
E37.qi = Q0
E37.qo = Q0
all e: used | e.fiber in (E0) implies #e.cost = 0
all e: used | e.fiber in ((((E1 + E4) + (E6 + E7)) + ((E9 + E12) + (E13 + (E15 + E17))))) implies #e.cost = 2
all e: used | e.fiber in (((E2 + E3) + (E5 + E11))) implies #e.cost = 1
all e: used | e.fiber in ((((E8 + E10) + (E14 + E16)) + ((E18 + E19) + (E21 + E23)))) implies #e.cost = 3
all e: used | e.fiber in (((E20 + (E22 + E24)) + (E25 + (E27 + E29)))) implies #e.cost = 4
all e: used | e.fiber in (((E26 + E28) + (E30 + E31))) implies #e.cost = 5
all e: used | e.fiber in ((E32 + E33)) implies #e.cost = 6
all e: used | e.fiber in ((E34 + E35)) implies #e.cost = 7
all e: used | e.fiber in ((E36 + E37)) implies #e.cost = 8
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q0)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 implies a.state = Q0
all a: active | a.lab = T3 implies a.state = Q0
all a: active | a.lab = T4 implies a.state = Q0
all a: active | a.lab = T5 implies a.state = Q0
all a: active | a.lab = T6 implies a.state = Q0
all a: active | a.lab = T7 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T8 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T9 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T10 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T11 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T12 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T13 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
}
fun range0: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop0: set Pos { P4 }
fun next0: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift0_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun shift0_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift0_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift0_4: Pos -> Pos { ((P0->P4 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range0 | loop0 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range0 | loop0 in (range0 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range0 | some (loop0 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range0 | some (loop0 & (range0 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range0 | (i.shift0_1) in (range0 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range0 | (i.shift0_1).future0 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range0 | (i.shift0_1).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range0 | (i.shift0_2) in (range0 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range0 | (i.shift0_2).future0 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range0 | (i.shift0_2).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range0 | (i.shift0_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range0 | (i.shift0_3) in (range0 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range0 | some ((i.shift0_3).future0 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range0 | some ((i.shift0_3).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range0 | (i.shift0_3).future0 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range0 | (i.shift0_3).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (((E29 + E31) + (E33 + (E35 + E37)))) implies e.ev = {i: range0 | (i.shift0_4) in (e.target.av)}
all e: used | e.fiber in (((E30 + E32) + (E34 + E36))) implies e.ev = {i: range0 | (i.shift0_4) in (range0 - e.target.av)}
all a: active | a.lab = T7 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T8 implies a.av = (next0.(child[a].ev))
all a: active | a.lab = T9 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T10 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T11 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T12 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T13 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop1: set Pos { (P2 + (P3 + P4)) }
fun next1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift1_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun shift1_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P2 + P4->P3))) }
fun shift1_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift1_4: Pos -> Pos { ((P0->P4 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range1 | loop1 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range1 | loop1 in (range1 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range1 | some (loop1 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range1 | some (loop1 & (range1 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range1 | (i.shift1_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range1 | (i.shift1_1) in (range1 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range1 | (i.shift1_1).future1 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range1 | (i.shift1_1).future1 in (range1 - e.target.av)}
all e: used | e.fiber in ((E17 + (E31 + E37))) implies e.ev = {i: range1 | (i.shift1_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + E32)) implies e.ev = {i: range1 | (i.shift1_2) in (range1 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range1 | (i.shift1_2).future1 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range1 | (i.shift1_2).future1 in (range1 - e.target.av)}
all e: used | e.fiber in ((E23 + E33)) implies e.ev = {i: range1 | (i.shift1_3) in (e.target.av)}
all e: used | e.fiber in ((E24 + E34)) implies e.ev = {i: range1 | (i.shift1_3) in (range1 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range1 | some ((i.shift1_3).future1 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range1 | some ((i.shift1_3).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range1 | (i.shift1_3).future1 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range1 | (i.shift1_3).future1 in (range1 - e.target.av)}
all e: used | e.fiber in ((E29 + E35)) implies e.ev = {i: range1 | (i.shift1_4) in (e.target.av)}
all e: used | e.fiber in ((E30 + E36)) implies e.ev = {i: range1 | (i.shift1_4) in (range1 - e.target.av)}
all a: active | a.lab = T7 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T8 implies a.av = (next1.(child[a].ev))
all a: active | a.lab = T9 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T10 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T11 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T12 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T13 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fun range2: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop2: set Pos { (P3 + P4) }
fun next2: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift2_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun shift2_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P3 + P4->P4))) }
fun shift2_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P3 + (P3->P4 + P4->P3))) }
fun shift2_4: Pos -> Pos { ((P0->P4 + P1->P3) + (P2->P4 + (P3->P3 + P4->P4))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range2 | (i.shift2_0) in (range2 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range2 | (i.shift2_0).future2 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range2 | (i.shift2_0).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range2 | loop2 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range2 | loop2 in (range2 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range2 | some (loop2 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range2 | some (loop2 & (range2 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range2 | (i.shift2_1) in (range2 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range2 | (i.shift2_1).future2 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range2 | (i.shift2_1).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range2 | (i.shift2_2) in (range2 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range2 | (i.shift2_2).future2 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range2 | (i.shift2_2).future2 in (range2 - e.target.av)}
all e: used | e.fiber in ((E23 + (E31 + E35))) implies e.ev = {i: range2 | (i.shift2_3) in (e.target.av)}
all e: used | e.fiber in ((E24 + (E32 + E36))) implies e.ev = {i: range2 | (i.shift2_3) in (range2 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range2 | some ((i.shift2_3).future2 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range2 | some ((i.shift2_3).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range2 | (i.shift2_3).future2 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range2 | (i.shift2_3).future2 in (range2 - e.target.av)}
all e: used | e.fiber in ((E29 + (E33 + E37))) implies e.ev = {i: range2 | (i.shift2_4) in (e.target.av)}
all e: used | e.fiber in ((E30 + E34)) implies e.ev = {i: range2 | (i.shift2_4) in (range2 - e.target.av)}
all a: active | a.lab = T7 implies a.av = (range2 - child[a].ev)
all a: active | a.lab = T8 implies a.av = (next2.(child[a].ev))
all a: active | a.lab = T9 implies a.av = ({i: range2 | some (i.future2 & child[a].ev)})
all a: active | a.lab = T10 implies a.av = ({i: range2 | i.future2 in child[a].ev})
all a: active | a.lab = T11 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T12 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T13 implies a.av = ((range2 - left[a].ev) + right[a].ev)
}
fun range3: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop3: set Pos { ((P1 + P2) + (P3 + P4)) }
fun next3: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift3_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun shift3_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P1 + P4->P2))) }
fun shift3_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P1 + (P3->P2 + P4->P3))) }
fun shift3_4: Pos -> Pos { ((P0->P4 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range3 | (i.shift3_0) in (range3 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range3 | (i.shift3_0).future3 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range3 | (i.shift3_0).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range3 | loop3 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range3 | loop3 in (range3 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range3 | some (loop3 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range3 | some (loop3 & (range3 - e.target.av))}
all e: used | e.fiber in ((E11 + E31)) implies e.ev = {i: range3 | (i.shift3_1) in (e.target.av)}
all e: used | e.fiber in ((E12 + E32)) implies e.ev = {i: range3 | (i.shift3_1) in (range3 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range3 | (i.shift3_1).future3 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range3 | (i.shift3_1).future3 in (range3 - e.target.av)}
all e: used | e.fiber in ((E17 + E33)) implies e.ev = {i: range3 | (i.shift3_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + E34)) implies e.ev = {i: range3 | (i.shift3_2) in (range3 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range3 | (i.shift3_2).future3 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range3 | (i.shift3_2).future3 in (range3 - e.target.av)}
all e: used | e.fiber in ((E23 + E35)) implies e.ev = {i: range3 | (i.shift3_3) in (e.target.av)}
all e: used | e.fiber in ((E24 + E36)) implies e.ev = {i: range3 | (i.shift3_3) in (range3 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range3 | some ((i.shift3_3).future3 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range3 | some ((i.shift3_3).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range3 | (i.shift3_3).future3 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range3 | (i.shift3_3).future3 in (range3 - e.target.av)}
all e: used | e.fiber in ((E29 + E37)) implies e.ev = {i: range3 | (i.shift3_4) in (e.target.av)}
all e: used | e.fiber in (E30) implies e.ev = {i: range3 | (i.shift3_4) in (range3 - e.target.av)}
all a: active | a.lab = T7 implies a.av = (range3 - child[a].ev)
all a: active | a.lab = T8 implies a.av = (next3.(child[a].ev))
all a: active | a.lab = T9 implies a.av = ({i: range3 | some (i.future3 & child[a].ev)})
all a: active | a.lab = T10 implies a.av = ({i: range3 | i.future3 in child[a].ev})
all a: active | a.lab = T11 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T12 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T13 implies a.av = ((range3 - left[a].ev) + right[a].ev)
}
fun range4: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop4: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun next4: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift4_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun shift4_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P0 + P4->P1))) }
fun shift4_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P0 + (P3->P1 + P4->P2))) }
fun shift4_4: Pos -> Pos { ((P0->P4 + P1->P0) + (P2->P1 + (P3->P2 + P4->P3))) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in ((E0 + (E1 + E31))) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + E32)) implies e.ev = {i: range4 | (i.shift4_0) in (range4 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range4 | (i.shift4_0).future4 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range4 | (i.shift4_0).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range4 | loop4 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range4 | loop4 in (range4 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range4 | some (loop4 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range4 | some (loop4 & (range4 - e.target.av))}
all e: used | e.fiber in ((E11 + E33)) implies e.ev = {i: range4 | (i.shift4_1) in (e.target.av)}
all e: used | e.fiber in ((E12 + E34)) implies e.ev = {i: range4 | (i.shift4_1) in (range4 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range4 | (i.shift4_1).future4 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range4 | (i.shift4_1).future4 in (range4 - e.target.av)}
all e: used | e.fiber in ((E17 + E35)) implies e.ev = {i: range4 | (i.shift4_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + E36)) implies e.ev = {i: range4 | (i.shift4_2) in (range4 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range4 | (i.shift4_2).future4 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range4 | (i.shift4_2).future4 in (range4 - e.target.av)}
all e: used | e.fiber in ((E23 + E37)) implies e.ev = {i: range4 | (i.shift4_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range4 | (i.shift4_3) in (range4 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range4 | some ((i.shift4_3).future4 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range4 | some ((i.shift4_3).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range4 | (i.shift4_3).future4 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range4 | (i.shift4_3).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range4 | (i.shift4_4) in (e.target.av)}
all e: used | e.fiber in (E30) implies e.ev = {i: range4 | (i.shift4_4) in (range4 - e.target.av)}
all a: active | a.lab = T7 implies a.av = (range4 - child[a].ev)
all a: active | a.lab = T8 implies a.av = (next4.(child[a].ev))
all a: active | a.lab = T9 implies a.av = ({i: range4 | some (i.future4 & child[a].ev)})
all a: active | a.lab = T10 implies a.av = ({i: range4 | i.future4 in child[a].ev})
all a: active | a.lab = T11 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T12 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T13 implies a.av = ((range4 - left[a].ev) + right[a].ev)
}
fun range5: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop5: set Pos { ((P0 + P1) + (P2 + P3)) }
fun next5: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift5_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun shift5_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P0 + P3->P1)) }
fun shift5_3: Pos -> Pos { ((P0->P3 + P1->P0) + (P2->P1 + P3->P2)) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in (((E0 + E1) + (E29 + E37))) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + E30)) implies e.ev = {i: range5 | (i.shift5_0) in (range5 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range5 | (i.shift5_0).future5 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range5 | (i.shift5_0).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range5 | loop5 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range5 | loop5 in (range5 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range5 | some (loop5 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range5 | some (loop5 & (range5 - e.target.av))}
all e: used | e.fiber in ((E11 + E31)) implies e.ev = {i: range5 | (i.shift5_1) in (e.target.av)}
all e: used | e.fiber in ((E12 + E32)) implies e.ev = {i: range5 | (i.shift5_1) in (range5 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range5 | (i.shift5_1).future5 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range5 | (i.shift5_1).future5 in (range5 - e.target.av)}
all e: used | e.fiber in ((E17 + E33)) implies e.ev = {i: range5 | (i.shift5_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + E34)) implies e.ev = {i: range5 | (i.shift5_2) in (range5 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range5 | (i.shift5_2).future5 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range5 | (i.shift5_2).future5 in (range5 - e.target.av)}
all e: used | e.fiber in ((E23 + E35)) implies e.ev = {i: range5 | (i.shift5_3) in (e.target.av)}
all e: used | e.fiber in ((E24 + E36)) implies e.ev = {i: range5 | (i.shift5_3) in (range5 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range5 | some ((i.shift5_3).future5 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range5 | some ((i.shift5_3).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range5 | (i.shift5_3).future5 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range5 | (i.shift5_3).future5 in (range5 - e.target.av)}
all a: active | a.lab = T7 implies a.av = (range5 - child[a].ev)
all a: active | a.lab = T8 implies a.av = (next5.(child[a].ev))
all a: active | a.lab = T9 implies a.av = ({i: range5 | some (i.future5 & child[a].ev)})
all a: active | a.lab = T10 implies a.av = ({i: range5 | i.future5 in child[a].ev})
all a: active | a.lab = T11 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T12 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T13 implies a.av = ((range5 - left[a].ev) + right[a].ev)
}
fun range6: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop6: set Pos { P3 }
fun next6: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun future6: Pos -> Pos { (*next6) & (range6->range6) }
fun shift6_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift6_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun shift6_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P3 + P3->P3)) }
fun shift6_3: Pos -> Pos { ((P0->P3 + P1->P3) + (P2->P3 + P3->P3)) }
pred semantics6[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range6
ev in used->range6
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range6 | (i.shift6_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range6 | (i.shift6_0) in (range6 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range6 | (i.shift6_0).future6 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range6 | (i.shift6_0).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range6 | loop6 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range6 | loop6 in (range6 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range6 | some (loop6 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range6 | some (loop6 & (range6 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range6 | (i.shift6_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range6 | (i.shift6_1) in (range6 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range6 | (i.shift6_1).future6 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range6 | (i.shift6_1).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range6 | (i.shift6_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range6 | (i.shift6_2) in (range6 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range6 | (i.shift6_2).future6 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range6 | (i.shift6_2).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (((E23 + (E29 + E31)) + (E33 + (E35 + E37)))) implies e.ev = {i: range6 | (i.shift6_3) in (e.target.av)}
all e: used | e.fiber in (((E24 + E30) + (E32 + (E34 + E36)))) implies e.ev = {i: range6 | (i.shift6_3) in (range6 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range6 | some ((i.shift6_3).future6 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range6 | some ((i.shift6_3).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range6 | (i.shift6_3).future6 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range6 | (i.shift6_3).future6 in (range6 - e.target.av)}
all a: active | a.lab = T7 implies a.av = (range6 - child[a].ev)
all a: active | a.lab = T8 implies a.av = (next6.(child[a].ev))
all a: active | a.lab = T9 implies a.av = ({i: range6 | some (i.future6 & child[a].ev)})
all a: active | a.lab = T10 implies a.av = ({i: range6 | i.future6 in child[a].ev})
all a: active | a.lab = T11 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T12 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T13 implies a.av = ((range6 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (P2)
all a: lab.T1 | a.av0 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av0 = (((P1 + P2) + (P3 + P4)))
all a: lab.T3 | a.av0 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av0 = ((P2 + P3))
all a: lab.T5 | a.av0 = ((P1 + (P2 + P4)))
all a: lab.T6 | a.av0 = (none)
(R->P0 in ev0)
semantics1[av1, ev1]
all a: lab.T0 | a.av1 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av1 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av1 = ((P2 + (P3 + P4)))
all a: lab.T3 | a.av1 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av1 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T5 | a.av1 = (P1)
all a: lab.T6 | a.av1 = ((P1 + (P2 + P4)))
(R->P0 in ev1)
semantics1[av2, ev2]
all a: lab.T0 | a.av2 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av2 = (none)
all a: lab.T2 | a.av2 = ((P1 + P3))
all a: lab.T3 | a.av2 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av2 = ((P0 + P3))
all a: lab.T5 | a.av2 = ((P0 + P2))
all a: lab.T6 | a.av2 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev2)
semantics2[av3, ev3]
all a: lab.T0 | a.av3 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av3 = ((P2 + P3))
all a: lab.T2 | a.av3 = (((P0 + P1) + (P3 + P4)))
all a: lab.T3 | a.av3 = ((P0 + P1))
all a: lab.T4 | a.av3 = (((P1 + P2) + (P3 + P4)))
all a: lab.T5 | a.av3 = ((P1 + P2))
all a: lab.T6 | a.av3 = ((P0 + P3))
(R->P0 in ev3)
semantics3[av4, ev4]
all a: lab.T0 | a.av4 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av4 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av4 = ((P0 + P1))
all a: lab.T3 | a.av4 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av4 = ((P0 + P1))
all a: lab.T5 | a.av4 = ((P1 + (P3 + P4)))
all a: lab.T6 | a.av4 = (P0)
(R->P0 in ev4)
semantics2[av5, ev5]
all a: lab.T0 | a.av5 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av5 = (P4)
all a: lab.T2 | a.av5 = ((P0 + (P1 + P3)))
all a: lab.T3 | a.av5 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av5 = ((P1 + (P3 + P4)))
all a: lab.T5 | a.av5 = ((P0 + P2))
all a: lab.T6 | a.av5 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev5)
semantics0[av6, ev6]
all a: lab.T0 | a.av6 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av6 = ((P1 + P4))
all a: lab.T2 | a.av6 = ((P0 + P1))
all a: lab.T3 | a.av6 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av6 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T5 | a.av6 = ((P0 + (P3 + P4)))
all a: lab.T6 | a.av6 = ((P1 + P3))
(R->P0 in ev6)
semantics1[av7, ev7]
all a: lab.T0 | a.av7 = (P2)
all a: lab.T1 | a.av7 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av7 = ((P0 + (P2 + P3)))
all a: lab.T3 | a.av7 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av7 = (P4)
all a: lab.T5 | a.av7 = ((P0 + (P1 + P3)))
all a: lab.T6 | a.av7 = ((P1 + P2))
(R->P0 in ev7)
semantics0[av8, ev8]
all a: lab.T0 | a.av8 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av8 = ((P0 + P1))
all a: lab.T2 | a.av8 = (((P0 + P2) + (P3 + P4)))
all a: lab.T3 | a.av8 = (none)
all a: lab.T4 | a.av8 = ((P1 + P4))
all a: lab.T5 | a.av8 = ((P2 + (P3 + P4)))
all a: lab.T6 | a.av8 = ((P2 + P4))
(R->P0 in ev8)
semantics2[av9, ev9]
all a: lab.T0 | a.av9 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av9 = (P3)
all a: lab.T2 | a.av9 = ((P0 + (P1 + P2)))
all a: lab.T3 | a.av9 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av9 = (P1)
all a: lab.T5 | a.av9 = (((P0 + P1) + (P2 + P4)))
all a: lab.T6 | a.av9 = ((P0 + P3))
(R->P0 in ev9)
semantics1[av10, ev10]
all a: lab.T0 | a.av10 = (none)
all a: lab.T1 | a.av10 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av10 = ((P0 + (P2 + P3)))
all a: lab.T3 | a.av10 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av10 = (((P0 + P2) + (P3 + P4)))
all a: lab.T5 | a.av10 = ((P0 + (P1 + P2)))
all a: lab.T6 | a.av10 = ((P0 + (P2 + P3)))
(R->P0 in ev10)
semantics4[av11, ev11]
all a: lab.T0 | a.av11 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av11 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av11 = ((P0 + P4))
all a: lab.T3 | a.av11 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av11 = ((P0 + (P2 + P4)))
all a: lab.T5 | a.av11 = ((P1 + P3))
all a: lab.T6 | a.av11 = ((P0 + P2))
(R->P0 in ev11)
semantics1[av12, ev12]
all a: lab.T0 | a.av12 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av12 = ((P0 + P3))
all a: lab.T2 | a.av12 = ((P1 + P2))
all a: lab.T3 | a.av12 = (P0)
all a: lab.T4 | a.av12 = ((P0 + (P3 + P4)))
all a: lab.T5 | a.av12 = ((P2 + (P3 + P4)))
all a: lab.T6 | a.av12 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev12)
semantics3[av13, ev13]
all a: lab.T0 | a.av13 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av13 = ((P1 + P3))
all a: lab.T2 | a.av13 = (((P0 + P2) + (P3 + P4)))
all a: lab.T3 | a.av13 = (((P0 + P2) + (P3 + P4)))
all a: lab.T4 | a.av13 = ((P0 + P2))
all a: lab.T5 | a.av13 = ((P2 + P3))
all a: lab.T6 | a.av13 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev13)
semantics4[av14, ev14]
all a: lab.T0 | a.av14 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av14 = ((P3 + P4))
all a: lab.T2 | a.av14 = ((P1 + (P2 + P3)))
all a: lab.T3 | a.av14 = ((P2 + P4))
all a: lab.T4 | a.av14 = ((P1 + P3))
all a: lab.T5 | a.av14 = (P4)
all a: lab.T6 | a.av14 = ((P0 + (P1 + P4)))
(R->P0 in ev14)
semantics4[av15, ev15]
all a: lab.T0 | a.av15 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av15 = (P3)
all a: lab.T2 | a.av15 = ((P1 + P2))
all a: lab.T3 | a.av15 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av15 = ((P1 + (P3 + P4)))
all a: lab.T5 | a.av15 = (((P1 + P2) + (P3 + P4)))
all a: lab.T6 | a.av15 = ((P0 + P1))
(R->P0 in ev15)
semantics2[av16, ev16]
all a: lab.T0 | a.av16 = (P2)
all a: lab.T1 | a.av16 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av16 = ((P2 + (P3 + P4)))
all a: lab.T3 | a.av16 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av16 = ((P0 + (P3 + P4)))
all a: lab.T5 | a.av16 = (((P0 + P1) + (P2 + P3)))
all a: lab.T6 | a.av16 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev16)
semantics4[av17, ev17]
all a: lab.T0 | a.av17 = ((P1 + P2))
all a: lab.T1 | a.av17 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av17 = ((P0 + P4))
all a: lab.T3 | a.av17 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av17 = ((P0 + P1))
all a: lab.T5 | a.av17 = ((P0 + P4))
all a: lab.T6 | a.av17 = ((P1 + P4))
(R->P0 in ev17)
semantics5[av18, ev18]
all a: lab.T0 | a.av18 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av18 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av18 = ((P0 + (P1 + P3)))
all a: lab.T3 | a.av18 = ((P0 + (P2 + P3)))
all a: lab.T4 | a.av18 = ((P0 + P1))
all a: lab.T5 | a.av18 = (((P0 + P1) + (P2 + P3)))
all a: lab.T6 | a.av18 = ((P0 + P1))
(R->P0 in ev18)
semantics3[av19, ev19]
all a: lab.T0 | a.av19 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av19 = (P3)
all a: lab.T2 | a.av19 = (((P0 + P1) + (P2 + P3)))
all a: lab.T3 | a.av19 = ((P0 + (P3 + P4)))
all a: lab.T4 | a.av19 = ((P0 + (P2 + P3)))
all a: lab.T5 | a.av19 = ((P1 + (P2 + P3)))
all a: lab.T6 | a.av19 = ((P0 + P3))
(R->P0 in ev19)
semantics2[av20, ev20]
all a: lab.T0 | a.av20 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av20 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av20 = ((P2 + P3))
all a: lab.T3 | a.av20 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av20 = (((P0 + P1) + (P3 + P4)))
all a: lab.T5 | a.av20 = ((P0 + (P2 + P3)))
all a: lab.T6 | a.av20 = (P2)
(R->P0 in ev20)
semantics2[av21, ev21]
all a: lab.T0 | a.av21 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av21 = ((P3 + P4))
all a: lab.T2 | a.av21 = (((P0 + P2) + (P3 + P4)))
all a: lab.T3 | a.av21 = ((P1 + (P2 + P4)))
all a: lab.T4 | a.av21 = ((P1 + P4))
all a: lab.T5 | a.av21 = ((P1 + (P2 + P4)))
all a: lab.T6 | a.av21 = ((P3 + P4))
(R->P0 in ev21)
semantics3[av22, ev22]
all a: lab.T0 | a.av22 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av22 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av22 = (((P0 + P2) + (P3 + P4)))
all a: lab.T3 | a.av22 = (P4)
all a: lab.T4 | a.av22 = ((P2 + P4))
all a: lab.T5 | a.av22 = ((P0 + (P2 + P3)))
all a: lab.T6 | a.av22 = (P2)
(R->P0 in ev22)
semantics3[av23, ev23]
all a: lab.T0 | a.av23 = (P4)
all a: lab.T1 | a.av23 = ((P0 + P1))
all a: lab.T2 | a.av23 = ((P0 + P1))
all a: lab.T3 | a.av23 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av23 = (((P0 + P1) + (P2 + P3)))
all a: lab.T5 | a.av23 = (((P0 + P1) + (P3 + P4)))
all a: lab.T6 | a.av23 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev23)
semantics3[av24, ev24]
all a: lab.T0 | a.av24 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av24 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av24 = ((P1 + P3))
all a: lab.T3 | a.av24 = ((P2 + P4))
all a: lab.T4 | a.av24 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T5 | a.av24 = ((P0 + (P1 + P4)))
all a: lab.T6 | a.av24 = ((P0 + (P1 + P4)))
(R->P0 in ev24)
semantics0[av25, ev25]
all a: lab.T0 | a.av25 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av25 = ((P3 + P4))
all a: lab.T2 | a.av25 = ((P2 + (P3 + P4)))
all a: lab.T3 | a.av25 = ((P0 + P3))
all a: lab.T4 | a.av25 = ((P1 + (P3 + P4)))
all a: lab.T5 | a.av25 = (((P0 + P1) + (P2 + P3)))
all a: lab.T6 | a.av25 = ((P1 + (P3 + P4)))
(R->P0 in ev25)
semantics2[av26, ev26]
all a: lab.T0 | a.av26 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av26 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av26 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T3 | a.av26 = (((P0 + P1) + (P2 + P3)))
all a: lab.T4 | a.av26 = (((P0 + P1) + (P2 + P4)))
all a: lab.T5 | a.av26 = ((P1 + (P3 + P4)))
all a: lab.T6 | a.av26 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev26)
semantics0[av27, ev27]
all a: lab.T0 | a.av27 = ((P1 + P4))
all a: lab.T1 | a.av27 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av27 = ((P0 + (P3 + P4)))
all a: lab.T3 | a.av27 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av27 = ((P0 + P2))
all a: lab.T5 | a.av27 = ((P1 + (P2 + P4)))
all a: lab.T6 | a.av27 = ((P0 + (P3 + P4)))
(R->P0 in ev27)
semantics4[av28, ev28]
all a: lab.T0 | a.av28 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av28 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av28 = ((P0 + (P2 + P3)))
all a: lab.T3 | a.av28 = ((P0 + P4))
all a: lab.T4 | a.av28 = ((P1 + (P3 + P4)))
all a: lab.T5 | a.av28 = ((P0 + P3))
all a: lab.T6 | a.av28 = ((P1 + (P3 + P4)))
(R->P0 in ev28)
semantics3[av29, ev29]
all a: lab.T0 | a.av29 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av29 = ((P0 + P3))
all a: lab.T2 | a.av29 = ((P2 + (P3 + P4)))
all a: lab.T3 | a.av29 = (((P0 + P1) + (P2 + P4)))
all a: lab.T4 | a.av29 = ((P2 + (P3 + P4)))
all a: lab.T5 | a.av29 = ((P0 + (P1 + P3)))
all a: lab.T6 | a.av29 = (P3)
(R->P0 in ev29)
semantics3[av30, ev30]
all a: lab.T0 | a.av30 = (P3)
all a: lab.T1 | a.av30 = ((P2 + P4))
all a: lab.T2 | a.av30 = ((P0 + (P1 + P3)))
all a: lab.T3 | a.av30 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av30 = ((P0 + (P1 + P3)))
all a: lab.T5 | a.av30 = (((P0 + P1) + (P2 + P4)))
all a: lab.T6 | a.av30 = ((P2 + (P3 + P4)))
(R->P0 in ev30)
semantics1[av31, ev31]
all a: lab.T0 | a.av31 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av31 = ((P3 + P4))
all a: lab.T2 | a.av31 = ((P2 + (P3 + P4)))
all a: lab.T3 | a.av31 = ((P1 + (P2 + P3)))
all a: lab.T4 | a.av31 = (((P0 + P1) + (P3 + P4)))
all a: lab.T5 | a.av31 = ((P0 + P1))
all a: lab.T6 | a.av31 = ((P1 + P3))
(R->P0 in ev31)
semantics1[av32, ev32]
all a: lab.T0 | a.av32 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av32 = (none)
all a: lab.T2 | a.av32 = ((P0 + P2))
all a: lab.T3 | a.av32 = ((P0 + P2))
all a: lab.T4 | a.av32 = ((P1 + (P2 + P4)))
all a: lab.T5 | a.av32 = ((P0 + (P3 + P4)))
all a: lab.T6 | a.av32 = ((P1 + P2))
(R->P0 in ev32)
semantics6[av33, ev33]
all a: lab.T0 | a.av33 = ((P0 + P3))
all a: lab.T1 | a.av33 = (none)
all a: lab.T2 | a.av33 = ((P0 + (P1 + P2)))
all a: lab.T3 | a.av33 = (((P0 + P1) + (P2 + P3)))
all a: lab.T4 | a.av33 = (((P0 + P1) + (P2 + P3)))
all a: lab.T5 | a.av33 = ((P0 + P3))
all a: lab.T6 | a.av33 = ((P0 + P1))
(R->P0 in ev33)
semantics0[av34, ev34]
all a: lab.T0 | a.av34 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av34 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av34 = (P0)
all a: lab.T3 | a.av34 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av34 = ((P0 + P1))
all a: lab.T5 | a.av34 = (((P0 + P1) + (P3 + P4)))
all a: lab.T6 | a.av34 = ((P0 + (P1 + P4)))
(R->P0 in ev34)
semantics2[av35, ev35]
all a: lab.T0 | a.av35 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av35 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av35 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T3 | a.av35 = ((P0 + (P2 + P3)))
all a: lab.T4 | a.av35 = ((P0 + (P1 + P3)))
all a: lab.T5 | a.av35 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T6 | a.av35 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev35)
semantics1[av36, ev36]
all a: lab.T0 | a.av36 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av36 = ((P0 + P1))
all a: lab.T2 | a.av36 = (((P0 + P2) + (P3 + P4)))
all a: lab.T3 | a.av36 = ((P2 + (P3 + P4)))
all a: lab.T4 | a.av36 = ((P1 + (P3 + P4)))
all a: lab.T5 | a.av36 = (((P0 + P1) + (P2 + P3)))
all a: lab.T6 | a.av36 = (P1)
(R->P0 in ev36)
semantics4[av37, ev37]
all a: lab.T0 | a.av37 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av37 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av37 = (P0)
all a: lab.T3 | a.av37 = ((P3 + P4))
all a: lab.T4 | a.av37 = ((P0 + P4))
all a: lab.T5 | a.av37 = ((P1 + P2))
all a: lab.T6 | a.av37 = ((P0 + (P1 + P4)))
(R->P0 in ev37)
semantics0[av38, ev38]
all a: lab.T0 | a.av38 = (P3)
all a: lab.T1 | a.av38 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av38 = ((P3 + P4))
all a: lab.T3 | a.av38 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av38 = (P4)
all a: lab.T5 | a.av38 = (P3)
all a: lab.T6 | a.av38 = ((P1 + (P2 + P4)))
(R->P0 in ev38)
semantics3[av39, ev39]
all a: lab.T0 | a.av39 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av39 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av39 = ((P0 + (P2 + P3)))
all a: lab.T3 | a.av39 = ((P1 + P3))
all a: lab.T4 | a.av39 = ((P0 + P4))
all a: lab.T5 | a.av39 = ((P1 + P4))
all a: lab.T6 | a.av39 = ((P0 + (P1 + P3)))
(R->P0 in ev39)
semantics2[av40, ev40]
all a: lab.T0 | a.av40 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av40 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av40 = ((P1 + (P2 + P4)))
all a: lab.T3 | a.av40 = ((P0 + P4))
all a: lab.T4 | a.av40 = ((P1 + P2))
all a: lab.T5 | a.av40 = ((P0 + (P3 + P4)))
all a: lab.T6 | a.av40 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev40)
semantics0[av41, ev41]
all a: lab.T0 | a.av41 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av41 = (P4)
all a: lab.T2 | a.av41 = ((P1 + (P2 + P3)))
all a: lab.T3 | a.av41 = (none)
all a: lab.T4 | a.av41 = ((P2 + P4))
all a: lab.T5 | a.av41 = ((P0 + (P1 + P3)))
all a: lab.T6 | a.av41 = ((P1 + P4))
(R->P0 in ev41)
semantics2[av42, ev42]
all a: lab.T0 | a.av42 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av42 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av42 = ((P0 + P4))
all a: lab.T3 | a.av42 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av42 = ((P0 + (P1 + P3)))
all a: lab.T5 | a.av42 = ((P0 + (P2 + P4)))
all a: lab.T6 | a.av42 = ((P0 + (P1 + P4)))
(R->P0 in ev42)
semantics4[av43, ev43]
all a: lab.T0 | a.av43 = (none)
all a: lab.T1 | a.av43 = ((P2 + P4))
all a: lab.T2 | a.av43 = (((P0 + P1) + (P2 + P4)))
all a: lab.T3 | a.av43 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av43 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T5 | a.av43 = ((P0 + P4))
all a: lab.T6 | a.av43 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev43)
semantics1[av44, ev44]
all a: lab.T0 | a.av44 = (P1)
all a: lab.T1 | a.av44 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av44 = ((P2 + (P3 + P4)))
all a: lab.T3 | a.av44 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av44 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T5 | a.av44 = ((P2 + (P3 + P4)))
all a: lab.T6 | a.av44 = ((P1 + P2))
(R->P0 in ev44)
semantics4[av45, ev45]
all a: lab.T0 | a.av45 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av45 = ((P1 + P2))
all a: lab.T2 | a.av45 = (((P0 + P1) + (P3 + P4)))
all a: lab.T3 | a.av45 = ((P1 + P3))
all a: lab.T4 | a.av45 = ((P0 + P3))
all a: lab.T5 | a.av45 = (P2)
all a: lab.T6 | a.av45 = (P4)
(R->P0 in ev45)
semantics1[av46, ev46]
all a: lab.T0 | a.av46 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av46 = (none)
all a: lab.T2 | a.av46 = (((P0 + P1) + (P2 + P4)))
all a: lab.T3 | a.av46 = ((P0 + (P2 + P4)))
all a: lab.T4 | a.av46 = ((P1 + P2))
all a: lab.T5 | a.av46 = ((P1 + (P2 + P3)))
all a: lab.T6 | a.av46 = (P0)
(R->P0 in ev46)
semantics1[av47, ev47]
all a: lab.T0 | a.av47 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av47 = ((P3 + P4))
all a: lab.T2 | a.av47 = ((P0 + (P2 + P4)))
all a: lab.T3 | a.av47 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av47 = ((P1 + (P2 + P4)))
all a: lab.T5 | a.av47 = ((P0 + (P3 + P4)))
all a: lab.T6 | a.av47 = ((P1 + (P3 + P4)))
(R->P0 in ev47)
semantics2[av48, ev48]
all a: lab.T0 | a.av48 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av48 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av48 = (none)
all a: lab.T3 | a.av48 = ((P0 + P4))
all a: lab.T4 | a.av48 = (none)
all a: lab.T5 | a.av48 = ((P2 + P4))
all a: lab.T6 | a.av48 = ((P0 + P4))
(R->P0 in ev48)
semantics4[av49, ev49]
all a: lab.T0 | a.av49 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av49 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av49 = (((P0 + P2) + (P3 + P4)))
all a: lab.T3 | a.av49 = (((P0 + P1) + (P2 + P3)))
all a: lab.T4 | a.av49 = ((P1 + (P3 + P4)))
all a: lab.T5 | a.av49 = (((P0 + P2) + (P3 + P4)))
all a: lab.T6 | a.av49 = ((P0 + (P1 + P4)))
(R->P0 in ev49)
semantics2[av50, ev50]
all a: lab.T0 | a.av50 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av50 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av50 = ((P0 + (P2 + P4)))
all a: lab.T3 | a.av50 = (((P0 + P2) + (P3 + P4)))
all a: lab.T4 | a.av50 = (((P0 + P1) + (P2 + P3)))
all a: lab.T5 | a.av50 = (((P1 + P2) + (P3 + P4)))
all a: lab.T6 | a.av50 = (P1)
not (R->P0 in ev50)
semantics0[av51, ev51]
all a: lab.T0 | a.av51 = (P1)
all a: lab.T1 | a.av51 = ((P1 + P4))
all a: lab.T2 | a.av51 = ((P1 + P2))
all a: lab.T3 | a.av51 = ((P2 + P3))
all a: lab.T4 | a.av51 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T5 | a.av51 = ((P2 + P3))
all a: lab.T6 | a.av51 = ((P0 + (P2 + P3)))
not (R->P0 in ev51)
semantics1[av52, ev52]
all a: lab.T0 | a.av52 = (P4)
all a: lab.T1 | a.av52 = (none)
all a: lab.T2 | a.av52 = ((P0 + (P2 + P3)))
all a: lab.T3 | a.av52 = ((P0 + (P2 + P3)))
all a: lab.T4 | a.av52 = ((P0 + (P1 + P4)))
all a: lab.T5 | a.av52 = ((P0 + (P3 + P4)))
all a: lab.T6 | a.av52 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev52)
semantics2[av53, ev53]
all a: lab.T0 | a.av53 = ((P2 + P4))
all a: lab.T1 | a.av53 = ((P0 + P2))
all a: lab.T2 | a.av53 = ((P0 + (P1 + P4)))
all a: lab.T3 | a.av53 = (none)
all a: lab.T4 | a.av53 = (P2)
all a: lab.T5 | a.av53 = ((P2 + P3))
all a: lab.T6 | a.av53 = ((P0 + P4))
not (R->P0 in ev53)
semantics0[av54, ev54]
all a: lab.T0 | a.av54 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av54 = (P0)
all a: lab.T2 | a.av54 = ((P2 + P4))
all a: lab.T3 | a.av54 = ((P0 + P4))
all a: lab.T4 | a.av54 = ((P2 + P3))
all a: lab.T5 | a.av54 = ((P0 + P3))
all a: lab.T6 | a.av54 = ((P0 + (P1 + P4)))
not (R->P0 in ev54)
semantics0[av55, ev55]
all a: lab.T0 | a.av55 = (P1)
all a: lab.T1 | a.av55 = ((P1 + P2))
all a: lab.T2 | a.av55 = ((P0 + P3))
all a: lab.T3 | a.av55 = (P4)
all a: lab.T4 | a.av55 = ((P0 + P3))
all a: lab.T5 | a.av55 = ((P1 + P4))
all a: lab.T6 | a.av55 = ((P0 + (P1 + P4)))
not (R->P0 in ev55)
semantics3[av56, ev56]
all a: lab.T0 | a.av56 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av56 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av56 = (((P0 + P2) + (P3 + P4)))
all a: lab.T3 | a.av56 = ((P3 + P4))
all a: lab.T4 | a.av56 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T5 | a.av56 = ((P1 + (P2 + P3)))
all a: lab.T6 | a.av56 = (none)
not (R->P0 in ev56)
semantics4[av57, ev57]
all a: lab.T0 | a.av57 = (P3)
all a: lab.T1 | a.av57 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av57 = (((P0 + P1) + (P3 + P4)))
all a: lab.T3 | a.av57 = ((P2 + P4))
all a: lab.T4 | a.av57 = ((P1 + P3))
all a: lab.T5 | a.av57 = ((P0 + P4))
all a: lab.T6 | a.av57 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev57)
semantics3[av58, ev58]
all a: lab.T0 | a.av58 = (P3)
all a: lab.T1 | a.av58 = ((P0 + P2))
all a: lab.T2 | a.av58 = ((P0 + (P1 + P4)))
all a: lab.T3 | a.av58 = ((P0 + (P1 + P3)))
all a: lab.T4 | a.av58 = (((P1 + P2) + (P3 + P4)))
all a: lab.T5 | a.av58 = (P3)
all a: lab.T6 | a.av58 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev58)
semantics2[av59, ev59]
all a: lab.T0 | a.av59 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av59 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av59 = ((P0 + P1))
all a: lab.T3 | a.av59 = ((P1 + P4))
all a: lab.T4 | a.av59 = ((P1 + P3))
all a: lab.T5 | a.av59 = (P3)
all a: lab.T6 | a.av59 = ((P2 + P4))
not (R->P0 in ev59)
semantics4[av60, ev60]
all a: lab.T0 | a.av60 = (P2)
all a: lab.T1 | a.av60 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av60 = ((P1 + (P3 + P4)))
all a: lab.T3 | a.av60 = ((P0 + P3))
all a: lab.T4 | a.av60 = ((P0 + P1))
all a: lab.T5 | a.av60 = ((P2 + P3))
all a: lab.T6 | a.av60 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev60)
semantics3[av61, ev61]
all a: lab.T0 | a.av61 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av61 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av61 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T3 | a.av61 = ((P0 + (P2 + P4)))
all a: lab.T4 | a.av61 = ((P1 + P3))
all a: lab.T5 | a.av61 = ((P0 + (P1 + P3)))
all a: lab.T6 | a.av61 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev61)
semantics1[av62, ev62]
all a: lab.T0 | a.av62 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av62 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av62 = ((P0 + P1))
all a: lab.T3 | a.av62 = ((P0 + (P2 + P3)))
all a: lab.T4 | a.av62 = ((P2 + P3))
all a: lab.T5 | a.av62 = (P2)
all a: lab.T6 | a.av62 = ((P0 + (P1 + P3)))
not (R->P0 in ev62)
semantics1[av63, ev63]
all a: lab.T0 | a.av63 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av63 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av63 = ((P2 + P4))
all a: lab.T3 | a.av63 = (((P0 + P1) + (P2 + P3)))
all a: lab.T4 | a.av63 = (P3)
all a: lab.T5 | a.av63 = ((P0 + P1))
all a: lab.T6 | a.av63 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev63)
semantics3[av64, ev64]
all a: lab.T0 | a.av64 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av64 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av64 = ((P0 + P3))
all a: lab.T3 | a.av64 = ((P0 + (P3 + P4)))
all a: lab.T4 | a.av64 = (((P0 + P2) + (P3 + P4)))
all a: lab.T5 | a.av64 = ((P0 + (P1 + P3)))
all a: lab.T6 | a.av64 = ((P1 + (P2 + P3)))
not (R->P0 in ev64)
semantics3[av65, ev65]
all a: lab.T0 | a.av65 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av65 = (none)
all a: lab.T2 | a.av65 = ((P0 + P3))
all a: lab.T3 | a.av65 = ((P0 + (P2 + P3)))
all a: lab.T4 | a.av65 = ((P1 + P4))
all a: lab.T5 | a.av65 = ((P1 + (P2 + P3)))
all a: lab.T6 | a.av65 = (P4)
not (R->P0 in ev65)
semantics0[av66, ev66]
all a: lab.T0 | a.av66 = ((P0 + P3))
all a: lab.T1 | a.av66 = ((P2 + P4))
all a: lab.T2 | a.av66 = ((P1 + (P2 + P3)))
all a: lab.T3 | a.av66 = (P1)
all a: lab.T4 | a.av66 = ((P2 + P3))
all a: lab.T5 | a.av66 = (((P0 + P1) + (P2 + P4)))
all a: lab.T6 | a.av66 = ((P0 + (P1 + P4)))
not (R->P0 in ev66)
semantics3[av67, ev67]
all a: lab.T0 | a.av67 = ((P2 + P3))
all a: lab.T1 | a.av67 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av67 = ((P0 + P1))
all a: lab.T3 | a.av67 = (none)
all a: lab.T4 | a.av67 = ((P1 + (P2 + P4)))
all a: lab.T5 | a.av67 = ((P2 + (P3 + P4)))
all a: lab.T6 | a.av67 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev67)
semantics1[av68, ev68]
all a: lab.T0 | a.av68 = (P3)
all a: lab.T1 | a.av68 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av68 = ((P0 + P4))
all a: lab.T3 | a.av68 = ((P0 + (P2 + P4)))
all a: lab.T4 | a.av68 = (((P0 + P1) + (P3 + P4)))
all a: lab.T5 | a.av68 = ((P0 + (P2 + P3)))
all a: lab.T6 | a.av68 = ((P0 + P1))
not (R->P0 in ev68)
semantics4[av69, ev69]
all a: lab.T0 | a.av69 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av69 = (P0)
all a: lab.T2 | a.av69 = ((P0 + (P3 + P4)))
all a: lab.T3 | a.av69 = (P3)
all a: lab.T4 | a.av69 = ((P0 + (P1 + P4)))
all a: lab.T5 | a.av69 = ((P0 + (P1 + P2)))
all a: lab.T6 | a.av69 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev69)
semantics0[av70, ev70]
all a: lab.T0 | a.av70 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av70 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av70 = ((P1 + P3))
all a: lab.T3 | a.av70 = ((P2 + (P3 + P4)))
all a: lab.T4 | a.av70 = ((P2 + P3))
all a: lab.T5 | a.av70 = ((P0 + (P1 + P4)))
all a: lab.T6 | a.av70 = ((P0 + P4))
not (R->P0 in ev70)
semantics2[av71, ev71]
all a: lab.T0 | a.av71 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av71 = ((P1 + P4))
all a: lab.T2 | a.av71 = ((P0 + P2))
all a: lab.T3 | a.av71 = (((P0 + P1) + (P2 + P4)))
all a: lab.T4 | a.av71 = (P1)
all a: lab.T5 | a.av71 = (none)
all a: lab.T6 | a.av71 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev71)
semantics1[av72, ev72]
all a: lab.T0 | a.av72 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av72 = (none)
all a: lab.T2 | a.av72 = ((P2 + P4))
all a: lab.T3 | a.av72 = (P0)
all a: lab.T4 | a.av72 = (((P0 + P1) + (P3 + P4)))
all a: lab.T5 | a.av72 = (none)
all a: lab.T6 | a.av72 = (P3)
not (R->P0 in ev72)
semantics0[av73, ev73]
all a: lab.T0 | a.av73 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av73 = ((P2 + P4))
all a: lab.T2 | a.av73 = ((P0 + (P1 + P3)))
all a: lab.T3 | a.av73 = ((P0 + (P1 + P2)))
all a: lab.T4 | a.av73 = (P1)
all a: lab.T5 | a.av73 = (((P1 + P2) + (P3 + P4)))
all a: lab.T6 | a.av73 = (P2)
not (R->P0 in ev73)
semantics1[av74, ev74]
all a: lab.T0 | a.av74 = ((P0 + P3))
all a: lab.T1 | a.av74 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av74 = ((P1 + (P2 + P4)))
all a: lab.T3 | a.av74 = (((P1 + P2) + (P3 + P4)))
all a: lab.T4 | a.av74 = ((P2 + (P3 + P4)))
all a: lab.T5 | a.av74 = ((P1 + P3))
all a: lab.T6 | a.av74 = ((P2 + (P3 + P4)))
not (R->P0 in ev74)
semantics4[av75, ev75]
all a: lab.T0 | a.av75 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av75 = (none)
all a: lab.T2 | a.av75 = ((P3 + P4))
all a: lab.T3 | a.av75 = ((P1 + (P2 + P3)))
all a: lab.T4 | a.av75 = ((P1 + P4))
all a: lab.T5 | a.av75 = ((P0 + (P1 + P2)))
all a: lab.T6 | a.av75 = ((P0 + P2))
not (R->P0 in ev75)
semantics4[av76, ev76]
all a: lab.T0 | a.av76 = ((P2 + P3))
all a: lab.T1 | a.av76 = ((P1 + P4))
all a: lab.T2 | a.av76 = ((P0 + (P2 + P3)))
all a: lab.T3 | a.av76 = (P3)
all a: lab.T4 | a.av76 = (P0)
all a: lab.T5 | a.av76 = ((P0 + (P2 + P4)))
all a: lab.T6 | a.av76 = (P3)
not (R->P0 in ev76)
semantics1[av77, ev77]
all a: lab.T0 | a.av77 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av77 = (P3)
all a: lab.T2 | a.av77 = (P4)
all a: lab.T3 | a.av77 = (P1)
all a: lab.T4 | a.av77 = ((P0 + P4))
all a: lab.T5 | a.av77 = ((P1 + P3))
all a: lab.T6 | a.av77 = ((P1 + P4))
not (R->P0 in ev77)
semantics0[av78, ev78]
all a: lab.T0 | a.av78 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av78 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av78 = (((P0 + P1) + (P2 + P3)))
all a: lab.T3 | a.av78 = ((P3 + P4))
all a: lab.T4 | a.av78 = (P0)
all a: lab.T5 | a.av78 = (P3)
all a: lab.T6 | a.av78 = (P0)
not (R->P0 in ev78)
semantics3[av79, ev79]
all a: lab.T0 | a.av79 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av79 = ((P0 + P3))
all a: lab.T2 | a.av79 = (P2)
all a: lab.T3 | a.av79 = (((P0 + P1) + (P2 + P4)))
all a: lab.T4 | a.av79 = ((P0 + (P1 + P2)))
all a: lab.T5 | a.av79 = (P4)
all a: lab.T6 | a.av79 = ((P0 + P3))
not (R->P0 in ev79)
semantics3[av80, ev80]
all a: lab.T0 | a.av80 = (P2)
all a: lab.T1 | a.av80 = ((P1 + P4))
all a: lab.T2 | a.av80 = ((P0 + (P2 + P4)))
all a: lab.T3 | a.av80 = ((P0 + (P3 + P4)))
all a: lab.T4 | a.av80 = (P4)
all a: lab.T5 | a.av80 = ((P0 + P4))
all a: lab.T6 | a.av80 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev80)
semantics3[av81, ev81]
all a: lab.T0 | a.av81 = ((P2 + P3))
all a: lab.T1 | a.av81 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av81 = ((P2 + P4))
all a: lab.T3 | a.av81 = ((P1 + (P2 + P3)))
all a: lab.T4 | a.av81 = ((P0 + (P3 + P4)))
all a: lab.T5 | a.av81 = ((P2 + (P3 + P4)))
all a: lab.T6 | a.av81 = (P0)
not (R->P0 in ev81)
semantics4[av82, ev82]
all a: lab.T0 | a.av82 = (none)
all a: lab.T1 | a.av82 = ((P2 + P3))
all a: lab.T2 | a.av82 = ((P2 + P3))
all a: lab.T3 | a.av82 = ((P3 + P4))
all a: lab.T4 | a.av82 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T5 | a.av82 = ((P0 + P1))
all a: lab.T6 | a.av82 = ((P3 + P4))
not (R->P0 in ev82)
semantics4[av83, ev83]
all a: lab.T0 | a.av83 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av83 = (none)
all a: lab.T2 | a.av83 = (P1)
all a: lab.T3 | a.av83 = ((P3 + P4))
all a: lab.T4 | a.av83 = (((P0 + P2) + (P3 + P4)))
all a: lab.T5 | a.av83 = ((P1 + (P2 + P4)))
all a: lab.T6 | a.av83 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev83)
semantics3[av84, ev84]
all a: lab.T0 | a.av84 = ((P0 + P4))
all a: lab.T1 | a.av84 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av84 = ((P0 + (P2 + P3)))
all a: lab.T3 | a.av84 = ((P1 + P3))
all a: lab.T4 | a.av84 = ((P2 + P4))
all a: lab.T5 | a.av84 = ((P0 + (P1 + P4)))
all a: lab.T6 | a.av84 = ((P0 + (P1 + P4)))
not (R->P0 in ev84)
semantics4[av85, ev85]
all a: lab.T0 | a.av85 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av85 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av85 = ((P0 + P3))
all a: lab.T3 | a.av85 = ((P0 + (P2 + P4)))
all a: lab.T4 | a.av85 = (((P0 + P1) + (P2 + P4)))
all a: lab.T5 | a.av85 = ((P0 + P2))
all a: lab.T6 | a.av85 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev85)
semantics0[av86, ev86]
all a: lab.T0 | a.av86 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av86 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av86 = (none)
all a: lab.T3 | a.av86 = ((P1 + (P2 + P3)))
all a: lab.T4 | a.av86 = ((P0 + P4))
all a: lab.T5 | a.av86 = ((P0 + P2))
all a: lab.T6 | a.av86 = ((P0 + (P3 + P4)))
not (R->P0 in ev86)
semantics2[av87, ev87]
all a: lab.T0 | a.av87 = ((P2 + P3))
all a: lab.T1 | a.av87 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av87 = ((P1 + (P2 + P3)))
all a: lab.T3 | a.av87 = (((P1 + P2) + (P3 + P4)))
all a: lab.T4 | a.av87 = (P1)
all a: lab.T5 | a.av87 = (((P0 + P1) + (P2 + P3)))
all a: lab.T6 | a.av87 = ((P1 + (P3 + P4)))
not (R->P0 in ev87)
semantics2[av88, ev88]
all a: lab.T0 | a.av88 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av88 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av88 = ((P1 + (P2 + P3)))
all a: lab.T3 | a.av88 = (((P0 + P2) + (P3 + P4)))
all a: lab.T4 | a.av88 = ((P1 + (P3 + P4)))
all a: lab.T5 | a.av88 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T6 | a.av88 = ((P1 + (P2 + P4)))
not (R->P0 in ev88)
semantics1[av89, ev89]
all a: lab.T0 | a.av89 = ((P0 + P1))
all a: lab.T1 | a.av89 = ((P0 + P1))
all a: lab.T2 | a.av89 = (((P0 + P2) + (P3 + P4)))
all a: lab.T3 | a.av89 = (P0)
all a: lab.T4 | a.av89 = ((P0 + P4))
all a: lab.T5 | a.av89 = ((P1 + (P2 + P3)))
all a: lab.T6 | a.av89 = ((P2 + (P3 + P4)))
not (R->P0 in ev89)
semantics1[av90, ev90]
all a: lab.T0 | a.av90 = ((P2 + P3))
all a: lab.T1 | a.av90 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av90 = (((P0 + P1) + (P2 + P3)))
all a: lab.T3 | a.av90 = ((P2 + (P3 + P4)))
all a: lab.T4 | a.av90 = (P1)
all a: lab.T5 | a.av90 = (((P0 + P1) + (P2 + P3)))
all a: lab.T6 | a.av90 = (P3)
not (R->P0 in ev90)
semantics0[av91, ev91]
all a: lab.T0 | a.av91 = ((P2 + P4))
all a: lab.T1 | a.av91 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av91 = (((P0 + P1) + (P3 + P4)))
all a: lab.T3 | a.av91 = ((P0 + (P3 + P4)))
all a: lab.T4 | a.av91 = ((P0 + (P1 + P4)))
all a: lab.T5 | a.av91 = (P4)
all a: lab.T6 | a.av91 = ((P1 + P3))
not (R->P0 in ev91)
semantics4[av92, ev92]
all a: lab.T0 | a.av92 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av92 = ((P1 + P4))
all a: lab.T2 | a.av92 = ((P0 + (P1 + P2)))
all a: lab.T3 | a.av92 = (((P1 + P2) + (P3 + P4)))
all a: lab.T4 | a.av92 = ((P1 + (P2 + P3)))
all a: lab.T5 | a.av92 = ((P1 + P3))
all a: lab.T6 | a.av92 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev92)
semantics3[av93, ev93]
all a: lab.T0 | a.av93 = (P4)
all a: lab.T1 | a.av93 = ((P2 + P3))
all a: lab.T2 | a.av93 = ((P0 + (P3 + P4)))
all a: lab.T3 | a.av93 = ((P0 + (P1 + P2)))
all a: lab.T4 | a.av93 = ((P0 + (P2 + P4)))
all a: lab.T5 | a.av93 = ((P0 + P1))
all a: lab.T6 | a.av93 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev93)
semantics1[av94, ev94]
all a: lab.T0 | a.av94 = ((P0 + P3))
all a: lab.T1 | a.av94 = ((P0 + P3))
all a: lab.T2 | a.av94 = ((P1 + (P2 + P4)))
all a: lab.T3 | a.av94 = ((P1 + (P3 + P4)))
all a: lab.T4 | a.av94 = (P2)
all a: lab.T5 | a.av94 = (((P0 + P2) + (P3 + P4)))
all a: lab.T6 | a.av94 = ((P1 + (P2 + P3)))
not (R->P0 in ev94)
semantics4[av95, ev95]
all a: lab.T0 | a.av95 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av95 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av95 = ((P0 + (P2 + P3)))
all a: lab.T3 | a.av95 = (((P0 + P1) + (P2 + P3)))
all a: lab.T4 | a.av95 = ((P1 + P2))
all a: lab.T5 | a.av95 = (((P0 + P1) + (P3 + P4)))
all a: lab.T6 | a.av95 = ((P0 + (P1 + P2)))
not (R->P0 in ev95)
semantics2[av96, ev96]
all a: lab.T0 | a.av96 = ((P1 + P2))
all a: lab.T1 | a.av96 = ((P0 + P4))
all a: lab.T2 | a.av96 = ((P1 + P4))
all a: lab.T3 | a.av96 = (((P0 + P1) + (P2 + P4)))
all a: lab.T4 | a.av96 = ((P1 + (P2 + P3)))
all a: lab.T5 | a.av96 = ((P0 + P1))
all a: lab.T6 | a.av96 = ((P0 + P2))
not (R->P0 in ev96)
semantics3[av97, ev97]
all a: lab.T0 | a.av97 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av97 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av97 = ((P0 + (P2 + P3)))
all a: lab.T3 | a.av97 = ((P0 + P2))
all a: lab.T4 | a.av97 = ((P0 + P1))
all a: lab.T5 | a.av97 = ((P0 + (P1 + P2)))
all a: lab.T6 | a.av97 = ((P2 + P3))
not (R->P0 in ev97)
semantics1[av98, ev98]
all a: lab.T0 | a.av98 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av98 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av98 = ((P1 + P3))
all a: lab.T3 | a.av98 = (((P0 + P1) + (P3 + P4)))
all a: lab.T4 | a.av98 = ((P0 + P2))
all a: lab.T5 | a.av98 = ((P0 + P2))
all a: lab.T6 | a.av98 = (P0)
not (R->P0 in ev98)
semantics4[av99, ev99]
all a: lab.T0 | a.av99 = ((P1 + P3))
all a: lab.T1 | a.av99 = ((P0 + P3))
all a: lab.T2 | a.av99 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T3 | a.av99 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T4 | a.av99 = ((P2 + P4))
all a: lab.T5 | a.av99 = ((P1 + P4))
all a: lab.T6 | a.av99 = ((P0 + (P2 + P3)))
not (R->P0 in ev99)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int

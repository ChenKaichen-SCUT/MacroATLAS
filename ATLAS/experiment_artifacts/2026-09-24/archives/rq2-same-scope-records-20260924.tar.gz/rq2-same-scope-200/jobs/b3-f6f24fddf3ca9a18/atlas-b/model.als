open util/ordering[SeqIdx]

abstract sig DAGNode {
	l: set DAGNode,
	r: set DAGNode
}
fact {
	all n: DAGNode | n not in n.^(l + r)
}

sig And, Or, Imply extends DAGNode {} {
	one l
	one r
}

sig Neg, G extends DAGNode {} {
    one l
    no r
}
abstract sig Literal extends DAGNode {} {
	no l
	no r
}

abstract sig SeqIdx {}
abstract sig Trace {
	lasso: SeqIdx -> SeqIdx,
	valuation: DAGNode -> SeqIdx
} {
	// Negation
    all n: Neg, i: seqRange | n->i in valuation iff n.l->i not in valuation
	// Or
    all n: Or, i: seqRange | n->i in valuation iff (n.l->i in valuation or n.r->i in valuation)
	// And
    all n: And, i: seqRange | n->i in valuation iff (n.l->i in valuation and n.r->i in valuation)
	// Imply
    all n: Imply, i: seqRange | n->i in valuation iff (n.l->i not in valuation or n.r->i in valuation)
	// G
    all n: G, i: seqRange | n->i in valuation iff all i': futureIdx[i] | n.l->i' in valuation
    // X
    
	// F
    
	// Until
    
}
fun seqRange[t: Trace]: set SeqIdx {
	let lastOfTrace = t.lasso.SeqIdx | lastOfTrace.prevs + lastOfTrace
}
fun futureIdx[t: Trace, i: SeqIdx]: set SeqIdx {
	i.^((next :> seqRange[t]) + t.lasso) + i
}
abstract sig PositiveTrace extends Trace {}
abstract sig NegativeTrace extends Trace {}
one sig x0, x1, x2 extends Literal {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9 extends SeqIdx {}
fact {
    first = T0
    next = T0->T1 + T1->T2 + T2->T3 + T3->T4 + T4->T5 + T5->T6 + T6->T7 + T7->T8 + T8->T9
}

one sig PT0 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x2->T7 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig PT1 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x1->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x1->T7 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T4 + x0->T5 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9) & valuation
}

one sig PT2 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x1->T6 + x0->T8 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x0->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x2->T8 + x2->T9) & valuation
}

one sig PT3 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x2->T8 + x1->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T4 + x2->T5 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT4 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x2->T4 + x0->T6 + x1->T6 + x2->T6 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig PT5 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T4 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x2->T5 + x2->T6 + x2->T8) & valuation
}

one sig PT6 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x2->T2 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x2->T7 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig PT7 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T3 + x1->T6 + x1->T7 + x0->T8 + x1->T8 + x2->T8 + x1->T9 in valuation
    no (x0->T0 + x0->T1 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T9 + x2->T9) & valuation
}

one sig PT8 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x0->T3 + x1->T3 + x0->T5 + x2->T5 + x0->T7 + x1->T7) & valuation
}

one sig PT9 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T5 + x1->T6 + x1->T7 + x2->T7 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T4 + x0->T5 + x1->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig PT10 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T2 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x2->T7 + x2->T8 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT11 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T3 + x0->T4 + x1->T4 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT12 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x2->T1 + x1->T3 + x2->T3 + x0->T5 + x1->T5 + x1->T6 + x2->T6 + x2->T7 + x0->T8 + x1->T8 + x1->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x0->T6 + x0->T7 + x1->T7 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT13 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x2->T9 in valuation
    no (x0->T0 + x0->T2 + x2->T2 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT14 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T0 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x2->T4 + x1->T5 + x2->T5 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x2->T8 + x2->T9) & valuation
}

one sig PT15 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x1->T7 + x2->T7 + x2->T8 + x1->T9 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x0->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x0->T8 + x1->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT16 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x0->T6 + x1->T6 + x2->T7 + x0->T8 + x1->T8 + x1->T9 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x0->T3 + x2->T3 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x2->T6 + x0->T7 + x1->T7 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT17 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x1->T5 + x2->T5 + x2->T6 + x1->T7 + x0->T8 + x1->T8 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x2->T4 + x0->T5 + x0->T6 + x1->T6 + x0->T7 + x2->T7 + x2->T8 + x0->T9) & valuation
}

one sig PT18 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T4 + x2->T4 + x1->T5 + x1->T6 + x1->T7 + x0->T8 + x1->T8 in valuation
    no (x2->T0 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x2->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig PT19 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T1 + x2->T2 + x1->T3 + x0->T6 + x1->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x2->T6 + x0->T7 + x0->T8 + x2->T9) & valuation
}

one sig PT20 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x1->T7 + x0->T8 + x1->T8 + x2->T8 + x1->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T7 + x2->T7 + x0->T9 + x2->T9) & valuation
}

one sig PT21 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x2->T4 + x1->T6 + x2->T6 + x1->T7 + x0->T8 + x1->T8 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x0->T7 + x2->T7 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT22 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T5 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x1->T6 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig PT23 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T4 + x1->T6 + x2->T6 + x2->T7 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x2->T8) & valuation
}

one sig PT24 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T1 + x2->T2 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T5 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x2->T9) & valuation
}

one sig PT25 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T1 + x1->T1 + x2->T1 + x2->T2 + x2->T3 + x1->T5 + x1->T6 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7) & valuation
}

one sig PT26 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T5 + x0->T6 + x0->T8 + x0->T9) & valuation
}

one sig PT27 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T1 + x2->T2 + x2->T3 + x1->T4 + x0->T5 + x1->T5 + x1->T6 + x2->T6 + x1->T7 + x1->T8 + x2->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 + x2->T5 + x0->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T9) & valuation
}

one sig PT28 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T7 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x2->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig PT29 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T7 + x2->T8 + x2->T9 in valuation
    no (x0->T1 + x0->T3 + x2->T3 + x0->T4 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT30 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T0 + x1->T1 + x2->T1 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x1->T8 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x2->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig PT31 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T5 + x1->T5 + x2->T6 + x2->T7 + x0->T8 + x1->T8 + x2->T8 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig PT32 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T5 + x1->T6 + x1->T7 + x1->T8 + x2->T8 + x1->T9 in valuation
    no (x2->T0 + x0->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT33 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x2->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT34 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x1->T8 + x2->T8 in valuation
    no (x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T4 + x2->T5 + x2->T6 + x2->T7 + x0->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig PT35 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T7 + x1->T7 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T6 + x1->T6 + x2->T6 + x2->T7 + x0->T8 + x1->T8 + x2->T8) & valuation
}

one sig PT36 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T1 + x2->T2 + x2->T3 + x2->T4 + x0->T8 + x1->T8 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT37 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T0 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x2->T5 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8) & valuation
}

one sig PT38 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T1 + x2->T2 + x2->T3 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x0->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT39 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T4 + x2->T6 + x1->T7 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x0->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9) & valuation
}

one sig PT40 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x1->T1 + x1->T3 + x2->T3 + x1->T4 + x2->T5 + x0->T6 + x1->T6 + x0->T8 + x1->T8 + x1->T9 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT41 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T4 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x0->T7 + x0->T8 + x2->T8 + x2->T9) & valuation
}

one sig PT42 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x2->T5 + x0->T6 + x0->T8 + x2->T9) & valuation
}

one sig PT43 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T1 + x2->T2 + x2->T3 + x0->T5 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T8 + x2->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x2->T9) & valuation
}

one sig PT44 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x1->T6 + x2->T6 + x1->T8 + x2->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T5 + x1->T5 + x0->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x2->T9) & valuation
}

one sig PT45 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x1->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x2->T0 + x2->T1 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x0->T6 + x0->T8 + x2->T8) & valuation
}

one sig PT46 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T8 + x1->T8 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x2->T4 + x0->T5 + x0->T7 + x1->T7 + x2->T7 + x2->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig PT47 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x1->T4 + x1->T6 + x0->T7 + x1->T7 + x2->T7 + x1->T8 + x2->T8 in valuation
    no (x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig PT48 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T4 + x1->T6 + x1->T7 + x2->T7 + x2->T9 in valuation
    no (x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT49 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T0 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x1->T5 + x0->T6 + x1->T6 + x0->T8 + x1->T8 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 + x0->T5 + x2->T5 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT50 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T6 + x2->T6 + x1->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x0->T7 + x2->T7 + x0->T8 + x0->T9) & valuation
}

one sig PT51 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x0->T9 + x1->T9 in valuation
    no (x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T6 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x2->T9) & valuation
}

one sig PT52 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T3 + x1->T3 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T9 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x2->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT53 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x2->T6 + x0->T8 + x1->T8 + x2->T9 in valuation
    no (x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x2->T7 + x2->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT54 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T0 + x1->T2 + x2->T3 + x2->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x2->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T9) & valuation
}

one sig PT55 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T4 + x1->T4 + x2->T5 + x0->T6 + x1->T6 + x1->T7 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 + x0->T5 + x1->T5 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig PT56 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4 + x2->T5 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig PT57 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T2 + x2->T2 + x2->T3 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x2->T8 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T8 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT58 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x1->T5 + x1->T6 + x2->T6 + x2->T7 + x1->T9 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T5 + x2->T5 + x0->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT59 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x1->T6 + x1->T7 + x1->T8 + x1->T9 in valuation
    no (x2->T0 + x0->T1 + x2->T3 + x0->T4 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT60 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x1->T6 + x2->T6 + x1->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T4 + x2->T5 + x0->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x2->T8) & valuation
}

one sig PT61 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T1 + x2->T2 + x1->T3 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x2->T8 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x2->T6 + x2->T7 + x0->T9 + x2->T9) & valuation
}

one sig PT62 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x0->T6 + x1->T6 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T5 + x1->T5 + x2->T6 + x0->T7 + x2->T9) & valuation
}

one sig PT63 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T1 + x1->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x1->T6 + x2->T7 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9) & valuation
}

one sig PT64 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T3 + x0->T4 + x0->T6 + x0->T7 + x2->T7 + x2->T8) & valuation
}

one sig PT65 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T0 + x2->T1 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x0->T7 + x1->T7 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x2->T9) & valuation
}

one sig PT66 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T7 + x2->T8 + x2->T9) & valuation
}

one sig PT67 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T6 + x1->T7 + x0->T8 + x1->T8 + x2->T8 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x2->T3 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x0->T7 + x2->T7 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig PT68 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T1 + x1->T1 + x1->T2 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x2->T6 + x0->T7 + x1->T7 + x1->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T6 + x1->T6 + x2->T7 + x0->T8) & valuation
}

one sig PT69 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T1 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x2->T9) & valuation
}


one sig NT0 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x0->T4 + x0->T6 + x2->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x0->T8 + x0->T9) & valuation
}

one sig NT1 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x0->T5 + x2->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4 + x1->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT2 extends NegativeTrace {} {
    lasso = T9->T0
    x2->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x2->T6 + x0->T7 + x1->T7 + x0->T8 + x0->T9 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x2->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT3 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 + x1->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT4 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x0->T7 + x0->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x1->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x1->T8) & valuation
}

one sig NT5 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT6 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x0->T5 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x0->T6 + x2->T6 + x2->T7 + x1->T8 + x1->T9) & valuation
}

one sig NT7 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x0->T8 + x2->T8 + x0->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T7 + x2->T7 + x1->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT8 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x0->T9 + x2->T9 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T3 + x2->T3 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x0->T7 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT9 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x0->T6 + x2->T6 + x1->T7 + x0->T8 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T4 + x1->T5 + x2->T5 + x1->T6 + x0->T7 + x2->T7 + x1->T8 + x0->T9) & valuation
}

one sig NT10 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x2->T4 + x0->T5 + x1->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x0->T9 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT11 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T4 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig NT12 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x2->T4 + x0->T5 + x0->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x1->T5 + x2->T5 + x1->T6 + x0->T7 + x1->T9) & valuation
}

one sig NT13 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x1->T5 + x1->T6 + x1->T7 + x1->T8 + x1->T9) & valuation
}

one sig NT14 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T1 + x2->T2 + x0->T3 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x1->T6 + x0->T7 + x1->T9 + x2->T9) & valuation
}

one sig NT15 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x0->T5 + x0->T7 + x1->T8 + x0->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT16 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x0->T5 + x0->T6 + x1->T6 + x0->T7 + x2->T7 + x1->T8 + x1->T9 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x2->T6 + x1->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig NT17 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T7 + x0->T8 + x2->T8 + x0->T9 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x2->T7 + x1->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT18 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x1->T9 + x2->T9 in valuation
    no (x2->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 + x2->T4 + x1->T5 + x0->T8 + x1->T8 + x2->T8 + x0->T9) & valuation
}

one sig NT19 extends NegativeTrace {} {
    lasso = T9->T0
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 + x0->T5 + x0->T6 + x0->T7 + x1->T8 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x1->T9) & valuation
}

one sig NT20 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x0->T6 + x0->T7 + x2->T9 in valuation
    no (x1->T0 + x2->T1 + x0->T2 + x0->T3 + x1->T4 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9) & valuation
}

one sig NT21 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x1->T5 + x1->T6 + x1->T7 + x2->T7 + x1->T8 + x1->T9) & valuation
}

one sig NT22 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x1->T6 + x0->T7 + x0->T8 + x2->T9 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x0->T9 + x1->T9) & valuation
}

one sig NT23 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x2->T9 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig NT24 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x2->T7 + x1->T8 + x1->T9) & valuation
}

one sig NT25 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x2->T0 + x0->T2 + x0->T3 + x1->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x1->T7 + x1->T8 + x1->T9) & valuation
}

one sig NT26 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x0->T5 + x0->T7 + x2->T7 + x2->T8 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x2->T9) & valuation
}

one sig NT27 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T5 + x1->T6 + x0->T7 + x0->T8 + x1->T8 + x2->T8 + x1->T9 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x0->T3 + x1->T3 + x0->T4 + x2->T4 + x0->T5 + x1->T5 + x0->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T9 + x2->T9) & valuation
}

one sig NT28 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x0->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x1->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT29 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x2->T6 + x1->T7 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x0->T7 + x2->T7 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT30 extends NegativeTrace {} {
    lasso = T9->T0
    x2->T0 + x2->T1 + x0->T2 + x2->T3 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T7 + x1->T7 + x2->T7) & valuation
}

one sig NT31 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T2 + x0->T3 + x1->T4 + x2->T5 + x0->T6 + x2->T6 + x1->T7 + x0->T8 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x1->T5 + x1->T6 + x0->T7 + x2->T7 + x1->T8 + x2->T8 + x0->T9) & valuation
}

one sig NT32 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x1->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4 + x1->T5 + x1->T6 + x1->T7 + x1->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT33 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x0->T6 + x0->T7 + x2->T7 + x0->T8 + x0->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT34 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x0->T5 + x0->T7 + x0->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT35 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x0->T7 + x1->T7 + x1->T8 + x2->T9 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x0->T5 + x0->T6 + x2->T6 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x1->T9) & valuation
}

one sig NT36 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T5 + x0->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T8 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig NT37 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x0->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x1->T9 + x2->T9 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x1->T8 + x2->T8 + x0->T9) & valuation
}

one sig NT38 extends NegativeTrace {} {
    lasso = T9->T0
    x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x0->T5 + x0->T6 + x1->T6 + x0->T7 + x0->T8 + x0->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT39 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x2->T7 + x0->T8 + x0->T9 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT40 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x2->T1 + x1->T2 + x0->T3 + x0->T5 + x2->T5 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x0->T9 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x1->T5 + x0->T6 + x1->T6 + x0->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT41 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x2->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x2->T9 in valuation
    no (x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT42 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x2->T7 + x1->T8 + x2->T8 in valuation
    no (x0->T1 + x1->T1 + x2->T2 + x2->T3 + x0->T4 + x1->T5 + x2->T6 + x0->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig NT43 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x1->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x2->T3 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x0->T8 + x1->T9) & valuation
}

one sig NT44 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x1->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT45 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T1 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x0->T5 + x1->T6 + x2->T6 + x0->T7 + x0->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T2 + x1->T2 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T7 + x2->T7 + x1->T8) & valuation
}

one sig NT46 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x2->T4 + x0->T5 + x0->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x1->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT47 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T1 + x2->T1 + x0->T2 + x2->T3 + x0->T4 + x2->T5 + x0->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x2->T8 + x2->T9) & valuation
}

one sig NT48 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T1 + x2->T3 + x1->T4 + x0->T5 + x2->T6 + x0->T7 + x1->T7 + x1->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T7 + x0->T8) & valuation
}

one sig NT49 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x2->T3 + x0->T4 + x0->T5 + x2->T5 + x1->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T4 + x2->T4 + x1->T5 + x0->T6 + x2->T6 + x1->T7 + x1->T8 + x1->T9) & valuation
}

one sig NT50 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x1->T7 + x1->T8 + x0->T9) & valuation
}

one sig NT51 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x2->T3 + x2->T4 + x0->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x1->T9 + x2->T9 in valuation
    no (x2->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x1->T5 + x2->T5 + x2->T6 + x2->T7 + x2->T8 + x0->T9) & valuation
}

one sig NT52 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x2->T6 + x1->T8 + x2->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x1->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x2->T9) & valuation
}

one sig NT53 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x0->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x2->T8 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig NT54 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x2->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T8 + x2->T8 + x1->T9 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x0->T5 + x1->T7 + x2->T7 + x0->T8 + x0->T9 + x2->T9) & valuation
}

one sig NT55 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x1->T1 + x2->T2 + x1->T3 + x1->T4 + x2->T4 + x1->T5 + x1->T6 + x1->T7 + x1->T8 + x1->T9) & valuation
}

one sig NT56 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T3 + x0->T5 + x1->T5 + x0->T6 + x0->T7 + x0->T8 + x2->T8 + x0->T9 + x1->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T9) & valuation
}

one sig NT57 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x0->T5 + x2->T5 + x0->T6 + x0->T7 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4 + x1->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT58 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x2->T7 + x1->T8 + x1->T9) & valuation
}

one sig NT59 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x0->T5 + x2->T5 + x1->T6 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x0->T6 + x2->T6 + x0->T7 + x1->T7 + x1->T8 + x1->T9) & valuation
}

one sig NT60 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T7 + x0->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x2->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x2->T7 + x1->T8 + x2->T8) & valuation
}

one sig NT61 extends NegativeTrace {} {
    lasso = T9->T0
    x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x0->T6 + x0->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x1->T9 + x2->T9) & valuation
}

one sig NT62 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x0->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT63 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T3 + x0->T4 + x2->T4 + x0->T5 + x0->T6 + x2->T6 + x1->T7 + x0->T9 + x2->T9 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x1->T5 + x2->T5 + x1->T6 + x0->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT64 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x1->T7 + x1->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T6 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig NT65 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x1->T1 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x0->T6 + x2->T6 + x1->T7 + x0->T8 + x1->T8 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x2->T5 + x1->T6 + x0->T7 + x2->T7 + x2->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig NT66 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x0->T5 + x2->T5 + x0->T6 + x0->T7 + x0->T9 + x2->T9 in valuation
    no (x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT67 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x1->T6 + x2->T7 + x1->T8 + x1->T9 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x2->T3 + x0->T4 + x1->T5 + x0->T6 + x2->T6 + x0->T7 + x1->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig NT68 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x0->T1 + x2->T2 + x1->T3 + x1->T4 + x0->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T9 + x2->T9 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT69 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x0->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x1->T8) & valuation
}

one sig LearnedLTL {
    Root: DAGNode
}
fun root: one DAGNode { LearnedLTL.Root }
fun childrenOf[n: DAGNode]: set DAGNode { n.^(l+r) }
fun childrenAndSelfOf[n: DAGNode]: set DAGNode { n.*(l+r) }
fun ancestorsOf[n: DAGNode]: set DAGNode { n.~^(l+r) }
fun ancestorsAndSelfOf[n: DAGNode]: set DAGNode { n.~*(l+r) }
fun subDAG[n: DAGNode]: DAGNode -> DAGNode { n.*(l+r) <: (l+r) }

fact {
    root = G0

    all imply: Imply {
        all n: childrenOf[imply] | n in (Literal + And + Or + Neg)
        all n: childrenOf[imply] & Neg | n.l in Literal
        all n: childrenAndSelfOf[imply.l] & Or | no childrenOf[n] & And
        all n: childrenAndSelfOf[imply.r] & And | no childrenOf[n] & Or
    }
}

one sig G0 extends G {} { l = Imply0 }
one sig Imply0 extends Imply {}
one sig And0 extends And {}


fact {
    Imply0.l = x0 or (Imply0.l in And and Imply0.l.l = x0)

    Imply0.r = And0 or (Imply0.r in Or and Imply0.r.l = And0)
    (And0->x1 + And0->x2) in subDAG[Imply0.r]
}

fun experimentReach: set DAGNode { childrenAndSelfOf[root] }
fun experimentKept: DAGNode -> DAGNode { (none->none) & subDAG[root] }
one sig ExperimentCost { used: set DAGNode }
fact { ExperimentCost.used = experimentReach }
fact ExperimentBounds {
  DAGNode = experimentReach + Literal + (none)
  #experimentReach <= 5
  #(experimentReach & (And + Or + Imply)) <= 3
  minsome ExperimentCost.used
}
run {
    all t: PositiveTrace | root->T0 in t.valuation
    all t: NegativeTrace | root->T0 not in t.valuation
    
} for 8 DAGNode, 5 Int
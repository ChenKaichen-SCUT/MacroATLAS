open util/ordering[SeqIdx]

abstract sig DAGNode {
	l: set DAGNode,
	r: set DAGNode
}
fact {
	all n: DAGNode | n not in n.^(l + r)
}

sig And, Or, Imply extends DAGNode {} {
	one l
	one r
}

sig Neg, F, G, X extends DAGNode {} {
    one l
    no r
}
abstract sig Literal extends DAGNode {} {
	no l
	no r
}

abstract sig SeqIdx {}
abstract sig Trace {
	lasso: SeqIdx -> SeqIdx,
	valuation: DAGNode -> SeqIdx
} {
	// Negation
    all n: Neg, i: seqRange | n->i in valuation iff n.l->i not in valuation
	// Or
    all n: Or, i: seqRange | n->i in valuation iff (n.l->i in valuation or n.r->i in valuation)
	// And
    all n: And, i: seqRange | n->i in valuation iff (n.l->i in valuation and n.r->i in valuation)
	// Imply
    all n: Imply, i: seqRange | n->i in valuation iff (n.l->i not in valuation or n.r->i in valuation)
	// G
    all n: G, i: seqRange | n->i in valuation iff all i': futureIdx[i] | n.l->i' in valuation
    // X
    all n: X, i: seqRange | n->i in valuation iff n.l->i.((next :> seqRange) + lasso) in valuation
	// F
    all n: F, i: seqRange | n->i in valuation iff some i': futureIdx[i] | n.l->i' in valuation
	// Until
    
}
fun seqRange[t: Trace]: set SeqIdx {
	let lastOfTrace = t.lasso.SeqIdx | lastOfTrace.prevs + lastOfTrace
}
fun futureIdx[t: Trace, i: SeqIdx]: set SeqIdx {
	i.^((next :> seqRange[t]) + t.lasso) + i
}
abstract sig PositiveTrace extends Trace {}
abstract sig NegativeTrace extends Trace {}
one sig x0, x1 extends Literal {}
one sig T0, T1, T2, T3, T4 extends SeqIdx {}
fact {
    first = T0
    next = T0->T1 + T1->T2 + T2->T3 + T3->T4
}

one sig PT0 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT1 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT2 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT3 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT4 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT5 extends PositiveTrace {} {
    lasso = T4->T1
    
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT6 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT7 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT8 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT9 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT10 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT11 extends PositiveTrace {} {
    lasso = T4->T3
    
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT12 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT13 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT14 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT15 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT16 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT17 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT18 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT19 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT20 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT21 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T1 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT22 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT23 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT24 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT25 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT26 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT27 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT28 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT29 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT30 extends PositiveTrace {} {
    lasso = T4->T1
    
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT31 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT32 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT33 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT34 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT35 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT36 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT37 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT38 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT39 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT40 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT41 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT42 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT43 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT44 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT45 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT46 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT47 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT48 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT49 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT50 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT51 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT52 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT53 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT54 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT55 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT56 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT57 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT58 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT59 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT60 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT61 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT62 extends PositiveTrace {} {
    lasso = T4->T1
    
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT63 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT64 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT65 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT66 extends PositiveTrace {} {
    lasso = T4->T3
    
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT67 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT68 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT69 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT70 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT71 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT72 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT73 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T1 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT74 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT75 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T1 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT76 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT77 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT78 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT79 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT80 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT81 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT82 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT83 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT84 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT85 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT86 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT87 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT88 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT89 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT90 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT91 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT92 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT93 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT94 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT95 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT96 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT97 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT98 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT99 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT100 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT101 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT102 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT103 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT104 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT105 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT106 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T1 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT107 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT108 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT109 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT110 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT111 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT112 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT113 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT114 extends PositiveTrace {} {
    lasso = T4->T1
    
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT115 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT116 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT117 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT118 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT119 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT120 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT121 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT122 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT123 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT124 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT125 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT126 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT127 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT128 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT129 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT130 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT131 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT132 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT133 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT134 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT135 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT136 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT137 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT138 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT139 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT140 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT141 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT142 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT143 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT144 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT145 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT146 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T1 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT147 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT148 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}


one sig NT0 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT5 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT6 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT7 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT8 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT9 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT10 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT11 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT12 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT13 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T3) & valuation
}

one sig NT14 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT15 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT16 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T4) & valuation
}

one sig NT17 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT18 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT19 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT20 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT21 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT22 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT23 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT24 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT25 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT26 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT27 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT28 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT29 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT30 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT31 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT32 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT33 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT34 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T2 + x0->T4) & valuation
}

one sig NT35 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT36 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT37 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT38 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT39 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT40 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT41 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT42 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT43 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT44 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT45 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT46 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT47 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT48 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT49 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT50 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT51 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT52 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT53 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT54 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT55 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT56 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT57 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT58 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT59 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT60 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT61 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT62 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT63 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT64 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT65 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT66 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT67 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT68 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT69 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT70 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT71 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT72 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT73 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT74 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT75 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT76 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT77 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0) & valuation
}

one sig NT78 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT79 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT80 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3) & valuation
}

one sig NT81 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT82 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT83 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT84 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT85 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT86 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT87 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT88 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT89 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT90 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT91 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT92 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1) & valuation
}

one sig NT93 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT94 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT95 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT96 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT97 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT98 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T4) & valuation
}

one sig NT99 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1) & valuation
}

one sig NT100 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT101 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT102 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T3 + x1->T3) & valuation
}

one sig NT103 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT104 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT105 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT106 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT107 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT108 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT109 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT110 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT111 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT112 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT113 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT114 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT115 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT116 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT117 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT118 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT119 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT120 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT121 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT122 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT123 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT124 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT125 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT126 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT127 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT128 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT129 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT130 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT131 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT132 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1) & valuation
}

one sig NT133 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT134 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT135 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT136 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT137 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT138 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT139 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T4) & valuation
}

one sig NT140 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT141 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT142 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT143 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT144 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT145 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT146 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT147 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT148 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT149 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT150 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT151 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT152 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T4 + x1->T4) & valuation
}

one sig NT153 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT154 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT155 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT156 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT157 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT158 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT159 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT160 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT161 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T4 + x1->T4) & valuation
}

one sig NT162 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT163 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT164 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T4) & valuation
}

one sig NT165 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT166 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT167 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT168 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT169 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT170 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT171 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT172 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT173 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT174 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT175 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT176 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT177 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT178 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT179 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT180 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT181 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT182 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT183 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT184 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT185 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT186 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT187 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT188 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT189 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT190 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT191 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT192 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT193 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT194 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3) & valuation
}

one sig NT195 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T4) & valuation
}

one sig NT196 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT197 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT198 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT199 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT200 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT201 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT202 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT203 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT204 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT205 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT206 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT207 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT208 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT209 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT210 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT211 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT212 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT213 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT214 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT215 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT216 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT217 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT218 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT219 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT220 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT221 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT222 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT223 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT224 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT225 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0) & valuation
}

one sig NT226 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT227 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT228 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT229 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT230 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT231 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT232 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT233 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT234 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T4) & valuation
}

one sig NT235 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT236 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT237 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT238 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT239 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT240 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT241 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T4) & valuation
}

one sig NT242 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT243 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT244 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT245 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT246 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0) & valuation
}

one sig NT247 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT248 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT249 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT250 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT251 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT252 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T3) & valuation
}

one sig NT253 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT254 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT255 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT256 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT257 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT258 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT259 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT260 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT261 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT262 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT263 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT264 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT265 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T4) & valuation
}

one sig NT266 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT267 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1) & valuation
}

one sig NT268 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT269 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT270 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT271 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT272 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT273 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT274 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT275 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT276 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3) & valuation
}

one sig NT277 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT278 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT279 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT280 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT281 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT282 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT283 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT284 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT285 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT286 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT287 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT288 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT289 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT290 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT291 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT292 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T3 + x1->T4) & valuation
}

one sig NT293 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT294 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT295 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT296 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT297 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT298 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT299 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT300 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT301 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT302 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT303 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT304 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT305 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT306 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT307 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT308 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT309 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT310 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT311 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1) & valuation
}

one sig NT312 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT313 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT314 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT315 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT316 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT317 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT318 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT319 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT320 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT321 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT322 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT323 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT324 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT325 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1) & valuation
}

one sig NT326 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT327 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT328 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT329 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT330 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT331 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT332 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT333 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T4 + x1->T4) & valuation
}

one sig NT334 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT335 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT336 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T4) & valuation
}

one sig NT337 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T3 + x1->T3) & valuation
}

one sig NT338 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT339 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT340 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT341 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT342 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2) & valuation
}

one sig NT343 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT344 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT345 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT346 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT347 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT348 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT349 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT350 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT351 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2) & valuation
}

one sig NT352 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT353 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT354 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT355 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT356 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT357 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT358 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT359 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT360 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT361 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T3) & valuation
}

one sig NT362 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT363 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT364 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0) & valuation
}

one sig NT365 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT366 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT367 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT368 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT369 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT370 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT371 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT372 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT373 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT374 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT375 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT376 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT377 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT378 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2) & valuation
}

one sig NT379 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT380 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT381 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT382 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT383 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT384 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT385 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT386 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT387 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT388 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT389 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT390 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT391 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT392 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T4) & valuation
}

one sig NT393 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT394 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT395 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT396 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT397 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT398 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT399 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2) & valuation
}

one sig NT400 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT401 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT402 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT403 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT404 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT405 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT406 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT407 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT408 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT409 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT410 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT411 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT412 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0) & valuation
}

one sig NT413 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT414 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT415 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT416 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT417 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT418 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT419 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT420 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT421 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT422 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT423 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0) & valuation
}

one sig NT424 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT425 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT426 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3) & valuation
}

one sig NT427 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT428 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT429 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2) & valuation
}

one sig NT430 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT431 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT432 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T3 + x1->T4) & valuation
}

one sig NT433 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT434 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT435 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT436 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT437 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT438 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT439 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT440 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T4) & valuation
}

one sig NT441 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT442 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT443 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T4) & valuation
}

one sig NT444 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT445 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT446 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT447 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT448 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT449 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT450 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2) & valuation
}

one sig NT451 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT452 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT453 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT454 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT455 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT456 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT457 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1) & valuation
}

one sig NT458 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT459 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT460 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT461 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT462 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT463 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT464 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT465 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT466 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3) & valuation
}

one sig NT467 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T4) & valuation
}

one sig NT468 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT469 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT470 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT471 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT472 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT473 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T4) & valuation
}

one sig NT474 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT475 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT476 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT477 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT478 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT479 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT480 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT481 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT482 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT483 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT484 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT485 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT486 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T3 + x0->T4) & valuation
}

one sig NT487 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT488 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT489 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT490 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT491 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT492 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT493 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT494 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT495 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT496 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT497 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT498 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT499 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT500 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT501 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT502 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT503 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT504 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT505 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT506 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT507 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT508 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT509 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT510 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2) & valuation
}

one sig NT511 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT512 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT513 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT514 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT515 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT516 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT517 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    
}

one sig NT518 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT519 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT520 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT521 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT522 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT523 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT524 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT525 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT526 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT527 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0) & valuation
}

one sig NT528 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT529 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT530 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT531 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT532 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT533 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT534 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT535 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT536 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT537 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT538 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT539 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT540 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT541 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2) & valuation
}

one sig NT542 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T4) & valuation
}

one sig NT543 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT544 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT545 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT546 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT547 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT548 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT549 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT550 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT551 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT552 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT553 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT554 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT555 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT556 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT557 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT558 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT559 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT560 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT561 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT562 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT563 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT564 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT565 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT566 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT567 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT568 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT569 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT570 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT571 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT572 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT573 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT574 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT575 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT576 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT577 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T3) & valuation
}

one sig NT578 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT579 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2) & valuation
}

one sig NT580 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT581 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT582 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT583 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT584 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT585 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT586 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT587 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT588 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT589 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT590 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT591 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT592 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT593 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT594 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT595 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT596 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT597 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT598 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT599 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT600 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT601 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT602 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT603 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT604 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT605 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT606 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT607 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT608 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT609 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT610 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT611 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT612 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT613 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT614 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT615 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT616 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT617 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT618 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT619 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT620 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT621 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT622 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT623 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT624 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT625 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT626 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT627 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT628 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT629 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT630 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT631 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT632 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT633 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT634 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT635 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT636 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT637 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT638 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT639 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT640 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT641 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT642 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT643 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT644 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT645 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT646 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT647 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT648 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT649 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT650 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT651 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT652 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT653 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT654 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT655 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT656 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT657 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT658 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT659 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT660 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT661 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT662 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT663 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT664 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2) & valuation
}

one sig NT665 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT666 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT667 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT668 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT669 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT670 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT671 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT672 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT673 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT674 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT675 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT676 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT677 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT678 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT679 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT680 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT681 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT682 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT683 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT684 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT685 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT686 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT687 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT688 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT689 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT690 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT691 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T2 + x1->T4) & valuation
}

one sig NT692 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT693 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT694 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT695 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT696 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT697 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT698 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT699 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1) & valuation
}

one sig NT700 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT701 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT702 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT703 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT704 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT705 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT706 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT707 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT708 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT709 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT710 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT711 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT712 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT713 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT714 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT715 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT716 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT717 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT718 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT719 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT720 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT721 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT722 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT723 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT724 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT725 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT726 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT727 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT728 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT729 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT730 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT731 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT732 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT733 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT734 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT735 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT736 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT737 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT738 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT739 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT740 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT741 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT742 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT743 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT744 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT745 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT746 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT747 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT748 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT749 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT750 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT751 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT752 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT753 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT754 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT755 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT756 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T3) & valuation
}

one sig NT757 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT758 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT759 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT760 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT761 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT762 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT763 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT764 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT765 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT766 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT767 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT768 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT769 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT770 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT771 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT772 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT773 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT774 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x0->T3) & valuation
}

one sig NT775 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1) & valuation
}

one sig NT776 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT777 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT778 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT779 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT780 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT781 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT782 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT783 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3) & valuation
}

one sig NT784 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT785 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT786 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT787 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT788 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT789 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT790 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT791 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT792 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1) & valuation
}

one sig NT793 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT794 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT795 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT796 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT797 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT798 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT799 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT800 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT801 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T4) & valuation
}

one sig NT802 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT803 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT804 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT805 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT806 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT807 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT808 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT809 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT810 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT811 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT812 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT813 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT814 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT815 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT816 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT817 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT818 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT819 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT820 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T4) & valuation
}

one sig NT821 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT822 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT823 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT824 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT825 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT826 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT827 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT828 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT829 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT830 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T3) & valuation
}

one sig NT831 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT832 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT833 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT834 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT835 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT836 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT837 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x1->T3) & valuation
}

one sig NT838 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT839 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT840 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT841 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT842 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT843 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT844 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT845 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT846 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT847 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT848 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT849 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT850 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT851 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT852 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT853 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT854 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT855 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT856 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT857 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT858 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT859 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT860 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT861 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT862 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT863 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT864 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT865 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT866 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT867 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT868 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT869 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT870 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT871 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT872 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT873 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT874 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT875 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2) & valuation
}

one sig NT876 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT877 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT878 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT879 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT880 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT881 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT882 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT883 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT884 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT885 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT886 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT887 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT888 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT889 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT890 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT891 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT892 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT893 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT894 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T4) & valuation
}

one sig NT895 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT896 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT897 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT898 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T4) & valuation
}

one sig NT899 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT900 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT901 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT902 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT903 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT904 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2) & valuation
}

one sig NT905 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT906 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT907 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT908 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT909 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT910 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT911 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT912 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT913 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT914 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT915 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT916 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT917 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT918 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT919 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT920 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT921 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT922 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT923 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT924 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT925 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT926 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT927 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT928 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT929 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT930 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT931 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT932 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT933 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT934 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT935 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT936 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT937 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT938 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT939 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT940 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT941 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT942 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT943 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT944 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT945 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT946 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT947 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT948 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT949 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT950 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT951 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT952 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T3) & valuation
}

one sig NT953 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT954 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT955 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT956 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT957 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT958 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT959 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT960 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT961 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT962 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT963 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT964 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT965 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT966 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT967 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT968 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT969 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT970 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT971 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT972 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT973 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT974 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT975 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT976 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT977 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT978 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT979 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT980 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT981 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T4) & valuation
}

one sig NT982 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT983 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT984 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT985 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT986 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT987 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT988 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT989 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT990 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT991 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT992 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT993 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT994 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT995 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT996 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT997 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT998 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT999 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1000 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1001 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT1002 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1003 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1004 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1005 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1006 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1007 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1008 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1009 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1010 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1011 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1012 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT1013 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1014 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T4) & valuation
}

one sig NT1015 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1016 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1017 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1018 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT1019 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1020 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1021 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1022 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1023 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1024 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1025 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1026 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1027 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1028 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT1029 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1030 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT1031 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT1032 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1033 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1034 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1035 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1036 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1037 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1038 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT1039 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1040 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1041 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT1042 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1) & valuation
}

one sig NT1043 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1044 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T3) & valuation
}

one sig NT1045 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1046 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT1047 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT1048 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1049 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1050 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT1051 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT1052 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1053 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1054 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1055 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1056 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1057 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1058 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1059 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1060 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1061 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1062 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1063 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT1064 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT1065 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1066 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1067 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T4 + x1->T4) & valuation
}

one sig NT1068 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1069 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT1070 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT1071 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT1072 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1073 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1074 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT1075 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT1076 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1077 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1078 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1079 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1080 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT1081 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT1082 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1083 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1084 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT1085 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1086 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1087 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1088 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT1089 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1090 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT1091 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT1092 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1093 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1094 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T4) & valuation
}

one sig NT1095 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1096 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1097 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1098 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1099 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1100 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1101 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1102 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T4) & valuation
}

one sig NT1103 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1104 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2) & valuation
}

one sig NT1105 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT1106 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1107 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2) & valuation
}

one sig NT1108 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1109 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T3 + x1->T4) & valuation
}

one sig NT1110 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T3) & valuation
}

one sig NT1111 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1112 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1113 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1114 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT1115 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1116 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1117 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1118 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT1119 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1120 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1121 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1122 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT1123 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1124 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1125 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT1126 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT1127 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT1128 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1129 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1130 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1131 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1132 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT1133 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1134 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1135 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1136 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1137 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1138 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1139 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1140 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1141 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT1142 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1143 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1144 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1145 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1146 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1147 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1148 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1149 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T4 + x1->T4) & valuation
}

one sig NT1150 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2) & valuation
}

one sig NT1151 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1152 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1153 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1154 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1155 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1156 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT1157 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1158 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T3) & valuation
}

one sig NT1159 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1160 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1161 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1162 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1163 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1164 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1165 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1166 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1167 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1168 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT1169 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1170 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1171 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1172 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT1173 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1174 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1175 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT1176 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T4) & valuation
}

one sig NT1177 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1178 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT1179 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1180 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1181 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T4) & valuation
}

one sig NT1182 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1183 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1184 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1185 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1186 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3) & valuation
}

one sig NT1187 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1188 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT1189 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1190 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1191 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT1192 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT1193 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT1194 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1195 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1196 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT1197 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2) & valuation
}

one sig NT1198 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT1199 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT1200 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1201 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1202 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1203 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2) & valuation
}

one sig NT1204 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2) & valuation
}

one sig NT1205 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT1206 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1207 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1208 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1209 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT1210 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1211 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1212 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1213 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1214 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1215 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT1216 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1217 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1218 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1219 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1220 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1221 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1222 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1223 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1224 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1225 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT1226 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT1227 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1228 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1229 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1230 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT1231 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1232 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1233 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1234 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT1235 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1236 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T3) & valuation
}

one sig NT1237 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1238 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1239 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT1240 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1241 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT1242 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1243 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1244 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT1245 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT1246 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT1247 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1248 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1249 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT1250 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1251 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1252 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1253 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1254 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1255 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1256 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1257 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT1258 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1259 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1260 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1261 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1262 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1263 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1264 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1265 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT1266 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1267 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1) & valuation
}

one sig NT1268 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1269 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1270 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1271 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT1272 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1273 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1274 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1275 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1276 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1277 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T4) & valuation
}

one sig NT1278 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1279 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1280 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1281 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT1282 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1283 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1284 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1285 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1286 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1287 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT1288 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT1289 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT1290 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1291 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1292 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT1293 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1294 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1295 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1296 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1297 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1298 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1299 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1300 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1301 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT1302 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3) & valuation
}

one sig NT1303 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1304 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1305 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1306 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT1307 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT1308 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1309 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1310 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1311 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T3) & valuation
}

one sig NT1312 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1313 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1314 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1) & valuation
}

one sig NT1315 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT1316 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1317 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1318 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1319 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1320 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT1321 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT1322 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1323 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1324 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1325 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1326 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1327 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1328 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1329 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1330 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1331 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT1332 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1333 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1334 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT1335 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1336 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT1337 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1338 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT1339 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T3) & valuation
}

one sig NT1340 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1341 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1342 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T4) & valuation
}

one sig NT1343 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1344 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1345 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1346 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT1347 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1348 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1349 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1350 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT1351 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1352 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1353 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1354 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1355 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1356 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T3 + x0->T4) & valuation
}

one sig NT1357 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T4) & valuation
}

one sig NT1358 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1359 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT1360 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1361 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT1362 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1363 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1364 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT1365 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT1366 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1367 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT1368 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1369 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1370 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1371 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT1372 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1373 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1374 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT1375 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1376 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT1377 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1378 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1379 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1380 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1381 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1382 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1383 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1384 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1385 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1386 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1387 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1388 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1389 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1390 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT1391 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1392 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1393 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1394 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT1395 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT1396 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T3) & valuation
}

one sig NT1397 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1398 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1399 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1400 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T3 + x0->T4) & valuation
}

one sig NT1401 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT1402 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1403 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T4) & valuation
}

one sig NT1404 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1405 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2) & valuation
}

one sig NT1406 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT1407 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1408 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1409 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT1410 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T3) & valuation
}

one sig NT1411 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1412 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1413 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1414 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1415 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT1416 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT1417 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1418 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT1419 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1420 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1421 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1422 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0) & valuation
}

one sig NT1423 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1424 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1425 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1426 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1427 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1428 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1429 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1430 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1431 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT1432 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1433 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1434 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT1435 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT1436 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT1437 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1438 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT1439 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1440 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1441 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1442 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1443 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1444 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0) & valuation
}

one sig NT1445 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1446 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1447 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1448 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1449 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1450 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1451 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT1452 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1453 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT1454 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1455 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1456 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1457 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1458 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1459 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1460 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT1461 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1462 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1463 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT1464 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1465 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T3) & valuation
}

one sig NT1466 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT1467 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1468 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT1469 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT1470 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1471 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1472 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT1473 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1474 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT1475 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1476 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T2 + x1->T4) & valuation
}

one sig NT1477 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1478 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT1479 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT1480 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT1481 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1482 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1483 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1484 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1485 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1486 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T4 + x1->T4) & valuation
}

one sig NT1487 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1488 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1489 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT1490 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT1491 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1492 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1493 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1494 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT1495 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT1496 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1497 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T3 + x1->T3) & valuation
}

one sig NT1498 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT1499 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1500 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT1501 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT1502 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1503 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1504 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1505 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1506 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT1507 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1) & valuation
}

one sig NT1508 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1509 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1510 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1511 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT1512 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1513 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T3) & valuation
}

one sig NT1514 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1515 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1516 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1517 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1518 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1519 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3) & valuation
}

one sig NT1520 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1521 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1522 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1523 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1524 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1525 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1526 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T4) & valuation
}

one sig NT1527 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1528 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1529 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1530 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T3) & valuation
}

one sig NT1531 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT1532 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1533 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1534 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1535 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1536 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1537 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT1538 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1539 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1540 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1541 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1542 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1543 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1544 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1545 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT1546 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1547 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1548 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT1549 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1550 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1551 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1552 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1553 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT1554 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1555 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT1556 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1557 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3) & valuation
}

one sig NT1558 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1559 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1560 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1561 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT1562 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1563 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1564 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1565 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1566 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1567 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT1568 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT1569 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1570 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1571 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1572 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1573 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1574 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1575 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1576 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT1577 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1578 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1579 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1580 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1581 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1582 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1583 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1584 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1585 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT1586 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1587 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT1588 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1589 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT1590 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT1591 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1592 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1593 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1594 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T4 + x1->T4) & valuation
}

one sig NT1595 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1596 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT1597 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1598 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1599 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1600 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1601 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1602 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1603 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT1604 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1605 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT1606 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1607 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT1608 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1609 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1610 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1611 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1612 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT1613 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1614 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT1615 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1616 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1617 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT1618 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1619 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1620 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1621 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1622 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1623 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1624 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1625 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1626 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT1627 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT1628 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1629 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1630 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1631 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1632 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT1633 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1634 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT1635 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1636 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1637 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1638 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1639 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT1640 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1641 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1642 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT1643 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1644 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1645 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1646 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT1647 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1648 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1649 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1650 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT1651 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1652 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2) & valuation
}

one sig NT1653 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1654 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT1655 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1656 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT1657 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1658 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1659 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT1660 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1661 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1662 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1663 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1) & valuation
}

one sig NT1664 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1665 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1666 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT1667 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1668 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1669 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1670 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3) & valuation
}

one sig NT1671 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT1672 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0) & valuation
}

one sig NT1673 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1674 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1675 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1676 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1677 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T3 + x0->T4) & valuation
}

one sig NT1678 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1679 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1680 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0) & valuation
}

one sig NT1681 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1682 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT1683 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1684 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT1685 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1686 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1687 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1688 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1689 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1690 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT1691 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1692 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1693 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1694 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1695 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1696 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1697 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1698 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1699 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1700 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1701 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1) & valuation
}

one sig NT1702 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1703 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1704 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1705 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1706 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3) & valuation
}

one sig NT1707 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1708 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT1709 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1710 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1711 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1712 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1713 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1714 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT1715 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1716 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1717 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1718 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1719 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1720 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1721 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1722 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1723 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT1724 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1725 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1726 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1727 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1728 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1729 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1730 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1731 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1732 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1733 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1734 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1735 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1736 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1737 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1738 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1739 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1740 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1741 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1742 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1743 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1744 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1745 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT1746 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1747 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T3) & valuation
}

one sig NT1748 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1749 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1750 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1751 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1752 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT1753 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1754 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1755 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2) & valuation
}

one sig NT1756 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3) & valuation
}

one sig NT1757 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1758 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1759 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1760 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1761 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1762 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1763 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1764 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1765 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1766 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1767 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1768 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1769 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1770 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT1771 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1772 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1773 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT1774 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT1775 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT1776 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1777 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1778 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1779 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1780 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1781 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1782 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1783 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1784 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1785 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT1786 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1787 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1788 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1789 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1790 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT1791 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1792 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T2 + x0->T4) & valuation
}

one sig NT1793 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3) & valuation
}

one sig NT1794 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1795 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1796 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1797 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1798 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1799 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1800 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1801 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1802 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1803 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1804 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1805 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1806 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1807 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1808 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT1809 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1810 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT1811 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1812 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1813 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1814 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1815 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT1816 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1817 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T4) & valuation
}

one sig NT1818 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1819 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1820 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T2 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1821 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1822 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT1823 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT1824 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1825 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1826 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1827 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1828 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T4 + x1->T4) & valuation
}

one sig NT1829 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1830 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1831 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1832 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T4) & valuation
}

one sig NT1833 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1834 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1835 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1836 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T4) & valuation
}

one sig NT1837 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1838 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1839 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1840 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1841 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1842 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1843 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT1844 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT1845 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT1846 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT1847 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1848 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT1849 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1850 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1851 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T3) & valuation
}

one sig NT1852 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1853 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT1854 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1855 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT1856 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1857 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T3 + x1->T4) & valuation
}

one sig NT1858 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1859 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT1860 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1861 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1862 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT1863 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1864 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1865 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT1866 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1867 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1868 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1869 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1870 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T3) & valuation
}

one sig NT1871 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1872 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1873 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1874 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1) & valuation
}

one sig NT1875 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1876 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1877 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT1878 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1879 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1880 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1881 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT1882 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1883 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 in valuation
    no (x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1884 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1885 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1886 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT1887 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1888 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1889 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT1890 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT1891 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1892 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1893 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT1894 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT1895 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1896 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT1897 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT1898 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1899 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT1900 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1901 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1902 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1903 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1904 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT1905 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1906 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1907 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1908 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1909 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT1910 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1911 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1912 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT1913 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1914 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1915 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1916 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1917 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T4) & valuation
}

one sig NT1918 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT1919 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1920 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1921 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1922 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT1923 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1924 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1925 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1926 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1927 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT1928 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1929 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1930 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T4) & valuation
}

one sig NT1931 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1932 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1933 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1934 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1935 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT1936 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT1937 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1938 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1939 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT1940 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1941 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1942 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1943 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1944 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T4) & valuation
}

one sig NT1945 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT1946 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1947 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT1948 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1949 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1950 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T4) & valuation
}

one sig NT1951 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT1952 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1953 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1954 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT1955 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1956 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT1957 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1958 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1959 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1960 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT1961 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1962 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1963 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT1964 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1965 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT1966 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT1967 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2) & valuation
}

one sig NT1968 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT1969 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1970 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT1971 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1972 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT1973 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1974 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1975 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1976 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1977 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT1978 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT1979 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1980 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T4) & valuation
}

one sig NT1981 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT1982 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1983 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1984 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1985 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT1986 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT1987 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT1988 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT1989 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T4) & valuation
}

one sig NT1990 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT1991 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1992 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T4) & valuation
}

one sig NT1993 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1994 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT1995 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1) & valuation
}

one sig NT1996 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT1997 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT1998 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT1999 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2000 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT2001 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1) & valuation
}

one sig NT2002 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2003 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2004 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT2005 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2006 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT2007 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2008 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T4) & valuation
}

one sig NT2009 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2010 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2011 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT2012 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT2013 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2014 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2015 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2016 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2017 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT2018 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2019 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2020 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2021 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2022 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2023 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2024 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2025 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT2026 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT2027 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT2028 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT2029 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2030 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT2031 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2032 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3) & valuation
}

one sig NT2033 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2034 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2035 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2036 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT2037 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT2038 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T4) & valuation
}

one sig NT2039 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2040 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2041 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2042 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2043 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2044 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2045 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT2046 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT2047 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2048 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2049 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT2050 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2051 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2052 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2053 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT2054 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT2055 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2056 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT2057 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT2058 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2059 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2060 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2061 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2062 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2) & valuation
}

one sig NT2063 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2064 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT2065 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2066 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT2067 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2068 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2069 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2070 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2071 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2072 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T3 + x0->T4) & valuation
}

one sig NT2073 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2074 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2075 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2076 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2077 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2078 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT2079 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2080 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2081 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2082 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2083 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT2084 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT2085 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2086 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT2087 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2088 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2089 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT2090 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2091 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2) & valuation
}

one sig NT2092 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2093 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2094 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2095 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT2096 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2097 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2098 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2099 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2100 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT2101 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2102 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2103 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2104 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2105 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2106 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2107 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT2108 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2109 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2110 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2) & valuation
}

one sig NT2111 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2112 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT2113 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2114 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2115 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT2116 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2117 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2118 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2119 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2120 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2) & valuation
}

one sig NT2121 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT2122 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2123 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2124 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2125 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3) & valuation
}

one sig NT2126 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT2127 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2128 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT2129 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2130 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2131 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT2132 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2133 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3) & valuation
}

one sig NT2134 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2135 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2136 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2137 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT2138 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2139 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT2140 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2141 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT2142 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2143 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2144 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2145 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2146 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2147 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2148 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2149 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2150 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2151 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2152 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3) & valuation
}

one sig NT2153 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2154 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2155 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT2156 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2157 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT2158 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2159 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT2160 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT2161 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2162 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2163 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2164 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2165 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2166 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2167 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2168 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2169 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2170 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2171 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2172 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT2173 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2174 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2175 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2176 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2177 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT2178 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2179 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2180 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2) & valuation
}

one sig NT2181 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2182 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2183 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2184 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T4) & valuation
}

one sig NT2185 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2186 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2187 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2188 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2189 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2190 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT2191 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT2192 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT2193 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2194 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT2195 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT2196 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2197 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2198 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2199 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2200 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2201 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2202 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2203 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T4) & valuation
}

one sig NT2204 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2205 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2206 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2207 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2208 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT2209 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2210 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2211 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT2212 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT2213 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2214 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2215 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT2216 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2217 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT2218 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2219 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2220 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2221 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2222 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2223 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2224 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2225 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2226 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2227 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT2228 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2229 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2230 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2231 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT2232 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2233 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2234 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2235 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2236 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2237 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2238 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2239 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2240 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2241 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT2242 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2243 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT2244 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT2245 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2246 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2247 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2248 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT2249 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2250 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2251 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2252 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT2253 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2254 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2255 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2256 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT2257 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2258 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT2259 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2260 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T3) & valuation
}

one sig NT2261 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT2262 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT2263 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2264 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT2265 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT2266 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2267 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT2268 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2269 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2270 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT2271 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT2272 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2273 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT2274 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2275 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2276 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2277 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT2278 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT2279 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2280 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2281 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2282 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2283 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2284 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2285 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2286 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2287 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2288 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2289 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2290 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT2291 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT2292 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2293 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T4 + x1->T4) & valuation
}

one sig NT2294 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT2295 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2296 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2297 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T3) & valuation
}

one sig NT2298 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2299 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2300 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2301 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2302 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2303 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2304 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1) & valuation
}

one sig NT2305 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2306 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2307 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2308 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2309 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2310 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2311 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT2312 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2313 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT2314 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2315 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT2316 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T3 + x0->T4) & valuation
}

one sig NT2317 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT2318 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2319 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2320 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2321 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T3 + x1->T3) & valuation
}

one sig NT2322 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2323 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT2324 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2325 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT2326 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2327 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T4) & valuation
}

one sig NT2328 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT2329 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2330 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT2331 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2332 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2333 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2334 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT2335 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2336 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2337 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2338 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T4) & valuation
}

one sig NT2339 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2340 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2341 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2342 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT2343 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2344 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT2345 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT2346 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT2347 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2348 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2349 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2350 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT2351 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T2 + x1->T4) & valuation
}

one sig NT2352 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT2353 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2354 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2355 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2356 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T4 + x1->T4) & valuation
}

one sig NT2357 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT2358 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2359 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2360 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2) & valuation
}

one sig NT2361 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2362 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2363 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2364 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2365 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT2366 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT2367 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2368 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2369 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2370 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2371 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2372 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2373 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2374 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1) & valuation
}

one sig NT2375 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2376 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2377 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2378 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2) & valuation
}

one sig NT2379 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2380 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T4 + x1->T4) & valuation
}

one sig NT2381 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2382 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT2383 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1) & valuation
}

one sig NT2384 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2385 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2386 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2387 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT2388 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2389 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT2390 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2391 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2392 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2393 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT2394 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2395 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2396 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2397 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2398 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2399 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT2400 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT2401 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2402 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2403 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT2404 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2405 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2406 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2407 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2408 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2409 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2410 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2411 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2412 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2413 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2414 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT2415 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2416 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT2417 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2418 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT2419 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2420 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2421 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT2422 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2423 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2424 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2425 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT2426 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2427 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT2428 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2429 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2430 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2431 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2432 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2433 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2434 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2435 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2436 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2437 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2438 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2439 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2440 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2441 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2442 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT2443 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT2444 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2445 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2446 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT2447 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2448 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2449 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2450 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2451 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2452 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2453 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT2454 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2455 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2456 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT2457 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2458 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2459 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT2460 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2461 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2462 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2463 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2464 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2465 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2466 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT2467 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2468 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2469 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2470 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2471 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T4) & valuation
}

one sig NT2472 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2473 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2474 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2475 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2476 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2477 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT2478 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT2479 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2480 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2481 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2482 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2483 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2484 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2485 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2486 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2487 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2488 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2489 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT2490 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2491 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT2492 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2493 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2494 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2495 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2496 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2497 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2) & valuation
}

one sig NT2498 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2499 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2500 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2501 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2502 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2503 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2504 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2505 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2506 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2507 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT2508 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2509 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2510 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT2511 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2512 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2513 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT2514 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2515 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2516 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT2517 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2518 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2519 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT2520 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2521 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2522 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT2523 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT2524 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2525 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2526 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T3) & valuation
}

one sig NT2527 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2528 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2529 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T3) & valuation
}

one sig NT2530 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2531 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2532 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT2533 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2534 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2535 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2536 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2537 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2538 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT2539 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2540 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT2541 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2542 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT2543 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT2544 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT2545 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2546 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2547 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2548 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT2549 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2550 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT2551 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2552 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1) & valuation
}

one sig NT2553 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2554 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2555 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2556 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2557 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2558 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T4) & valuation
}

one sig NT2559 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T3 + x1->T4) & valuation
}

one sig NT2560 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT2561 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2562 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2563 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT2564 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2565 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2566 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2567 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2) & valuation
}

one sig NT2568 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2569 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2570 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2571 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT2572 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2573 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT2574 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2575 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT2576 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2577 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T4) & valuation
}

one sig NT2578 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2579 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T4 + x1->T4) & valuation
}

one sig NT2580 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2581 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2582 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2583 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2584 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT2585 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT2586 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2587 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2588 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T4) & valuation
}

one sig NT2589 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2590 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2591 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT2592 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2593 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT2594 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT2595 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT2596 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2597 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2598 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2599 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2600 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2601 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2602 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT2603 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2604 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2605 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2606 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2) & valuation
}

one sig NT2607 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2608 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT2609 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2610 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2611 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2612 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2613 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2614 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1) & valuation
}

one sig NT2615 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT2616 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT2617 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2618 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT2619 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2620 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2621 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2622 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT2623 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT2624 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2625 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2626 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2627 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2628 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2629 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT2630 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2631 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2632 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT2633 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT2634 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2635 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT2636 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2637 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2638 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2639 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2640 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T3 + x0->T4) & valuation
}

one sig NT2641 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2642 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2643 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2644 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2645 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2646 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3) & valuation
}

one sig NT2647 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2648 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T3) & valuation
}

one sig NT2649 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2650 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2) & valuation
}

one sig NT2651 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2652 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2653 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2654 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2655 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2656 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2657 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2658 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2659 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT2660 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2661 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2662 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT2663 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2664 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2665 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2666 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2667 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2668 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2669 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2670 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2671 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2672 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2673 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2674 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2675 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2676 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2677 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT2678 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2679 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2680 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2681 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2682 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2683 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2684 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT2685 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2) & valuation
}

one sig NT2686 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2687 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2688 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2) & valuation
}

one sig NT2689 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2690 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2691 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2692 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2693 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2694 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2695 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2696 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T4) & valuation
}

one sig NT2697 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT2698 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT2699 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2700 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2701 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1) & valuation
}

one sig NT2702 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT2703 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2704 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT2705 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2706 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2707 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2708 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT2709 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2710 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2711 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2712 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT2713 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2714 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2715 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2716 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2717 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2718 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2719 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT2720 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT2721 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT2722 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2723 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2724 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2725 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2726 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2727 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT2728 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2729 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3) & valuation
}

one sig NT2730 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T3 + x1->T4) & valuation
}

one sig NT2731 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2732 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2733 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2734 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2735 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT2736 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2737 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2738 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2739 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2740 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2741 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2742 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2743 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2744 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2745 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T4 + x1->T4) & valuation
}

one sig NT2746 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2747 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2748 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT2749 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT2750 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT2751 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT2752 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT2753 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT2754 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2755 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2756 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT2757 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2758 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2759 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2760 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2761 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2762 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2763 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2764 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT2765 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2766 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2767 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2768 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2769 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2770 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2771 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T3) & valuation
}

one sig NT2772 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2773 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2774 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT2775 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2776 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT2777 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2778 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT2779 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T4) & valuation
}

one sig NT2780 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2781 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT2782 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2783 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT2784 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2785 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2786 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2787 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT2788 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2789 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT2790 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2) & valuation
}

one sig NT2791 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2792 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2793 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2794 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2795 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT2796 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2) & valuation
}

one sig NT2797 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2798 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2) & valuation
}

one sig NT2799 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2800 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2801 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2802 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT2803 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2804 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2805 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1) & valuation
}

one sig NT2806 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T3 + x0->T4) & valuation
}

one sig NT2807 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T4) & valuation
}

one sig NT2808 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2809 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT2810 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2811 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2812 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2813 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2814 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT2815 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2816 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2817 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2818 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2819 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2820 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT2821 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2822 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2823 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2824 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2825 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2826 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2827 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2828 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2829 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2830 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2831 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT2832 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2833 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2834 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2835 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2836 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT2837 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2) & valuation
}

one sig NT2838 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2839 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2840 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2841 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2842 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2843 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2844 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T3) & valuation
}

one sig NT2845 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2846 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2847 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2848 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2849 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2850 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2851 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2852 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2853 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T2 + x0->T4) & valuation
}

one sig NT2854 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2855 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2856 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2857 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T3) & valuation
}

one sig NT2858 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2859 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2860 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2861 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT2862 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT2863 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2864 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2865 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2) & valuation
}

one sig NT2866 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2867 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2868 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2869 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT2870 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT2871 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2872 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT2873 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT2874 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT2875 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2876 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2877 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2878 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT2879 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2880 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2881 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2882 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2883 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2884 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2885 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2886 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2887 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2888 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2889 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2890 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2) & valuation
}

one sig NT2891 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2892 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2893 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T4) & valuation
}

one sig NT2894 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2895 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT2896 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2897 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1) & valuation
}

one sig NT2898 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2899 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2900 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2901 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2902 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2903 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2904 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2905 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2) & valuation
}

one sig NT2906 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2907 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2908 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3) & valuation
}

one sig NT2909 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT2910 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T3 + x0->T4) & valuation
}

one sig NT2911 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2912 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2913 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2914 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2915 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2916 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT2917 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2918 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT2919 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T3) & valuation
}

one sig NT2920 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2921 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT2922 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2923 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2924 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT2925 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2926 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2927 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2928 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T3 + x1->T4) & valuation
}

one sig NT2929 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2930 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2931 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2932 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2933 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3) & valuation
}

one sig NT2934 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2935 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3) & valuation
}

one sig NT2936 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2937 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2938 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2939 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT2940 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT2941 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT2942 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2943 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2944 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2945 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2946 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2947 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2948 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT2949 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1) & valuation
}

one sig NT2950 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T3 + x1->T3) & valuation
}

one sig NT2951 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT2952 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2953 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2954 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2955 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2956 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2957 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2958 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT2959 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2960 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2961 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2962 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2963 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2964 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2965 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT2966 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2967 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2968 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2969 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2970 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2971 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2972 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT2973 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2974 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2975 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2976 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT2977 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2978 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT2979 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT2980 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2981 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT2982 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2983 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT2984 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT2985 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT2986 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT2987 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2988 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2989 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT2990 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT2991 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT2992 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2993 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT2994 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT2995 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT2996 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT2997 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT2998 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT2999 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT3000 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3001 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT3002 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3003 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT3004 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3005 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3006 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2) & valuation
}

one sig NT3007 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3008 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3009 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT3010 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3011 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3012 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3013 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT3014 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT3015 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3016 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3017 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT3018 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3019 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3020 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3021 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3022 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3023 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3024 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3025 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1) & valuation
}

one sig NT3026 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3027 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3028 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT3029 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3030 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3031 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3032 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3033 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT3034 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3035 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3036 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT3037 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3038 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3039 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T3 + x0->T4) & valuation
}

one sig NT3040 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT3041 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3042 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT3043 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT3044 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3045 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3046 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT3047 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3048 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3049 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT3050 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3051 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT3052 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3053 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT3054 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3055 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3056 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT3057 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT3058 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT3059 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3060 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3061 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3062 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3063 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3064 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3065 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3066 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3067 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3068 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3069 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3070 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3071 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3072 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3073 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3074 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3075 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3076 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3077 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3078 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT3079 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3080 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3081 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3082 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3083 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3084 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2) & valuation
}

one sig NT3085 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3086 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT3087 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3088 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3089 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2) & valuation
}

one sig NT3090 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT3091 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3092 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3093 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3094 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3095 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3) & valuation
}

one sig NT3096 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT3097 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3098 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3099 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3100 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT3101 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3102 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3103 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3104 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3105 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3106 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT3107 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT3108 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3109 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T4) & valuation
}

one sig NT3110 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3111 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3112 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T3) & valuation
}

one sig NT3113 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT3114 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3) & valuation
}

one sig NT3115 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T3) & valuation
}

one sig NT3116 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT3117 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3118 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3119 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3120 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3121 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3122 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3123 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3124 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT3125 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3126 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3127 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1) & valuation
}

one sig NT3128 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT3129 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3130 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT3131 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3132 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT3133 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3134 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3135 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3136 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT3137 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3138 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3139 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3140 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT3141 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3142 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3143 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT3144 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0) & valuation
}

one sig NT3145 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3146 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3147 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T4) & valuation
}

one sig NT3148 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3) & valuation
}

one sig NT3149 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3150 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3151 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3152 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3153 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3154 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3155 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3156 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2) & valuation
}

one sig NT3157 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3158 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3159 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3) & valuation
}

one sig NT3160 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3161 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3162 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3163 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3164 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3165 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3166 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3167 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3168 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT3169 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT3170 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3171 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT3172 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3173 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3174 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3175 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T3) & valuation
}

one sig NT3176 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3177 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3178 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3179 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT3180 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3181 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT3182 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3183 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3184 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT3185 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT3186 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3187 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3188 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3189 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3190 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3191 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT3192 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3193 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3194 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3195 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT3196 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3197 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3198 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3199 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3200 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3201 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3202 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT3203 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T3 + x1->T3) & valuation
}

one sig NT3204 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT3205 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3206 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3207 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3208 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT3209 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3210 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3211 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT3212 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT3213 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3214 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3215 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3216 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2) & valuation
}

one sig NT3217 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3218 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T3) & valuation
}

one sig NT3219 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3220 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3221 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3222 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3223 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3224 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3225 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3226 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3227 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3228 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3229 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3230 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3231 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3232 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3233 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3234 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT3235 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2) & valuation
}

one sig NT3236 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3237 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3238 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3239 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT3240 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT3241 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT3242 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3243 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3244 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3245 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3246 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3247 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT3248 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3249 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3250 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3251 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3252 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3253 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT3254 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T3) & valuation
}

one sig NT3255 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT3256 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3257 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3258 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT3259 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3260 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT3261 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT3262 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT3263 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3264 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3265 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3266 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT3267 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3268 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3269 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3270 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3271 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT3272 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3273 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3274 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3275 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3276 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT3277 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT3278 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3279 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3280 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT3281 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3282 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3283 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3284 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3285 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T4) & valuation
}

one sig NT3286 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T3 + x1->T4) & valuation
}

one sig NT3287 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3288 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3289 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3290 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3291 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3292 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3293 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3294 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T4) & valuation
}

one sig NT3295 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3296 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2) & valuation
}

one sig NT3297 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3298 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3299 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3300 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT3301 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3302 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3303 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3304 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T3 + x1->T3) & valuation
}

one sig NT3305 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3306 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3307 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT3308 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3309 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3310 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3311 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT3312 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT3313 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT3314 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT3315 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3316 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT3317 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3318 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT3319 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3320 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3321 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3322 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3323 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3324 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3325 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3326 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3327 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3328 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT3329 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3330 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3331 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3332 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T4) & valuation
}

one sig NT3333 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3334 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3335 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3336 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3337 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT3338 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3339 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3340 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3341 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3342 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3343 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3344 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3345 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3346 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2) & valuation
}

one sig NT3347 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT3348 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3349 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3350 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT3351 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3352 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3353 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT3354 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3355 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT3356 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT3357 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3358 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3359 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3360 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3361 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3362 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3363 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3364 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T4) & valuation
}

one sig NT3365 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3366 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3367 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3368 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT3369 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3370 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT3371 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT3372 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3373 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT3374 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3375 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3376 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3377 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT3378 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3379 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3380 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT3381 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3382 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3383 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3384 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT3385 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T2 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3386 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3387 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3388 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3389 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3390 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3391 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT3392 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3393 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0) & valuation
}

one sig NT3394 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT3395 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3396 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3397 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT3398 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT3399 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3400 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3401 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3402 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT3403 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT3404 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT3405 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3406 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T3) & valuation
}

one sig NT3407 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3408 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3409 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3410 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3411 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT3412 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3413 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT3414 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3415 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3416 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT3417 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3418 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3419 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3420 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3421 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3422 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3423 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT3424 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3425 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3426 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3427 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT3428 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1) & valuation
}

one sig NT3429 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3430 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3431 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3432 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3433 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3434 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT3435 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3436 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3437 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3438 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3439 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT3440 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3441 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3442 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0) & valuation
}

one sig NT3443 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3444 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3445 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3446 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3447 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3448 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3449 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT3450 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3451 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3452 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3453 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3454 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3455 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT3456 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3457 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3458 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT3459 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3460 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3461 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3462 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3463 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT3464 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T3) & valuation
}

one sig NT3465 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3466 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3467 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3468 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3469 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3470 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3471 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3) & valuation
}

one sig NT3472 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3473 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3474 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3475 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1) & valuation
}

one sig NT3476 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3477 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3478 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3479 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3480 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT3481 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3482 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3483 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT3484 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3485 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3486 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3487 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT3488 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3489 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3490 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT3491 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3492 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3493 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3494 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3495 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T4) & valuation
}

one sig NT3496 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT3497 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3498 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3499 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3500 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT3501 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3502 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3503 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3504 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3505 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT3506 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3507 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT3508 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3509 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3510 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3511 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3512 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT3513 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3514 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3) & valuation
}

one sig NT3515 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT3516 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3517 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3) & valuation
}

one sig NT3518 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3519 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3520 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3521 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3522 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3523 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3524 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT3525 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3526 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3527 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3528 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3529 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3530 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3531 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT3532 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3533 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3534 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3535 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3536 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3537 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3538 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3539 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3540 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3541 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3542 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3543 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT3544 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3545 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3546 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3547 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT3548 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3549 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3550 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T3) & valuation
}

one sig NT3551 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3552 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT3553 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3554 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3) & valuation
}

one sig NT3555 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3556 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT3557 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3558 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2) & valuation
}

one sig NT3559 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3560 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3561 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3562 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3563 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3564 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3565 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T4) & valuation
}

one sig NT3566 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3567 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT3568 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3569 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT3570 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3571 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3572 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT3573 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT3574 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3575 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT3576 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3577 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3578 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3579 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT3580 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3581 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3582 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3583 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3584 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT3585 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT3586 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T4) & valuation
}

one sig NT3587 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3588 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3589 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3590 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3591 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT3592 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT3593 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T4) & valuation
}

one sig NT3594 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT3595 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3596 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3597 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3598 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT3599 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT3600 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3601 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3602 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3603 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3604 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3605 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3606 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T3) & valuation
}

one sig NT3607 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT3608 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3609 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3610 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT3611 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2) & valuation
}

one sig NT3612 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3613 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT3614 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3615 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3616 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT3617 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT3618 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3619 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3620 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T3 + x0->T4) & valuation
}

one sig NT3621 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3622 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3623 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3624 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1) & valuation
}

one sig NT3625 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3626 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT3627 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3628 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3629 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3630 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3631 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3632 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT3633 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3634 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3635 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT3636 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3637 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3638 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3639 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT3640 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3641 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT3642 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3643 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3644 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3645 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2) & valuation
}

one sig NT3646 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT3647 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3648 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3649 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3650 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3651 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3652 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3653 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3654 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3655 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3656 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3657 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT3658 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3659 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3660 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3661 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT3662 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT3663 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3664 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3665 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3666 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3667 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3668 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT3669 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3670 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3671 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3672 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3673 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT3674 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3675 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT3676 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT3677 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3678 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3679 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3680 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3681 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3682 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT3683 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT3684 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3685 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3686 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3687 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3688 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT3689 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT3690 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3691 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3692 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT3693 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3694 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3695 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT3696 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3697 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT3698 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3699 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT3700 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2) & valuation
}

one sig NT3701 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT3702 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3703 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT3704 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3705 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT3706 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3707 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3708 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3709 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3) & valuation
}

one sig NT3710 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3711 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3712 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3713 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3714 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3715 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3716 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3717 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3718 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3719 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3720 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT3721 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3722 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3723 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3724 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3725 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T4) & valuation
}

one sig NT3726 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3727 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3728 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3729 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3730 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2) & valuation
}

one sig NT3731 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3732 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3733 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT3734 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3735 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT3736 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3737 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3738 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3739 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3740 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3741 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3742 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT3743 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3744 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3745 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2) & valuation
}

one sig NT3746 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3747 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3748 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3749 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3750 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT3751 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3752 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3753 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3754 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT3755 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT3756 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3757 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3758 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3759 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3760 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3761 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3762 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3763 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3764 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3765 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3766 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3767 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT3768 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3769 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3770 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3771 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3772 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T4) & valuation
}

one sig NT3773 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3774 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3775 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT3776 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3777 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T4) & valuation
}

one sig NT3778 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT3779 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3780 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3781 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3782 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3783 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT3784 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3785 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3786 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT3787 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3788 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3789 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3790 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3791 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3792 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3793 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3794 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3795 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3796 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT3797 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT3798 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3799 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT3800 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT3801 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3802 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT3803 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3804 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT3805 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT3806 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT3807 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3808 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3809 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3810 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3811 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3812 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT3813 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3814 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3815 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3816 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT3817 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x1->T3) & valuation
}

one sig NT3818 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3819 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T4) & valuation
}

one sig NT3820 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3821 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3822 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3823 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3824 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT3825 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3826 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3827 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3828 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3829 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3830 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3831 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT3832 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3833 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3834 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT3835 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3836 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3837 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3838 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3839 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3840 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3841 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT3842 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT3843 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT3844 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3845 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T3 + x0->T4) & valuation
}

one sig NT3846 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT3847 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3848 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3849 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3850 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3851 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3852 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3853 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT3854 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3855 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3856 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3857 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3858 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3859 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3860 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3861 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3862 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3863 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3864 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3865 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3866 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3867 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT3868 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3869 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT3870 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT3871 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3872 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3873 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT3874 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT3875 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3876 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3877 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3878 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3879 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3880 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT3881 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT3882 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3883 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT3884 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3885 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3886 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3887 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1) & valuation
}

one sig NT3888 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1) & valuation
}

one sig NT3889 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT3890 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3891 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3892 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3893 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT3894 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3895 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3896 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3897 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3898 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3899 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3900 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3901 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT3902 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT3903 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3904 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3905 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3906 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3907 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3908 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3909 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3910 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3911 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT3912 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT3913 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3914 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3915 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3916 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T4) & valuation
}

one sig NT3917 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT3918 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3919 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT3920 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3921 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3922 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3923 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3924 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3925 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT3926 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3927 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3928 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3) & valuation
}

one sig NT3929 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT3930 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3931 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3932 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT3933 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT3934 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT3935 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT3936 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3937 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3938 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T3) & valuation
}

one sig NT3939 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3940 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3941 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3942 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3943 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3944 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3945 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2) & valuation
}

one sig NT3946 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3947 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT3948 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3949 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3950 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT3951 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3952 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3953 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T4 + x1->T4) & valuation
}

one sig NT3954 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3955 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3956 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT3957 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3958 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT3959 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT3960 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3961 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT3962 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT3963 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT3964 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT3965 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT3966 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3967 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT3968 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3969 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3970 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT3971 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3972 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3973 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3974 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3975 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3976 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT3977 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT3978 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2) & valuation
}

one sig NT3979 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3980 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT3981 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT3982 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT3983 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3) & valuation
}

one sig NT3984 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT3985 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT3986 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3987 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT3988 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT3989 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3990 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT3991 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT3992 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT3993 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT3994 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT3995 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT3996 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT3997 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT3998 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT3999 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4000 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4001 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4002 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT4003 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT4004 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4005 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4006 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4007 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT4008 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT4009 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2) & valuation
}

one sig NT4010 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT4011 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4012 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT4013 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4014 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4015 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT4016 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4017 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4018 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4019 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4020 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4021 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT4022 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4023 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4024 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT4025 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4026 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4027 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4028 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT4029 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4030 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4031 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4032 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4033 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4034 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT4035 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT4036 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4037 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4038 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT4039 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4040 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4041 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4042 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT4043 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT4044 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4045 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4046 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4047 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4048 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4049 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4050 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT4051 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T4) & valuation
}

one sig NT4052 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT4053 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4054 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT4055 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4056 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT4057 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4058 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4059 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4060 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4061 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4062 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT4063 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT4064 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4065 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4066 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4067 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4068 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2) & valuation
}

one sig NT4069 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4070 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4071 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T3) & valuation
}

one sig NT4072 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T3) & valuation
}

one sig NT4073 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4074 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT4075 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT4076 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4077 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT4078 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT4079 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4080 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4081 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT4082 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT4083 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    
}

one sig NT4084 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4085 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4086 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4087 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4088 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4089 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4090 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4091 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT4092 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4093 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4094 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT4095 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4096 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4097 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4098 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4099 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4100 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT4101 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4102 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4103 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4104 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4105 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4106 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT4107 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT4108 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4109 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT4110 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4111 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4112 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT4113 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4114 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4115 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4116 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT4117 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4118 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4119 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4120 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4121 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4122 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4123 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4124 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4125 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4126 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT4127 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4128 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT4129 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4130 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4131 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4132 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4133 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4134 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4135 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3) & valuation
}

one sig NT4136 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T3 + x0->T4) & valuation
}

one sig NT4137 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0) & valuation
}

one sig NT4138 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4139 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT4140 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT4141 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4142 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T4) & valuation
}

one sig NT4143 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4144 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT4145 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4146 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4147 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT4148 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4149 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4150 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT4151 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT4152 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4153 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT4154 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4155 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT4156 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4157 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4158 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4159 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4160 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT4161 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4162 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4163 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4164 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT4165 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4166 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4167 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4168 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT4169 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4170 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT4171 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT4172 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT4173 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4174 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3) & valuation
}

one sig NT4175 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4176 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4177 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4178 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T3) & valuation
}

one sig NT4179 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4180 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4181 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4182 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4183 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT4184 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4185 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4186 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4187 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4188 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT4189 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT4190 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT4191 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT4192 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4193 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT4194 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT4195 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT4196 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4197 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT4198 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT4199 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4200 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT4201 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT4202 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4203 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4204 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4205 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4206 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT4207 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4208 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4209 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4210 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4211 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4212 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT4213 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4214 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4215 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4216 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4217 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T4) & valuation
}

one sig NT4218 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4219 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4220 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4221 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4222 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT4223 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4224 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4225 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT4226 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4227 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT4228 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4229 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4230 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4231 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4232 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4233 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT4234 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T3) & valuation
}

one sig NT4235 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4236 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4237 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4238 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4239 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4240 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT4241 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT4242 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4243 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4244 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT4245 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4246 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT4247 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4248 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4249 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT4250 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT4251 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4252 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4253 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4254 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4255 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4256 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4257 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4258 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4259 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T3) & valuation
}

one sig NT4260 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4261 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4262 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4263 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4264 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT4265 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4266 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2) & valuation
}

one sig NT4267 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4268 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4269 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4270 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT4271 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT4272 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT4273 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4274 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4275 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4276 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT4277 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2) & valuation
}

one sig NT4278 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4279 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4280 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4281 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4282 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4283 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT4284 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT4285 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4286 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4287 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT4288 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT4289 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4290 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4291 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4292 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT4293 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4294 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4295 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT4296 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4297 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4298 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4299 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4300 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT4301 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4302 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT4303 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4304 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT4305 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4306 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4307 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT4308 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT4309 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4310 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4311 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4312 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4313 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT4314 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4315 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2) & valuation
}

one sig NT4316 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4317 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4318 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT4319 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT4320 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT4321 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4322 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4323 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4324 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4325 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4326 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4327 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4328 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4329 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4330 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4331 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T4 + x1->T4) & valuation
}

one sig NT4332 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4333 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4334 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4335 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4336 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT4337 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4338 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4339 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT4340 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4341 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4342 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4343 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4344 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4345 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T3 + x0->T4) & valuation
}

one sig NT4346 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT4347 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4348 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT4349 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT4350 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4351 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT4352 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT4353 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT4354 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4355 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4356 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT4357 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4358 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4359 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4360 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4361 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4362 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT4363 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4364 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4365 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4366 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT4367 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T4) & valuation
}

one sig NT4368 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4369 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4370 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4371 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4372 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4373 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4374 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4375 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4376 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4377 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT4378 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT4379 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4380 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT4381 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4382 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4383 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4384 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4385 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT4386 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4387 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT4388 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4389 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4390 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4391 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT4392 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT4393 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4394 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4395 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4396 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2) & valuation
}

one sig NT4397 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4398 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4399 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4400 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4401 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4402 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4403 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4404 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4405 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT4406 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4407 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4408 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4409 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4410 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT4411 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4412 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4413 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4414 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4415 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4416 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT4417 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT4418 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4419 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4420 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT4421 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT4422 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4423 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4424 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT4425 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4426 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT4427 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4428 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4429 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4430 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4431 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT4432 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT4433 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT4434 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4435 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4436 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT4437 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4438 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4439 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4440 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4441 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4442 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT4443 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT4444 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT4445 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3) & valuation
}

one sig NT4446 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT4447 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4448 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4449 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4450 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4451 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT4452 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT4453 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4454 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T4 + x1->T4) & valuation
}

one sig NT4455 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4456 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4457 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT4458 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4459 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4460 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT4461 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT4462 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4463 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4464 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4465 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT4466 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4467 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4468 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4469 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4470 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT4471 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4472 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT4473 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4474 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4475 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT4476 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4477 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4478 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4479 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT4480 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4481 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT4482 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4483 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4484 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT4485 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4486 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT4487 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4488 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0) & valuation
}

one sig NT4489 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT4490 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4491 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT4492 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4493 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT4494 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT4495 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT4496 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4497 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4498 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4499 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4500 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4501 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4502 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT4503 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4504 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4505 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4506 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT4507 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4508 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4509 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT4510 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T4) & valuation
}

one sig NT4511 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4512 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4513 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4514 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4515 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4516 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T3 + x1->T3) & valuation
}

one sig NT4517 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4518 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T4) & valuation
}

one sig NT4519 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4520 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T4) & valuation
}

one sig NT4521 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4522 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4523 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4524 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT4525 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT4526 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4527 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4528 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4529 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4530 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4531 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T4) & valuation
}

one sig NT4532 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4533 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4534 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4535 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT4536 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1) & valuation
}

one sig NT4537 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4538 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT4539 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2) & valuation
}

one sig NT4540 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 in valuation
    no (x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4541 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT4542 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4543 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4544 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT4545 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4546 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4547 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2) & valuation
}

one sig NT4548 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT4549 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT4550 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4551 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT4552 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4553 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4554 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4555 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4556 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT4557 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4558 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2) & valuation
}

one sig NT4559 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT4560 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4561 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT4562 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4563 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4564 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4565 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4566 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4567 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4568 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4569 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4570 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4571 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4572 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4573 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT4574 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4575 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4576 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT4577 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4578 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4579 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4580 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4581 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4582 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT4583 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4584 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4585 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4586 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2) & valuation
}

one sig NT4587 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4588 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT4589 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4590 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4591 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4592 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4593 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT4594 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT4595 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4596 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4597 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4598 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4599 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT4600 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4601 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT4602 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4603 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT4604 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4605 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT4606 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4607 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4608 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT4609 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4610 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4611 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT4612 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4613 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4614 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT4615 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4616 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT4617 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT4618 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4619 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4620 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4621 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT4622 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2) & valuation
}

one sig NT4623 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4624 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4625 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4626 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4627 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4628 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4629 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT4630 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4631 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4632 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4633 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4634 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT4635 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT4636 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4637 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4638 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2) & valuation
}

one sig NT4639 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4640 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4641 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT4642 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4643 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1) & valuation
}

one sig NT4644 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T3) & valuation
}

one sig NT4645 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT4646 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2) & valuation
}

one sig NT4647 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4648 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4649 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT4650 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4651 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4652 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4653 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4654 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT4655 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT4656 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4657 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4658 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4659 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT4660 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4661 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4662 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT4663 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4664 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    
}

one sig NT4665 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4666 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT4667 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4668 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4669 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4670 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4671 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4672 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4673 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4674 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4675 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4676 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT4677 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4678 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4679 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT4680 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4681 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4682 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4683 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4684 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4685 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4686 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4687 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT4688 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT4689 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4690 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT4691 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT4692 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4693 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT4694 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT4695 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT4696 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4697 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4698 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4699 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT4700 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT4701 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT4702 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT4703 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT4704 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4705 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4706 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4707 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4708 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4709 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT4710 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4711 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT4712 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4713 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT4714 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4715 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4716 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT4717 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT4718 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4719 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4720 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4721 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4722 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT4723 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4724 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT4725 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT4726 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4727 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4728 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4729 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4730 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4731 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4732 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4733 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT4734 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4735 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4736 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4737 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4738 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x0->T3) & valuation
}

one sig NT4739 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T3 + x1->T3) & valuation
}

one sig NT4740 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT4741 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4742 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4743 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT4744 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT4745 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4746 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT4747 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4748 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4749 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4750 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4751 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T4) & valuation
}

one sig NT4752 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4753 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT4754 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4755 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT4756 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT4757 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4758 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1) & valuation
}

one sig NT4759 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT4760 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4761 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4762 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4763 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4764 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4765 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4766 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4767 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT4768 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4769 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4770 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4771 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT4772 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4773 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2) & valuation
}

one sig NT4774 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4775 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T4) & valuation
}

one sig NT4776 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4777 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT4778 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT4779 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT4780 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT4781 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4782 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4783 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4784 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4785 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4786 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4787 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4788 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4789 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T4) & valuation
}

one sig NT4790 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4791 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4792 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4793 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4794 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4795 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4796 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT4797 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4798 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT4799 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4800 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT4801 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2) & valuation
}

one sig NT4802 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2) & valuation
}

one sig NT4803 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT4804 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4805 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT4806 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4807 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1) & valuation
}

one sig NT4808 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2) & valuation
}

one sig NT4809 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4810 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT4811 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4812 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT4813 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4814 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4815 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4816 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT4817 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4818 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4819 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4820 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT4821 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT4822 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4823 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3) & valuation
}

one sig NT4824 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4825 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT4826 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT4827 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4828 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4829 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT4830 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4831 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4832 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT4833 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT4834 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4835 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4836 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4837 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT4838 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4839 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT4840 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4841 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT4842 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT4843 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT4844 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT4845 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1) & valuation
}

one sig NT4846 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT4847 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT4848 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT4849 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT4850 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T3 + x1->T4) & valuation
}

one sig LearnedLTL {
    Root: DAGNode
}
fun root: one DAGNode { LearnedLTL.Root }
fun childrenOf[n: DAGNode]: set DAGNode { n.^(l+r) }
fun childrenAndSelfOf[n: DAGNode]: set DAGNode { n.*(l+r) }
fun ancestorsOf[n: DAGNode]: set DAGNode { n.~^(l+r) }
fun ancestorsAndSelfOf[n: DAGNode]: set DAGNode { n.~*(l+r) }
fun subDAG[n: DAGNode]: DAGNode -> DAGNode { n.*(l+r) <: (l+r) }



fun experimentReach: set DAGNode { childrenAndSelfOf[root] }
fun experimentKept: DAGNode -> DAGNode { (none->none) & subDAG[root] }
one sig ExperimentCost { used: set DAGNode }
fact { ExperimentCost.used = experimentReach }
fact ExperimentBounds {
  DAGNode = experimentReach + Literal + (none)
  #experimentReach <= 5
  #(experimentReach & (And + Or + Imply)) <= 2
  minsome ExperimentCost.used
}
run {
    all t: PositiveTrace | root->T0 in t.valuation
    all t: NegativeTrace | root->T0 not in t.valuation
    
} for 7 DAGNode, 4 Int
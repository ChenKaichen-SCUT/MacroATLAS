open util/ordering[SeqIdx]

abstract sig DAGNode {
	l: set DAGNode,
	r: set DAGNode
}
fact {
	all n: DAGNode | n not in n.^(l + r)
}

sig And, Or, Imply extends DAGNode {} {
	one l
	one r
}

sig Neg, G extends DAGNode {} {
    one l
    no r
}
abstract sig Literal extends DAGNode {} {
	no l
	no r
}

abstract sig SeqIdx {}
abstract sig Trace {
	lasso: SeqIdx -> SeqIdx,
	valuation: DAGNode -> SeqIdx
} {
	// Negation
    all n: Neg, i: seqRange | n->i in valuation iff n.l->i not in valuation
	// Or
    all n: Or, i: seqRange | n->i in valuation iff (n.l->i in valuation or n.r->i in valuation)
	// And
    all n: And, i: seqRange | n->i in valuation iff (n.l->i in valuation and n.r->i in valuation)
	// Imply
    all n: Imply, i: seqRange | n->i in valuation iff (n.l->i not in valuation or n.r->i in valuation)
	// G
    all n: G, i: seqRange | n->i in valuation iff all i': futureIdx[i] | n.l->i' in valuation
    // X
    
	// F
    
	// Until
    
}
fun seqRange[t: Trace]: set SeqIdx {
	let lastOfTrace = t.lasso.SeqIdx | lastOfTrace.prevs + lastOfTrace
}
fun futureIdx[t: Trace, i: SeqIdx]: set SeqIdx {
	i.^((next :> seqRange[t]) + t.lasso) + i
}
abstract sig PositiveTrace extends Trace {}
abstract sig NegativeTrace extends Trace {}
one sig x0, x1, x2 extends Literal {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22, T23, T24, T25, T26, T27, T28, T29, T30, T31, T32, T33, T34, T35, T36, T37, T38, T39 extends SeqIdx {}
fact {
    first = T0
    next = T0->T1 + T1->T2 + T2->T3 + T3->T4 + T4->T5 + T5->T6 + T6->T7 + T7->T8 + T8->T9 + T9->T10 + T10->T11 + T11->T12 + T12->T13 + T13->T14 + T14->T15 + T15->T16 + T16->T17 + T17->T18 + T18->T19 + T19->T20 + T20->T21 + T21->T22 + T22->T23 + T23->T24 + T24->T25 + T25->T26 + T26->T27 + T27->T28 + T28->T29 + T29->T30 + T30->T31 + T31->T32 + T32->T33 + T33->T34 + T34->T35 + T35->T36 + T36->T37 + T37->T38 + T38->T39
}

one sig PT0 extends PositiveTrace {} {
    lasso = T39->T0
    x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x1->T7 + x1->T8 + x0->T9 + x1->T9 + x2->T9 + x0->T10 + x1->T10 + x2->T10 + x0->T12 + x1->T12 + x1->T13 + x0->T14 + x1->T14 + x0->T15 + x1->T15 + x2->T15 + x1->T16 + x2->T16 + x1->T17 + x2->T17 + x1->T18 + x2->T18 + x2->T19 + x1->T20 + x2->T20 + x1->T21 + x2->T21 + x0->T22 + x1->T22 + x2->T22 + x0->T23 + x1->T23 + x2->T23 + x2->T24 + x0->T25 + x1->T25 + x2->T25 + x1->T26 + x1->T28 + x0->T29 + x1->T29 + x2->T29 + x0->T30 + x1->T30 + x2->T30 + x0->T31 + x1->T31 + x2->T31 + x0->T32 + x1->T32 + x2->T32 + x1->T33 + x1->T34 + x2->T34 + x2->T35 + x1->T36 + x2->T36 + x1->T37 + x2->T37 + x1->T38 + x2->T38 + x2->T39 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T11 + x1->T11 + x2->T11 + x2->T12 + x0->T13 + x2->T13 + x2->T14 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x1->T19 + x0->T20 + x0->T21 + x0->T24 + x1->T24 + x0->T26 + x2->T26 + x0->T27 + x1->T27 + x2->T27 + x0->T28 + x2->T28 + x0->T33 + x2->T33 + x0->T34 + x0->T35 + x1->T35 + x0->T36 + x0->T37 + x0->T38 + x0->T39 + x1->T39) & valuation
}

one sig PT1 extends PositiveTrace {} {
    lasso = T39->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x1->T6 + x2->T6 + x2->T7 + x1->T8 + x0->T9 + x1->T9 + x2->T9 + x1->T10 + x2->T10 + x1->T11 + x2->T11 + x0->T13 + x1->T13 + x0->T14 + x1->T14 + x2->T14 + x1->T16 + x2->T20 + x0->T21 + x1->T21 + x2->T21 + x0->T22 + x1->T22 + x2->T23 + x0->T24 + x1->T24 + x1->T25 + x2->T25 + x2->T27 + x1->T28 + x1->T29 + x2->T29 + x2->T30 + x1->T31 + x1->T32 + x2->T32 + x2->T33 + x0->T34 + x1->T34 + x0->T35 + x1->T35 + x2->T35 + x2->T37 + x0->T38 + x1->T38 + x2->T38 + x1->T39 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x0->T5 + x1->T5 + x0->T6 + x0->T7 + x1->T7 + x0->T8 + x2->T8 + x0->T10 + x0->T11 + x0->T12 + x1->T12 + x2->T12 + x2->T13 + x0->T15 + x1->T15 + x2->T15 + x0->T16 + x2->T16 + x0->T17 + x1->T17 + x2->T17 + x0->T18 + x1->T18 + x2->T18 + x0->T19 + x1->T19 + x2->T19 + x0->T20 + x1->T20 + x2->T22 + x0->T23 + x1->T23 + x2->T24 + x0->T25 + x0->T26 + x1->T26 + x2->T26 + x0->T27 + x1->T27 + x0->T28 + x2->T28 + x0->T29 + x0->T30 + x1->T30 + x0->T31 + x2->T31 + x0->T32 + x0->T33 + x1->T33 + x2->T34 + x0->T36 + x1->T36 + x2->T36 + x0->T37 + x1->T37 + x0->T39 + x2->T39) & valuation
}

one sig PT2 extends PositiveTrace {} {
    lasso = T39->T0
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x1->T7 + x0->T8 + x1->T8 + x1->T9 + x2->T9 + x1->T10 + x2->T10 + x1->T11 + x2->T11 + x1->T12 + x2->T12 + x1->T13 + x2->T13 + x1->T14 + x1->T16 + x1->T17 + x2->T17 + x0->T18 + x1->T18 + x0->T19 + x1->T19 + x2->T19 + x2->T20 + x1->T21 + x2->T21 + x0->T22 + x1->T22 + x1->T23 + x2->T24 + x1->T25 + x2->T25 + x2->T26 + x1->T28 + x2->T28 + x2->T30 + x1->T31 + x2->T31 + x1->T32 + x2->T32 + x0->T33 + x1->T33 + x2->T33 + x1->T34 + x2->T34 + x0->T35 + x1->T35 + x0->T37 + x1->T37 + x2->T37 + x0->T38 + x1->T38 + x2->T38 + x1->T39 in valuation
    no (x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x2->T4 + x0->T5 + x2->T6 + x0->T7 + x2->T7 + x2->T8 + x0->T9 + x0->T10 + x0->T11 + x0->T12 + x0->T13 + x0->T14 + x2->T14 + x0->T15 + x1->T15 + x2->T15 + x0->T16 + x2->T16 + x0->T17 + x2->T18 + x0->T20 + x1->T20 + x0->T21 + x2->T22 + x0->T23 + x2->T23 + x0->T24 + x1->T24 + x0->T25 + x0->T26 + x1->T26 + x0->T27 + x1->T27 + x2->T27 + x0->T28 + x0->T29 + x1->T29 + x2->T29 + x0->T30 + x1->T30 + x0->T31 + x0->T32 + x0->T34 + x2->T35 + x0->T36 + x1->T36 + x2->T36 + x0->T39 + x2->T39) & valuation
}

one sig PT3 extends PositiveTrace {} {
    lasso = T39->T0
    x1->T0 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T9 + x1->T9 + x2->T10 + x1->T11 + x0->T12 + x1->T12 + x2->T12 + x1->T13 + x0->T14 + x1->T14 + x1->T15 + x0->T17 + x1->T17 + x2->T17 + x2->T18 + x1->T20 + x0->T21 + x1->T21 + x0->T22 + x1->T22 + x2->T22 + x2->T23 + x0->T24 + x1->T24 + x2->T24 + x0->T25 + x1->T25 + x0->T26 + x1->T26 + x2->T26 + x0->T27 + x1->T27 + x2->T27 + x0->T28 + x1->T28 + x2->T29 + x0->T30 + x1->T30 + x0->T31 + x1->T31 + x1->T32 + x2->T32 + x1->T34 + x0->T36 + x1->T36 + x2->T36 + x0->T37 + x1->T37 + x2->T37 + x0->T38 + x1->T38 + x2->T39 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T4 + x0->T5 + x2->T5 + x2->T6 + x0->T8 + x1->T8 + x2->T8 + x2->T9 + x0->T10 + x1->T10 + x0->T11 + x2->T11 + x0->T13 + x2->T13 + x2->T14 + x0->T15 + x2->T15 + x0->T16 + x1->T16 + x2->T16 + x0->T18 + x1->T18 + x0->T19 + x1->T19 + x2->T19 + x0->T20 + x2->T20 + x2->T21 + x0->T23 + x1->T23 + x2->T25 + x2->T28 + x0->T29 + x1->T29 + x2->T30 + x2->T31 + x0->T32 + x0->T33 + x1->T33 + x2->T33 + x0->T34 + x2->T34 + x0->T35 + x1->T35 + x2->T35 + x2->T38 + x0->T39 + x1->T39) & valuation
}

one sig PT4 extends PositiveTrace {} {
    lasso = T39->T0
    x0->T0 + x1->T0 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T5 + x0->T6 + x1->T6 + x2->T7 + x2->T8 + x2->T9 + x0->T11 + x1->T11 + x2->T11 + x0->T12 + x1->T12 + x2->T13 + x0->T14 + x1->T14 + x2->T14 + x1->T15 + x1->T16 + x0->T17 + x1->T17 + x0->T18 + x1->T18 + x2->T18 + x1->T19 + x0->T20 + x1->T20 + x2->T20 + x0->T22 + x1->T22 + x2->T23 + x1->T24 + x1->T25 + x2->T25 + x2->T26 + x1->T27 + x1->T28 + x0->T29 + x1->T29 + x2->T29 + x1->T31 + x2->T31 + x0->T32 + x1->T32 + x2->T32 + x2->T33 + x0->T34 + x1->T34 + x2->T34 + x0->T35 + x1->T35 + x0->T36 + x1->T36 + x2->T36 + x2->T37 + x1->T38 + x2->T38 + x1->T39 + x2->T39 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 + x0->T10 + x1->T10 + x2->T10 + x2->T12 + x0->T13 + x1->T13 + x0->T15 + x2->T15 + x0->T16 + x2->T16 + x2->T17 + x0->T19 + x2->T19 + x0->T21 + x1->T21 + x2->T21 + x2->T22 + x0->T23 + x1->T23 + x0->T24 + x2->T24 + x0->T25 + x0->T26 + x1->T26 + x0->T27 + x2->T27 + x0->T28 + x2->T28 + x0->T30 + x1->T30 + x2->T30 + x0->T31 + x0->T33 + x1->T33 + x2->T35 + x0->T37 + x1->T37 + x0->T38 + x0->T39) & valuation
}

one sig PT5 extends PositiveTrace {} {
    lasso = T39->T0
    x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T7 + x0->T9 + x1->T9 + x0->T10 + x1->T10 + x2->T10 + x0->T11 + x1->T11 + x2->T11 + x0->T13 + x1->T13 + x2->T13 + x0->T14 + x1->T14 + x0->T15 + x1->T15 + x0->T16 + x1->T16 + x1->T17 + x2->T17 + x0->T18 + x1->T18 + x2->T18 + x1->T19 + x1->T20 + x2->T20 + x0->T23 + x1->T23 + x2->T23 + x1->T24 + x2->T24 + x2->T25 + x1->T26 + x1->T27 + x2->T27 + x1->T29 + x2->T30 + x0->T31 + x1->T31 + x1->T32 + x2->T33 + x2->T34 + x1->T35 + x2->T35 + x1->T36 + x2->T36 + x0->T37 + x1->T37 + x2->T37 + x0->T39 + x1->T39 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x2->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x2->T8 + x2->T9 + x0->T12 + x1->T12 + x2->T12 + x2->T14 + x2->T15 + x2->T16 + x0->T17 + x0->T19 + x2->T19 + x0->T20 + x0->T21 + x1->T21 + x2->T21 + x0->T22 + x1->T22 + x2->T22 + x0->T24 + x0->T25 + x1->T25 + x0->T26 + x2->T26 + x0->T27 + x0->T28 + x1->T28 + x2->T28 + x0->T29 + x2->T29 + x0->T30 + x1->T30 + x2->T31 + x0->T32 + x2->T32 + x0->T33 + x1->T33 + x0->T34 + x1->T34 + x0->T35 + x0->T36 + x0->T38 + x1->T38 + x2->T38 + x2->T39) & valuation
}

one sig PT6 extends PositiveTrace {} {
    lasso = T39->T0
    x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T4 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x2->T7 + x2->T8 + x0->T10 + x1->T10 + x0->T12 + x1->T12 + x2->T12 + x0->T14 + x1->T14 + x2->T14 + x0->T15 + x1->T15 + x1->T16 + x1->T17 + x2->T17 + x0->T18 + x1->T18 + x0->T19 + x1->T19 + x2->T19 + x0->T22 + x1->T22 + x2->T22 + x0->T26 + x1->T26 + x2->T26 + x1->T27 + x1->T28 + x0->T29 + x1->T29 + x2->T29 + x0->T30 + x1->T30 + x2->T31 + x1->T33 + x2->T33 + x1->T34 + x2->T34 + x1->T35 + x2->T36 + x1->T37 + x1->T38 + x1->T39 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T5 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 + x2->T9 + x2->T10 + x0->T11 + x1->T11 + x2->T11 + x0->T13 + x1->T13 + x2->T13 + x2->T15 + x0->T16 + x2->T16 + x0->T17 + x2->T18 + x0->T20 + x1->T20 + x2->T20 + x0->T21 + x1->T21 + x2->T21 + x0->T23 + x1->T23 + x2->T23 + x0->T24 + x1->T24 + x2->T24 + x0->T25 + x1->T25 + x2->T25 + x0->T27 + x2->T27 + x0->T28 + x2->T28 + x2->T30 + x0->T31 + x1->T31 + x0->T32 + x1->T32 + x2->T32 + x0->T33 + x0->T34 + x0->T35 + x2->T35 + x0->T36 + x1->T36 + x0->T37 + x2->T37 + x0->T38 + x2->T38 + x0->T39 + x2->T39) & valuation
}

one sig PT7 extends PositiveTrace {} {
    lasso = T39->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T7 + x2->T8 + x1->T9 + x1->T10 + x0->T12 + x1->T12 + x0->T13 + x1->T13 + x2->T13 + x0->T14 + x1->T14 + x1->T15 + x2->T15 + x2->T16 + x2->T18 + x0->T19 + x1->T19 + x2->T19 + x0->T20 + x1->T20 + x2->T21 + x1->T23 + x2->T23 + x2->T24 + x1->T25 + x2->T25 + x2->T26 + x2->T27 + x0->T29 + x1->T29 + x2->T30 + x0->T31 + x1->T31 + x2->T31 + x1->T32 + x2->T32 + x1->T33 + x2->T33 + x0->T34 + x1->T34 + x2->T34 + x2->T35 + x1->T36 + x2->T36 + x2->T38 + x1->T39 + x2->T39 in valuation
    no (x2->T0 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T5 + x2->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x2->T9 + x0->T10 + x2->T10 + x0->T11 + x1->T11 + x2->T11 + x2->T12 + x2->T14 + x0->T15 + x0->T16 + x1->T16 + x0->T17 + x1->T17 + x2->T17 + x0->T18 + x1->T18 + x2->T20 + x0->T21 + x1->T21 + x0->T22 + x1->T22 + x2->T22 + x0->T23 + x0->T24 + x1->T24 + x0->T25 + x0->T26 + x1->T26 + x0->T27 + x1->T27 + x0->T28 + x1->T28 + x2->T28 + x2->T29 + x0->T30 + x1->T30 + x0->T32 + x0->T33 + x0->T35 + x1->T35 + x0->T36 + x0->T37 + x1->T37 + x2->T37 + x0->T38 + x1->T38 + x0->T39) & valuation
}

one sig PT8 extends PositiveTrace {} {
    lasso = T39->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x1->T5 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 + x2->T9 + x1->T10 + x1->T11 + x2->T11 + x1->T12 + x2->T13 + x2->T15 + x0->T16 + x1->T16 + x2->T16 + x2->T17 + x2->T18 + x0->T19 + x1->T19 + x2->T19 + x0->T21 + x1->T21 + x0->T22 + x1->T22 + x1->T24 + x0->T25 + x1->T25 + x0->T26 + x1->T26 + x1->T27 + x1->T28 + x0->T30 + x1->T30 + x2->T31 + x1->T32 + x1->T33 + x2->T33 + x2->T34 + x1->T36 + x2->T36 + x0->T37 + x1->T37 + x2->T37 + x1->T39 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T3 + x0->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x2->T7 + x2->T8 + x0->T10 + x2->T10 + x0->T11 + x0->T12 + x2->T12 + x0->T13 + x1->T13 + x0->T14 + x1->T14 + x2->T14 + x0->T15 + x1->T15 + x0->T17 + x1->T17 + x0->T18 + x1->T18 + x0->T20 + x1->T20 + x2->T20 + x2->T21 + x2->T22 + x0->T23 + x1->T23 + x2->T23 + x0->T24 + x2->T24 + x2->T25 + x2->T26 + x0->T27 + x2->T27 + x0->T28 + x2->T28 + x0->T29 + x1->T29 + x2->T29 + x2->T30 + x0->T31 + x1->T31 + x0->T32 + x2->T32 + x0->T33 + x0->T34 + x1->T34 + x0->T35 + x1->T35 + x2->T35 + x0->T36 + x0->T38 + x1->T38 + x2->T38 + x0->T39 + x2->T39) & valuation
}

one sig PT9 extends PositiveTrace {} {
    lasso = T39->T0
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x1->T8 + x2->T8 + x0->T9 + x1->T9 + x1->T10 + x2->T10 + x1->T11 + x2->T11 + x2->T12 + x2->T14 + x1->T15 + x2->T15 + x0->T16 + x1->T16 + x2->T16 + x0->T18 + x1->T18 + x0->T21 + x1->T21 + x2->T21 + x2->T22 + x1->T23 + x2->T23 + x1->T24 + x2->T25 + x2->T26 + x1->T27 + x2->T27 + x1->T28 + x2->T28 + x0->T30 + x1->T30 + x2->T30 + x1->T32 + x2->T32 + x0->T34 + x1->T34 + x2->T34 + x2->T35 + x2->T36 + x1->T37 + x2->T39 in valuation
    no (x0->T1 + x2->T3 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x2->T9 + x0->T10 + x0->T11 + x0->T12 + x1->T12 + x0->T13 + x1->T13 + x2->T13 + x0->T14 + x1->T14 + x0->T15 + x0->T17 + x1->T17 + x2->T17 + x2->T18 + x0->T19 + x1->T19 + x2->T19 + x0->T20 + x1->T20 + x2->T20 + x0->T22 + x1->T22 + x0->T23 + x0->T24 + x2->T24 + x0->T25 + x1->T25 + x0->T26 + x1->T26 + x0->T27 + x0->T28 + x0->T29 + x1->T29 + x2->T29 + x0->T31 + x1->T31 + x2->T31 + x0->T32 + x0->T33 + x1->T33 + x2->T33 + x0->T35 + x1->T35 + x0->T36 + x1->T36 + x0->T37 + x2->T37 + x0->T38 + x1->T38 + x2->T38 + x0->T39 + x1->T39) & valuation
}


one sig NT0 extends NegativeTrace {} {
    lasso = T39->T0
    x0->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x0->T8 + x0->T9 + x1->T9 + x0->T10 + x1->T10 + x2->T11 + x0->T12 + x2->T12 + x0->T13 + x1->T13 + x2->T13 + x0->T14 + x2->T14 + x1->T15 + x0->T17 + x1->T17 + x2->T17 + x0->T18 + x0->T19 + x0->T20 + x2->T20 + x2->T21 + x1->T22 + x2->T22 + x2->T23 + x0->T24 + x1->T24 + x2->T24 + x0->T25 + x1->T26 + x2->T27 + x0->T28 + x2->T29 + x0->T30 + x0->T31 + x2->T31 + x0->T32 + x2->T33 + x1->T34 + x2->T34 + x0->T35 + x2->T35 + x1->T36 + x1->T37 + x0->T38 + x1->T38 + x2->T38 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T5 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x2->T9 + x2->T10 + x0->T11 + x1->T11 + x1->T12 + x1->T14 + x0->T15 + x2->T15 + x0->T16 + x1->T16 + x2->T16 + x1->T18 + x2->T18 + x1->T19 + x2->T19 + x1->T20 + x0->T21 + x1->T21 + x0->T22 + x0->T23 + x1->T23 + x1->T25 + x2->T25 + x0->T26 + x2->T26 + x0->T27 + x1->T27 + x1->T28 + x2->T28 + x0->T29 + x1->T29 + x1->T30 + x2->T30 + x1->T31 + x1->T32 + x2->T32 + x0->T33 + x1->T33 + x0->T34 + x1->T35 + x0->T36 + x2->T36 + x0->T37 + x2->T37 + x0->T39 + x1->T39 + x2->T39) & valuation
}

one sig NT1 extends NegativeTrace {} {
    lasso = T39->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x1->T6 + x0->T7 + x0->T8 + x0->T9 + x2->T9 + x0->T10 + x2->T10 + x0->T11 + x2->T12 + x0->T13 + x2->T13 + x0->T14 + x2->T14 + x2->T15 + x2->T16 + x0->T17 + x2->T17 + x0->T18 + x2->T18 + x0->T19 + x0->T20 + x0->T21 + x2->T21 + x1->T22 + x2->T22 + x0->T23 + x0->T24 + x2->T24 + x2->T25 + x1->T26 + x2->T26 + x0->T27 + x1->T27 + x0->T28 + x0->T29 + x1->T29 + x2->T29 + x1->T30 + x2->T30 + x0->T31 + x2->T31 + x0->T32 + x2->T32 + x0->T33 + x2->T33 + x2->T34 + x0->T35 + x1->T35 + x2->T35 + x0->T36 + x0->T37 + x1->T37 + x0->T38 + x1->T38 + x0->T39 in valuation
    no (x1->T0 + x2->T0 + x2->T1 + x1->T3 + x2->T3 + x1->T4 + x1->T5 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9 + x1->T10 + x1->T11 + x2->T11 + x0->T12 + x1->T12 + x1->T13 + x1->T14 + x0->T15 + x1->T15 + x0->T16 + x1->T16 + x1->T17 + x1->T18 + x1->T19 + x2->T19 + x1->T20 + x2->T20 + x1->T21 + x0->T22 + x1->T23 + x2->T23 + x1->T24 + x0->T25 + x1->T25 + x0->T26 + x2->T27 + x1->T28 + x2->T28 + x0->T30 + x1->T31 + x1->T32 + x1->T33 + x0->T34 + x1->T34 + x1->T36 + x2->T36 + x2->T37 + x2->T38 + x1->T39 + x2->T39) & valuation
}

one sig NT2 extends NegativeTrace {} {
    lasso = T39->T0
    x0->T0 + x2->T0 + x0->T2 + x2->T2 + x0->T4 + x2->T4 + x0->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x0->T9 + x2->T9 + x0->T10 + x0->T11 + x1->T11 + x0->T12 + x2->T12 + x0->T13 + x2->T13 + x0->T14 + x0->T15 + x0->T16 + x0->T17 + x2->T17 + x0->T18 + x0->T19 + x0->T20 + x0->T21 + x1->T22 + x2->T22 + x0->T23 + x2->T23 + x0->T24 + x2->T24 + x2->T25 + x0->T26 + x0->T27 + x2->T27 + x0->T28 + x2->T28 + x0->T29 + x1->T29 + x0->T30 + x0->T31 + x2->T31 + x0->T33 + x0->T34 + x2->T34 + x0->T35 + x2->T35 + x0->T36 + x2->T36 + x0->T38 + x1->T38 + x2->T38 + x0->T39 + x2->T39 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9 + x1->T10 + x2->T10 + x2->T11 + x1->T12 + x1->T13 + x1->T14 + x2->T14 + x1->T15 + x2->T15 + x1->T16 + x2->T16 + x1->T17 + x1->T18 + x2->T18 + x1->T19 + x2->T19 + x1->T20 + x2->T20 + x1->T21 + x2->T21 + x0->T22 + x1->T23 + x1->T24 + x0->T25 + x1->T25 + x1->T26 + x2->T26 + x1->T27 + x1->T28 + x2->T29 + x1->T30 + x2->T30 + x1->T31 + x0->T32 + x1->T32 + x2->T32 + x1->T33 + x2->T33 + x1->T34 + x1->T35 + x1->T36 + x0->T37 + x1->T37 + x2->T37 + x1->T39) & valuation
}

one sig NT3 extends NegativeTrace {} {
    lasso = T39->T0
    x0->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x0->T9 + x0->T10 + x0->T11 + x2->T11 + x1->T12 + x0->T13 + x0->T14 + x0->T17 + x1->T18 + x0->T19 + x2->T19 + x0->T20 + x0->T22 + x1->T22 + x0->T23 + x1->T23 + x2->T23 + x0->T25 + x0->T26 + x2->T26 + x2->T27 + x0->T28 + x1->T28 + x2->T28 + x1->T29 + x1->T31 + x2->T31 + x1->T32 + x2->T34 + x0->T35 + x1->T35 + x0->T36 + x1->T36 + x1->T37 + x0->T39 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x1->T6 + x0->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9 + x1->T10 + x2->T10 + x1->T11 + x0->T12 + x2->T12 + x1->T13 + x2->T13 + x1->T14 + x2->T14 + x0->T15 + x1->T15 + x2->T15 + x0->T16 + x1->T16 + x2->T16 + x1->T17 + x2->T17 + x0->T18 + x2->T18 + x1->T19 + x1->T20 + x2->T20 + x0->T21 + x1->T21 + x2->T21 + x2->T22 + x0->T24 + x1->T24 + x2->T24 + x1->T25 + x2->T25 + x1->T26 + x0->T27 + x1->T27 + x0->T29 + x2->T29 + x0->T30 + x1->T30 + x2->T30 + x0->T31 + x0->T32 + x2->T32 + x0->T33 + x1->T33 + x2->T33 + x0->T34 + x1->T34 + x2->T35 + x2->T36 + x0->T37 + x2->T37 + x0->T38 + x1->T38 + x2->T38 + x1->T39 + x2->T39) & valuation
}

one sig NT4 extends NegativeTrace {} {
    lasso = T39->T0
    x2->T0 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x2->T4 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x2->T7 + x2->T8 + x0->T9 + x2->T9 + x1->T10 + x1->T11 + x2->T11 + x0->T12 + x2->T12 + x1->T13 + x0->T14 + x1->T14 + x1->T15 + x2->T16 + x0->T17 + x1->T17 + x2->T17 + x0->T18 + x1->T18 + x1->T19 + x0->T22 + x1->T22 + x1->T23 + x0->T24 + x1->T24 + x0->T25 + x1->T25 + x2->T25 + x1->T26 + x2->T26 + x0->T27 + x1->T27 + x1->T28 + x2->T28 + x0->T30 + x0->T31 + x1->T31 + x2->T31 + x1->T33 + x1->T34 + x2->T34 + x1->T35 + x2->T35 + x1->T36 + x0->T37 + x1->T37 + x0->T39 + x1->T39 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x2->T6 + x0->T8 + x1->T8 + x1->T9 + x0->T10 + x2->T10 + x0->T11 + x1->T12 + x0->T13 + x2->T13 + x2->T14 + x0->T15 + x2->T15 + x0->T16 + x1->T16 + x2->T18 + x0->T19 + x2->T19 + x0->T20 + x1->T20 + x2->T20 + x0->T21 + x1->T21 + x2->T21 + x2->T22 + x0->T23 + x2->T23 + x2->T24 + x0->T26 + x2->T27 + x0->T28 + x0->T29 + x1->T29 + x2->T29 + x1->T30 + x2->T30 + x0->T32 + x1->T32 + x2->T32 + x0->T33 + x2->T33 + x0->T34 + x0->T35 + x0->T36 + x2->T36 + x2->T37 + x0->T38 + x1->T38 + x2->T38 + x2->T39) & valuation
}

one sig NT5 extends NegativeTrace {} {
    lasso = T39->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T2 + x1->T3 + x2->T3 + x2->T4 + x0->T6 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x2->T9 + x0->T10 + x1->T10 + x0->T11 + x1->T11 + x2->T11 + x1->T12 + x2->T12 + x0->T13 + x1->T13 + x2->T13 + x0->T14 + x1->T14 + x2->T14 + x2->T15 + x0->T16 + x2->T16 + x2->T17 + x1->T18 + x2->T18 + x1->T19 + x0->T20 + x1->T22 + x2->T22 + x0->T23 + x2->T23 + x0->T25 + x0->T26 + x2->T26 + x0->T27 + x1->T27 + x0->T28 + x2->T29 + x1->T30 + x2->T30 + x0->T31 + x1->T32 + x1->T33 + x0->T34 + x2->T35 + x0->T36 + x0->T37 + x1->T37 + x0->T38 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x1->T9 + x2->T10 + x0->T12 + x0->T15 + x1->T15 + x1->T16 + x0->T17 + x1->T17 + x0->T18 + x0->T19 + x2->T19 + x1->T20 + x2->T20 + x0->T21 + x1->T21 + x2->T21 + x0->T22 + x1->T23 + x0->T24 + x1->T24 + x2->T24 + x1->T25 + x2->T25 + x1->T26 + x2->T27 + x1->T28 + x2->T28 + x0->T29 + x1->T29 + x0->T30 + x1->T31 + x2->T31 + x0->T32 + x2->T32 + x0->T33 + x2->T33 + x1->T34 + x2->T34 + x0->T35 + x1->T35 + x1->T36 + x2->T36 + x2->T37 + x1->T38 + x2->T38 + x0->T39 + x1->T39 + x2->T39) & valuation
}

one sig NT6 extends NegativeTrace {} {
    lasso = T39->T0
    x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x0->T6 + x0->T7 + x2->T7 + x0->T10 + x2->T10 + x0->T11 + x2->T11 + x0->T13 + x2->T13 + x0->T14 + x0->T15 + x1->T15 + x2->T15 + x0->T16 + x0->T17 + x0->T18 + x0->T19 + x0->T20 + x1->T20 + x2->T20 + x2->T21 + x0->T23 + x2->T24 + x0->T25 + x0->T26 + x0->T27 + x1->T27 + x2->T27 + x1->T28 + x2->T28 + x0->T29 + x2->T29 + x0->T30 + x2->T30 + x0->T31 + x0->T32 + x0->T33 + x2->T33 + x0->T34 + x2->T34 + x1->T35 + x2->T35 + x0->T36 + x1->T37 + x2->T37 + x0->T38 + x2->T39 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9 + x1->T10 + x1->T11 + x0->T12 + x1->T12 + x2->T12 + x1->T13 + x1->T14 + x2->T14 + x1->T16 + x2->T16 + x1->T17 + x2->T17 + x1->T18 + x2->T18 + x1->T19 + x2->T19 + x0->T21 + x1->T21 + x0->T22 + x1->T22 + x2->T22 + x1->T23 + x2->T23 + x0->T24 + x1->T24 + x1->T25 + x2->T25 + x1->T26 + x2->T26 + x0->T28 + x1->T29 + x1->T30 + x1->T31 + x2->T31 + x1->T32 + x2->T32 + x1->T33 + x1->T34 + x0->T35 + x1->T36 + x2->T36 + x0->T37 + x1->T38 + x2->T38 + x0->T39 + x1->T39) & valuation
}

one sig NT7 extends NegativeTrace {} {
    lasso = T39->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x2->T5 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x0->T9 + x2->T9 + x0->T10 + x2->T10 + x0->T12 + x0->T13 + x0->T14 + x0->T15 + x2->T15 + x0->T16 + x2->T16 + x0->T17 + x0->T18 + x2->T18 + x0->T19 + x2->T19 + x0->T20 + x0->T21 + x1->T21 + x0->T22 + x2->T23 + x0->T24 + x2->T24 + x0->T25 + x2->T25 + x0->T26 + x0->T27 + x1->T27 + x0->T28 + x0->T29 + x0->T30 + x2->T30 + x0->T31 + x2->T31 + x0->T32 + x2->T32 + x0->T33 + x2->T33 + x0->T34 + x2->T34 + x0->T35 + x0->T36 + x2->T36 + x0->T37 + x0->T38 + x2->T38 + x0->T39 + x2->T39 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x0->T6 + x1->T6 + x1->T7 + x1->T8 + x2->T8 + x1->T9 + x1->T10 + x0->T11 + x1->T11 + x2->T11 + x1->T12 + x2->T12 + x1->T13 + x2->T13 + x1->T14 + x2->T14 + x1->T15 + x1->T16 + x1->T17 + x2->T17 + x1->T18 + x1->T19 + x1->T20 + x2->T20 + x2->T21 + x1->T22 + x2->T22 + x0->T23 + x1->T23 + x1->T24 + x1->T25 + x1->T26 + x2->T26 + x2->T27 + x1->T28 + x2->T28 + x1->T29 + x2->T29 + x1->T30 + x1->T31 + x1->T32 + x1->T33 + x1->T34 + x1->T35 + x2->T35 + x1->T36 + x1->T37 + x2->T37 + x1->T38 + x1->T39) & valuation
}

one sig NT8 extends NegativeTrace {} {
    lasso = T39->T0
    x2->T0 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T5 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x0->T9 + x1->T9 + x1->T10 + x0->T11 + x2->T11 + x0->T12 + x1->T12 + x2->T12 + x0->T13 + x1->T13 + x2->T13 + x1->T14 + x0->T15 + x2->T16 + x0->T17 + x2->T17 + x0->T18 + x1->T18 + x2->T18 + x0->T21 + x1->T21 + x1->T22 + x2->T22 + x1->T23 + x2->T23 + x0->T24 + x1->T25 + x0->T26 + x2->T26 + x2->T27 + x2->T28 + x0->T30 + x1->T30 + x2->T30 + x0->T31 + x2->T31 + x0->T32 + x1->T32 + x1->T33 + x2->T33 + x0->T34 + x2->T34 + x0->T35 + x2->T36 + x1->T37 + x1->T38 + x0->T39 + x2->T39 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T8 + x2->T8 + x2->T9 + x0->T10 + x2->T10 + x1->T11 + x0->T14 + x2->T14 + x1->T15 + x2->T15 + x0->T16 + x1->T16 + x1->T17 + x0->T19 + x1->T19 + x2->T19 + x0->T20 + x1->T20 + x2->T20 + x2->T21 + x0->T22 + x0->T23 + x1->T24 + x2->T24 + x0->T25 + x2->T25 + x1->T26 + x0->T27 + x1->T27 + x0->T28 + x1->T28 + x0->T29 + x1->T29 + x2->T29 + x1->T31 + x2->T32 + x0->T33 + x1->T34 + x1->T35 + x2->T35 + x0->T36 + x1->T36 + x0->T37 + x2->T37 + x0->T38 + x2->T38 + x1->T39) & valuation
}

one sig NT9 extends NegativeTrace {} {
    lasso = T39->T0
    x0->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9 + x0->T10 + x2->T10 + x0->T11 + x0->T12 + x2->T12 + x0->T13 + x0->T14 + x0->T15 + x1->T15 + x2->T15 + x2->T16 + x0->T17 + x2->T18 + x0->T19 + x0->T20 + x1->T20 + x0->T21 + x1->T23 + x2->T23 + x0->T24 + x2->T24 + x1->T25 + x2->T25 + x0->T27 + x1->T27 + x2->T27 + x0->T28 + x2->T28 + x0->T30 + x2->T30 + x1->T31 + x2->T31 + x0->T32 + x0->T33 + x2->T33 + x2->T34 + x0->T35 + x1->T35 + x2->T35 + x0->T36 + x2->T36 + x0->T37 + x0->T38 + x2->T38 + x0->T39 + x1->T39 + x2->T39 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x0->T3 + x1->T3 + x2->T3 + x1->T5 + x1->T6 + x1->T8 + x1->T10 + x1->T11 + x2->T11 + x1->T12 + x1->T13 + x2->T13 + x1->T14 + x2->T14 + x0->T16 + x1->T16 + x1->T17 + x2->T17 + x0->T18 + x1->T18 + x1->T19 + x2->T19 + x2->T20 + x1->T21 + x2->T21 + x0->T22 + x1->T22 + x2->T22 + x0->T23 + x1->T24 + x0->T25 + x0->T26 + x1->T26 + x2->T26 + x1->T28 + x0->T29 + x1->T29 + x2->T29 + x1->T30 + x0->T31 + x1->T32 + x2->T32 + x1->T33 + x0->T34 + x1->T34 + x1->T36 + x1->T37 + x2->T37 + x1->T38) & valuation
}

one sig LearnedLTL {
    Root: DAGNode
}
fun root: one DAGNode { LearnedLTL.Root }
fun childrenOf[n: DAGNode]: set DAGNode { n.^(l+r) }
fun childrenAndSelfOf[n: DAGNode]: set DAGNode { n.*(l+r) }
fun ancestorsOf[n: DAGNode]: set DAGNode { n.~^(l+r) }
fun ancestorsAndSelfOf[n: DAGNode]: set DAGNode { n.~*(l+r) }
fun subDAG[n: DAGNode]: DAGNode -> DAGNode { n.*(l+r) <: (l+r) }

fact {
    root = G0

    all imply: Imply {
        all n: childrenOf[imply] | n in (Literal + And + Or + Neg)
        all n: childrenOf[imply] & Neg | n.l in Literal
        all n: childrenAndSelfOf[imply.l] & Or | no childrenOf[n] & And
        all n: childrenAndSelfOf[imply.r] & And | no childrenOf[n] & Or
    }
}

one sig G0 extends G {} { l = Imply0 }
one sig Imply0 extends Imply {}
one sig And0 extends And {}


fact {
    Imply0.l = x0 or (Imply0.l in And and Imply0.l.l = x0)

    Imply0.r = And0 or (Imply0.r in Or and Imply0.r.l = And0)
    (And0->x1 + And0->x2) in subDAG[Imply0.r]
}

fun experimentReach: set DAGNode { childrenAndSelfOf[root] }
fun experimentKept: DAGNode -> DAGNode { (none->none) & subDAG[root] }
one sig ExperimentCost { used: set DAGNode }
fact { ExperimentCost.used = experimentReach }
fact ExperimentBounds {
  DAGNode = experimentReach + Literal + (none)
  #experimentReach <= 5
  #(experimentReach & (And + Or + Imply)) <= 3
  minsome ExperimentCost.used
}
run {
    all t: PositiveTrace | root->T0 in t.valuation
    all t: NegativeTrace | root->T0 not in t.valuation
    
} for 8 DAGNode, 5 Int
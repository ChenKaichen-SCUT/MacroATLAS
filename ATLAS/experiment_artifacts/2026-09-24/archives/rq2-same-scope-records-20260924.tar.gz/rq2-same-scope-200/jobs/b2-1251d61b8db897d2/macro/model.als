abstract sig Unit {}
one sig U0, U1, U2, U3, U4 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7 extends Label {}
abstract sig Q {}
one sig Q0, Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10, Q11, Q12, Q13, Q14 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E26, E27, E28, E29, E30, E31, E32, E33, E34, E35, E36, E37, E38, E39, E40, E41, E42, E43, E44, E45, E46, E47, E48, E49, E50, E51, E52, E53, E54, E55, E56, E57, E58, E59, E60, E61, E62, E63, E64, E65, E66, E67, E68, E69, E70, E71, E72, E73, E74, E75, E76, E77, E78, E79, E80, E81, E82, E83, E84, E85, E86, E87, E88, E89, E90, E91, E92, E93, E94, E95, E96, E97, E98, E99, E100, E101, E102, E103, E104, E105, E106, E107, E108 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4, P5, P6, P7, P8, P9 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos, av20: set Pos, av21: set Pos, av22: set Pos, av23: set Pos, av24: set Pos, av25: set Pos, av26: set Pos, av27: set Pos, av28: set Pos, av29: set Pos, av30: set Pos, av31: set Pos, av32: set Pos, av33: set Pos, av34: set Pos, av35: set Pos, av36: set Pos, av37: set Pos, av38: set Pos, av39: set Pos, av40: set Pos, av41: set Pos, av42: set Pos, av43: set Pos, av44: set Pos, av45: set Pos, av46: set Pos, av47: set Pos, av48: set Pos, av49: set Pos, av50: set Pos, av51: set Pos, av52: set Pos, av53: set Pos, av54: set Pos, av55: set Pos, av56: set Pos, av57: set Pos, av58: set Pos, av59: set Pos, av60: set Pos, av61: set Pos, av62: set Pos, av63: set Pos, av64: set Pos, av65: set Pos, av66: set Pos, av67: set Pos, av68: set Pos, av69: set Pos, av70: set Pos, av71: set Pos, av72: set Pos, av73: set Pos, av74: set Pos, av75: set Pos, av76: set Pos }
one sig A0, A1, A2, A3, A4 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos, ev20: set Pos, ev21: set Pos, ev22: set Pos, ev23: set Pos, ev24: set Pos, ev25: set Pos, ev26: set Pos, ev27: set Pos, ev28: set Pos, ev29: set Pos, ev30: set Pos, ev31: set Pos, ev32: set Pos, ev33: set Pos, ev34: set Pos, ev35: set Pos, ev36: set Pos, ev37: set Pos, ev38: set Pos, ev39: set Pos, ev40: set Pos, ev41: set Pos, ev42: set Pos, ev43: set Pos, ev44: set Pos, ev45: set Pos, ev46: set Pos, ev47: set Pos, ev48: set Pos, ev49: set Pos, ev50: set Pos, ev51: set Pos, ev52: set Pos, ev53: set Pos, ev54: set Pos, ev55: set Pos, ev56: set Pos, ev57: set Pos, ev58: set Pos, ev59: set Pos, ev60: set Pos, ev61: set Pos, ev62: set Pos, ev63: set Pos, ev64: set Pos, ev65: set Pos, ev66: set Pos, ev67: set Pos, ev68: set Pos, ev69: set Pos, ev70: set Pos, ev71: set Pos, ev72: set Pos, ev73: set Pos, ev74: set Pos, ev75: set Pos, ev76: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (T0 + (T1 + T2)) }
fun un: set Label { (T3 + T4) }
fun bin: set Label { (T5 + (T6 + T7)) }
fun nonempty: set Fiber { ((((((E1 + E2) + (E3 + (E4 + E5))) + ((E6 + (E7 + E9)) + (E10 + (E11 + E12)))) + (((E13 + (E14 + E15)) + (E17 + (E18 + E19))) + ((E20 + (E21 + E22)) + (E23 + (E25 + E26))))) + ((((E27 + (E28 + E29)) + (E30 + (E32 + E33))) + ((E34 + (E35 + E36)) + (E37 + (E39 + E40)))) + (((E41 + (E42 + E43)) + (E44 + (E46 + E47))) + ((E48 + (E49 + E50)) + (E51 + (E53 + E54)))))) + (((((E55 + E56) + (E57 + (E58 + E59))) + ((E61 + (E62 + E63)) + (E64 + (E65 + E66)))) + (((E68 + (E69 + E70)) + (E71 + (E72 + E73))) + ((E75 + (E76 + E77)) + (E78 + (E79 + E80))))) + ((((E82 + (E83 + E84)) + (E85 + (E86 + E87))) + ((E89 + (E90 + E91)) + (E92 + (E93 + E94)))) + (((E96 + (E97 + E98)) + (E99 + (E100 + E101))) + ((E103 + (E104 + E105)) + (E106 + (E107 + E108))))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { ((U0->U1 + U1->U2) + (U2->U3 + U3->U4)) }
fun carrierNext: Carrier -> Carrier { ((((A0->A1 + A1->A2) + (A2->A3 + (A3->A4 + A4->R))) + ((R->C0 + C0->L0) + (L0->D0 + (D0->C1 + C1->L1)))) + (((L1->D1 + D1->C2) + (C2->L2 + (L2->D2 + D2->C3))) + ((C3->L3 + L3->D3) + (D3->C4 + (C4->L4 + L4->D4))))) }
fun child[a: Anchor]: set Port { a.(((A0->C0 + A1->C1) + (A2->C2 + (A3->C3 + A4->C4)))) }
fun left[a: Anchor]: set Port { a.(((A0->L0 + A1->L1) + (A2->L2 + (A3->L3 + A4->L4)))) }
fun right[a: Anchor]: set Port { a.(((A0->D0 + A1->D1) + (A2->D2 + (A3->D3 + A4->D4)))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
no iden & ^graph
active = R.target.*graph
R.fiber not in nonempty
R.target.lab = T4
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
no A3.graph & (((A0 + A1) + (A2 + A3)))
no A4.graph & (((A0 + A1) + (A2 + (A3 + A4))))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
lone lab.T2
some A0.lab and A0.lab in un and R.target != A0 implies #(target.A0) > 1
some A1.lab and A1.lab in un and R.target != A1 implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un and R.target != A2 implies #(target.A2) > 1
some A2.lab implies some A1.lab
some A3.lab and A3.lab in un and R.target != A3 implies #(target.A3) > 1
some A3.lab implies some A2.lab
some A4.lab and A4.lab in un and R.target != A4 implies #(target.A4) > 1
some A4.lab implies some A3.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q4
E2.qi = Q0
E2.qo = Q3
E3.qi = Q0
E3.qo = Q4
E4.qi = Q0
E4.qo = Q4
E5.qi = Q0
E5.qo = Q4
E6.qi = Q0
E6.qo = Q4
E7.qi = Q0
E7.qo = Q4
E8.qi = Q1
E8.qo = Q1
E9.qi = Q1
E9.qo = Q4
E10.qi = Q1
E10.qo = Q3
E11.qi = Q1
E11.qo = Q4
E12.qi = Q1
E12.qo = Q4
E13.qi = Q1
E13.qo = Q4
E14.qi = Q1
E14.qo = Q4
E15.qi = Q1
E15.qo = Q4
E16.qi = Q2
E16.qo = Q2
E17.qi = Q2
E17.qo = Q4
E18.qi = Q2
E18.qo = Q3
E19.qi = Q2
E19.qo = Q4
E20.qi = Q2
E20.qo = Q4
E21.qi = Q2
E21.qo = Q4
E22.qi = Q2
E22.qo = Q4
E23.qi = Q2
E23.qo = Q4
E24.qi = Q3
E24.qo = Q3
E25.qi = Q3
E25.qo = Q4
E26.qi = Q3
E26.qo = Q4
E27.qi = Q3
E27.qo = Q4
E28.qi = Q3
E28.qo = Q4
E29.qi = Q3
E29.qo = Q4
E30.qi = Q3
E30.qo = Q4
E31.qi = Q4
E31.qo = Q4
E32.qi = Q4
E32.qo = Q4
E33.qi = Q4
E33.qo = Q4
E34.qi = Q4
E34.qo = Q4
E35.qi = Q4
E35.qo = Q4
E36.qi = Q4
E36.qo = Q4
E37.qi = Q4
E37.qo = Q4
E38.qi = Q5
E38.qo = Q5
E39.qi = Q5
E39.qo = Q4
E40.qi = Q5
E40.qo = Q4
E41.qi = Q5
E41.qo = Q4
E42.qi = Q5
E42.qo = Q4
E43.qi = Q5
E43.qo = Q4
E44.qi = Q5
E44.qo = Q4
E45.qi = Q6
E45.qo = Q6
E46.qi = Q6
E46.qo = Q4
E47.qi = Q6
E47.qo = Q4
E48.qi = Q6
E48.qo = Q4
E49.qi = Q6
E49.qo = Q4
E50.qi = Q6
E50.qo = Q4
E51.qi = Q6
E51.qo = Q4
E52.qi = Q7
E52.qo = Q7
E53.qi = Q7
E53.qo = Q4
E54.qi = Q7
E54.qo = Q4
E55.qi = Q7
E55.qo = Q4
E56.qi = Q7
E56.qo = Q4
E57.qi = Q7
E57.qo = Q4
E58.qi = Q7
E58.qo = Q10
E59.qi = Q7
E59.qo = Q4
E60.qi = Q8
E60.qo = Q8
E61.qi = Q8
E61.qo = Q4
E62.qi = Q8
E62.qo = Q4
E63.qi = Q8
E63.qo = Q4
E64.qi = Q8
E64.qo = Q4
E65.qi = Q8
E65.qo = Q4
E66.qi = Q8
E66.qo = Q4
E67.qi = Q9
E67.qo = Q9
E68.qi = Q9
E68.qo = Q4
E69.qi = Q9
E69.qo = Q4
E70.qi = Q9
E70.qo = Q4
E71.qi = Q9
E71.qo = Q4
E72.qi = Q9
E72.qo = Q4
E73.qi = Q9
E73.qo = Q4
E74.qi = Q10
E74.qo = Q10
E75.qi = Q10
E75.qo = Q4
E76.qi = Q10
E76.qo = Q4
E77.qi = Q10
E77.qo = Q4
E78.qi = Q10
E78.qo = Q4
E79.qi = Q10
E79.qo = Q4
E80.qi = Q10
E80.qo = Q4
E81.qi = Q11
E81.qo = Q11
E82.qi = Q11
E82.qo = Q4
E83.qi = Q11
E83.qo = Q4
E84.qi = Q11
E84.qo = Q4
E85.qi = Q11
E85.qo = Q4
E86.qi = Q11
E86.qo = Q4
E87.qi = Q11
E87.qo = Q4
E88.qi = Q12
E88.qo = Q12
E89.qi = Q12
E89.qo = Q4
E90.qi = Q12
E90.qo = Q4
E91.qi = Q12
E91.qo = Q4
E92.qi = Q12
E92.qo = Q4
E93.qi = Q12
E93.qo = Q4
E94.qi = Q12
E94.qo = Q4
E95.qi = Q13
E95.qo = Q13
E96.qi = Q13
E96.qo = Q4
E97.qi = Q13
E97.qo = Q4
E98.qi = Q13
E98.qo = Q4
E99.qi = Q13
E99.qo = Q4
E100.qi = Q13
E100.qo = Q4
E101.qi = Q13
E101.qo = Q4
E102.qi = Q14
E102.qo = Q14
E103.qi = Q14
E103.qo = Q4
E104.qi = Q14
E104.qo = Q4
E105.qi = Q14
E105.qo = Q4
E106.qi = Q14
E106.qo = Q4
E107.qi = Q14
E107.qo = Q4
E108.qi = Q14
E108.qo = Q4
all e: used | e.fiber in ((((E0 + (E8 + E16)) + ((E24 + E31) + (E38 + E45))) + (((E52 + E60) + (E67 + E74)) + ((E81 + E88) + (E95 + E102))))) implies #e.cost = 0
all e: used | e.fiber in ((((((E1 + E5) + (E7 + (E9 + E13))) + ((E15 + (E17 + E21)) + (E23 + (E25 + E28)))) + (((E30 + (E32 + E35)) + (E37 + (E39 + E42))) + ((E44 + (E46 + E49)) + (E51 + (E53 + E56))))) + ((((E57 + E59) + (E61 + (E64 + E66))) + ((E68 + (E71 + E73)) + (E75 + (E78 + E80)))) + (((E82 + (E85 + E87)) + (E89 + (E92 + E94))) + ((E96 + (E99 + E101)) + (E103 + (E106 + E108))))))) implies #e.cost = 2
all e: used | e.fiber in (((((E2 + (E6 + E10)) + ((E14 + E18) + (E22 + E26))) + (((E29 + E33) + (E36 + E40)) + ((E43 + E47) + (E50 + E54)))) + (((E58 + (E62 + E65)) + ((E69 + E72) + (E76 + E79))) + (((E83 + E86) + (E90 + E93)) + ((E97 + E100) + (E104 + E107)))))) implies #e.cost = 1
all e: used | e.fiber in (((((E3 + E4) + (E11 + E12)) + ((E19 + E20) + (E27 + (E34 + E41)))) + (((E48 + E55) + (E63 + E70)) + ((E77 + E84) + (E91 + (E98 + E105)))))) implies #e.cost = 3
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q10)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q1
all a: active | a.lab = T2 implies a.state = Q2
all a: active | a.lab = T3 and child[a].fiber.qo = Q0 implies a.state = Q3
all a: active | a.lab = T3 and child[a].fiber.qo = Q1 implies a.state = Q3
all a: active | a.lab = T3 and child[a].fiber.qo = Q2 implies a.state = Q3
all a: active | a.lab = T3 and child[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T3 and child[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q7 implies a.state = Q10
all a: active | a.lab = T4 and child[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T4 and child[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q5
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q5
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q5
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q5
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q5 implies a.state = Q5
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q6 implies a.state = Q12
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q8 implies a.state = Q5
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q9 implies a.state = Q12
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q12 implies a.state = Q12
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q14 implies a.state = Q12
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q8 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q8 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q8 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q0 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q1 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q2 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q8 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q0 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q1 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q2 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q3 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q5 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q8 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q0 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q1 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q2 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q3 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q5 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q8 implies a.state = Q8
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q0 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q1 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q2 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q3 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q5 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q8 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q0 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q1 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q2 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q3 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q5 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q8 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q0 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q1 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q2 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q3 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q5 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q6 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q8 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q9 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q12 implies a.state = Q14
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T5 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q14 implies a.state = Q14
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q9
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q9
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q9
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q9
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q5 implies a.state = Q13
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q6 implies a.state = Q9
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q8 implies a.state = Q13
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q9 implies a.state = Q9
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q11 implies a.state = Q13
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q13 implies a.state = Q13
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q0 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q1 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q2 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q3 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q6 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q9 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q0 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q1 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q2 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q3 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q6 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q9 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q0 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q1 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q2 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q3 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q6 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q9 implies a.state = Q6
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q0 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q1 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q2 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q3 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q6 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q9 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q0 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q1 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q2 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q3 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q5 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q6 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q8 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q9 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q11 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q13 implies a.state = Q11
all a: active | a.lab = T6 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T6 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q9 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q13 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q3 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q4 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q1 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q9 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q13 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q5 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q6 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q7 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q8 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q9 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q10 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q11 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q1 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q9 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q13 implies a.state = Q7
all a: active | a.lab = T7 and left[a].fiber.qo = Q12 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q13 and right[a].fiber.qo = Q14 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q0 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q1 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q2 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q3 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q4 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q5 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q6 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q7 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q8 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q9 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q10 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q11 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q12 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q13 implies a.state = Q4
all a: active | a.lab = T7 and left[a].fiber.qo = Q14 and right[a].fiber.qo = Q14 implies a.state = Q4
}
fun range0: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop0: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun next0: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P0)))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in (((((E0 + (E1 + E8)) + ((E9 + E16) + (E17 + E24))) + (((E25 + E31) + (E32 + E38)) + ((E39 + E45) + (E46 + E52)))) + (((E53 + (E60 + E61)) + ((E67 + E68) + (E74 + E75))) + (((E81 + E82) + (E88 + E89)) + ((E95 + E96) + (E102 + E103)))))) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (((((E2 + E3) + (E10 + E11)) + ((E18 + E19) + (E26 + (E33 + E40)))) + (((E47 + E54) + (E62 + E69)) + ((E76 + E83) + (E90 + (E97 + E104)))))) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in ((((E4 + (E12 + E20)) + ((E27 + E34) + (E41 + E48))) + (((E55 + E63) + (E70 + E77)) + ((E84 + E91) + (E98 + E105))))) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in ((((E5 + (E13 + E21)) + ((E28 + E35) + (E42 + E49))) + (((E56 + E64) + (E71 + E78)) + ((E85 + E92) + (E99 + E106))))) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (((((E6 + E14) + (E22 + E29)) + ((E36 + E43) + (E50 + E57))) + (((E58 + E65) + (E72 + E79)) + ((E86 + E93) + (E100 + E107))))) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in ((((E7 + (E15 + E23)) + ((E30 + E37) + (E44 + E51))) + (((E59 + E66) + (E73 + E80)) + ((E87 + E94) + (E101 + E108))))) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T4 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T5 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T6 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T7 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { P0 }
fun loop1: set Pos { P0 }
fun next1: Pos -> Pos { P0->P0 }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { P0->P0 }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in (((((E0 + (E1 + E8)) + ((E9 + E16) + (E17 + E24))) + (((E25 + E31) + (E32 + E38)) + ((E39 + E45) + (E46 + E52)))) + (((E53 + (E60 + E61)) + ((E67 + E68) + (E74 + E75))) + (((E81 + E82) + (E88 + E89)) + ((E95 + E96) + (E102 + E103)))))) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in (((((E2 + E3) + (E10 + E11)) + ((E18 + E19) + (E26 + (E33 + E40)))) + (((E47 + E54) + (E62 + E69)) + ((E76 + E83) + (E90 + (E97 + E104)))))) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in ((((E4 + (E12 + E20)) + ((E27 + E34) + (E41 + E48))) + (((E55 + E63) + (E70 + E77)) + ((E84 + E91) + (E98 + E105))))) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in ((((E5 + (E13 + E21)) + ((E28 + E35) + (E42 + E49))) + (((E56 + E64) + (E71 + E78)) + ((E85 + E92) + (E99 + E106))))) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (((((E6 + E14) + (E22 + E29)) + ((E36 + E43) + (E50 + E57))) + (((E58 + E65) + (E72 + E79)) + ((E86 + E93) + (E100 + E107))))) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in ((((E7 + (E15 + E23)) + ((E30 + E37) + (E44 + E51))) + (((E59 + E66) + (E73 + E80)) + ((E87 + E94) + (E101 + E108))))) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T4 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T5 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T6 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T7 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (((P0 + P3) + (P4 + (P7 + P9))))
all a: lab.T1 | a.av0 = (((P0 + (P1 + P4)) + ((P5 + P7) + (P8 + P9))))
all a: lab.T2 | a.av0 = (((P0 + P2) + (P4 + (P6 + P8))))
(R->P0 in ev0)
semantics0[av1, ev1]
all a: lab.T0 | a.av1 = (((P3 + P4) + (P5 + (P6 + P9))))
all a: lab.T1 | a.av1 = (((P1 + (P4 + P5)) + ((P6 + P7) + (P8 + P9))))
all a: lab.T2 | a.av1 = (((P0 + P2) + (P7 + P9)))
(R->P0 in ev1)
semantics0[av2, ev2]
all a: lab.T0 | a.av2 = ((P1 + (P3 + P8)))
all a: lab.T1 | a.av2 = (((P0 + (P2 + P3)) + ((P5 + P6) + (P8 + P9))))
all a: lab.T2 | a.av2 = (((P3 + (P4 + P5)) + (P6 + (P8 + P9))))
(R->P0 in ev2)
semantics0[av3, ev3]
all a: lab.T0 | a.av3 = ((P2 + (P5 + P9)))
all a: lab.T1 | a.av3 = (((P0 + (P1 + P5)) + (P6 + (P7 + P9))))
all a: lab.T2 | a.av3 = ((P1 + (P3 + P8)))
(R->P0 in ev3)
semantics0[av4, ev4]
all a: lab.T0 | a.av4 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av4 = (((P1 + P4) + (P5 + (P8 + P9))))
all a: lab.T2 | a.av4 = ((P4 + P5))
(R->P0 in ev4)
semantics0[av5, ev5]
all a: lab.T0 | a.av5 = (((P3 + (P4 + P5)) + (P6 + (P7 + P8))))
all a: lab.T1 | a.av5 = ((P0 + (P1 + P9)))
all a: lab.T2 | a.av5 = ((P0 + (P1 + P2)))
(R->P0 in ev5)
semantics0[av6, ev6]
all a: lab.T0 | a.av6 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P7 + (P8 + P9)))))
all a: lab.T1 | a.av6 = (((P0 + (P1 + P2)) + (P3 + (P4 + P8))))
all a: lab.T2 | a.av6 = (((P0 + P1) + (P3 + P6)))
(R->P0 in ev6)
semantics0[av7, ev7]
all a: lab.T0 | a.av7 = ((P0 + P1))
all a: lab.T1 | a.av7 = (((P0 + (P1 + P2)) + (P4 + (P5 + P6))))
all a: lab.T2 | a.av7 = (((P1 + P2) + (P3 + (P4 + P7))))
(R->P0 in ev7)
semantics0[av8, ev8]
all a: lab.T0 | a.av8 = (((P2 + P3) + (P6 + (P7 + P9))))
all a: lab.T1 | a.av8 = (((P1 + (P2 + P3)) + (P5 + (P8 + P9))))
all a: lab.T2 | a.av8 = (((P1 + P2) + (P4 + (P5 + P8))))
(R->P0 in ev8)
semantics0[av9, ev9]
all a: lab.T0 | a.av9 = (((P0 + P1) + (P2 + P8)))
all a: lab.T1 | a.av9 = (((P0 + (P3 + P4)) + (P5 + (P6 + P8))))
all a: lab.T2 | a.av9 = (((P0 + P3) + (P5 + (P6 + P8))))
(R->P0 in ev9)
semantics0[av10, ev10]
all a: lab.T0 | a.av10 = (((P4 + P5) + (P6 + P7)))
all a: lab.T1 | a.av10 = (((P1 + (P2 + P4)) + ((P5 + P6) + (P7 + P8))))
all a: lab.T2 | a.av10 = (((P0 + P1) + (P3 + (P7 + P8))))
(R->P0 in ev10)
semantics0[av11, ev11]
all a: lab.T0 | a.av11 = (((P0 + P1) + (P3 + (P4 + P6))))
all a: lab.T1 | a.av11 = (((P0 + P1) + (P3 + (P6 + P9))))
all a: lab.T2 | a.av11 = (((P0 + (P1 + P2)) + (P5 + (P7 + P8))))
(R->P0 in ev11)
semantics0[av12, ev12]
all a: lab.T0 | a.av12 = (((P1 + P5) + (P6 + P8)))
all a: lab.T1 | a.av12 = (((P0 + (P1 + P3)) + ((P4 + P5) + (P6 + P9))))
all a: lab.T2 | a.av12 = ((P1 + P2))
(R->P0 in ev12)
semantics0[av13, ev13]
all a: lab.T0 | a.av13 = (((P1 + P3) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av13 = (((P1 + P2) + (P4 + (P5 + P7))))
all a: lab.T2 | a.av13 = (((P0 + P1) + (P4 + P5)))
(R->P0 in ev13)
semantics0[av14, ev14]
all a: lab.T0 | a.av14 = (((P2 + P3) + (P5 + P6)))
all a: lab.T1 | a.av14 = ((((P0 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + P8))))
all a: lab.T2 | a.av14 = (((P1 + (P3 + P4)) + (P7 + (P8 + P9))))
(R->P0 in ev14)
semantics0[av15, ev15]
all a: lab.T0 | a.av15 = ((P0 + (P6 + P8)))
all a: lab.T1 | a.av15 = (((P3 + P5) + (P7 + P8)))
all a: lab.T2 | a.av15 = (((P1 + P2) + (P3 + P8)))
(R->P0 in ev15)
semantics0[av16, ev16]
all a: lab.T0 | a.av16 = (((P4 + P5) + (P6 + (P7 + P9))))
all a: lab.T1 | a.av16 = (((P2 + (P4 + P5)) + (P6 + (P7 + P8))))
all a: lab.T2 | a.av16 = (((P0 + P2) + (P4 + P7)))
(R->P0 in ev16)
semantics0[av17, ev17]
all a: lab.T0 | a.av17 = ((P2 + (P3 + P6)))
all a: lab.T1 | a.av17 = ((P0 + P2))
all a: lab.T2 | a.av17 = (((P2 + P5) + (P7 + P8)))
(R->P0 in ev17)
semantics0[av18, ev18]
all a: lab.T0 | a.av18 = (((P3 + P4) + (P5 + (P6 + P9))))
all a: lab.T1 | a.av18 = (((P4 + P5) + (P6 + (P8 + P9))))
all a: lab.T2 | a.av18 = (((P1 + P2) + (P7 + P9)))
(R->P0 in ev18)
semantics0[av19, ev19]
all a: lab.T0 | a.av19 = (((P2 + P4) + (P7 + P9)))
all a: lab.T1 | a.av19 = ((((P0 + P1) + (P3 + P4)) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T2 | a.av19 = (((P0 + P3) + (P5 + (P6 + P9))))
(R->P0 in ev19)
semantics0[av20, ev20]
all a: lab.T0 | a.av20 = ((P0 + (P3 + P6)))
all a: lab.T1 | a.av20 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av20 = (((P0 + (P2 + P4)) + (P5 + (P8 + P9))))
(R->P0 in ev20)
semantics0[av21, ev21]
all a: lab.T0 | a.av21 = (((P1 + P4) + (P6 + P8)))
all a: lab.T1 | a.av21 = (((P1 + P3) + (P4 + (P6 + P8))))
all a: lab.T2 | a.av21 = (((P3 + P6) + (P7 + (P8 + P9))))
(R->P0 in ev21)
semantics0[av22, ev22]
all a: lab.T0 | a.av22 = (((P0 + P1) + (P2 + (P8 + P9))))
all a: lab.T1 | a.av22 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P7 + P8))))
all a: lab.T2 | a.av22 = (((P1 + P2) + (P3 + P5)))
(R->P0 in ev22)
semantics0[av23, ev23]
all a: lab.T0 | a.av23 = (((P1 + P2) + (P3 + (P4 + P5))))
all a: lab.T1 | a.av23 = (((P2 + P3) + (P4 + (P5 + P8))))
all a: lab.T2 | a.av23 = (((P2 + P3) + (P5 + (P7 + P8))))
(R->P0 in ev23)
semantics0[av24, ev24]
all a: lab.T0 | a.av24 = (((P0 + (P1 + P3)) + ((P5 + P7) + (P8 + P9))))
all a: lab.T1 | a.av24 = (((P0 + (P3 + P5)) + ((P6 + P7) + (P8 + P9))))
all a: lab.T2 | a.av24 = (((P2 + P3) + (P6 + P8)))
(R->P0 in ev24)
semantics0[av25, ev25]
all a: lab.T0 | a.av25 = (((P0 + P1) + (P3 + (P7 + P8))))
all a: lab.T1 | a.av25 = (((P0 + P1) + (P2 + (P7 + P9))))
all a: lab.T2 | a.av25 = (((P1 + P2) + (P4 + (P5 + P7))))
(R->P0 in ev25)
semantics0[av26, ev26]
all a: lab.T0 | a.av26 = (((P4 + P6) + (P7 + P8)))
all a: lab.T1 | a.av26 = (((P3 + P6) + (P7 + P9)))
all a: lab.T2 | a.av26 = (((P0 + P1) + (P5 + (P6 + P9))))
(R->P0 in ev26)
semantics0[av27, ev27]
all a: lab.T0 | a.av27 = (((P0 + P1) + (P2 + (P8 + P9))))
all a: lab.T1 | a.av27 = (((P0 + (P1 + P3)) + (P6 + (P7 + P8))))
all a: lab.T2 | a.av27 = (((P3 + P6) + (P7 + P8)))
(R->P0 in ev27)
semantics0[av28, ev28]
all a: lab.T0 | a.av28 = (((P1 + P3) + (P4 + (P5 + P7))))
all a: lab.T1 | a.av28 = ((P3 + (P4 + P8)))
all a: lab.T2 | a.av28 = (((P2 + P4) + (P6 + (P8 + P9))))
(R->P0 in ev28)
semantics0[av29, ev29]
all a: lab.T0 | a.av29 = (((P1 + P3) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av29 = (((P0 + (P3 + P5)) + (P7 + (P8 + P9))))
all a: lab.T2 | a.av29 = ((P0 + (P5 + P9)))
(R->P0 in ev29)
semantics0[av30, ev30]
all a: lab.T0 | a.av30 = (((P1 + P4) + (P5 + P6)))
all a: lab.T1 | a.av30 = ((((P1 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + P8))))
all a: lab.T2 | a.av30 = (((P1 + (P3 + P6)) + (P7 + (P8 + P9))))
(R->P0 in ev30)
semantics0[av31, ev31]
all a: lab.T0 | a.av31 = (((P1 + P3) + (P6 + P9)))
all a: lab.T1 | a.av31 = (((P2 + P3) + (P6 + (P8 + P9))))
all a: lab.T2 | a.av31 = (((P2 + (P3 + P5)) + (P6 + (P8 + P9))))
(R->P0 in ev31)
semantics0[av32, ev32]
all a: lab.T0 | a.av32 = ((P2 + (P5 + P8)))
all a: lab.T1 | a.av32 = (((P0 + (P2 + P4)) + ((P5 + P6) + (P8 + P9))))
all a: lab.T2 | a.av32 = (((P0 + P3) + (P5 + P7)))
(R->P0 in ev32)
semantics0[av33, ev33]
all a: lab.T0 | a.av33 = ((P0 + (P4 + P8)))
all a: lab.T1 | a.av33 = (((P0 + P4) + (P8 + P9)))
all a: lab.T2 | a.av33 = ((P5 + (P7 + P9)))
(R->P0 in ev33)
semantics0[av34, ev34]
all a: lab.T0 | a.av34 = (((P0 + (P3 + P4)) + ((P5 + P7) + (P8 + P9))))
all a: lab.T1 | a.av34 = (((P0 + P1) + (P3 + (P6 + P9))))
all a: lab.T2 | a.av34 = ((P0 + P3))
(R->P0 in ev34)
semantics0[av35, ev35]
all a: lab.T0 | a.av35 = (((P0 + (P1 + P5)) + (P6 + (P7 + P9))))
all a: lab.T1 | a.av35 = (((P0 + P4) + (P5 + (P6 + P9))))
all a: lab.T2 | a.av35 = (((P2 + (P3 + P4)) + ((P5 + P6) + (P8 + P9))))
(R->P0 in ev35)
semantics0[av36, ev36]
all a: lab.T0 | a.av36 = ((P0 + P4))
all a: lab.T1 | a.av36 = ((P1 + (P2 + P8)))
all a: lab.T2 | a.av36 = (((P1 + P2) + (P3 + (P5 + P9))))
(R->P0 in ev36)
semantics0[av37, ev37]
all a: lab.T0 | a.av37 = (((P2 + (P3 + P5)) + (P6 + (P7 + P8))))
all a: lab.T1 | a.av37 = (((P1 + (P3 + P4)) + (P6 + (P8 + P9))))
all a: lab.T2 | a.av37 = (((P0 + (P1 + P3)) + (P6 + (P8 + P9))))
(R->P0 in ev37)
semantics0[av38, ev38]
all a: lab.T0 | a.av38 = (((P2 + (P5 + P6)) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av38 = (((P2 + (P5 + P6)) + (P7 + (P8 + P9))))
all a: lab.T2 | a.av38 = (((P0 + P2) + (P4 + (P5 + P7))))
(R->P0 in ev38)
semantics0[av39, ev39]
all a: lab.T0 | a.av39 = (((P2 + P3) + (P4 + (P6 + P8))))
all a: lab.T1 | a.av39 = (((P1 + P4) + (P8 + P9)))
all a: lab.T2 | a.av39 = (((P0 + P1) + (P4 + (P5 + P9))))
(R->P0 in ev39)
semantics0[av40, ev40]
all a: lab.T0 | a.av40 = (((P1 + (P2 + P4)) + (P5 + (P7 + P8))))
all a: lab.T1 | a.av40 = (((P0 + P5) + (P6 + (P7 + P8))))
all a: lab.T2 | a.av40 = (((P2 + P4) + (P6 + (P7 + P9))))
not (R->P0 in ev40)
semantics0[av41, ev41]
all a: lab.T0 | a.av41 = ((((P1 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T1 | a.av41 = ((P0 + P3))
all a: lab.T2 | a.av41 = ((((P0 + P2) + (P4 + P5)) + ((P6 + P7) + (P8 + P9))))
not (R->P0 in ev41)
semantics0[av42, ev42]
all a: lab.T0 | a.av42 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P8 + P9)))))
all a: lab.T1 | a.av42 = (none)
all a: lab.T2 | a.av42 = ((((P0 + P1) + (P3 + P4)) + ((P5 + P6) + (P8 + P9))))
not (R->P0 in ev42)
semantics0[av43, ev43]
all a: lab.T0 | a.av43 = ((((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T1 | a.av43 = (P6)
all a: lab.T2 | a.av43 = ((((P0 + P1) + (P2 + P3)) + ((P5 + P7) + (P8 + P9))))
not (R->P0 in ev43)
semantics0[av44, ev44]
all a: lab.T0 | a.av44 = (((P0 + P2) + (P4 + (P6 + P7))))
all a: lab.T1 | a.av44 = (((P3 + P5) + (P6 + (P7 + P9))))
all a: lab.T2 | a.av44 = (((P1 + (P2 + P3)) + (P6 + (P7 + P9))))
not (R->P0 in ev44)
semantics0[av45, ev45]
all a: lab.T0 | a.av45 = ((((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T1 | a.av45 = (none)
all a: lab.T2 | a.av45 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))))
not (R->P0 in ev45)
semantics1[av46, ev46]
all a: lab.T0 | a.av46 = (P0)
all a: lab.T1 | a.av46 = (none)
all a: lab.T2 | a.av46 = (P0)
not (R->P0 in ev46)
semantics0[av47, ev47]
all a: lab.T0 | a.av47 = (((P2 + P3) + (P5 + (P6 + P8))))
all a: lab.T1 | a.av47 = (((P3 + P5) + (P6 + (P8 + P9))))
all a: lab.T2 | a.av47 = (((P0 + (P2 + P3)) + (P5 + (P7 + P8))))
not (R->P0 in ev47)
semantics0[av48, ev48]
all a: lab.T0 | a.av48 = (((P1 + (P2 + P3)) + (P5 + (P6 + P9))))
all a: lab.T1 | a.av48 = ((P0 + (P7 + P8)))
all a: lab.T2 | a.av48 = (((P1 + (P2 + P3)) + ((P5 + P6) + (P8 + P9))))
not (R->P0 in ev48)
semantics0[av49, ev49]
all a: lab.T0 | a.av49 = (((P1 + (P3 + P4)) + (P5 + (P8 + P9))))
all a: lab.T1 | a.av49 = ((P0 + (P2 + P8)))
all a: lab.T2 | a.av49 = (((P1 + (P2 + P3)) + ((P4 + P5) + (P6 + P9))))
not (R->P0 in ev49)
semantics0[av50, ev50]
all a: lab.T0 | a.av50 = ((((P0 + P1) + (P2 + P3)) + ((P5 + P6) + (P7 + P8))))
all a: lab.T1 | a.av50 = (((P1 + P4) + (P5 + P8)))
all a: lab.T2 | a.av50 = (((P0 + (P1 + P2)) + (P5 + (P6 + P7))))
not (R->P0 in ev50)
semantics0[av51, ev51]
all a: lab.T0 | a.av51 = ((((P0 + P1) + (P3 + P4)) + ((P6 + P7) + (P8 + P9))))
all a: lab.T1 | a.av51 = (((P0 + P2) + (P5 + P8)))
all a: lab.T2 | a.av51 = ((((P0 + P2) + (P3 + P5)) + ((P6 + P7) + (P8 + P9))))
not (R->P0 in ev51)
semantics0[av52, ev52]
all a: lab.T0 | a.av52 = (((P0 + (P3 + P5)) + (P6 + (P7 + P8))))
all a: lab.T1 | a.av52 = ((P4 + (P6 + P9)))
all a: lab.T2 | a.av52 = (((P0 + (P1 + P4)) + (P5 + (P7 + P8))))
not (R->P0 in ev52)
semantics0[av53, ev53]
all a: lab.T0 | a.av53 = ((((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T1 | a.av53 = (P5)
all a: lab.T2 | a.av53 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P6) + (P7 + (P8 + P9)))))
not (R->P0 in ev53)
semantics0[av54, ev54]
all a: lab.T0 | a.av54 = ((((P0 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T1 | a.av54 = (((P0 + P3) + (P4 + P8)))
all a: lab.T2 | a.av54 = (((P2 + P4) + (P7 + P9)))
not (R->P0 in ev54)
semantics0[av55, ev55]
all a: lab.T0 | a.av55 = (((P1 + (P2 + P3)) + ((P4 + P5) + (P6 + P8))))
all a: lab.T1 | a.av55 = (((P0 + P1) + (P4 + (P7 + P9))))
all a: lab.T2 | a.av55 = (((P2 + (P3 + P5)) + (P6 + (P7 + P8))))
not (R->P0 in ev55)
semantics0[av56, ev56]
all a: lab.T0 | a.av56 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P8 + P9))))
all a: lab.T1 | a.av56 = (P3)
all a: lab.T2 | a.av56 = (((P1 + (P2 + P4)) + ((P5 + P6) + (P8 + P9))))
not (R->P0 in ev56)
semantics0[av57, ev57]
all a: lab.T0 | a.av57 = ((((P0 + P1) + (P4 + P5)) + ((P6 + P7) + (P8 + P9))))
all a: lab.T1 | a.av57 = (none)
all a: lab.T2 | a.av57 = ((((P0 + P1) + (P3 + P4)) + ((P5 + P6) + (P7 + (P8 + P9)))))
not (R->P0 in ev57)
semantics0[av58, ev58]
all a: lab.T0 | a.av58 = ((P0 + (P3 + P6)))
all a: lab.T1 | a.av58 = ((P0 + (P1 + P8)))
all a: lab.T2 | a.av58 = (((P0 + (P3 + P5)) + (P6 + (P7 + P9))))
not (R->P0 in ev58)
semantics0[av59, ev59]
all a: lab.T0 | a.av59 = ((P1 + (P8 + P9)))
all a: lab.T1 | a.av59 = ((P5 + (P7 + P9)))
all a: lab.T2 | a.av59 = ((P3 + (P6 + P8)))
not (R->P0 in ev59)
semantics0[av60, ev60]
all a: lab.T0 | a.av60 = (((P1 + P2) + (P3 + (P7 + P9))))
all a: lab.T1 | a.av60 = (P3)
all a: lab.T2 | a.av60 = (((P1 + P3) + (P7 + P9)))
not (R->P0 in ev60)
semantics0[av61, ev61]
all a: lab.T0 | a.av61 = (((P2 + (P3 + P4)) + ((P5 + P7) + (P8 + P9))))
all a: lab.T1 | a.av61 = ((P0 + P1))
all a: lab.T2 | a.av61 = (((P1 + P2) + (P7 + P9)))
not (R->P0 in ev61)
semantics0[av62, ev62]
all a: lab.T0 | a.av62 = (((P0 + (P2 + P3)) + ((P6 + P7) + (P8 + P9))))
all a: lab.T1 | a.av62 = ((P4 + P5))
all a: lab.T2 | a.av62 = ((((P0 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + (P8 + P9)))))
not (R->P0 in ev62)
semantics0[av63, ev63]
all a: lab.T0 | a.av63 = (((P2 + P3) + (P4 + (P6 + P9))))
all a: lab.T1 | a.av63 = ((P5 + (P6 + P7)))
all a: lab.T2 | a.av63 = (((P1 + (P2 + P4)) + (P6 + (P7 + P9))))
not (R->P0 in ev63)
semantics0[av64, ev64]
all a: lab.T0 | a.av64 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P7) + (P8 + P9))))
all a: lab.T1 | a.av64 = ((P1 + (P6 + P9)))
all a: lab.T2 | a.av64 = (((P0 + P4) + (P7 + P8)))
not (R->P0 in ev64)
semantics0[av65, ev65]
all a: lab.T0 | a.av65 = ((P4 + (P6 + P7)))
all a: lab.T1 | a.av65 = ((P0 + (P1 + P8)))
all a: lab.T2 | a.av65 = ((P4 + (P5 + P6)))
not (R->P0 in ev65)
semantics0[av66, ev66]
all a: lab.T0 | a.av66 = (((P1 + (P2 + P4)) + (P5 + (P7 + P8))))
all a: lab.T1 | a.av66 = (((P0 + P2) + (P3 + (P7 + P9))))
all a: lab.T2 | a.av66 = (((P0 + (P2 + P3)) + ((P5 + P7) + (P8 + P9))))
not (R->P0 in ev66)
semantics0[av67, ev67]
all a: lab.T0 | a.av67 = (((P0 + (P2 + P3)) + ((P5 + P6) + (P7 + P9))))
all a: lab.T1 | a.av67 = ((P1 + (P7 + P8)))
all a: lab.T2 | a.av67 = ((((P0 + P1) + (P2 + P3)) + ((P5 + P6) + (P7 + P9))))
not (R->P0 in ev67)
semantics0[av68, ev68]
all a: lab.T0 | a.av68 = (((P0 + (P1 + P3)) + ((P5 + P7) + (P8 + P9))))
all a: lab.T1 | a.av68 = (((P0 + (P1 + P2)) + (P4 + (P6 + P9))))
all a: lab.T2 | a.av68 = (((P1 + (P2 + P4)) + ((P5 + P7) + (P8 + P9))))
not (R->P0 in ev68)
semantics0[av69, ev69]
all a: lab.T0 | a.av69 = (((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P8))))
all a: lab.T1 | a.av69 = (((P0 + P1) + (P2 + P6)))
all a: lab.T2 | a.av69 = (((P0 + (P2 + P3)) + (P4 + (P5 + P8))))
not (R->P0 in ev69)
semantics0[av70, ev70]
all a: lab.T0 | a.av70 = ((((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T1 | a.av70 = (P0)
all a: lab.T2 | a.av70 = ((((P1 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + (P8 + P9)))))
not (R->P0 in ev70)
semantics0[av71, ev71]
all a: lab.T0 | a.av71 = ((((P0 + P1) + (P3 + P4)) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T1 | a.av71 = ((P2 + (P5 + P7)))
all a: lab.T2 | a.av71 = (((P0 + (P1 + P3)) + ((P4 + P6) + (P7 + P9))))
not (R->P0 in ev71)
semantics0[av72, ev72]
all a: lab.T0 | a.av72 = ((((P1 + P2) + (P3 + P4)) + ((P5 + P6) + (P8 + P9))))
all a: lab.T1 | a.av72 = ((P4 + P7))
all a: lab.T2 | a.av72 = ((((P1 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + (P8 + P9)))))
not (R->P0 in ev72)
semantics0[av73, ev73]
all a: lab.T0 | a.av73 = (((P1 + (P3 + P4)) + ((P5 + P6) + (P7 + P8))))
all a: lab.T1 | a.av73 = ((P0 + P4))
all a: lab.T2 | a.av73 = (((P1 + (P3 + P5)) + (P6 + (P8 + P9))))
not (R->P0 in ev73)
semantics0[av74, ev74]
all a: lab.T0 | a.av74 = ((((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T1 | a.av74 = ((P5 + P8))
all a: lab.T2 | a.av74 = ((((P1 + P2) + (P3 + P4)) + ((P6 + P7) + (P8 + P9))))
not (R->P0 in ev74)
semantics0[av75, ev75]
all a: lab.T0 | a.av75 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P9)))))
all a: lab.T1 | a.av75 = ((P0 + P6))
all a: lab.T2 | a.av75 = ((((P2 + P3) + (P4 + P5)) + ((P6 + P7) + (P8 + P9))))
not (R->P0 in ev75)
semantics0[av76, ev76]
all a: lab.T0 | a.av76 = ((((P0 + P1) + (P2 + P3)) + ((P5 + P6) + (P7 + (P8 + P9)))))
all a: lab.T1 | a.av76 = ((P0 + P4))
all a: lab.T2 | a.av76 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P7 + (P8 + P9)))))
not (R->P0 in ev76)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int

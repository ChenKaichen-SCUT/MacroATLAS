# Failure analysis

- rq4f_boolean_B/B09.trace: Only macro solved
- rq4f_fixed_B/B09.trace: Only macro solved
- rq4f_unary_B/B07.trace: Only macro solved
- rq4f_unary_B/B09.trace: Only macro solved
- rq4f_unary_B/B11.trace: Only macro solved

abstract sig Unit {}
one sig U0, U1, U2 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8 extends Label {}
abstract sig Q {}
one sig Q0 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E9, E11, E12, E13, E15, E17 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos }
one sig A0, A1, A2 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (T0 + T1) }
fun un: set Label { ((T2 + T3) + (T4 + T5)) }
fun bin: set Label { (T6 + (T7 + T8)) }
fun nonempty: set Fiber { (((E1 + (E2 + E3)) + (E4 + (E5 + E6))) + ((E7 + (E9 + E11)) + ((E12 + E13) + (E15 + E17)))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { (U0->U1 + U1->U2) }
fun carrierNext: Carrier -> Carrier { (((A0->A1 + (A1->A2 + A2->R)) + (R->C0 + (C0->L0 + L0->D0))) + ((D0->C1 + (C1->L1 + L1->D1)) + (D1->C2 + (C2->L2 + L2->D2)))) }
fun child[a: Anchor]: set Port { a.((A0->C0 + (A1->C1 + A2->C2))) }
fun left[a: Anchor]: set Port { a.((A0->L0 + (A1->L1 + A2->L2))) }
fun right[a: Anchor]: set Port { a.((A0->D0 + (A1->D1 + A2->D2))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un implies #(target.A2) > 1
some A2.lab implies some A1.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q0
E7.qo = Q0
E9.qi = Q0
E9.qo = Q0
E11.qi = Q0
E11.qo = Q0
E12.qi = Q0
E12.qo = Q0
E13.qi = Q0
E13.qo = Q0
E15.qi = Q0
E15.qo = Q0
E17.qi = Q0
E17.qo = Q0
all e: used | e.fiber in (E0) implies #e.cost = 0
all e: used | e.fiber in ((((E1 + E4) + (E6 + E7)) + ((E9 + E12) + (E13 + (E15 + E17))))) implies #e.cost = 2
all e: used | e.fiber in (((E2 + E3) + (E5 + E11))) implies #e.cost = 1
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q0)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T3 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T4 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T5 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T8 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
}
fun range0: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop0: set Pos { P4 }
fun next0: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift0_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun shift0_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P4 + P4->P4))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range0 | loop0 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range0 | some (loop0 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range0 | (i.shift0_1) in (range0 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range0 | (i.shift0_1).future0 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next0.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop1: set Pos { ((P0 + P1) + (P2 + P3)) }
fun next1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift1_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun shift1_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P0 + P3->P1)) }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range1 | loop1 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range1 | some (loop1 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range1 | (i.shift1_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range1 | (i.shift1_1) in (range1 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range1 | (i.shift1_1).future1 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range1 | (i.shift1_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next1.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fun range2: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop2: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun next2: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift2_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun shift2_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P0 + P4->P1))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range2 | (i.shift2_0) in (range2 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range2 | (i.shift2_0).future2 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range2 | (i.shift2_0).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range2 | loop2 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range2 | some (loop2 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range2 | (i.shift2_1) in (range2 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range2 | (i.shift2_1).future2 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range2 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next2.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range2 | some (i.future2 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range2 | i.future2 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range2 - left[a].ev) + right[a].ev)
}
fun range3: set Pos { P0 }
fun loop3: set Pos { P0 }
fun next3: Pos -> Pos { P0->P0 }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { P0->P0 }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in (((E0 + E1) + (E11 + E17))) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + E12)) implies e.ev = {i: range3 | (i.shift3_0) in (range3 - e.target.av)}
all e: used | e.fiber in ((E3 + E13)) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (range3 - e.target.av))}
all e: used | e.fiber in ((E5 + E15)) implies e.ev = {i: range3 | (i.shift3_0).future3 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range3 | (i.shift3_0).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range3 | loop3 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range3 | some (loop3 & (e.target.av))}
all a: active | a.lab = T2 implies a.av = (range3 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next3.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range3 | some (i.future3 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range3 | i.future3 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range3 - left[a].ev) + right[a].ev)
}
fun range4: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop4: set Pos { ((P1 + P2) + (P3 + P4)) }
fun next4: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift4_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun shift4_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P1 + P4->P2))) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range4 | (i.shift4_0) in (range4 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range4 | (i.shift4_0).future4 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range4 | (i.shift4_0).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range4 | loop4 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range4 | some (loop4 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range4 | (i.shift4_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range4 | (i.shift4_1) in (range4 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range4 | (i.shift4_1).future4 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range4 | (i.shift4_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range4 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next4.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range4 | some (i.future4 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range4 | i.future4 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range4 - left[a].ev) + right[a].ev)
}
fun range5: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop5: set Pos { (P3 + P4) }
fun next5: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift5_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun shift5_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P3 + P4->P4))) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range5 | (i.shift5_0) in (range5 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range5 | (i.shift5_0).future5 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range5 | (i.shift5_0).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range5 | loop5 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range5 | some (loop5 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range5 | (i.shift5_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range5 | (i.shift5_1) in (range5 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range5 | (i.shift5_1).future5 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range5 | (i.shift5_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range5 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next5.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range5 | some (i.future5 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range5 | i.future5 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range5 - left[a].ev) + right[a].ev)
}
fun range6: set Pos { (P0 + (P1 + P2)) }
fun loop6: set Pos { (P0 + (P1 + P2)) }
fun next6: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P0)) }
fun future6: Pos -> Pos { (*next6) & (range6->range6) }
fun shift6_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift6_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P0)) }
fun shift6_2: Pos -> Pos { (P0->P2 + (P1->P0 + P2->P1)) }
pred semantics6[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range6
ev in used->range6
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range6 | (i.shift6_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range6 | (i.shift6_0) in (range6 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range6 | (i.shift6_0).future6 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range6 | (i.shift6_0).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range6 | loop6 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range6 | some (loop6 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range6 | (i.shift6_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range6 | (i.shift6_1) in (range6 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range6 | (i.shift6_1).future6 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range6 | (i.shift6_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range6 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next6.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range6 | some (i.future6 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range6 | i.future6 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range6 - left[a].ev) + right[a].ev)
}
fun range7: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop7: set Pos { P3 }
fun next7: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun future7: Pos -> Pos { (*next7) & (range7->range7) }
fun shift7_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift7_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun shift7_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P3 + P3->P3)) }
pred semantics7[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range7
ev in used->range7
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range7 | (i.shift7_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range7 | (i.shift7_0) in (range7 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range7 | (i.shift7_0).future7 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range7 | (i.shift7_0).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range7 | loop7 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range7 | some (loop7 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range7 | (i.shift7_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range7 | (i.shift7_1) in (range7 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range7 | (i.shift7_1).future7 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range7 | (i.shift7_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range7 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next7.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range7 | some (i.future7 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range7 | i.future7 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range7 - left[a].ev) + right[a].ev)
}
fun range8: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop8: set Pos { (P2 + (P3 + P4)) }
fun next8: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun future8: Pos -> Pos { (*next8) & (range8->range8) }
fun shift8_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift8_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun shift8_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P2 + P4->P3))) }
pred semantics8[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range8
ev in used->range8
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range8 | (i.shift8_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range8 | (i.shift8_0) in (range8 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range8 | (i.shift8_0).future8 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range8 | (i.shift8_0).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range8 | loop8 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range8 | some (loop8 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range8 | (i.shift8_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range8 | (i.shift8_1) in (range8 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range8 | (i.shift8_1).future8 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range8 | (i.shift8_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range8 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next8.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range8 | some (i.future8 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range8 | i.future8 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range8 - left[a].ev) + right[a].ev)
}
fun range9: set Pos { (P0 + P1) }
fun loop9: set Pos { P1 }
fun next9: Pos -> Pos { (P0->P1 + P1->P1) }
fun future9: Pos -> Pos { (*next9) & (range9->range9) }
fun shift9_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift9_1: Pos -> Pos { (P0->P1 + P1->P1) }
pred semantics9[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range9
ev in used->range9
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range9 | (i.shift9_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range9 | (i.shift9_0) in (range9 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range9 | (i.shift9_0).future9 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range9 | (i.shift9_0).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range9 | loop9 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range9 | some (loop9 & (e.target.av))}
all e: used | e.fiber in ((E11 + E17)) implies e.ev = {i: range9 | (i.shift9_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range9 | (i.shift9_1) in (range9 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range9 | (i.shift9_1).future9 in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range9 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next9.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range9 | some (i.future9 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range9 | i.future9 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range9 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av0 = ((P2 + P3))
(R->P0 in ev0)
semantics1[av1, ev1]
all a: lab.T0 | a.av1 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av1 = ((P0 + (P1 + P3)))
(R->P0 in ev1)
semantics2[av2, ev2]
all a: lab.T0 | a.av2 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av2 = ((P0 + (P1 + P3)))
(R->P0 in ev2)
semantics2[av3, ev3]
all a: lab.T0 | a.av3 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av3 = ((P1 + (P2 + P3)))
(R->P0 in ev3)
semantics3[av4, ev4]
all a: lab.T0 | a.av4 = (P0)
all a: lab.T1 | a.av4 = (P0)
(R->P0 in ev4)
semantics4[av5, ev5]
all a: lab.T0 | a.av5 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av5 = ((P0 + (P2 + P3)))
(R->P0 in ev5)
semantics1[av6, ev6]
all a: lab.T0 | a.av6 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av6 = (P3)
(R->P0 in ev6)
semantics5[av7, ev7]
all a: lab.T0 | a.av7 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av7 = ((P0 + (P2 + P3)))
(R->P0 in ev7)
semantics6[av8, ev8]
all a: lab.T0 | a.av8 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av8 = ((P0 + P2))
(R->P0 in ev8)
semantics0[av9, ev9]
all a: lab.T0 | a.av9 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av9 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev9)
semantics7[av10, ev10]
all a: lab.T0 | a.av10 = ((P0 + P2))
all a: lab.T1 | a.av10 = ((P0 + P2))
not (R->P0 in ev10)
semantics5[av11, ev11]
all a: lab.T0 | a.av11 = ((P1 + P4))
all a: lab.T1 | a.av11 = (P1)
not (R->P0 in ev11)
semantics8[av12, ev12]
all a: lab.T0 | a.av12 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av12 = ((P0 + (P1 + P4)))
not (R->P0 in ev12)
semantics5[av13, ev13]
all a: lab.T0 | a.av13 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av13 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev13)
semantics7[av14, ev14]
all a: lab.T0 | a.av14 = (P1)
all a: lab.T1 | a.av14 = ((P1 + P2))
not (R->P0 in ev14)
semantics8[av15, ev15]
all a: lab.T0 | a.av15 = (P1)
all a: lab.T1 | a.av15 = ((P0 + (P2 + P4)))
not (R->P0 in ev15)
semantics8[av16, ev16]
all a: lab.T0 | a.av16 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av16 = ((P0 + (P3 + P4)))
not (R->P0 in ev16)
semantics0[av17, ev17]
all a: lab.T0 | a.av17 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av17 = ((P0 + P3))
not (R->P0 in ev17)
semantics9[av18, ev18]
all a: lab.T0 | a.av18 = (none)
all a: lab.T1 | a.av18 = (P1)
not (R->P0 in ev18)
semantics5[av19, ev19]
all a: lab.T0 | a.av19 = ((P1 + P4))
all a: lab.T1 | a.av19 = ((P3 + P4))
not (R->P0 in ev19)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 5 Int

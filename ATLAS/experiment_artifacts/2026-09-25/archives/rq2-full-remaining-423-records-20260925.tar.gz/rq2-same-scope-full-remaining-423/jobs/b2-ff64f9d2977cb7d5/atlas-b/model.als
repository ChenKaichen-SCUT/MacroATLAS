open util/ordering[SeqIdx]

abstract sig DAGNode {
	l: set DAGNode,
	r: set DAGNode
}
fact {
	all n: DAGNode | n not in n.^(l + r)
}

sig And, Or, Imply extends DAGNode {} {
	one l
	one r
}

sig Neg, F, G, X extends DAGNode {} {
    one l
    no r
}
abstract sig Literal extends DAGNode {} {
	no l
	no r
}

abstract sig SeqIdx {}
abstract sig Trace {
	lasso: SeqIdx -> SeqIdx,
	valuation: DAGNode -> SeqIdx
} {
	// Negation
    all n: Neg, i: seqRange | n->i in valuation iff n.l->i not in valuation
	// Or
    all n: Or, i: seqRange | n->i in valuation iff (n.l->i in valuation or n.r->i in valuation)
	// And
    all n: And, i: seqRange | n->i in valuation iff (n.l->i in valuation and n.r->i in valuation)
	// Imply
    all n: Imply, i: seqRange | n->i in valuation iff (n.l->i not in valuation or n.r->i in valuation)
	// G
    all n: G, i: seqRange | n->i in valuation iff all i': futureIdx[i] | n.l->i' in valuation
    // X
    all n: X, i: seqRange | n->i in valuation iff n.l->i.((next :> seqRange) + lasso) in valuation
	// F
    all n: F, i: seqRange | n->i in valuation iff some i': futureIdx[i] | n.l->i' in valuation
	// Until
    
}
fun seqRange[t: Trace]: set SeqIdx {
	let lastOfTrace = t.lasso.SeqIdx | lastOfTrace.prevs + lastOfTrace
}
fun futureIdx[t: Trace, i: SeqIdx]: set SeqIdx {
	i.^((next :> seqRange[t]) + t.lasso) + i
}
abstract sig PositiveTrace extends Trace {}
abstract sig NegativeTrace extends Trace {}
one sig x0, x1 extends Literal {}
one sig T0, T1, T2, T3, T4 extends SeqIdx {}
fact {
    first = T0
    next = T0->T1 + T1->T2 + T2->T3 + T3->T4
}

one sig PT0 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT1 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT2 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT3 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT4 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT5 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT6 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT7 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT8 extends PositiveTrace {} {
    lasso = T4->T0
    
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT9 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT10 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT11 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT12 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT13 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT14 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT15 extends PositiveTrace {} {
    lasso = T4->T0
    
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT16 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT17 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT18 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT19 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT20 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT21 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT22 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT23 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT24 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT25 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT26 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT27 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT28 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT29 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT30 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT31 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig PT32 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT33 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}


one sig NT0 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT1 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT2 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT3 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT4 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT5 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT6 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT7 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT8 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT9 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT10 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT11 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT12 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT13 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT14 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT15 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT16 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT17 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT18 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT19 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT20 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT21 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT22 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T4) & valuation
}

one sig NT23 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT24 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT25 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT26 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT27 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT28 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT29 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT30 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT31 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT32 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT33 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT34 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT35 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT36 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT37 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT38 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT39 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT40 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT41 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT42 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT43 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT44 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT45 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT46 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT47 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT48 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT49 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT50 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT51 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT52 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT53 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T3) & valuation
}

one sig NT54 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT55 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT56 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT57 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT58 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT59 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT60 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT61 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT62 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT63 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT64 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4) & valuation
}

one sig NT65 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT66 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT67 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT68 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT69 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT70 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT71 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT72 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T2 + x0->T4) & valuation
}

one sig NT73 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT74 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT75 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT76 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT77 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT78 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT79 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT80 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT81 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT82 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT83 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT84 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT85 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT86 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT87 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT88 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1) & valuation
}

one sig NT89 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT90 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT91 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT92 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT93 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT94 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT95 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2) & valuation
}

one sig NT96 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT97 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT98 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT99 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT100 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT101 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT102 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT103 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT104 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT105 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT106 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT107 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT108 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT109 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT110 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT111 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT112 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT113 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT114 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT115 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT116 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT117 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT118 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT119 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT120 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT121 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT122 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT123 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT124 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT125 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT126 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT127 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT128 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT129 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT130 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT131 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT132 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT133 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT134 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT135 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT136 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT137 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3) & valuation
}

one sig NT138 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT139 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT140 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT141 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT142 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT143 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT144 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT145 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT146 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT147 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT148 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT149 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT150 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT151 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT152 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3) & valuation
}

one sig NT153 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT154 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT155 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT156 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT157 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT158 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT159 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT160 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT161 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT162 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT163 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT164 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT165 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT166 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT167 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT168 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT169 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT170 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT171 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT172 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT173 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT174 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT175 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT176 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT177 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT178 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT179 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT180 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT181 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T4) & valuation
}

one sig NT182 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT183 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT184 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT185 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT186 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT187 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT188 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT189 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT190 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT191 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT192 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT193 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T3) & valuation
}

one sig NT194 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT195 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT196 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT197 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT198 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT199 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT200 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT201 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT202 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT203 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT204 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT205 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT206 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT207 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT208 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT209 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT210 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x1->T3) & valuation
}

one sig NT211 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT212 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT213 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT214 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT215 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT216 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT217 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT218 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT219 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT220 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1) & valuation
}

one sig NT221 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT222 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT223 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT224 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT225 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT226 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT227 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT228 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT229 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT230 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT231 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT232 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT233 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT234 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT235 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT236 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT237 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT238 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT239 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT240 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT241 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3) & valuation
}

one sig NT242 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT243 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT244 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT245 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT246 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT247 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT248 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT249 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT250 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT251 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT252 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT253 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT254 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT255 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT256 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT257 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1) & valuation
}

one sig NT258 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2) & valuation
}

one sig NT259 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT260 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT261 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT262 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT263 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT264 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT265 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT266 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT267 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT268 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT269 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT270 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT271 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT272 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT273 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT274 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT275 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT276 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT277 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT278 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT279 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT280 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT281 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT282 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T4) & valuation
}

one sig NT283 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT284 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT285 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT286 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3) & valuation
}

one sig NT287 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT288 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT289 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT290 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT291 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT292 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT293 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT294 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT295 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT296 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT297 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT298 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT299 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT300 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT301 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT302 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT303 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT304 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT305 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT306 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT307 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT308 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT309 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT310 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT311 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT312 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT313 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT314 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT315 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT316 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT317 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT318 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT319 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT320 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    
}

one sig NT321 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT322 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT323 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT324 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0) & valuation
}

one sig NT325 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT326 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT327 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT328 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT329 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT330 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT331 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT332 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT333 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT334 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT335 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT336 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT337 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT338 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT339 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT340 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2) & valuation
}

one sig NT341 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT342 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT343 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT344 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT345 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT346 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT347 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT348 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2) & valuation
}

one sig NT349 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT350 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT351 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT352 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT353 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT354 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT355 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT356 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT357 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT358 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT359 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT360 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT361 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT362 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT363 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT364 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT365 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT366 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT367 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT368 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT369 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T4) & valuation
}

one sig NT370 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT371 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT372 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT373 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT374 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1) & valuation
}

one sig NT375 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT376 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT377 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT378 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT379 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT380 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT381 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT382 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT383 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T3) & valuation
}

one sig NT384 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT385 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT386 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT387 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT388 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT389 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT390 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT391 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT392 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT393 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT394 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT395 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT396 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 in valuation
    no (x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT397 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT398 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT399 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT400 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT401 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x1->T3) & valuation
}

one sig NT402 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT403 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3) & valuation
}

one sig NT404 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT405 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT406 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT407 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT408 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT409 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT410 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT411 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1) & valuation
}

one sig NT412 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT413 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0) & valuation
}

one sig NT414 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT415 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT416 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT417 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT418 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT419 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT420 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT421 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT422 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT423 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT424 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT425 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT426 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT427 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT428 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT429 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT430 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT431 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT432 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3) & valuation
}

one sig NT433 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT434 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT435 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT436 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT437 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT438 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT439 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT440 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT441 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT442 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT443 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT444 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT445 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT446 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT447 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT448 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT449 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT450 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT451 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT452 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT453 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT454 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT455 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT456 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT457 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT458 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT459 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT460 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT461 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT462 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT463 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT464 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT465 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT466 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT467 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT468 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT469 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT470 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT471 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT472 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2) & valuation
}

one sig NT473 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT474 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT475 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT476 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT477 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT478 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT479 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT480 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT481 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT482 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT483 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT484 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT485 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT486 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT487 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT488 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT489 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT490 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT491 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT492 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT493 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT494 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT495 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT496 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT497 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2) & valuation
}

one sig NT498 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT499 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT500 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT501 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT502 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT503 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT504 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT505 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT506 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT507 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT508 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT509 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT510 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T3 + x0->T4) & valuation
}

one sig NT511 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT512 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT513 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT514 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT515 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT516 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT517 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT518 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2) & valuation
}

one sig NT519 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT520 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT521 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT522 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT523 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT524 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT525 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT526 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT527 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT528 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT529 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT530 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT531 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT532 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT533 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT534 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT535 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT536 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT537 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT538 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT539 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT540 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT541 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT542 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT543 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT544 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT545 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT546 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT547 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT548 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT549 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT550 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT551 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T3 + x1->T4) & valuation
}

one sig NT552 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT553 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT554 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT555 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3) & valuation
}

one sig NT556 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT557 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT558 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT559 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT560 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT561 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT562 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT563 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT564 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT565 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT566 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT567 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT568 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2) & valuation
}

one sig NT569 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT570 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT571 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x1->T2) & valuation
}

one sig NT572 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT573 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2) & valuation
}

one sig NT574 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT575 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT576 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT577 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT578 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT579 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT580 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT581 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT582 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT583 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT584 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT585 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT586 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT587 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2) & valuation
}

one sig NT588 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT589 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT590 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT591 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2) & valuation
}

one sig NT592 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2) & valuation
}

one sig NT593 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT594 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT595 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT596 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT597 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT598 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1) & valuation
}

one sig NT599 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT600 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT601 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT602 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT603 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT604 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT605 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT606 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T4) & valuation
}

one sig NT607 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT608 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT609 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3) & valuation
}

one sig NT610 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT611 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT612 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2) & valuation
}

one sig NT613 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT614 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT615 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT616 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT617 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT618 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT619 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT620 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT621 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT622 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1) & valuation
}

one sig NT623 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3) & valuation
}

one sig NT624 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT625 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT626 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT627 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT628 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT629 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT630 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT631 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT632 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT633 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT634 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T4) & valuation
}

one sig NT635 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0) & valuation
}

one sig NT636 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT637 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT638 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT639 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT640 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT641 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT642 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT643 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT644 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT645 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT646 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT647 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT648 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT649 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT650 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT651 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT652 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT653 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT654 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT655 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT656 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT657 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT658 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T4) & valuation
}

one sig NT659 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT660 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT661 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT662 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T4) & valuation
}

one sig NT663 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT664 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT665 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT666 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT667 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT668 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    
}

one sig NT669 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT670 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT671 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT672 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT673 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT674 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT675 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT676 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3) & valuation
}

one sig NT677 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT678 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT679 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT680 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT681 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT682 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT683 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT684 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT685 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT686 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT687 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 in valuation
    no (x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT688 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT689 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT690 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT691 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT692 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2) & valuation
}

one sig NT693 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT694 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT695 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT696 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT697 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT698 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT699 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT700 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT701 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT702 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT703 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT704 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT705 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT706 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT707 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T3 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT708 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT709 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT710 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT711 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT712 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT713 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT714 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT715 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT716 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT717 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT718 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT719 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT720 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT721 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT722 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT723 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x1->T4) & valuation
}

one sig NT724 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT725 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT726 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT727 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT728 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT729 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT730 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT731 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT732 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT733 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT734 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT735 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT736 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT737 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT738 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT739 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT740 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3) & valuation
}

one sig NT741 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT742 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT743 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT744 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT745 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT746 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT747 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT748 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT749 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT750 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT751 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT752 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT753 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT754 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2) & valuation
}

one sig NT755 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT756 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT757 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT758 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT759 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2) & valuation
}

one sig NT760 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT761 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT762 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT763 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT764 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT765 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T3 + x0->T4) & valuation
}

one sig NT766 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT767 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT768 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT769 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT770 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT771 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT772 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT773 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT774 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T3) & valuation
}

one sig NT775 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT776 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T3 + x1->T4) & valuation
}

one sig NT777 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T4) & valuation
}

one sig NT778 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT779 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T3 + x0->T4) & valuation
}

one sig NT780 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT781 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT782 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT783 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T4) & valuation
}

one sig NT784 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT785 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT786 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT787 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT788 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT789 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT790 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT791 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT792 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT793 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4) & valuation
}

one sig NT794 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT795 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4) & valuation
}

one sig NT796 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT797 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT798 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT799 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT800 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT801 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT802 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT803 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT804 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T3 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT805 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT806 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT807 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT808 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT809 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT810 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x0->T4) & valuation
}

one sig NT811 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT812 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3) & valuation
}

one sig NT813 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT814 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT815 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT816 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T2 + x0->T4) & valuation
}

one sig NT817 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT818 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 in valuation
    no (x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT819 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT820 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT821 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT822 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T1 + x0->T2 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT823 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT824 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT825 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT826 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT827 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT828 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T4) & valuation
}

one sig NT829 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT830 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT831 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT832 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT833 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT834 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T2) & valuation
}

one sig NT835 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2) & valuation
}

one sig NT836 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT837 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT838 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT839 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT840 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT841 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT842 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x1->T4) & valuation
}

one sig NT843 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT844 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT845 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT846 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT847 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT848 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT849 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2) & valuation
}

one sig NT850 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x1->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT851 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T4) & valuation
}

one sig NT852 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT853 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT854 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT855 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT856 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT857 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T3) & valuation
}

one sig NT858 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT859 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT860 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT861 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT862 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT863 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT864 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT865 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT866 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT867 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT868 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT869 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT870 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T3 + x1->T3) & valuation
}

one sig NT871 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT872 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT873 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT874 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2) & valuation
}

one sig NT875 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T4) & valuation
}

one sig NT876 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig NT877 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT878 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T2 + x1->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT879 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 in valuation
    no (x1->T3 + x1->T4) & valuation
}

one sig NT880 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4) & valuation
}

one sig NT881 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T4) & valuation
}

one sig NT882 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT883 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT884 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT885 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 in valuation
    no (x1->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT886 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x1->T4) & valuation
}

one sig NT887 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x1->T1 + x0->T3 + x0->T4) & valuation
}

one sig NT888 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT889 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT890 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T2 + x1->T3) & valuation
}

one sig NT891 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT892 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT893 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 in valuation
    no (x0->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT894 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT895 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 in valuation
    no (x0->T2 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT896 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT897 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT898 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT899 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT900 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T1 + x0->T2 + x1->T3) & valuation
}

one sig NT901 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT902 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2) & valuation
}

one sig NT903 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT904 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT905 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T2 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT906 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT907 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT908 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT909 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x1->T2) & valuation
}

one sig NT910 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT911 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3) & valuation
}

one sig NT912 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT913 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT914 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x0->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT915 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 in valuation
    no (x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT916 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T2 + x1->T4) & valuation
}

one sig NT917 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 in valuation
    no (x0->T1 + x0->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT918 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3) & valuation
}

one sig NT919 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT920 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3) & valuation
}

one sig NT921 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT922 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T2 + x1->T2 + x1->T3 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT923 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T3) & valuation
}

one sig NT924 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT925 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT926 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT927 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT928 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT929 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT930 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT931 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x0->T2 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT932 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4) & valuation
}

one sig NT933 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x1->T2 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT934 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T1 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3) & valuation
}

one sig NT935 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T4) & valuation
}

one sig NT936 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x1->T3 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT937 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x0->T2 + x1->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT938 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1) & valuation
}

one sig NT939 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4) & valuation
}

one sig NT940 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig NT941 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT942 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T2 + x1->T2) & valuation
}

one sig NT943 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T4 + x1->T4) & valuation
}

one sig NT944 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT945 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x0->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT946 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x0->T1 + x1->T1 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT947 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T2 + x1->T3 + x0->T4) & valuation
}

one sig NT948 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T3 + x0->T4) & valuation
}

one sig NT949 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T2) & valuation
}

one sig NT950 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT951 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T3 + x0->T4) & valuation
}

one sig NT952 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T4) & valuation
}

one sig NT953 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x0->T3) & valuation
}

one sig NT954 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T2 + x1->T3 + x1->T4) & valuation
}

one sig NT955 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x0->T3 + x1->T3) & valuation
}

one sig NT956 extends NegativeTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T4 in valuation
    no (x0->T0 + x1->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig NT957 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T3 + x1->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT958 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 in valuation
    no (x1->T0 + x0->T2 + x0->T4 + x1->T4) & valuation
}

one sig NT959 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x1->T4) & valuation
}

one sig NT960 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3) & valuation
}

one sig NT961 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T1 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT962 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T1 + x1->T1 + x1->T2 + x0->T3 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig NT963 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T3 + x1->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T4) & valuation
}

one sig NT964 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4) & valuation
}

one sig NT965 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x0->T3) & valuation
}

one sig LearnedLTL {
    Root: DAGNode
}
fun root: one DAGNode { LearnedLTL.Root }
fun childrenOf[n: DAGNode]: set DAGNode { n.^(l+r) }
fun childrenAndSelfOf[n: DAGNode]: set DAGNode { n.*(l+r) }
fun ancestorsOf[n: DAGNode]: set DAGNode { n.~^(l+r) }
fun ancestorsAndSelfOf[n: DAGNode]: set DAGNode { n.~*(l+r) }
fun subDAG[n: DAGNode]: DAGNode -> DAGNode { n.*(l+r) <: (l+r) }



fun experimentReach: set DAGNode { childrenAndSelfOf[root] }
fun experimentKept: DAGNode -> DAGNode { (none->none) & subDAG[root] }
one sig ExperimentCost { used: set DAGNode }
fact { ExperimentCost.used = experimentReach }
fact ExperimentBounds {
  DAGNode = experimentReach + Literal + (none)
  #experimentReach <= 5
  #(experimentReach & (And + Or + Imply)) <= 2
  minsome ExperimentCost.used
}
run {
    all t: PositiveTrace | root->T0 in t.valuation
    all t: NegativeTrace | root->T0 not in t.valuation
    
} for 7 DAGNode, 4 Int
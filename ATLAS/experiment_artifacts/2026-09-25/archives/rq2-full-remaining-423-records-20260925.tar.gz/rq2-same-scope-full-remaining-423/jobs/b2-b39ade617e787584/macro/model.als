abstract sig Unit {}
one sig U0, U1, U2, U3, U4 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9 extends Label {}
abstract sig Q {}
one sig Q0 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E27, E29 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos, av20: set Pos, av21: set Pos, av22: set Pos, av23: set Pos, av24: set Pos, av25: set Pos, av26: set Pos, av27: set Pos, av28: set Pos, av29: set Pos, av30: set Pos, av31: set Pos, av32: set Pos, av33: set Pos, av34: set Pos, av35: set Pos, av36: set Pos, av37: set Pos, av38: set Pos, av39: set Pos, av40: set Pos, av41: set Pos, av42: set Pos, av43: set Pos, av44: set Pos, av45: set Pos, av46: set Pos, av47: set Pos, av48: set Pos, av49: set Pos, av50: set Pos, av51: set Pos, av52: set Pos, av53: set Pos, av54: set Pos, av55: set Pos, av56: set Pos, av57: set Pos, av58: set Pos, av59: set Pos, av60: set Pos, av61: set Pos, av62: set Pos, av63: set Pos, av64: set Pos, av65: set Pos, av66: set Pos, av67: set Pos, av68: set Pos, av69: set Pos, av70: set Pos, av71: set Pos, av72: set Pos, av73: set Pos, av74: set Pos, av75: set Pos, av76: set Pos, av77: set Pos, av78: set Pos, av79: set Pos, av80: set Pos, av81: set Pos, av82: set Pos, av83: set Pos, av84: set Pos, av85: set Pos, av86: set Pos, av87: set Pos, av88: set Pos, av89: set Pos, av90: set Pos, av91: set Pos, av92: set Pos, av93: set Pos, av94: set Pos, av95: set Pos, av96: set Pos, av97: set Pos, av98: set Pos, av99: set Pos, av100: set Pos, av101: set Pos, av102: set Pos, av103: set Pos, av104: set Pos, av105: set Pos, av106: set Pos, av107: set Pos, av108: set Pos, av109: set Pos, av110: set Pos, av111: set Pos, av112: set Pos, av113: set Pos, av114: set Pos, av115: set Pos, av116: set Pos, av117: set Pos, av118: set Pos, av119: set Pos, av120: set Pos, av121: set Pos, av122: set Pos, av123: set Pos, av124: set Pos, av125: set Pos, av126: set Pos, av127: set Pos, av128: set Pos, av129: set Pos, av130: set Pos, av131: set Pos, av132: set Pos, av133: set Pos, av134: set Pos, av135: set Pos, av136: set Pos, av137: set Pos, av138: set Pos, av139: set Pos, av140: set Pos, av141: set Pos, av142: set Pos, av143: set Pos, av144: set Pos, av145: set Pos, av146: set Pos, av147: set Pos, av148: set Pos, av149: set Pos, av150: set Pos, av151: set Pos, av152: set Pos, av153: set Pos, av154: set Pos, av155: set Pos, av156: set Pos, av157: set Pos, av158: set Pos, av159: set Pos, av160: set Pos, av161: set Pos, av162: set Pos, av163: set Pos, av164: set Pos, av165: set Pos, av166: set Pos, av167: set Pos, av168: set Pos, av169: set Pos, av170: set Pos, av171: set Pos, av172: set Pos, av173: set Pos, av174: set Pos, av175: set Pos, av176: set Pos, av177: set Pos, av178: set Pos, av179: set Pos, av180: set Pos, av181: set Pos, av182: set Pos, av183: set Pos, av184: set Pos, av185: set Pos, av186: set Pos, av187: set Pos, av188: set Pos, av189: set Pos, av190: set Pos, av191: set Pos, av192: set Pos, av193: set Pos, av194: set Pos, av195: set Pos, av196: set Pos, av197: set Pos, av198: set Pos, av199: set Pos, av200: set Pos, av201: set Pos, av202: set Pos, av203: set Pos, av204: set Pos, av205: set Pos, av206: set Pos, av207: set Pos, av208: set Pos, av209: set Pos, av210: set Pos, av211: set Pos, av212: set Pos, av213: set Pos, av214: set Pos, av215: set Pos, av216: set Pos, av217: set Pos, av218: set Pos, av219: set Pos, av220: set Pos, av221: set Pos, av222: set Pos, av223: set Pos, av224: set Pos, av225: set Pos, av226: set Pos, av227: set Pos, av228: set Pos, av229: set Pos, av230: set Pos, av231: set Pos, av232: set Pos, av233: set Pos, av234: set Pos, av235: set Pos, av236: set Pos, av237: set Pos, av238: set Pos, av239: set Pos, av240: set Pos, av241: set Pos, av242: set Pos, av243: set Pos, av244: set Pos, av245: set Pos, av246: set Pos, av247: set Pos, av248: set Pos, av249: set Pos, av250: set Pos, av251: set Pos, av252: set Pos, av253: set Pos, av254: set Pos, av255: set Pos, av256: set Pos, av257: set Pos, av258: set Pos, av259: set Pos, av260: set Pos, av261: set Pos, av262: set Pos, av263: set Pos, av264: set Pos, av265: set Pos, av266: set Pos, av267: set Pos, av268: set Pos, av269: set Pos, av270: set Pos, av271: set Pos, av272: set Pos, av273: set Pos, av274: set Pos, av275: set Pos, av276: set Pos, av277: set Pos, av278: set Pos, av279: set Pos, av280: set Pos, av281: set Pos, av282: set Pos, av283: set Pos, av284: set Pos, av285: set Pos, av286: set Pos, av287: set Pos, av288: set Pos, av289: set Pos, av290: set Pos, av291: set Pos, av292: set Pos, av293: set Pos, av294: set Pos, av295: set Pos, av296: set Pos, av297: set Pos, av298: set Pos, av299: set Pos, av300: set Pos, av301: set Pos, av302: set Pos, av303: set Pos, av304: set Pos, av305: set Pos, av306: set Pos, av307: set Pos, av308: set Pos, av309: set Pos, av310: set Pos, av311: set Pos, av312: set Pos, av313: set Pos, av314: set Pos, av315: set Pos, av316: set Pos, av317: set Pos, av318: set Pos, av319: set Pos, av320: set Pos, av321: set Pos, av322: set Pos, av323: set Pos, av324: set Pos, av325: set Pos, av326: set Pos, av327: set Pos, av328: set Pos, av329: set Pos, av330: set Pos, av331: set Pos, av332: set Pos, av333: set Pos, av334: set Pos, av335: set Pos, av336: set Pos, av337: set Pos, av338: set Pos, av339: set Pos, av340: set Pos, av341: set Pos, av342: set Pos, av343: set Pos, av344: set Pos, av345: set Pos, av346: set Pos, av347: set Pos }
one sig A0, A1, A2, A3, A4 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos, ev20: set Pos, ev21: set Pos, ev22: set Pos, ev23: set Pos, ev24: set Pos, ev25: set Pos, ev26: set Pos, ev27: set Pos, ev28: set Pos, ev29: set Pos, ev30: set Pos, ev31: set Pos, ev32: set Pos, ev33: set Pos, ev34: set Pos, ev35: set Pos, ev36: set Pos, ev37: set Pos, ev38: set Pos, ev39: set Pos, ev40: set Pos, ev41: set Pos, ev42: set Pos, ev43: set Pos, ev44: set Pos, ev45: set Pos, ev46: set Pos, ev47: set Pos, ev48: set Pos, ev49: set Pos, ev50: set Pos, ev51: set Pos, ev52: set Pos, ev53: set Pos, ev54: set Pos, ev55: set Pos, ev56: set Pos, ev57: set Pos, ev58: set Pos, ev59: set Pos, ev60: set Pos, ev61: set Pos, ev62: set Pos, ev63: set Pos, ev64: set Pos, ev65: set Pos, ev66: set Pos, ev67: set Pos, ev68: set Pos, ev69: set Pos, ev70: set Pos, ev71: set Pos, ev72: set Pos, ev73: set Pos, ev74: set Pos, ev75: set Pos, ev76: set Pos, ev77: set Pos, ev78: set Pos, ev79: set Pos, ev80: set Pos, ev81: set Pos, ev82: set Pos, ev83: set Pos, ev84: set Pos, ev85: set Pos, ev86: set Pos, ev87: set Pos, ev88: set Pos, ev89: set Pos, ev90: set Pos, ev91: set Pos, ev92: set Pos, ev93: set Pos, ev94: set Pos, ev95: set Pos, ev96: set Pos, ev97: set Pos, ev98: set Pos, ev99: set Pos, ev100: set Pos, ev101: set Pos, ev102: set Pos, ev103: set Pos, ev104: set Pos, ev105: set Pos, ev106: set Pos, ev107: set Pos, ev108: set Pos, ev109: set Pos, ev110: set Pos, ev111: set Pos, ev112: set Pos, ev113: set Pos, ev114: set Pos, ev115: set Pos, ev116: set Pos, ev117: set Pos, ev118: set Pos, ev119: set Pos, ev120: set Pos, ev121: set Pos, ev122: set Pos, ev123: set Pos, ev124: set Pos, ev125: set Pos, ev126: set Pos, ev127: set Pos, ev128: set Pos, ev129: set Pos, ev130: set Pos, ev131: set Pos, ev132: set Pos, ev133: set Pos, ev134: set Pos, ev135: set Pos, ev136: set Pos, ev137: set Pos, ev138: set Pos, ev139: set Pos, ev140: set Pos, ev141: set Pos, ev142: set Pos, ev143: set Pos, ev144: set Pos, ev145: set Pos, ev146: set Pos, ev147: set Pos, ev148: set Pos, ev149: set Pos, ev150: set Pos, ev151: set Pos, ev152: set Pos, ev153: set Pos, ev154: set Pos, ev155: set Pos, ev156: set Pos, ev157: set Pos, ev158: set Pos, ev159: set Pos, ev160: set Pos, ev161: set Pos, ev162: set Pos, ev163: set Pos, ev164: set Pos, ev165: set Pos, ev166: set Pos, ev167: set Pos, ev168: set Pos, ev169: set Pos, ev170: set Pos, ev171: set Pos, ev172: set Pos, ev173: set Pos, ev174: set Pos, ev175: set Pos, ev176: set Pos, ev177: set Pos, ev178: set Pos, ev179: set Pos, ev180: set Pos, ev181: set Pos, ev182: set Pos, ev183: set Pos, ev184: set Pos, ev185: set Pos, ev186: set Pos, ev187: set Pos, ev188: set Pos, ev189: set Pos, ev190: set Pos, ev191: set Pos, ev192: set Pos, ev193: set Pos, ev194: set Pos, ev195: set Pos, ev196: set Pos, ev197: set Pos, ev198: set Pos, ev199: set Pos, ev200: set Pos, ev201: set Pos, ev202: set Pos, ev203: set Pos, ev204: set Pos, ev205: set Pos, ev206: set Pos, ev207: set Pos, ev208: set Pos, ev209: set Pos, ev210: set Pos, ev211: set Pos, ev212: set Pos, ev213: set Pos, ev214: set Pos, ev215: set Pos, ev216: set Pos, ev217: set Pos, ev218: set Pos, ev219: set Pos, ev220: set Pos, ev221: set Pos, ev222: set Pos, ev223: set Pos, ev224: set Pos, ev225: set Pos, ev226: set Pos, ev227: set Pos, ev228: set Pos, ev229: set Pos, ev230: set Pos, ev231: set Pos, ev232: set Pos, ev233: set Pos, ev234: set Pos, ev235: set Pos, ev236: set Pos, ev237: set Pos, ev238: set Pos, ev239: set Pos, ev240: set Pos, ev241: set Pos, ev242: set Pos, ev243: set Pos, ev244: set Pos, ev245: set Pos, ev246: set Pos, ev247: set Pos, ev248: set Pos, ev249: set Pos, ev250: set Pos, ev251: set Pos, ev252: set Pos, ev253: set Pos, ev254: set Pos, ev255: set Pos, ev256: set Pos, ev257: set Pos, ev258: set Pos, ev259: set Pos, ev260: set Pos, ev261: set Pos, ev262: set Pos, ev263: set Pos, ev264: set Pos, ev265: set Pos, ev266: set Pos, ev267: set Pos, ev268: set Pos, ev269: set Pos, ev270: set Pos, ev271: set Pos, ev272: set Pos, ev273: set Pos, ev274: set Pos, ev275: set Pos, ev276: set Pos, ev277: set Pos, ev278: set Pos, ev279: set Pos, ev280: set Pos, ev281: set Pos, ev282: set Pos, ev283: set Pos, ev284: set Pos, ev285: set Pos, ev286: set Pos, ev287: set Pos, ev288: set Pos, ev289: set Pos, ev290: set Pos, ev291: set Pos, ev292: set Pos, ev293: set Pos, ev294: set Pos, ev295: set Pos, ev296: set Pos, ev297: set Pos, ev298: set Pos, ev299: set Pos, ev300: set Pos, ev301: set Pos, ev302: set Pos, ev303: set Pos, ev304: set Pos, ev305: set Pos, ev306: set Pos, ev307: set Pos, ev308: set Pos, ev309: set Pos, ev310: set Pos, ev311: set Pos, ev312: set Pos, ev313: set Pos, ev314: set Pos, ev315: set Pos, ev316: set Pos, ev317: set Pos, ev318: set Pos, ev319: set Pos, ev320: set Pos, ev321: set Pos, ev322: set Pos, ev323: set Pos, ev324: set Pos, ev325: set Pos, ev326: set Pos, ev327: set Pos, ev328: set Pos, ev329: set Pos, ev330: set Pos, ev331: set Pos, ev332: set Pos, ev333: set Pos, ev334: set Pos, ev335: set Pos, ev336: set Pos, ev337: set Pos, ev338: set Pos, ev339: set Pos, ev340: set Pos, ev341: set Pos, ev342: set Pos, ev343: set Pos, ev344: set Pos, ev345: set Pos, ev346: set Pos, ev347: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (T0 + (T1 + T2)) }
fun un: set Label { ((T3 + T4) + (T5 + T6)) }
fun bin: set Label { (T7 + (T8 + T9)) }
fun nonempty: set Fiber { ((((E1 + (E2 + E3)) + (E4 + (E5 + E6))) + ((E7 + (E8 + E9)) + ((E10 + E11) + (E12 + E13)))) + (((E14 + (E15 + E16)) + ((E17 + E18) + (E19 + E20))) + ((E21 + (E22 + E23)) + ((E24 + E25) + (E27 + E29))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { ((U0->U1 + U1->U2) + (U2->U3 + U3->U4)) }
fun carrierNext: Carrier -> Carrier { ((((A0->A1 + A1->A2) + (A2->A3 + (A3->A4 + A4->R))) + ((R->C0 + C0->L0) + (L0->D0 + (D0->C1 + C1->L1)))) + (((L1->D1 + D1->C2) + (C2->L2 + (L2->D2 + D2->C3))) + ((C3->L3 + L3->D3) + (D3->C4 + (C4->L4 + L4->D4))))) }
fun child[a: Anchor]: set Port { a.(((A0->C0 + A1->C1) + (A2->C2 + (A3->C3 + A4->C4)))) }
fun left[a: Anchor]: set Port { a.(((A0->L0 + A1->L1) + (A2->L2 + (A3->L3 + A4->L4)))) }
fun right[a: Anchor]: set Port { a.(((A0->D0 + A1->D1) + (A2->D2 + (A3->D3 + A4->D4)))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
no A3.graph & (((A0 + A1) + (A2 + A3)))
no A4.graph & (((A0 + A1) + (A2 + (A3 + A4))))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
lone lab.T2
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un implies #(target.A2) > 1
some A2.lab implies some A1.lab
some A3.lab and A3.lab in un implies #(target.A3) > 1
some A3.lab implies some A2.lab
some A4.lab and A4.lab in un implies #(target.A4) > 1
some A4.lab implies some A3.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q0
E7.qo = Q0
E8.qi = Q0
E8.qo = Q0
E9.qi = Q0
E9.qo = Q0
E10.qi = Q0
E10.qo = Q0
E11.qi = Q0
E11.qo = Q0
E12.qi = Q0
E12.qo = Q0
E13.qi = Q0
E13.qo = Q0
E14.qi = Q0
E14.qo = Q0
E15.qi = Q0
E15.qo = Q0
E16.qi = Q0
E16.qo = Q0
E17.qi = Q0
E17.qo = Q0
E18.qi = Q0
E18.qo = Q0
E19.qi = Q0
E19.qo = Q0
E20.qi = Q0
E20.qo = Q0
E21.qi = Q0
E21.qo = Q0
E22.qi = Q0
E22.qo = Q0
E23.qi = Q0
E23.qo = Q0
E24.qi = Q0
E24.qo = Q0
E25.qi = Q0
E25.qo = Q0
E27.qi = Q0
E27.qo = Q0
E29.qi = Q0
E29.qo = Q0
all e: used | e.fiber in (E0) implies #e.cost = 0
all e: used | e.fiber in ((((E1 + E4) + (E6 + E7)) + ((E9 + E12) + (E13 + (E15 + E17))))) implies #e.cost = 2
all e: used | e.fiber in (((E2 + E3) + (E5 + E11))) implies #e.cost = 1
all e: used | e.fiber in ((((E8 + E10) + (E14 + E16)) + ((E18 + E19) + (E21 + E23)))) implies #e.cost = 3
all e: used | e.fiber in (((E20 + (E22 + E24)) + (E25 + (E27 + E29)))) implies #e.cost = 4
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q0)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 implies a.state = Q0
all a: active | a.lab = T3 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T4 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T5 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T6 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T8 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T9 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
}
fun range0: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop0: set Pos { ((P1 + P2) + (P3 + P4)) }
fun next0: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift0_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun shift0_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P1 + P4->P2))) }
fun shift0_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P1 + (P3->P2 + P4->P3))) }
fun shift0_4: Pos -> Pos { ((P0->P4 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range0 | loop0 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range0 | loop0 in (range0 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range0 | some (loop0 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range0 | some (loop0 & (range0 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range0 | (i.shift0_1) in (range0 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range0 | (i.shift0_1).future0 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range0 | (i.shift0_1).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range0 | (i.shift0_2) in (range0 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range0 | (i.shift0_2).future0 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range0 | (i.shift0_2).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range0 | (i.shift0_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range0 | (i.shift0_3) in (range0 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range0 | some ((i.shift0_3).future0 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range0 | (i.shift0_3).future0 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range0 | (i.shift0_4) in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next0.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop1: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun next1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift1_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun shift1_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P0 + P4->P1))) }
fun shift1_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P0 + (P3->P1 + P4->P2))) }
fun shift1_4: Pos -> Pos { ((P0->P4 + P1->P0) + (P2->P1 + (P3->P2 + P4->P3))) }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range1 | loop1 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range1 | loop1 in (range1 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range1 | some (loop1 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range1 | some (loop1 & (range1 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range1 | (i.shift1_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range1 | (i.shift1_1) in (range1 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range1 | (i.shift1_1).future1 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range1 | (i.shift1_1).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range1 | (i.shift1_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range1 | (i.shift1_2) in (range1 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range1 | (i.shift1_2).future1 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range1 | (i.shift1_2).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range1 | (i.shift1_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range1 | (i.shift1_3) in (range1 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range1 | some ((i.shift1_3).future1 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range1 | (i.shift1_3).future1 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range1 | (i.shift1_4) in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next1.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fun range2: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop2: set Pos { (P2 + (P3 + P4)) }
fun next2: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift2_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun shift2_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P2 + P4->P3))) }
fun shift2_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift2_4: Pos -> Pos { ((P0->P4 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range2 | (i.shift2_0) in (range2 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range2 | (i.shift2_0).future2 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range2 | (i.shift2_0).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range2 | loop2 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range2 | loop2 in (range2 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range2 | some (loop2 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range2 | some (loop2 & (range2 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range2 | (i.shift2_1) in (range2 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range2 | (i.shift2_1).future2 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range2 | (i.shift2_1).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range2 | (i.shift2_2) in (range2 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range2 | (i.shift2_2).future2 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range2 | (i.shift2_2).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range2 | (i.shift2_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range2 | (i.shift2_3) in (range2 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range2 | some ((i.shift2_3).future2 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range2 | (i.shift2_3).future2 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range2 | (i.shift2_4) in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range2 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next2.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range2 | some (i.future2 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range2 | i.future2 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range2 - left[a].ev) + right[a].ev)
}
fun range3: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop3: set Pos { P4 }
fun next3: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift3_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun shift3_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift3_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift3_4: Pos -> Pos { ((P0->P4 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range3 | (i.shift3_0) in (range3 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range3 | (i.shift3_0).future3 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range3 | (i.shift3_0).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range3 | loop3 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range3 | loop3 in (range3 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range3 | some (loop3 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range3 | some (loop3 & (range3 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range3 | (i.shift3_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range3 | (i.shift3_1) in (range3 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range3 | (i.shift3_1).future3 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range3 | (i.shift3_1).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range3 | (i.shift3_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range3 | (i.shift3_2) in (range3 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range3 | (i.shift3_2).future3 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range3 | (i.shift3_2).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range3 | (i.shift3_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range3 | (i.shift3_3) in (range3 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range3 | some ((i.shift3_3).future3 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range3 | (i.shift3_3).future3 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range3 | (i.shift3_4) in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range3 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next3.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range3 | some (i.future3 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range3 | i.future3 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range3 - left[a].ev) + right[a].ev)
}
fun range4: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop4: set Pos { (P3 + P4) }
fun next4: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift4_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun shift4_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P3 + P4->P4))) }
fun shift4_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P3 + (P3->P4 + P4->P3))) }
fun shift4_4: Pos -> Pos { ((P0->P4 + P1->P3) + (P2->P4 + (P3->P3 + P4->P4))) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range4 | (i.shift4_0) in (range4 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range4 | (i.shift4_0).future4 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range4 | (i.shift4_0).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range4 | loop4 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range4 | loop4 in (range4 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range4 | some (loop4 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range4 | some (loop4 & (range4 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range4 | (i.shift4_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range4 | (i.shift4_1) in (range4 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range4 | (i.shift4_1).future4 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range4 | (i.shift4_1).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range4 | (i.shift4_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range4 | (i.shift4_2) in (range4 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range4 | (i.shift4_2).future4 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range4 | (i.shift4_2).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range4 | (i.shift4_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range4 | (i.shift4_3) in (range4 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range4 | some ((i.shift4_3).future4 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range4 | (i.shift4_3).future4 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range4 | (i.shift4_4) in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range4 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next4.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range4 | some (i.future4 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range4 | i.future4 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range4 - left[a].ev) + right[a].ev)
}
fun range5: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop5: set Pos { P3 }
fun next5: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift5_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun shift5_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P3 + P3->P3)) }
fun shift5_3: Pos -> Pos { ((P0->P3 + P1->P3) + (P2->P3 + P3->P3)) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range5 | (i.shift5_0) in (range5 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range5 | (i.shift5_0).future5 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range5 | (i.shift5_0).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range5 | loop5 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range5 | loop5 in (range5 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range5 | some (loop5 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range5 | some (loop5 & (range5 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range5 | (i.shift5_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range5 | (i.shift5_1) in (range5 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range5 | (i.shift5_1).future5 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range5 | (i.shift5_1).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range5 | (i.shift5_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range5 | (i.shift5_2) in (range5 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range5 | (i.shift5_2).future5 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range5 | (i.shift5_2).future5 in (range5 - e.target.av)}
all e: used | e.fiber in ((E23 + E29)) implies e.ev = {i: range5 | (i.shift5_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range5 | (i.shift5_3) in (range5 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range5 | some ((i.shift5_3).future5 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range5 | (i.shift5_3).future5 in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range5 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next5.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range5 | some (i.future5 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range5 | i.future5 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range5 - left[a].ev) + right[a].ev)
}
fun range6: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop6: set Pos { ((P0 + P1) + (P2 + P3)) }
fun next6: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun future6: Pos -> Pos { (*next6) & (range6->range6) }
fun shift6_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift6_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun shift6_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P0 + P3->P1)) }
fun shift6_3: Pos -> Pos { ((P0->P3 + P1->P0) + (P2->P1 + P3->P2)) }
pred semantics6[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range6
ev in used->range6
all e: used | e.fiber in ((E0 + (E1 + E29))) implies e.ev = {i: range6 | (i.shift6_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range6 | (i.shift6_0) in (range6 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range6 | (i.shift6_0).future6 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range6 | (i.shift6_0).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range6 | loop6 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range6 | loop6 in (range6 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range6 | some (loop6 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range6 | some (loop6 & (range6 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range6 | (i.shift6_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range6 | (i.shift6_1) in (range6 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range6 | (i.shift6_1).future6 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range6 | (i.shift6_1).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range6 | (i.shift6_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range6 | (i.shift6_2) in (range6 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range6 | (i.shift6_2).future6 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range6 | (i.shift6_2).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range6 | (i.shift6_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range6 | (i.shift6_3) in (range6 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range6 | some ((i.shift6_3).future6 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range6 | (i.shift6_3).future6 in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range6 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next6.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range6 | some (i.future6 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range6 | i.future6 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range6 - left[a].ev) + right[a].ev)
}
fun range7: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop7: set Pos { (P1 + (P2 + P3)) }
fun next7: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P1)) }
fun future7: Pos -> Pos { (*next7) & (range7->range7) }
fun shift7_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift7_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P1)) }
fun shift7_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P1 + P3->P2)) }
fun shift7_3: Pos -> Pos { ((P0->P3 + P1->P1) + (P2->P2 + P3->P3)) }
pred semantics7[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range7
ev in used->range7
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range7 | (i.shift7_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range7 | (i.shift7_0) in (range7 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range7 | (i.shift7_0).future7 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range7 | (i.shift7_0).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range7 | loop7 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range7 | loop7 in (range7 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range7 | some (loop7 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range7 | some (loop7 & (range7 - e.target.av))}
all e: used | e.fiber in ((E11 + E29)) implies e.ev = {i: range7 | (i.shift7_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range7 | (i.shift7_1) in (range7 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range7 | (i.shift7_1).future7 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range7 | (i.shift7_1).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range7 | (i.shift7_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range7 | (i.shift7_2) in (range7 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range7 | some ((i.shift7_2).future7 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range7 | some ((i.shift7_2).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range7 | (i.shift7_2).future7 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range7 | (i.shift7_2).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range7 | (i.shift7_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range7 | (i.shift7_3) in (range7 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range7 | some ((i.shift7_3).future7 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range7 | (i.shift7_3).future7 in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range7 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next7.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range7 | some (i.future7 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range7 | i.future7 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range7 - left[a].ev) + right[a].ev)
}
fun range8: set Pos { (P0 + (P1 + P2)) }
fun loop8: set Pos { P2 }
fun next8: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun future8: Pos -> Pos { (*next8) & (range8->range8) }
fun shift8_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift8_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun shift8_2: Pos -> Pos { (P0->P2 + (P1->P2 + P2->P2)) }
pred semantics8[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range8
ev in used->range8
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range8 | (i.shift8_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range8 | (i.shift8_0) in (range8 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range8 | (i.shift8_0).future8 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range8 | (i.shift8_0).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range8 | loop8 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range8 | loop8 in (range8 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range8 | some (loop8 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range8 | some (loop8 & (range8 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range8 | (i.shift8_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range8 | (i.shift8_1) in (range8 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range8 | (i.shift8_1).future8 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range8 | (i.shift8_1).future8 in (range8 - e.target.av)}
all e: used | e.fiber in ((E17 + (E23 + E29))) implies e.ev = {i: range8 | (i.shift8_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + E24)) implies e.ev = {i: range8 | (i.shift8_2) in (range8 - e.target.av)}
all e: used | e.fiber in ((E19 + E25)) implies e.ev = {i: range8 | some ((i.shift8_2).future8 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range8 | some ((i.shift8_2).future8 & (range8 - e.target.av))}
all e: used | e.fiber in ((E21 + E27)) implies e.ev = {i: range8 | (i.shift8_2).future8 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range8 | (i.shift8_2).future8 in (range8 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range8 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next8.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range8 | some (i.future8 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range8 | i.future8 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range8 - left[a].ev) + right[a].ev)
}
fun range9: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop9: set Pos { (P2 + P3) }
fun next9: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P2)) }
fun future9: Pos -> Pos { (*next9) & (range9->range9) }
fun shift9_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift9_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P2)) }
fun shift9_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P2 + P3->P3)) }
fun shift9_3: Pos -> Pos { ((P0->P3 + P1->P2) + (P2->P3 + P3->P2)) }
pred semantics9[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range9
ev in used->range9
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range9 | (i.shift9_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range9 | (i.shift9_0) in (range9 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range9 | (i.shift9_0).future9 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range9 | (i.shift9_0).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range9 | loop9 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range9 | loop9 in (range9 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range9 | some (loop9 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range9 | some (loop9 & (range9 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range9 | (i.shift9_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range9 | (i.shift9_1) in (range9 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range9 | (i.shift9_1).future9 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range9 | (i.shift9_1).future9 in (range9 - e.target.av)}
all e: used | e.fiber in ((E17 + E29)) implies e.ev = {i: range9 | (i.shift9_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range9 | (i.shift9_2) in (range9 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range9 | some ((i.shift9_2).future9 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range9 | some ((i.shift9_2).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range9 | (i.shift9_2).future9 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range9 | (i.shift9_2).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range9 | (i.shift9_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range9 | (i.shift9_3) in (range9 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range9 | some ((i.shift9_3).future9 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range9 | (i.shift9_3).future9 in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range9 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next9.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range9 | some (i.future9 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range9 | i.future9 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range9 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av0 = ((P0 + P3))
all a: lab.T2 | a.av0 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev0)
semantics1[av1, ev1]
all a: lab.T0 | a.av1 = (P1)
all a: lab.T1 | a.av1 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av1 = ((P0 + (P3 + P4)))
(R->P0 in ev1)
semantics2[av2, ev2]
all a: lab.T0 | a.av2 = (P3)
all a: lab.T1 | a.av2 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av2 = ((P2 + (P3 + P4)))
(R->P0 in ev2)
semantics2[av3, ev3]
all a: lab.T0 | a.av3 = (P2)
all a: lab.T1 | a.av3 = (P0)
all a: lab.T2 | a.av3 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev3)
semantics2[av4, ev4]
all a: lab.T0 | a.av4 = ((P0 + P1))
all a: lab.T1 | a.av4 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av4 = ((P1 + P2))
(R->P0 in ev4)
semantics2[av5, ev5]
all a: lab.T0 | a.av5 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av5 = (none)
all a: lab.T2 | a.av5 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev5)
semantics2[av6, ev6]
all a: lab.T0 | a.av6 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av6 = (P0)
all a: lab.T2 | a.av6 = (P4)
(R->P0 in ev6)
semantics2[av7, ev7]
all a: lab.T0 | a.av7 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av7 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av7 = ((P0 + (P3 + P4)))
(R->P0 in ev7)
semantics3[av8, ev8]
all a: lab.T0 | a.av8 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av8 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av8 = ((P0 + P2))
(R->P0 in ev8)
semantics3[av9, ev9]
all a: lab.T0 | a.av9 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av9 = ((P1 + P4))
all a: lab.T2 | a.av9 = ((P0 + (P2 + P4)))
(R->P0 in ev9)
semantics1[av10, ev10]
all a: lab.T0 | a.av10 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av10 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av10 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev10)
semantics4[av11, ev11]
all a: lab.T0 | a.av11 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av11 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av11 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev11)
semantics2[av12, ev12]
all a: lab.T0 | a.av12 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av12 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av12 = ((P0 + (P1 + P4)))
(R->P0 in ev12)
semantics3[av13, ev13]
all a: lab.T0 | a.av13 = ((P1 + P4))
all a: lab.T1 | a.av13 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av13 = ((P2 + P4))
(R->P0 in ev13)
semantics4[av14, ev14]
all a: lab.T0 | a.av14 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av14 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av14 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev14)
semantics5[av15, ev15]
all a: lab.T0 | a.av15 = ((P0 + P3))
all a: lab.T1 | a.av15 = (P0)
all a: lab.T2 | a.av15 = ((P0 + P1))
(R->P0 in ev15)
semantics3[av16, ev16]
all a: lab.T0 | a.av16 = ((P0 + P3))
all a: lab.T1 | a.av16 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av16 = ((P1 + P4))
(R->P0 in ev16)
semantics4[av17, ev17]
all a: lab.T0 | a.av17 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av17 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av17 = ((P0 + P4))
(R->P0 in ev17)
semantics3[av18, ev18]
all a: lab.T0 | a.av18 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av18 = ((P0 + P3))
all a: lab.T2 | a.av18 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev18)
semantics4[av19, ev19]
all a: lab.T0 | a.av19 = ((P2 + P3))
all a: lab.T1 | a.av19 = ((P0 + P2))
all a: lab.T2 | a.av19 = ((P1 + (P3 + P4)))
(R->P0 in ev19)
semantics0[av20, ev20]
all a: lab.T0 | a.av20 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av20 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av20 = ((P0 + P4))
(R->P0 in ev20)
semantics1[av21, ev21]
all a: lab.T0 | a.av21 = ((P0 + P3))
all a: lab.T1 | a.av21 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av21 = ((P0 + (P1 + P2)))
(R->P0 in ev21)
semantics0[av22, ev22]
all a: lab.T0 | a.av22 = (none)
all a: lab.T1 | a.av22 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av22 = ((P1 + P4))
(R->P0 in ev22)
semantics5[av23, ev23]
all a: lab.T0 | a.av23 = (none)
all a: lab.T1 | a.av23 = ((P0 + P3))
all a: lab.T2 | a.av23 = ((P0 + P3))
(R->P0 in ev23)
semantics2[av24, ev24]
all a: lab.T0 | a.av24 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av24 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av24 = (none)
(R->P0 in ev24)
semantics4[av25, ev25]
all a: lab.T0 | a.av25 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av25 = ((P1 + P3))
all a: lab.T2 | a.av25 = ((P0 + (P1 + P4)))
(R->P0 in ev25)
semantics1[av26, ev26]
all a: lab.T0 | a.av26 = ((P1 + P3))
all a: lab.T1 | a.av26 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av26 = ((P1 + P4))
(R->P0 in ev26)
semantics2[av27, ev27]
all a: lab.T0 | a.av27 = ((P0 + P4))
all a: lab.T1 | a.av27 = ((P0 + P4))
all a: lab.T2 | a.av27 = ((P0 + (P1 + P4)))
(R->P0 in ev27)
semantics4[av28, ev28]
all a: lab.T0 | a.av28 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av28 = ((P3 + P4))
all a: lab.T2 | a.av28 = ((P1 + P3))
(R->P0 in ev28)
semantics1[av29, ev29]
all a: lab.T0 | a.av29 = ((P0 + P1))
all a: lab.T1 | a.av29 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av29 = ((P0 + (P2 + P3)))
(R->P0 in ev29)
semantics2[av30, ev30]
all a: lab.T0 | a.av30 = (none)
all a: lab.T1 | a.av30 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av30 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev30)
semantics3[av31, ev31]
all a: lab.T0 | a.av31 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av31 = ((P0 + P1))
all a: lab.T2 | a.av31 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev31)
semantics0[av32, ev32]
all a: lab.T0 | a.av32 = ((P0 + P2))
all a: lab.T1 | a.av32 = ((P1 + P3))
all a: lab.T2 | a.av32 = ((P0 + (P1 + P2)))
(R->P0 in ev32)
semantics0[av33, ev33]
all a: lab.T0 | a.av33 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av33 = ((P0 + P2))
all a: lab.T2 | a.av33 = (none)
(R->P0 in ev33)
semantics3[av34, ev34]
all a: lab.T0 | a.av34 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av34 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av34 = (P4)
(R->P0 in ev34)
semantics4[av35, ev35]
all a: lab.T0 | a.av35 = ((P1 + P4))
all a: lab.T1 | a.av35 = ((P0 + P1))
all a: lab.T2 | a.av35 = (P3)
(R->P0 in ev35)
semantics2[av36, ev36]
all a: lab.T0 | a.av36 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av36 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av36 = ((P0 + (P1 + P4)))
(R->P0 in ev36)
semantics0[av37, ev37]
all a: lab.T0 | a.av37 = ((P1 + P3))
all a: lab.T1 | a.av37 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av37 = ((P1 + (P3 + P4)))
(R->P0 in ev37)
semantics1[av38, ev38]
all a: lab.T0 | a.av38 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av38 = ((P0 + P4))
all a: lab.T2 | a.av38 = (none)
(R->P0 in ev38)
semantics1[av39, ev39]
all a: lab.T0 | a.av39 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av39 = ((P2 + P4))
all a: lab.T2 | a.av39 = ((P1 + P3))
(R->P0 in ev39)
semantics1[av40, ev40]
all a: lab.T0 | a.av40 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av40 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av40 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev40)
semantics3[av41, ev41]
all a: lab.T0 | a.av41 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av41 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av41 = ((P0 + P3))
(R->P0 in ev41)
semantics3[av42, ev42]
all a: lab.T0 | a.av42 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av42 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av42 = ((P0 + P3))
(R->P0 in ev42)
semantics1[av43, ev43]
all a: lab.T0 | a.av43 = ((P3 + P4))
all a: lab.T1 | a.av43 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av43 = ((P1 + (P3 + P4)))
(R->P0 in ev43)
semantics2[av44, ev44]
all a: lab.T0 | a.av44 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av44 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av44 = ((P0 + P4))
(R->P0 in ev44)
semantics0[av45, ev45]
all a: lab.T0 | a.av45 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av45 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av45 = ((P0 + (P1 + P3)))
(R->P0 in ev45)
semantics6[av46, ev46]
all a: lab.T0 | a.av46 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av46 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av46 = (P2)
(R->P0 in ev46)
semantics3[av47, ev47]
all a: lab.T0 | a.av47 = ((P0 + P4))
all a: lab.T1 | a.av47 = ((P1 + P4))
all a: lab.T2 | a.av47 = ((P1 + (P2 + P4)))
(R->P0 in ev47)
semantics3[av48, ev48]
all a: lab.T0 | a.av48 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av48 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av48 = (P4)
(R->P0 in ev48)
semantics6[av49, ev49]
all a: lab.T0 | a.av49 = ((P1 + P2))
all a: lab.T1 | a.av49 = ((P0 + P3))
all a: lab.T2 | a.av49 = ((P1 + (P2 + P3)))
(R->P0 in ev49)
semantics0[av50, ev50]
all a: lab.T0 | a.av50 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av50 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av50 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev50)
semantics2[av51, ev51]
all a: lab.T0 | a.av51 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av51 = ((P0 + P1))
all a: lab.T2 | a.av51 = ((P2 + (P3 + P4)))
(R->P0 in ev51)
semantics4[av52, ev52]
all a: lab.T0 | a.av52 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av52 = ((P2 + P4))
all a: lab.T2 | a.av52 = ((P0 + (P2 + P3)))
(R->P0 in ev52)
semantics3[av53, ev53]
all a: lab.T0 | a.av53 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av53 = ((P0 + P4))
all a: lab.T2 | a.av53 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev53)
semantics1[av54, ev54]
all a: lab.T0 | a.av54 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av54 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av54 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev54)
semantics0[av55, ev55]
all a: lab.T0 | a.av55 = (P1)
all a: lab.T1 | a.av55 = ((P0 + P3))
all a: lab.T2 | a.av55 = (P2)
(R->P0 in ev55)
semantics3[av56, ev56]
all a: lab.T0 | a.av56 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av56 = ((P1 + P3))
all a: lab.T2 | a.av56 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev56)
semantics7[av57, ev57]
all a: lab.T0 | a.av57 = (P2)
all a: lab.T1 | a.av57 = ((P0 + P2))
all a: lab.T2 | a.av57 = ((P1 + P2))
(R->P0 in ev57)
semantics0[av58, ev58]
all a: lab.T0 | a.av58 = (P2)
all a: lab.T1 | a.av58 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av58 = ((P0 + P3))
(R->P0 in ev58)
semantics3[av59, ev59]
all a: lab.T0 | a.av59 = (P1)
all a: lab.T1 | a.av59 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av59 = ((P1 + (P2 + P3)))
(R->P0 in ev59)
semantics3[av60, ev60]
all a: lab.T0 | a.av60 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av60 = (P1)
all a: lab.T2 | a.av60 = ((P1 + P4))
(R->P0 in ev60)
semantics4[av61, ev61]
all a: lab.T0 | a.av61 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av61 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av61 = (P2)
(R->P0 in ev61)
semantics2[av62, ev62]
all a: lab.T0 | a.av62 = (P4)
all a: lab.T1 | a.av62 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av62 = (none)
(R->P0 in ev62)
semantics5[av63, ev63]
all a: lab.T0 | a.av63 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av63 = (P0)
all a: lab.T2 | a.av63 = (P1)
(R->P0 in ev63)
semantics2[av64, ev64]
all a: lab.T0 | a.av64 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av64 = ((P1 + P3))
all a: lab.T2 | a.av64 = ((P3 + P4))
(R->P0 in ev64)
semantics4[av65, ev65]
all a: lab.T0 | a.av65 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av65 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av65 = (P4)
(R->P0 in ev65)
semantics3[av66, ev66]
all a: lab.T0 | a.av66 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av66 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av66 = ((P1 + (P2 + P4)))
(R->P0 in ev66)
semantics1[av67, ev67]
all a: lab.T0 | a.av67 = (P4)
all a: lab.T1 | a.av67 = ((P0 + P2))
all a: lab.T2 | a.av67 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev67)
semantics6[av68, ev68]
all a: lab.T0 | a.av68 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av68 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av68 = ((P0 + P1))
(R->P0 in ev68)
semantics2[av69, ev69]
all a: lab.T0 | a.av69 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av69 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av69 = ((P1 + P4))
(R->P0 in ev69)
semantics4[av70, ev70]
all a: lab.T0 | a.av70 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av70 = ((P0 + P1))
all a: lab.T2 | a.av70 = ((P1 + P2))
(R->P0 in ev70)
semantics4[av71, ev71]
all a: lab.T0 | a.av71 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av71 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av71 = ((P1 + (P2 + P3)))
(R->P0 in ev71)
semantics4[av72, ev72]
all a: lab.T0 | a.av72 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av72 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av72 = ((P2 + (P3 + P4)))
(R->P0 in ev72)
semantics4[av73, ev73]
all a: lab.T0 | a.av73 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av73 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av73 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev73)
semantics5[av74, ev74]
all a: lab.T0 | a.av74 = ((P1 + P3))
all a: lab.T1 | a.av74 = (none)
all a: lab.T2 | a.av74 = ((P2 + P3))
(R->P0 in ev74)
semantics1[av75, ev75]
all a: lab.T0 | a.av75 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av75 = ((P0 + P3))
all a: lab.T2 | a.av75 = ((P0 + (P2 + P4)))
(R->P0 in ev75)
semantics1[av76, ev76]
all a: lab.T0 | a.av76 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av76 = ((P2 + P3))
all a: lab.T2 | a.av76 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev76)
semantics0[av77, ev77]
all a: lab.T0 | a.av77 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av77 = (P1)
all a: lab.T2 | a.av77 = ((P0 + (P1 + P3)))
(R->P0 in ev77)
semantics2[av78, ev78]
all a: lab.T0 | a.av78 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av78 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av78 = ((P0 + (P1 + P3)))
(R->P0 in ev78)
semantics0[av79, ev79]
all a: lab.T0 | a.av79 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av79 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av79 = ((P2 + P4))
(R->P0 in ev79)
semantics4[av80, ev80]
all a: lab.T0 | a.av80 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av80 = (P3)
all a: lab.T2 | a.av80 = ((P0 + (P2 + P4)))
(R->P0 in ev80)
semantics2[av81, ev81]
all a: lab.T0 | a.av81 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av81 = ((P1 + P2))
all a: lab.T2 | a.av81 = ((P1 + P4))
(R->P0 in ev81)
semantics4[av82, ev82]
all a: lab.T0 | a.av82 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av82 = (none)
all a: lab.T2 | a.av82 = ((P2 + P3))
(R->P0 in ev82)
semantics4[av83, ev83]
all a: lab.T0 | a.av83 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av83 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av83 = ((P2 + P4))
(R->P0 in ev83)
semantics1[av84, ev84]
all a: lab.T0 | a.av84 = ((P1 + P4))
all a: lab.T1 | a.av84 = ((P0 + P2))
all a: lab.T2 | a.av84 = (none)
(R->P0 in ev84)
semantics5[av85, ev85]
all a: lab.T0 | a.av85 = (P3)
all a: lab.T1 | a.av85 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av85 = (P2)
(R->P0 in ev85)
semantics4[av86, ev86]
all a: lab.T0 | a.av86 = ((P0 + P3))
all a: lab.T1 | a.av86 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av86 = ((P1 + (P2 + P3)))
(R->P0 in ev86)
semantics5[av87, ev87]
all a: lab.T0 | a.av87 = ((P2 + P3))
all a: lab.T1 | a.av87 = ((P0 + P2))
all a: lab.T2 | a.av87 = (P1)
(R->P0 in ev87)
semantics6[av88, ev88]
all a: lab.T0 | a.av88 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av88 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av88 = ((P0 + P2))
(R->P0 in ev88)
semantics8[av89, ev89]
all a: lab.T0 | a.av89 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av89 = (P0)
all a: lab.T2 | a.av89 = (P1)
(R->P0 in ev89)
semantics4[av90, ev90]
all a: lab.T0 | a.av90 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av90 = ((P0 + P2))
all a: lab.T2 | a.av90 = ((P1 + (P2 + P4)))
(R->P0 in ev90)
semantics4[av91, ev91]
all a: lab.T0 | a.av91 = ((P0 + P4))
all a: lab.T1 | a.av91 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av91 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev91)
semantics0[av92, ev92]
all a: lab.T0 | a.av92 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av92 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av92 = ((P0 + P1))
(R->P0 in ev92)
semantics0[av93, ev93]
all a: lab.T0 | a.av93 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av93 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av93 = ((P0 + P2))
(R->P0 in ev93)
semantics9[av94, ev94]
all a: lab.T0 | a.av94 = ((P0 + P3))
all a: lab.T1 | a.av94 = ((P0 + P2))
all a: lab.T2 | a.av94 = ((P0 + P1))
(R->P0 in ev94)
semantics4[av95, ev95]
all a: lab.T0 | a.av95 = ((P0 + P2))
all a: lab.T1 | a.av95 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av95 = ((P0 + (P1 + P4)))
(R->P0 in ev95)
semantics4[av96, ev96]
all a: lab.T0 | a.av96 = ((P0 + P1))
all a: lab.T1 | a.av96 = ((P1 + P2))
all a: lab.T2 | a.av96 = ((P0 + (P2 + P3)))
(R->P0 in ev96)
semantics3[av97, ev97]
all a: lab.T0 | a.av97 = ((P0 + P3))
all a: lab.T1 | a.av97 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av97 = ((P2 + (P3 + P4)))
(R->P0 in ev97)
semantics2[av98, ev98]
all a: lab.T0 | a.av98 = (P0)
all a: lab.T1 | a.av98 = (P1)
all a: lab.T2 | a.av98 = ((P1 + (P3 + P4)))
(R->P0 in ev98)
semantics1[av99, ev99]
all a: lab.T0 | a.av99 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av99 = (P0)
all a: lab.T2 | a.av99 = ((P0 + (P1 + P3)))
(R->P0 in ev99)
semantics0[av100, ev100]
all a: lab.T0 | a.av100 = ((P0 + P3))
all a: lab.T1 | a.av100 = ((P0 + P3))
all a: lab.T2 | a.av100 = ((P1 + P2))
(R->P0 in ev100)
semantics2[av101, ev101]
all a: lab.T0 | a.av101 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av101 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av101 = ((P0 + (P3 + P4)))
(R->P0 in ev101)
semantics2[av102, ev102]
all a: lab.T0 | a.av102 = (P0)
all a: lab.T1 | a.av102 = ((P0 + P2))
all a: lab.T2 | a.av102 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev102)
semantics1[av103, ev103]
all a: lab.T0 | a.av103 = ((P0 + P2))
all a: lab.T1 | a.av103 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av103 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev103)
semantics1[av104, ev104]
all a: lab.T0 | a.av104 = ((P0 + P4))
all a: lab.T1 | a.av104 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av104 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev104)
semantics2[av105, ev105]
all a: lab.T0 | a.av105 = ((P3 + P4))
all a: lab.T1 | a.av105 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av105 = ((P1 + P3))
(R->P0 in ev105)
semantics5[av106, ev106]
all a: lab.T0 | a.av106 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av106 = (P0)
all a: lab.T2 | a.av106 = ((P0 + (P2 + P3)))
(R->P0 in ev106)
semantics1[av107, ev107]
all a: lab.T0 | a.av107 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av107 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av107 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev107)
semantics2[av108, ev108]
all a: lab.T0 | a.av108 = (P4)
all a: lab.T1 | a.av108 = ((P0 + P2))
all a: lab.T2 | a.av108 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev108)
semantics3[av109, ev109]
all a: lab.T0 | a.av109 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av109 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av109 = ((P1 + (P2 + P4)))
(R->P0 in ev109)
semantics9[av110, ev110]
all a: lab.T0 | a.av110 = (P2)
all a: lab.T1 | a.av110 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av110 = (P3)
(R->P0 in ev110)
semantics2[av111, ev111]
all a: lab.T0 | a.av111 = (P4)
all a: lab.T1 | a.av111 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av111 = (P4)
(R->P0 in ev111)
semantics2[av112, ev112]
all a: lab.T0 | a.av112 = ((P0 + P1))
all a: lab.T1 | a.av112 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av112 = (P2)
(R->P0 in ev112)
semantics0[av113, ev113]
all a: lab.T0 | a.av113 = ((P0 + P3))
all a: lab.T1 | a.av113 = ((P0 + P3))
all a: lab.T2 | a.av113 = ((P2 + P4))
(R->P0 in ev113)
semantics3[av114, ev114]
all a: lab.T0 | a.av114 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av114 = ((P1 + P2))
all a: lab.T2 | a.av114 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev114)
semantics0[av115, ev115]
all a: lab.T0 | a.av115 = ((P0 + P2))
all a: lab.T1 | a.av115 = ((P0 + P2))
all a: lab.T2 | a.av115 = ((P1 + (P2 + P3)))
(R->P0 in ev115)
semantics2[av116, ev116]
all a: lab.T0 | a.av116 = ((P0 + P4))
all a: lab.T1 | a.av116 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av116 = ((P0 + P1))
(R->P0 in ev116)
semantics2[av117, ev117]
all a: lab.T0 | a.av117 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av117 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av117 = ((P0 + (P1 + P4)))
(R->P0 in ev117)
semantics0[av118, ev118]
all a: lab.T0 | a.av118 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av118 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av118 = ((P1 + (P2 + P3)))
(R->P0 in ev118)
semantics1[av119, ev119]
all a: lab.T0 | a.av119 = ((P1 + P4))
all a: lab.T1 | a.av119 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av119 = (P0)
(R->P0 in ev119)
semantics3[av120, ev120]
all a: lab.T0 | a.av120 = (P3)
all a: lab.T1 | a.av120 = (P0)
all a: lab.T2 | a.av120 = ((P2 + P4))
(R->P0 in ev120)
semantics1[av121, ev121]
all a: lab.T0 | a.av121 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av121 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av121 = (P4)
(R->P0 in ev121)
semantics1[av122, ev122]
all a: lab.T0 | a.av122 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av122 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av122 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev122)
semantics1[av123, ev123]
all a: lab.T0 | a.av123 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av123 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av123 = ((P0 + P2))
(R->P0 in ev123)
semantics0[av124, ev124]
all a: lab.T0 | a.av124 = ((P3 + P4))
all a: lab.T1 | a.av124 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av124 = ((P1 + P2))
(R->P0 in ev124)
semantics0[av125, ev125]
all a: lab.T0 | a.av125 = ((P0 + P1))
all a: lab.T1 | a.av125 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av125 = (none)
(R->P0 in ev125)
semantics4[av126, ev126]
all a: lab.T0 | a.av126 = ((P3 + P4))
all a: lab.T1 | a.av126 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av126 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev126)
semantics1[av127, ev127]
all a: lab.T0 | a.av127 = (P1)
all a: lab.T1 | a.av127 = ((P0 + P4))
all a: lab.T2 | a.av127 = ((P0 + (P1 + P3)))
(R->P0 in ev127)
semantics6[av128, ev128]
all a: lab.T0 | a.av128 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av128 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av128 = ((P0 + P3))
(R->P0 in ev128)
semantics2[av129, ev129]
all a: lab.T0 | a.av129 = ((P0 + P4))
all a: lab.T1 | a.av129 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av129 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev129)
semantics0[av130, ev130]
all a: lab.T0 | a.av130 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av130 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av130 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev130)
semantics1[av131, ev131]
all a: lab.T0 | a.av131 = ((P0 + P4))
all a: lab.T1 | a.av131 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av131 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev131)
semantics0[av132, ev132]
all a: lab.T0 | a.av132 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av132 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av132 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev132)
semantics1[av133, ev133]
all a: lab.T0 | a.av133 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av133 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av133 = ((P0 + (P1 + P4)))
(R->P0 in ev133)
semantics3[av134, ev134]
all a: lab.T0 | a.av134 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av134 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av134 = ((P1 + P2))
(R->P0 in ev134)
semantics1[av135, ev135]
all a: lab.T0 | a.av135 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av135 = (P3)
all a: lab.T2 | a.av135 = ((P0 + (P1 + P3)))
(R->P0 in ev135)
semantics2[av136, ev136]
all a: lab.T0 | a.av136 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av136 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av136 = ((P1 + (P3 + P4)))
(R->P0 in ev136)
semantics5[av137, ev137]
all a: lab.T0 | a.av137 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av137 = (P1)
all a: lab.T2 | a.av137 = (P3)
(R->P0 in ev137)
semantics1[av138, ev138]
all a: lab.T0 | a.av138 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av138 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av138 = ((P2 + (P3 + P4)))
(R->P0 in ev138)
semantics3[av139, ev139]
all a: lab.T0 | a.av139 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av139 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av139 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev139)
semantics1[av140, ev140]
all a: lab.T0 | a.av140 = ((P1 + P2))
all a: lab.T1 | a.av140 = ((P0 + P3))
all a: lab.T2 | a.av140 = ((P0 + P3))
(R->P0 in ev140)
semantics1[av141, ev141]
all a: lab.T0 | a.av141 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av141 = ((P0 + P2))
all a: lab.T2 | a.av141 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev141)
semantics3[av142, ev142]
all a: lab.T0 | a.av142 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av142 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av142 = ((P0 + (P1 + P2)))
(R->P0 in ev142)
semantics1[av143, ev143]
all a: lab.T0 | a.av143 = (P0)
all a: lab.T1 | a.av143 = ((P0 + P2))
all a: lab.T2 | a.av143 = ((P2 + P4))
(R->P0 in ev143)
semantics1[av144, ev144]
all a: lab.T0 | a.av144 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av144 = (P2)
all a: lab.T2 | a.av144 = ((P0 + P1))
(R->P0 in ev144)
semantics2[av145, ev145]
all a: lab.T0 | a.av145 = ((P0 + P1))
all a: lab.T1 | a.av145 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av145 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev145)
semantics3[av146, ev146]
all a: lab.T0 | a.av146 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av146 = ((P0 + P2))
all a: lab.T2 | a.av146 = ((P0 + (P2 + P4)))
(R->P0 in ev146)
semantics1[av147, ev147]
all a: lab.T0 | a.av147 = ((P3 + P4))
all a: lab.T1 | a.av147 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av147 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev147)
semantics2[av148, ev148]
all a: lab.T0 | a.av148 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av148 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av148 = ((P0 + (P1 + P4)))
(R->P0 in ev148)
semantics3[av149, ev149]
all a: lab.T0 | a.av149 = (P4)
all a: lab.T1 | a.av149 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av149 = ((P2 + P4))
(R->P0 in ev149)
semantics1[av150, ev150]
all a: lab.T0 | a.av150 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av150 = (P1)
all a: lab.T2 | a.av150 = ((P0 + (P1 + P3)))
(R->P0 in ev150)
semantics9[av151, ev151]
all a: lab.T0 | a.av151 = (P2)
all a: lab.T1 | a.av151 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av151 = ((P1 + P3))
(R->P0 in ev151)
semantics0[av152, ev152]
all a: lab.T0 | a.av152 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av152 = ((P0 + P1))
all a: lab.T2 | a.av152 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev152)
semantics1[av153, ev153]
all a: lab.T0 | a.av153 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av153 = (none)
all a: lab.T2 | a.av153 = ((P2 + (P3 + P4)))
(R->P0 in ev153)
semantics2[av154, ev154]
all a: lab.T0 | a.av154 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av154 = ((P1 + P3))
all a: lab.T2 | a.av154 = (P3)
(R->P0 in ev154)
semantics0[av155, ev155]
all a: lab.T0 | a.av155 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av155 = ((P0 + P1))
all a: lab.T2 | a.av155 = ((P0 + (P1 + P3)))
(R->P0 in ev155)
semantics0[av156, ev156]
all a: lab.T0 | a.av156 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av156 = (none)
all a: lab.T2 | a.av156 = ((P0 + (P2 + P3)))
(R->P0 in ev156)
semantics3[av157, ev157]
all a: lab.T0 | a.av157 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av157 = ((P2 + P4))
all a: lab.T2 | a.av157 = ((P0 + (P3 + P4)))
(R->P0 in ev157)
semantics7[av158, ev158]
all a: lab.T0 | a.av158 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av158 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av158 = ((P1 + P3))
(R->P0 in ev158)
semantics0[av159, ev159]
all a: lab.T0 | a.av159 = ((P1 + P3))
all a: lab.T1 | a.av159 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av159 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev159)
semantics7[av160, ev160]
all a: lab.T0 | a.av160 = ((P1 + P3))
all a: lab.T1 | a.av160 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av160 = ((P1 + P3))
(R->P0 in ev160)
semantics1[av161, ev161]
all a: lab.T0 | a.av161 = (P4)
all a: lab.T1 | a.av161 = ((P0 + P2))
all a: lab.T2 | a.av161 = ((P0 + P4))
(R->P0 in ev161)
semantics2[av162, ev162]
all a: lab.T0 | a.av162 = ((P0 + P1))
all a: lab.T1 | a.av162 = ((P0 + P2))
all a: lab.T2 | a.av162 = ((P0 + P4))
(R->P0 in ev162)
semantics6[av163, ev163]
all a: lab.T0 | a.av163 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av163 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av163 = ((P0 + (P2 + P3)))
(R->P0 in ev163)
semantics9[av164, ev164]
all a: lab.T0 | a.av164 = (P0)
all a: lab.T1 | a.av164 = ((P1 + P2))
all a: lab.T2 | a.av164 = ((P1 + P2))
(R->P0 in ev164)
semantics1[av165, ev165]
all a: lab.T0 | a.av165 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av165 = ((P0 + P3))
all a: lab.T2 | a.av165 = (P1)
(R->P0 in ev165)
semantics4[av166, ev166]
all a: lab.T0 | a.av166 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av166 = ((P1 + P3))
all a: lab.T2 | a.av166 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev166)
semantics1[av167, ev167]
all a: lab.T0 | a.av167 = ((P0 + P4))
all a: lab.T1 | a.av167 = (none)
all a: lab.T2 | a.av167 = ((P0 + P3))
(R->P0 in ev167)
semantics1[av168, ev168]
all a: lab.T0 | a.av168 = ((P0 + P3))
all a: lab.T1 | a.av168 = ((P1 + P4))
all a: lab.T2 | a.av168 = ((P0 + (P3 + P4)))
(R->P0 in ev168)
semantics4[av169, ev169]
all a: lab.T0 | a.av169 = (P0)
all a: lab.T1 | a.av169 = ((P1 + P4))
all a: lab.T2 | a.av169 = ((P0 + (P1 + P2)))
(R->P0 in ev169)
semantics2[av170, ev170]
all a: lab.T0 | a.av170 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av170 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av170 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev170)
semantics1[av171, ev171]
all a: lab.T0 | a.av171 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av171 = ((P0 + P3))
all a: lab.T2 | a.av171 = ((P0 + (P1 + P4)))
(R->P0 in ev171)
semantics3[av172, ev172]
all a: lab.T0 | a.av172 = (none)
all a: lab.T1 | a.av172 = ((P0 + P4))
all a: lab.T2 | a.av172 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev172)
semantics2[av173, ev173]
all a: lab.T0 | a.av173 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av173 = (P2)
all a: lab.T2 | a.av173 = ((P0 + (P3 + P4)))
(R->P0 in ev173)
semantics1[av174, ev174]
all a: lab.T0 | a.av174 = ((P2 + P3))
all a: lab.T1 | a.av174 = ((P3 + P4))
all a: lab.T2 | a.av174 = (P3)
not (R->P0 in ev174)
semantics4[av175, ev175]
all a: lab.T0 | a.av175 = (P4)
all a: lab.T1 | a.av175 = ((P2 + P4))
all a: lab.T2 | a.av175 = ((P2 + P3))
not (R->P0 in ev175)
semantics9[av176, ev176]
all a: lab.T0 | a.av176 = ((P2 + P3))
all a: lab.T1 | a.av176 = ((P1 + P3))
all a: lab.T2 | a.av176 = ((P1 + (P2 + P3)))
not (R->P0 in ev176)
semantics5[av177, ev177]
all a: lab.T0 | a.av177 = (none)
all a: lab.T1 | a.av177 = (P3)
all a: lab.T2 | a.av177 = ((P0 + P3))
not (R->P0 in ev177)
semantics2[av178, ev178]
all a: lab.T0 | a.av178 = ((P2 + P3))
all a: lab.T1 | a.av178 = ((P1 + P3))
all a: lab.T2 | a.av178 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev178)
semantics0[av179, ev179]
all a: lab.T0 | a.av179 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av179 = (P4)
all a: lab.T2 | a.av179 = (P3)
not (R->P0 in ev179)
semantics9[av180, ev180]
all a: lab.T0 | a.av180 = (P1)
all a: lab.T1 | a.av180 = ((P1 + P3))
all a: lab.T2 | a.av180 = ((P0 + P3))
not (R->P0 in ev180)
semantics1[av181, ev181]
all a: lab.T0 | a.av181 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av181 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av181 = ((P0 + P3))
not (R->P0 in ev181)
semantics1[av182, ev182]
all a: lab.T0 | a.av182 = (P3)
all a: lab.T1 | a.av182 = (P4)
all a: lab.T2 | a.av182 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev182)
semantics7[av183, ev183]
all a: lab.T0 | a.av183 = (P2)
all a: lab.T1 | a.av183 = ((P1 + P2))
all a: lab.T2 | a.av183 = ((P0 + P2))
not (R->P0 in ev183)
semantics0[av184, ev184]
all a: lab.T0 | a.av184 = (P3)
all a: lab.T1 | a.av184 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av184 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev184)
semantics1[av185, ev185]
all a: lab.T0 | a.av185 = (P3)
all a: lab.T1 | a.av185 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av185 = ((P0 + P2))
not (R->P0 in ev185)
semantics0[av186, ev186]
all a: lab.T0 | a.av186 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av186 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av186 = ((P0 + (P3 + P4)))
not (R->P0 in ev186)
semantics0[av187, ev187]
all a: lab.T0 | a.av187 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av187 = ((P3 + P4))
all a: lab.T2 | a.av187 = ((P1 + (P2 + P3)))
not (R->P0 in ev187)
semantics3[av188, ev188]
all a: lab.T0 | a.av188 = (P0)
all a: lab.T1 | a.av188 = (P3)
all a: lab.T2 | a.av188 = ((P2 + (P3 + P4)))
not (R->P0 in ev188)
semantics4[av189, ev189]
all a: lab.T0 | a.av189 = (none)
all a: lab.T1 | a.av189 = ((P2 + P3))
all a: lab.T2 | a.av189 = ((P0 + (P3 + P4)))
not (R->P0 in ev189)
semantics0[av190, ev190]
all a: lab.T0 | a.av190 = (P4)
all a: lab.T1 | a.av190 = ((P2 + P4))
all a: lab.T2 | a.av190 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev190)
semantics1[av191, ev191]
all a: lab.T0 | a.av191 = (P4)
all a: lab.T1 | a.av191 = ((P1 + P4))
all a: lab.T2 | a.av191 = ((P0 + P3))
not (R->P0 in ev191)
semantics3[av192, ev192]
all a: lab.T0 | a.av192 = ((P0 + P2))
all a: lab.T1 | a.av192 = (P4)
all a: lab.T2 | a.av192 = ((P0 + (P2 + P3)))
not (R->P0 in ev192)
semantics5[av193, ev193]
all a: lab.T0 | a.av193 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av193 = (P3)
all a: lab.T2 | a.av193 = ((P0 + (P2 + P3)))
not (R->P0 in ev193)
semantics2[av194, ev194]
all a: lab.T0 | a.av194 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av194 = ((P2 + P3))
all a: lab.T2 | a.av194 = ((P2 + (P3 + P4)))
not (R->P0 in ev194)
semantics4[av195, ev195]
all a: lab.T0 | a.av195 = ((P1 + P4))
all a: lab.T1 | a.av195 = ((P2 + P4))
all a: lab.T2 | a.av195 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev195)
semantics3[av196, ev196]
all a: lab.T0 | a.av196 = ((P1 + P4))
all a: lab.T1 | a.av196 = (P3)
all a: lab.T2 | a.av196 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev196)
semantics2[av197, ev197]
all a: lab.T0 | a.av197 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av197 = ((P1 + P3))
all a: lab.T2 | a.av197 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev197)
semantics7[av198, ev198]
all a: lab.T0 | a.av198 = ((P1 + P3))
all a: lab.T1 | a.av198 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av198 = (P2)
not (R->P0 in ev198)
semantics0[av199, ev199]
all a: lab.T0 | a.av199 = (P3)
all a: lab.T1 | a.av199 = (P4)
all a: lab.T2 | a.av199 = ((P0 + P4))
not (R->P0 in ev199)
semantics3[av200, ev200]
all a: lab.T0 | a.av200 = (P3)
all a: lab.T1 | a.av200 = (P1)
all a: lab.T2 | a.av200 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev200)
semantics1[av201, ev201]
all a: lab.T0 | a.av201 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av201 = (P1)
all a: lab.T2 | a.av201 = ((P2 + P3))
not (R->P0 in ev201)
semantics4[av202, ev202]
all a: lab.T0 | a.av202 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av202 = ((P1 + P3))
all a: lab.T2 | a.av202 = ((P0 + P1))
not (R->P0 in ev202)
semantics0[av203, ev203]
all a: lab.T0 | a.av203 = (none)
all a: lab.T1 | a.av203 = ((P3 + P4))
all a: lab.T2 | a.av203 = ((P3 + P4))
not (R->P0 in ev203)
semantics4[av204, ev204]
all a: lab.T0 | a.av204 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av204 = (P4)
all a: lab.T2 | a.av204 = ((P2 + (P3 + P4)))
not (R->P0 in ev204)
semantics6[av205, ev205]
all a: lab.T0 | a.av205 = (P2)
all a: lab.T1 | a.av205 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av205 = (P1)
not (R->P0 in ev205)
semantics0[av206, ev206]
all a: lab.T0 | a.av206 = (P3)
all a: lab.T1 | a.av206 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av206 = ((P0 + P4))
not (R->P0 in ev206)
semantics5[av207, ev207]
all a: lab.T0 | a.av207 = (P3)
all a: lab.T1 | a.av207 = ((P1 + P3))
all a: lab.T2 | a.av207 = (P2)
not (R->P0 in ev207)
semantics2[av208, ev208]
all a: lab.T0 | a.av208 = ((P2 + P3))
all a: lab.T1 | a.av208 = (P4)
all a: lab.T2 | a.av208 = ((P1 + P3))
not (R->P0 in ev208)
semantics3[av209, ev209]
all a: lab.T0 | a.av209 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av209 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av209 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev209)
semantics0[av210, ev210]
all a: lab.T0 | a.av210 = (P2)
all a: lab.T1 | a.av210 = (P2)
all a: lab.T2 | a.av210 = ((P3 + P4))
not (R->P0 in ev210)
semantics9[av211, ev211]
all a: lab.T0 | a.av211 = (P1)
all a: lab.T1 | a.av211 = (P3)
all a: lab.T2 | a.av211 = ((P0 + P3))
not (R->P0 in ev211)
semantics3[av212, ev212]
all a: lab.T0 | a.av212 = (none)
all a: lab.T1 | a.av212 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av212 = ((P0 + (P1 + P3)))
not (R->P0 in ev212)
semantics0[av213, ev213]
all a: lab.T0 | a.av213 = ((P0 + P4))
all a: lab.T1 | a.av213 = (P4)
all a: lab.T2 | a.av213 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev213)
semantics0[av214, ev214]
all a: lab.T0 | a.av214 = (none)
all a: lab.T1 | a.av214 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av214 = (P3)
not (R->P0 in ev214)
semantics4[av215, ev215]
all a: lab.T0 | a.av215 = ((P3 + P4))
all a: lab.T1 | a.av215 = ((P1 + P4))
all a: lab.T2 | a.av215 = ((P0 + P4))
not (R->P0 in ev215)
semantics0[av216, ev216]
all a: lab.T0 | a.av216 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av216 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av216 = ((P1 + (P3 + P4)))
not (R->P0 in ev216)
semantics0[av217, ev217]
all a: lab.T0 | a.av217 = ((P2 + P4))
all a: lab.T1 | a.av217 = (P3)
all a: lab.T2 | a.av217 = ((P0 + P4))
not (R->P0 in ev217)
semantics2[av218, ev218]
all a: lab.T0 | a.av218 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av218 = (P4)
all a: lab.T2 | a.av218 = ((P3 + P4))
not (R->P0 in ev218)
semantics4[av219, ev219]
all a: lab.T0 | a.av219 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av219 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av219 = ((P0 + P3))
not (R->P0 in ev219)
semantics0[av220, ev220]
all a: lab.T0 | a.av220 = (P3)
all a: lab.T1 | a.av220 = ((P2 + P4))
all a: lab.T2 | a.av220 = ((P0 + P2))
not (R->P0 in ev220)
semantics2[av221, ev221]
all a: lab.T0 | a.av221 = ((P0 + P2))
all a: lab.T1 | a.av221 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av221 = ((P1 + (P3 + P4)))
not (R->P0 in ev221)
semantics4[av222, ev222]
all a: lab.T0 | a.av222 = (P4)
all a: lab.T1 | a.av222 = (P3)
all a: lab.T2 | a.av222 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev222)
semantics2[av223, ev223]
all a: lab.T0 | a.av223 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av223 = ((P2 + P4))
all a: lab.T2 | a.av223 = ((P2 + P3))
not (R->P0 in ev223)
semantics2[av224, ev224]
all a: lab.T0 | a.av224 = ((P2 + P4))
all a: lab.T1 | a.av224 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av224 = ((P2 + P4))
not (R->P0 in ev224)
semantics4[av225, ev225]
all a: lab.T0 | a.av225 = (P4)
all a: lab.T1 | a.av225 = (P4)
all a: lab.T2 | a.av225 = (P2)
not (R->P0 in ev225)
semantics3[av226, ev226]
all a: lab.T0 | a.av226 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av226 = (P3)
all a: lab.T2 | a.av226 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev226)
semantics1[av227, ev227]
all a: lab.T0 | a.av227 = (P1)
all a: lab.T1 | a.av227 = (P1)
all a: lab.T2 | a.av227 = ((P2 + P3))
not (R->P0 in ev227)
semantics2[av228, ev228]
all a: lab.T0 | a.av228 = ((P2 + P4))
all a: lab.T1 | a.av228 = ((P1 + P4))
all a: lab.T2 | a.av228 = ((P1 + (P3 + P4)))
not (R->P0 in ev228)
semantics3[av229, ev229]
all a: lab.T0 | a.av229 = (P1)
all a: lab.T1 | a.av229 = ((P1 + P3))
all a: lab.T2 | a.av229 = ((P0 + P4))
not (R->P0 in ev229)
semantics0[av230, ev230]
all a: lab.T0 | a.av230 = ((P1 + P4))
all a: lab.T1 | a.av230 = ((P1 + P4))
all a: lab.T2 | a.av230 = ((P0 + (P2 + P3)))
not (R->P0 in ev230)
semantics5[av231, ev231]
all a: lab.T0 | a.av231 = ((P2 + P3))
all a: lab.T1 | a.av231 = ((P1 + P3))
all a: lab.T2 | a.av231 = (P1)
not (R->P0 in ev231)
semantics1[av232, ev232]
all a: lab.T0 | a.av232 = (P1)
all a: lab.T1 | a.av232 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av232 = ((P1 + P3))
not (R->P0 in ev232)
semantics5[av233, ev233]
all a: lab.T0 | a.av233 = (none)
all a: lab.T1 | a.av233 = (P2)
all a: lab.T2 | a.av233 = ((P0 + P2))
not (R->P0 in ev233)
semantics1[av234, ev234]
all a: lab.T0 | a.av234 = ((P2 + P3))
all a: lab.T1 | a.av234 = (P4)
all a: lab.T2 | a.av234 = (P2)
not (R->P0 in ev234)
semantics3[av235, ev235]
all a: lab.T0 | a.av235 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av235 = ((P1 + P4))
all a: lab.T2 | a.av235 = (P4)
not (R->P0 in ev235)
semantics3[av236, ev236]
all a: lab.T0 | a.av236 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av236 = ((P2 + P4))
all a: lab.T2 | a.av236 = (P1)
not (R->P0 in ev236)
semantics1[av237, ev237]
all a: lab.T0 | a.av237 = ((P0 + P4))
all a: lab.T1 | a.av237 = (P3)
all a: lab.T2 | a.av237 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev237)
semantics0[av238, ev238]
all a: lab.T0 | a.av238 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av238 = ((P3 + P4))
all a: lab.T2 | a.av238 = ((P2 + (P3 + P4)))
not (R->P0 in ev238)
semantics0[av239, ev239]
all a: lab.T0 | a.av239 = ((P0 + P2))
all a: lab.T1 | a.av239 = (P3)
all a: lab.T2 | a.av239 = (P2)
not (R->P0 in ev239)
semantics4[av240, ev240]
all a: lab.T0 | a.av240 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av240 = ((P1 + P2))
all a: lab.T2 | a.av240 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev240)
semantics4[av241, ev241]
all a: lab.T0 | a.av241 = (P3)
all a: lab.T1 | a.av241 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av241 = ((P0 + (P3 + P4)))
not (R->P0 in ev241)
semantics3[av242, ev242]
all a: lab.T0 | a.av242 = (P1)
all a: lab.T1 | a.av242 = ((P2 + P3))
all a: lab.T2 | a.av242 = ((P0 + (P3 + P4)))
not (R->P0 in ev242)
semantics2[av243, ev243]
all a: lab.T0 | a.av243 = ((P2 + P3))
all a: lab.T1 | a.av243 = (P4)
all a: lab.T2 | a.av243 = ((P0 + P1))
not (R->P0 in ev243)
semantics5[av244, ev244]
all a: lab.T0 | a.av244 = ((P2 + P3))
all a: lab.T1 | a.av244 = (P3)
all a: lab.T2 | a.av244 = ((P1 + P2))
not (R->P0 in ev244)
semantics1[av245, ev245]
all a: lab.T0 | a.av245 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av245 = (P3)
all a: lab.T2 | a.av245 = ((P0 + P2))
not (R->P0 in ev245)
semantics4[av246, ev246]
all a: lab.T0 | a.av246 = ((P0 + P3))
all a: lab.T1 | a.av246 = (P4)
all a: lab.T2 | a.av246 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev246)
semantics4[av247, ev247]
all a: lab.T0 | a.av247 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av247 = (P4)
all a: lab.T2 | a.av247 = (P4)
not (R->P0 in ev247)
semantics5[av248, ev248]
all a: lab.T0 | a.av248 = ((P2 + P3))
all a: lab.T1 | a.av248 = ((P2 + P3))
all a: lab.T2 | a.av248 = ((P0 + (P1 + P2)))
not (R->P0 in ev248)
semantics3[av249, ev249]
all a: lab.T0 | a.av249 = ((P0 + P4))
all a: lab.T1 | a.av249 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av249 = ((P0 + (P1 + P4)))
not (R->P0 in ev249)
semantics0[av250, ev250]
all a: lab.T0 | a.av250 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av250 = ((P2 + P3))
all a: lab.T2 | a.av250 = ((P0 + P3))
not (R->P0 in ev250)
semantics1[av251, ev251]
all a: lab.T0 | a.av251 = ((P2 + P4))
all a: lab.T1 | a.av251 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av251 = ((P0 + P1))
not (R->P0 in ev251)
semantics4[av252, ev252]
all a: lab.T0 | a.av252 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av252 = ((P2 + P3))
all a: lab.T2 | a.av252 = ((P2 + P4))
not (R->P0 in ev252)
semantics2[av253, ev253]
all a: lab.T0 | a.av253 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av253 = (P1)
all a: lab.T2 | a.av253 = ((P0 + P3))
not (R->P0 in ev253)
semantics0[av254, ev254]
all a: lab.T0 | a.av254 = ((P1 + P4))
all a: lab.T1 | a.av254 = (P3)
all a: lab.T2 | a.av254 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev254)
semantics1[av255, ev255]
all a: lab.T0 | a.av255 = (P2)
all a: lab.T1 | a.av255 = ((P1 + P2))
all a: lab.T2 | a.av255 = ((P0 + (P2 + P4)))
not (R->P0 in ev255)
semantics0[av256, ev256]
all a: lab.T0 | a.av256 = ((P2 + P4))
all a: lab.T1 | a.av256 = ((P3 + P4))
all a: lab.T2 | a.av256 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev256)
semantics4[av257, ev257]
all a: lab.T0 | a.av257 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av257 = (P4)
all a: lab.T2 | a.av257 = (none)
not (R->P0 in ev257)
semantics1[av258, ev258]
all a: lab.T0 | a.av258 = (P3)
all a: lab.T1 | a.av258 = ((P2 + P4))
all a: lab.T2 | a.av258 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev258)
semantics1[av259, ev259]
all a: lab.T0 | a.av259 = (P2)
all a: lab.T1 | a.av259 = ((P1 + P2))
all a: lab.T2 | a.av259 = ((P0 + (P1 + P4)))
not (R->P0 in ev259)
semantics3[av260, ev260]
all a: lab.T0 | a.av260 = ((P1 + P4))
all a: lab.T1 | a.av260 = ((P1 + P2))
all a: lab.T2 | a.av260 = ((P0 + (P1 + P3)))
not (R->P0 in ev260)
semantics3[av261, ev261]
all a: lab.T0 | a.av261 = ((P2 + P3))
all a: lab.T1 | a.av261 = (P2)
all a: lab.T2 | a.av261 = (P4)
not (R->P0 in ev261)
semantics4[av262, ev262]
all a: lab.T0 | a.av262 = (P3)
all a: lab.T1 | a.av262 = ((P2 + P3))
all a: lab.T2 | a.av262 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev262)
semantics0[av263, ev263]
all a: lab.T0 | a.av263 = ((P3 + P4))
all a: lab.T1 | a.av263 = ((P2 + P3))
all a: lab.T2 | a.av263 = ((P2 + (P3 + P4)))
not (R->P0 in ev263)
semantics2[av264, ev264]
all a: lab.T0 | a.av264 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av264 = (P3)
all a: lab.T2 | a.av264 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev264)
semantics5[av265, ev265]
all a: lab.T0 | a.av265 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av265 = (P2)
all a: lab.T2 | a.av265 = (P0)
not (R->P0 in ev265)
semantics4[av266, ev266]
all a: lab.T0 | a.av266 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av266 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av266 = ((P0 + (P1 + P2)))
not (R->P0 in ev266)
semantics3[av267, ev267]
all a: lab.T0 | a.av267 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av267 = (P4)
all a: lab.T2 | a.av267 = ((P1 + (P2 + P3)))
not (R->P0 in ev267)
semantics3[av268, ev268]
all a: lab.T0 | a.av268 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av268 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av268 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev268)
semantics2[av269, ev269]
all a: lab.T0 | a.av269 = ((P1 + P3))
all a: lab.T1 | a.av269 = ((P2 + P3))
all a: lab.T2 | a.av269 = (P2)
not (R->P0 in ev269)
semantics6[av270, ev270]
all a: lab.T0 | a.av270 = ((P1 + P3))
all a: lab.T1 | a.av270 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av270 = (P3)
not (R->P0 in ev270)
semantics2[av271, ev271]
all a: lab.T0 | a.av271 = ((P3 + P4))
all a: lab.T1 | a.av271 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av271 = ((P0 + (P3 + P4)))
not (R->P0 in ev271)
semantics1[av272, ev272]
all a: lab.T0 | a.av272 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av272 = (P4)
all a: lab.T2 | a.av272 = ((P1 + (P2 + P3)))
not (R->P0 in ev272)
semantics1[av273, ev273]
all a: lab.T0 | a.av273 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av273 = ((P1 + P3))
all a: lab.T2 | a.av273 = ((P0 + P1))
not (R->P0 in ev273)
semantics6[av274, ev274]
all a: lab.T0 | a.av274 = (none)
all a: lab.T1 | a.av274 = (P1)
all a: lab.T2 | a.av274 = ((P1 + P2))
not (R->P0 in ev274)
semantics4[av275, ev275]
all a: lab.T0 | a.av275 = (none)
all a: lab.T1 | a.av275 = (P2)
all a: lab.T2 | a.av275 = ((P0 + (P2 + P4)))
not (R->P0 in ev275)
semantics1[av276, ev276]
all a: lab.T0 | a.av276 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av276 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av276 = ((P0 + P4))
not (R->P0 in ev276)
semantics4[av277, ev277]
all a: lab.T0 | a.av277 = ((P0 + P3))
all a: lab.T1 | a.av277 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av277 = ((P3 + P4))
not (R->P0 in ev277)
semantics4[av278, ev278]
all a: lab.T0 | a.av278 = (P1)
all a: lab.T1 | a.av278 = ((P1 + P2))
all a: lab.T2 | a.av278 = ((P1 + (P2 + P3)))
not (R->P0 in ev278)
semantics4[av279, ev279]
all a: lab.T0 | a.av279 = ((P1 + P4))
all a: lab.T1 | a.av279 = (P2)
all a: lab.T2 | a.av279 = ((P0 + (P1 + P3)))
not (R->P0 in ev279)
semantics3[av280, ev280]
all a: lab.T0 | a.av280 = ((P3 + P4))
all a: lab.T1 | a.av280 = ((P1 + P3))
all a: lab.T2 | a.av280 = ((P2 + P3))
not (R->P0 in ev280)
semantics2[av281, ev281]
all a: lab.T0 | a.av281 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av281 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av281 = ((P2 + (P3 + P4)))
not (R->P0 in ev281)
semantics1[av282, ev282]
all a: lab.T0 | a.av282 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av282 = (P4)
all a: lab.T2 | a.av282 = (P1)
not (R->P0 in ev282)
semantics5[av283, ev283]
all a: lab.T0 | a.av283 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av283 = (P3)
all a: lab.T2 | a.av283 = ((P0 + P3))
not (R->P0 in ev283)
semantics3[av284, ev284]
all a: lab.T0 | a.av284 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av284 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av284 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev284)
semantics1[av285, ev285]
all a: lab.T0 | a.av285 = (P0)
all a: lab.T1 | a.av285 = (P4)
all a: lab.T2 | a.av285 = ((P0 + P4))
not (R->P0 in ev285)
semantics0[av286, ev286]
all a: lab.T0 | a.av286 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av286 = (P2)
all a: lab.T2 | a.av286 = ((P1 + P2))
not (R->P0 in ev286)
semantics0[av287, ev287]
all a: lab.T0 | a.av287 = ((P0 + P3))
all a: lab.T1 | a.av287 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av287 = ((P0 + P4))
not (R->P0 in ev287)
semantics4[av288, ev288]
all a: lab.T0 | a.av288 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av288 = ((P1 + P3))
all a: lab.T2 | a.av288 = ((P0 + P2))
not (R->P0 in ev288)
semantics0[av289, ev289]
all a: lab.T0 | a.av289 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av289 = ((P3 + P4))
all a: lab.T2 | a.av289 = ((P1 + P2))
not (R->P0 in ev289)
semantics2[av290, ev290]
all a: lab.T0 | a.av290 = ((P1 + P3))
all a: lab.T1 | a.av290 = ((P2 + P3))
all a: lab.T2 | a.av290 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev290)
semantics4[av291, ev291]
all a: lab.T0 | a.av291 = ((P0 + P3))
all a: lab.T1 | a.av291 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av291 = ((P1 + P4))
not (R->P0 in ev291)
semantics2[av292, ev292]
all a: lab.T0 | a.av292 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av292 = ((P1 + P3))
all a: lab.T2 | a.av292 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev292)
semantics0[av293, ev293]
all a: lab.T0 | a.av293 = ((P1 + P4))
all a: lab.T1 | a.av293 = (P4)
all a: lab.T2 | a.av293 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev293)
semantics1[av294, ev294]
all a: lab.T0 | a.av294 = ((P1 + P3))
all a: lab.T1 | a.av294 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av294 = ((P0 + (P1 + P3)))
not (R->P0 in ev294)
semantics2[av295, ev295]
all a: lab.T0 | a.av295 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av295 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av295 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev295)
semantics1[av296, ev296]
all a: lab.T0 | a.av296 = (P2)
all a: lab.T1 | a.av296 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av296 = ((P0 + P1))
not (R->P0 in ev296)
semantics5[av297, ev297]
all a: lab.T0 | a.av297 = (P3)
all a: lab.T1 | a.av297 = ((P1 + P3))
all a: lab.T2 | a.av297 = ((P1 + P3))
not (R->P0 in ev297)
semantics6[av298, ev298]
all a: lab.T0 | a.av298 = (P1)
all a: lab.T1 | a.av298 = (P3)
all a: lab.T2 | a.av298 = (P0)
not (R->P0 in ev298)
semantics3[av299, ev299]
all a: lab.T0 | a.av299 = (P2)
all a: lab.T1 | a.av299 = ((P2 + P4))
all a: lab.T2 | a.av299 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev299)
semantics4[av300, ev300]
all a: lab.T0 | a.av300 = (P3)
all a: lab.T1 | a.av300 = (P3)
all a: lab.T2 | a.av300 = ((P1 + (P2 + P3)))
not (R->P0 in ev300)
semantics2[av301, ev301]
all a: lab.T0 | a.av301 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av301 = (P2)
all a: lab.T2 | a.av301 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev301)
semantics1[av302, ev302]
all a: lab.T0 | a.av302 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av302 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av302 = ((P2 + P3))
not (R->P0 in ev302)
semantics4[av303, ev303]
all a: lab.T0 | a.av303 = ((P1 + P4))
all a: lab.T1 | a.av303 = (P4)
all a: lab.T2 | a.av303 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev303)
semantics3[av304, ev304]
all a: lab.T0 | a.av304 = (P1)
all a: lab.T1 | a.av304 = (P1)
all a: lab.T2 | a.av304 = ((P0 + (P2 + P3)))
not (R->P0 in ev304)
semantics3[av305, ev305]
all a: lab.T0 | a.av305 = (P4)
all a: lab.T1 | a.av305 = (P3)
all a: lab.T2 | a.av305 = ((P0 + P3))
not (R->P0 in ev305)
semantics3[av306, ev306]
all a: lab.T0 | a.av306 = (P3)
all a: lab.T1 | a.av306 = ((P1 + P3))
all a: lab.T2 | a.av306 = ((P0 + P3))
not (R->P0 in ev306)
semantics0[av307, ev307]
all a: lab.T0 | a.av307 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av307 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av307 = ((P0 + (P1 + P4)))
not (R->P0 in ev307)
semantics0[av308, ev308]
all a: lab.T0 | a.av308 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av308 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av308 = ((P1 + (P3 + P4)))
not (R->P0 in ev308)
semantics2[av309, ev309]
all a: lab.T0 | a.av309 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av309 = ((P1 + P2))
all a: lab.T2 | a.av309 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev309)
semantics3[av310, ev310]
all a: lab.T0 | a.av310 = ((P2 + P4))
all a: lab.T1 | a.av310 = ((P3 + P4))
all a: lab.T2 | a.av310 = (P3)
not (R->P0 in ev310)
semantics4[av311, ev311]
all a: lab.T0 | a.av311 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av311 = (P3)
all a: lab.T2 | a.av311 = (P3)
not (R->P0 in ev311)
semantics1[av312, ev312]
all a: lab.T0 | a.av312 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av312 = ((P2 + P4))
all a: lab.T2 | a.av312 = ((P0 + P3))
not (R->P0 in ev312)
semantics0[av313, ev313]
all a: lab.T0 | a.av313 = ((P3 + P4))
all a: lab.T1 | a.av313 = ((P1 + P3))
all a: lab.T2 | a.av313 = ((P2 + (P3 + P4)))
not (R->P0 in ev313)
semantics3[av314, ev314]
all a: lab.T0 | a.av314 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av314 = (P3)
all a: lab.T2 | a.av314 = ((P1 + (P2 + P4)))
not (R->P0 in ev314)
semantics3[av315, ev315]
all a: lab.T0 | a.av315 = (P1)
all a: lab.T1 | a.av315 = ((P2 + P3))
all a: lab.T2 | a.av315 = (P1)
not (R->P0 in ev315)
semantics4[av316, ev316]
all a: lab.T0 | a.av316 = (P4)
all a: lab.T1 | a.av316 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av316 = ((P1 + (P2 + P3)))
not (R->P0 in ev316)
semantics4[av317, ev317]
all a: lab.T0 | a.av317 = (none)
all a: lab.T1 | a.av317 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av317 = ((P1 + P3))
not (R->P0 in ev317)
semantics4[av318, ev318]
all a: lab.T0 | a.av318 = (none)
all a: lab.T1 | a.av318 = ((P2 + P4))
all a: lab.T2 | a.av318 = ((P3 + P4))
not (R->P0 in ev318)
semantics1[av319, ev319]
all a: lab.T0 | a.av319 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av319 = (P3)
all a: lab.T2 | a.av319 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev319)
semantics3[av320, ev320]
all a: lab.T0 | a.av320 = ((P3 + P4))
all a: lab.T1 | a.av320 = ((P1 + P3))
all a: lab.T2 | a.av320 = ((P0 + (P1 + P4)))
not (R->P0 in ev320)
semantics1[av321, ev321]
all a: lab.T0 | a.av321 = ((P2 + P3))
all a: lab.T1 | a.av321 = (P1)
all a: lab.T2 | a.av321 = ((P0 + P1))
not (R->P0 in ev321)
semantics2[av322, ev322]
all a: lab.T0 | a.av322 = (P1)
all a: lab.T1 | a.av322 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av322 = ((P0 + P2))
not (R->P0 in ev322)
semantics3[av323, ev323]
all a: lab.T0 | a.av323 = (P1)
all a: lab.T1 | a.av323 = (P1)
all a: lab.T2 | a.av323 = ((P1 + (P2 + P3)))
not (R->P0 in ev323)
semantics3[av324, ev324]
all a: lab.T0 | a.av324 = (P4)
all a: lab.T1 | a.av324 = ((P2 + P4))
all a: lab.T2 | a.av324 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev324)
semantics2[av325, ev325]
all a: lab.T0 | a.av325 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av325 = ((P2 + P3))
all a: lab.T2 | a.av325 = ((P2 + P4))
not (R->P0 in ev325)
semantics4[av326, ev326]
all a: lab.T0 | a.av326 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av326 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av326 = ((P1 + P4))
not (R->P0 in ev326)
semantics4[av327, ev327]
all a: lab.T0 | a.av327 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av327 = (P4)
all a: lab.T2 | a.av327 = (P3)
not (R->P0 in ev327)
semantics0[av328, ev328]
all a: lab.T0 | a.av328 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av328 = ((P1 + P4))
all a: lab.T2 | a.av328 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev328)
semantics3[av329, ev329]
all a: lab.T0 | a.av329 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av329 = ((P3 + P4))
all a: lab.T2 | a.av329 = ((P1 + P3))
not (R->P0 in ev329)
semantics1[av330, ev330]
all a: lab.T0 | a.av330 = ((P2 + P4))
all a: lab.T1 | a.av330 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av330 = (P3)
not (R->P0 in ev330)
semantics1[av331, ev331]
all a: lab.T0 | a.av331 = ((P1 + P2))
all a: lab.T1 | a.av331 = ((P1 + P3))
all a: lab.T2 | a.av331 = ((P2 + P4))
not (R->P0 in ev331)
semantics0[av332, ev332]
all a: lab.T0 | a.av332 = (P2)
all a: lab.T1 | a.av332 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av332 = ((P3 + P4))
not (R->P0 in ev332)
semantics4[av333, ev333]
all a: lab.T0 | a.av333 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av333 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av333 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev333)
semantics0[av334, ev334]
all a: lab.T0 | a.av334 = ((P2 + P3))
all a: lab.T1 | a.av334 = (P1)
all a: lab.T2 | a.av334 = ((P2 + (P3 + P4)))
not (R->P0 in ev334)
semantics0[av335, ev335]
all a: lab.T0 | a.av335 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av335 = ((P1 + P3))
all a: lab.T2 | a.av335 = ((P0 + (P1 + P3)))
not (R->P0 in ev335)
semantics3[av336, ev336]
all a: lab.T0 | a.av336 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av336 = ((P1 + P4))
all a: lab.T2 | a.av336 = ((P2 + P4))
not (R->P0 in ev336)
semantics1[av337, ev337]
all a: lab.T0 | a.av337 = ((P2 + P3))
all a: lab.T1 | a.av337 = ((P2 + P4))
all a: lab.T2 | a.av337 = ((P3 + P4))
not (R->P0 in ev337)
semantics3[av338, ev338]
all a: lab.T0 | a.av338 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av338 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av338 = ((P1 + (P2 + P3)))
not (R->P0 in ev338)
semantics4[av339, ev339]
all a: lab.T0 | a.av339 = ((P0 + P4))
all a: lab.T1 | a.av339 = ((P2 + P4))
all a: lab.T2 | a.av339 = (P2)
not (R->P0 in ev339)
semantics3[av340, ev340]
all a: lab.T0 | a.av340 = (none)
all a: lab.T1 | a.av340 = ((P2 + P3))
all a: lab.T2 | a.av340 = ((P0 + P4))
not (R->P0 in ev340)
semantics4[av341, ev341]
all a: lab.T0 | a.av341 = (none)
all a: lab.T1 | a.av341 = (P3)
all a: lab.T2 | a.av341 = ((P3 + P4))
not (R->P0 in ev341)
semantics5[av342, ev342]
all a: lab.T0 | a.av342 = (P2)
all a: lab.T1 | a.av342 = (P1)
all a: lab.T2 | a.av342 = ((P1 + P2))
not (R->P0 in ev342)
semantics2[av343, ev343]
all a: lab.T0 | a.av343 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av343 = (P2)
all a: lab.T2 | a.av343 = ((P0 + P3))
not (R->P0 in ev343)
semantics0[av344, ev344]
all a: lab.T0 | a.av344 = ((P3 + P4))
all a: lab.T1 | a.av344 = ((P1 + P2))
all a: lab.T2 | a.av344 = ((P0 + P1))
not (R->P0 in ev344)
semantics0[av345, ev345]
all a: lab.T0 | a.av345 = ((P1 + P3))
all a: lab.T1 | a.av345 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av345 = ((P1 + P3))
not (R->P0 in ev345)
semantics1[av346, ev346]
all a: lab.T0 | a.av346 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av346 = ((P3 + P4))
all a: lab.T2 | a.av346 = ((P1 + (P2 + P3)))
not (R->P0 in ev346)
semantics1[av347, ev347]
all a: lab.T0 | a.av347 = ((P2 + P3))
all a: lab.T1 | a.av347 = ((P2 + P3))
all a: lab.T2 | a.av347 = ((P2 + (P3 + P4)))
not (R->P0 in ev347)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int

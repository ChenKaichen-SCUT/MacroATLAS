abstract sig Unit {}
one sig U0, U1, U2, U3, U4 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8 extends Label {}
abstract sig Q {}
one sig Q0 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E27, E29 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4, P5, P6, P7, P8, P9 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos, av20: set Pos, av21: set Pos, av22: set Pos, av23: set Pos, av24: set Pos, av25: set Pos, av26: set Pos, av27: set Pos, av28: set Pos, av29: set Pos, av30: set Pos, av31: set Pos, av32: set Pos, av33: set Pos, av34: set Pos, av35: set Pos, av36: set Pos, av37: set Pos, av38: set Pos, av39: set Pos, av40: set Pos, av41: set Pos, av42: set Pos, av43: set Pos, av44: set Pos, av45: set Pos, av46: set Pos, av47: set Pos, av48: set Pos, av49: set Pos, av50: set Pos, av51: set Pos, av52: set Pos, av53: set Pos, av54: set Pos, av55: set Pos, av56: set Pos, av57: set Pos, av58: set Pos, av59: set Pos, av60: set Pos, av61: set Pos, av62: set Pos, av63: set Pos, av64: set Pos, av65: set Pos, av66: set Pos, av67: set Pos, av68: set Pos, av69: set Pos, av70: set Pos, av71: set Pos, av72: set Pos, av73: set Pos, av74: set Pos, av75: set Pos, av76: set Pos, av77: set Pos, av78: set Pos, av79: set Pos, av80: set Pos, av81: set Pos }
one sig A0, A1, A2, A3, A4 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos, ev20: set Pos, ev21: set Pos, ev22: set Pos, ev23: set Pos, ev24: set Pos, ev25: set Pos, ev26: set Pos, ev27: set Pos, ev28: set Pos, ev29: set Pos, ev30: set Pos, ev31: set Pos, ev32: set Pos, ev33: set Pos, ev34: set Pos, ev35: set Pos, ev36: set Pos, ev37: set Pos, ev38: set Pos, ev39: set Pos, ev40: set Pos, ev41: set Pos, ev42: set Pos, ev43: set Pos, ev44: set Pos, ev45: set Pos, ev46: set Pos, ev47: set Pos, ev48: set Pos, ev49: set Pos, ev50: set Pos, ev51: set Pos, ev52: set Pos, ev53: set Pos, ev54: set Pos, ev55: set Pos, ev56: set Pos, ev57: set Pos, ev58: set Pos, ev59: set Pos, ev60: set Pos, ev61: set Pos, ev62: set Pos, ev63: set Pos, ev64: set Pos, ev65: set Pos, ev66: set Pos, ev67: set Pos, ev68: set Pos, ev69: set Pos, ev70: set Pos, ev71: set Pos, ev72: set Pos, ev73: set Pos, ev74: set Pos, ev75: set Pos, ev76: set Pos, ev77: set Pos, ev78: set Pos, ev79: set Pos, ev80: set Pos, ev81: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (T0 + T1) }
fun un: set Label { ((T2 + T3) + (T4 + T5)) }
fun bin: set Label { (T6 + (T7 + T8)) }
fun nonempty: set Fiber { ((((E1 + (E2 + E3)) + (E4 + (E5 + E6))) + ((E7 + (E8 + E9)) + ((E10 + E11) + (E12 + E13)))) + (((E14 + (E15 + E16)) + ((E17 + E18) + (E19 + E20))) + ((E21 + (E22 + E23)) + ((E24 + E25) + (E27 + E29))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { ((U0->U1 + U1->U2) + (U2->U3 + U3->U4)) }
fun carrierNext: Carrier -> Carrier { ((((A0->A1 + A1->A2) + (A2->A3 + (A3->A4 + A4->R))) + ((R->C0 + C0->L0) + (L0->D0 + (D0->C1 + C1->L1)))) + (((L1->D1 + D1->C2) + (C2->L2 + (L2->D2 + D2->C3))) + ((C3->L3 + L3->D3) + (D3->C4 + (C4->L4 + L4->D4))))) }
fun child[a: Anchor]: set Port { a.(((A0->C0 + A1->C1) + (A2->C2 + (A3->C3 + A4->C4)))) }
fun left[a: Anchor]: set Port { a.(((A0->L0 + A1->L1) + (A2->L2 + (A3->L3 + A4->L4)))) }
fun right[a: Anchor]: set Port { a.(((A0->D0 + A1->D1) + (A2->D2 + (A3->D3 + A4->D4)))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
no A3.graph & (((A0 + A1) + (A2 + A3)))
no A4.graph & (((A0 + A1) + (A2 + (A3 + A4))))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un implies #(target.A2) > 1
some A2.lab implies some A1.lab
some A3.lab and A3.lab in un implies #(target.A3) > 1
some A3.lab implies some A2.lab
some A4.lab and A4.lab in un implies #(target.A4) > 1
some A4.lab implies some A3.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q0
E7.qo = Q0
E8.qi = Q0
E8.qo = Q0
E9.qi = Q0
E9.qo = Q0
E10.qi = Q0
E10.qo = Q0
E11.qi = Q0
E11.qo = Q0
E12.qi = Q0
E12.qo = Q0
E13.qi = Q0
E13.qo = Q0
E14.qi = Q0
E14.qo = Q0
E15.qi = Q0
E15.qo = Q0
E16.qi = Q0
E16.qo = Q0
E17.qi = Q0
E17.qo = Q0
E18.qi = Q0
E18.qo = Q0
E19.qi = Q0
E19.qo = Q0
E20.qi = Q0
E20.qo = Q0
E21.qi = Q0
E21.qo = Q0
E22.qi = Q0
E22.qo = Q0
E23.qi = Q0
E23.qo = Q0
E24.qi = Q0
E24.qo = Q0
E25.qi = Q0
E25.qo = Q0
E27.qi = Q0
E27.qo = Q0
E29.qi = Q0
E29.qo = Q0
all e: used | e.fiber in (E0) implies #e.cost = 0
all e: used | e.fiber in ((((E1 + E4) + (E6 + E7)) + ((E9 + E12) + (E13 + (E15 + E17))))) implies #e.cost = 2
all e: used | e.fiber in (((E2 + E3) + (E5 + E11))) implies #e.cost = 1
all e: used | e.fiber in ((((E8 + E10) + (E14 + E16)) + ((E18 + E19) + (E21 + E23)))) implies #e.cost = 3
all e: used | e.fiber in (((E20 + (E22 + E24)) + (E25 + (E27 + E29)))) implies #e.cost = 4
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q0)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T3 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T4 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T5 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T8 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
}
fun range0: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop0: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun next0: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P0)))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift0_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P0)))) }
fun shift0_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P0 + P9->P1)))) }
fun shift0_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P0 + (P8->P1 + P9->P2)))) }
fun shift0_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P0) + (P7->P1 + (P8->P2 + P9->P3)))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range0 | loop0 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range0 | loop0 in (range0 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range0 | some (loop0 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range0 | some (loop0 & (range0 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range0 | (i.shift0_1) in (range0 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range0 | (i.shift0_1).future0 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range0 | (i.shift0_1).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range0 | (i.shift0_2) in (range0 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range0 | (i.shift0_2).future0 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range0 | (i.shift0_2).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range0 | (i.shift0_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range0 | (i.shift0_3) in (range0 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range0 | some ((i.shift0_3).future0 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range0 | (i.shift0_3).future0 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range0 | (i.shift0_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next0.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop1: set Pos { (((P1 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun next1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P1)))) }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift1_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P1)))) }
fun shift1_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P1 + P9->P2)))) }
fun shift1_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P1 + (P8->P2 + P9->P3)))) }
fun shift1_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P1) + (P7->P2 + (P8->P3 + P9->P4)))) }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range1 | loop1 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range1 | loop1 in (range1 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range1 | some (loop1 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range1 | some (loop1 & (range1 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range1 | (i.shift1_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range1 | (i.shift1_1) in (range1 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range1 | (i.shift1_1).future1 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range1 | (i.shift1_1).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range1 | (i.shift1_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range1 | (i.shift1_2) in (range1 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range1 | (i.shift1_2).future1 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range1 | (i.shift1_2).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range1 | (i.shift1_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range1 | (i.shift1_3) in (range1 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range1 | some ((i.shift1_3).future1 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range1 | (i.shift1_3).future1 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range1 | (i.shift1_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next1.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fun range2: set Pos { ((P0 + (P1 + P2)) + (P3 + (P4 + P5))) }
fun loop2: set Pos { P5 }
fun next2: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P5))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) }
fun shift2_1: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P5))) }
fun shift2_2: Pos -> Pos { ((P0->P2 + (P1->P3 + P2->P4)) + (P3->P5 + (P4->P5 + P5->P5))) }
fun shift2_3: Pos -> Pos { ((P0->P3 + (P1->P4 + P2->P5)) + (P3->P5 + (P4->P5 + P5->P5))) }
fun shift2_4: Pos -> Pos { ((P0->P4 + (P1->P5 + P2->P5)) + (P3->P5 + (P4->P5 + P5->P5))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range2 | (i.shift2_0) in (range2 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range2 | (i.shift2_0).future2 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range2 | (i.shift2_0).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range2 | loop2 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range2 | loop2 in (range2 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range2 | some (loop2 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range2 | some (loop2 & (range2 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range2 | (i.shift2_1) in (range2 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range2 | (i.shift2_1).future2 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range2 | (i.shift2_1).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range2 | (i.shift2_2) in (range2 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range2 | (i.shift2_2).future2 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range2 | (i.shift2_2).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range2 | (i.shift2_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range2 | (i.shift2_3) in (range2 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range2 | some ((i.shift2_3).future2 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range2 | (i.shift2_3).future2 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range2 | (i.shift2_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range2 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next2.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range2 | some (i.future2 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range2 | i.future2 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range2 - left[a].ev) + right[a].ev)
}
fun range3: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop3: set Pos { ((P5 + P6) + (P7 + (P8 + P9))) }
fun next3: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P5)))) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift3_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P5)))) }
fun shift3_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P5 + P9->P6)))) }
fun shift3_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P5 + (P8->P6 + P9->P7)))) }
fun shift3_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P5) + (P7->P6 + (P8->P7 + P9->P8)))) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range3 | (i.shift3_0) in (range3 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range3 | (i.shift3_0).future3 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range3 | (i.shift3_0).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range3 | loop3 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range3 | loop3 in (range3 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range3 | some (loop3 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range3 | some (loop3 & (range3 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range3 | (i.shift3_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range3 | (i.shift3_1) in (range3 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range3 | (i.shift3_1).future3 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range3 | (i.shift3_1).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range3 | (i.shift3_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range3 | (i.shift3_2) in (range3 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range3 | (i.shift3_2).future3 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range3 | (i.shift3_2).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range3 | (i.shift3_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range3 | (i.shift3_3) in (range3 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range3 | some ((i.shift3_3).future3 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range3 | (i.shift3_3).future3 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range3 | (i.shift3_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range3 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next3.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range3 | some (i.future3 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range3 | i.future3 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range3 - left[a].ev) + right[a].ev)
}
fun range4: set Pos { ((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) }
fun loop4: set Pos { (P4 + (P5 + P6)) }
fun next4: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P4))) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { ((P0->P0 + (P1->P1 + P2->P2)) + ((P3->P3 + P4->P4) + (P5->P5 + P6->P6))) }
fun shift4_1: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P4))) }
fun shift4_2: Pos -> Pos { ((P0->P2 + (P1->P3 + P2->P4)) + ((P3->P5 + P4->P6) + (P5->P4 + P6->P5))) }
fun shift4_3: Pos -> Pos { ((P0->P3 + (P1->P4 + P2->P5)) + ((P3->P6 + P4->P4) + (P5->P5 + P6->P6))) }
fun shift4_4: Pos -> Pos { ((P0->P4 + (P1->P5 + P2->P6)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P4))) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range4 | (i.shift4_0) in (range4 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range4 | (i.shift4_0).future4 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range4 | (i.shift4_0).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range4 | loop4 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range4 | loop4 in (range4 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range4 | some (loop4 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range4 | some (loop4 & (range4 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range4 | (i.shift4_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range4 | (i.shift4_1) in (range4 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range4 | (i.shift4_1).future4 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range4 | (i.shift4_1).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range4 | (i.shift4_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range4 | (i.shift4_2) in (range4 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range4 | (i.shift4_2).future4 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range4 | (i.shift4_2).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range4 | (i.shift4_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range4 | (i.shift4_3) in (range4 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range4 | some ((i.shift4_3).future4 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range4 | (i.shift4_3).future4 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range4 | (i.shift4_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range4 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next4.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range4 | some (i.future4 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range4 | i.future4 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range4 - left[a].ev) + right[a].ev)
}
fun range5: set Pos { ((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) }
fun loop5: set Pos { P6 }
fun next5: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P6))) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { ((P0->P0 + (P1->P1 + P2->P2)) + ((P3->P3 + P4->P4) + (P5->P5 + P6->P6))) }
fun shift5_1: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P6))) }
fun shift5_2: Pos -> Pos { ((P0->P2 + (P1->P3 + P2->P4)) + ((P3->P5 + P4->P6) + (P5->P6 + P6->P6))) }
fun shift5_3: Pos -> Pos { ((P0->P3 + (P1->P4 + P2->P5)) + ((P3->P6 + P4->P6) + (P5->P6 + P6->P6))) }
fun shift5_4: Pos -> Pos { ((P0->P4 + (P1->P5 + P2->P6)) + ((P3->P6 + P4->P6) + (P5->P6 + P6->P6))) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range5 | (i.shift5_0) in (range5 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range5 | (i.shift5_0).future5 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range5 | (i.shift5_0).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range5 | loop5 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range5 | loop5 in (range5 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range5 | some (loop5 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range5 | some (loop5 & (range5 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range5 | (i.shift5_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range5 | (i.shift5_1) in (range5 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range5 | (i.shift5_1).future5 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range5 | (i.shift5_1).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range5 | (i.shift5_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range5 | (i.shift5_2) in (range5 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range5 | (i.shift5_2).future5 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range5 | (i.shift5_2).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range5 | (i.shift5_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range5 | (i.shift5_3) in (range5 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range5 | some ((i.shift5_3).future5 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range5 | (i.shift5_3).future5 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range5 | (i.shift5_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range5 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next5.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range5 | some (i.future5 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range5 | i.future5 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range5 - left[a].ev) + right[a].ev)
}
fun range6: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop6: set Pos { (P8 + P9) }
fun next6: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P8)))) }
fun future6: Pos -> Pos { (*next6) & (range6->range6) }
fun shift6_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift6_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P8)))) }
fun shift6_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P8 + P9->P9)))) }
fun shift6_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P8 + (P8->P9 + P9->P8)))) }
fun shift6_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P8) + (P7->P9 + (P8->P8 + P9->P9)))) }
pred semantics6[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range6
ev in used->range6
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range6 | (i.shift6_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range6 | (i.shift6_0) in (range6 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range6 | (i.shift6_0).future6 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range6 | (i.shift6_0).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range6 | loop6 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range6 | loop6 in (range6 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range6 | some (loop6 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range6 | some (loop6 & (range6 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range6 | (i.shift6_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range6 | (i.shift6_1) in (range6 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range6 | (i.shift6_1).future6 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range6 | (i.shift6_1).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range6 | (i.shift6_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range6 | (i.shift6_2) in (range6 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range6 | (i.shift6_2).future6 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range6 | (i.shift6_2).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range6 | (i.shift6_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range6 | (i.shift6_3) in (range6 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range6 | some ((i.shift6_3).future6 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range6 | (i.shift6_3).future6 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range6 | (i.shift6_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range6 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next6.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range6 | some (i.future6 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range6 | i.future6 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range6 - left[a].ev) + right[a].ev)
}
fun range7: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop7: set Pos { ((P6 + P7) + (P8 + P9)) }
fun next7: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P6)))) }
fun future7: Pos -> Pos { (*next7) & (range7->range7) }
fun shift7_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift7_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P6)))) }
fun shift7_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P6 + P9->P7)))) }
fun shift7_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P6 + (P8->P7 + P9->P8)))) }
fun shift7_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
pred semantics7[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range7
ev in used->range7
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range7 | (i.shift7_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range7 | (i.shift7_0) in (range7 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range7 | (i.shift7_0).future7 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range7 | (i.shift7_0).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range7 | loop7 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range7 | loop7 in (range7 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range7 | some (loop7 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range7 | some (loop7 & (range7 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range7 | (i.shift7_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range7 | (i.shift7_1) in (range7 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range7 | (i.shift7_1).future7 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range7 | (i.shift7_1).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range7 | (i.shift7_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range7 | (i.shift7_2) in (range7 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range7 | some ((i.shift7_2).future7 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range7 | some ((i.shift7_2).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range7 | (i.shift7_2).future7 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range7 | (i.shift7_2).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range7 | (i.shift7_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range7 | (i.shift7_3) in (range7 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range7 | some ((i.shift7_3).future7 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range7 | (i.shift7_3).future7 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range7 | (i.shift7_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range7 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next7.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range7 | some (i.future7 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range7 | i.future7 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range7 - left[a].ev) + right[a].ev)
}
fun range8: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop8: set Pos { (((P2 + P3) + (P4 + P5)) + ((P6 + P7) + (P8 + P9))) }
fun next8: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P2)))) }
fun future8: Pos -> Pos { (*next8) & (range8->range8) }
fun shift8_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift8_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P2)))) }
fun shift8_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P2 + P9->P3)))) }
fun shift8_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P2 + (P8->P3 + P9->P4)))) }
fun shift8_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P2) + (P7->P3 + (P8->P4 + P9->P5)))) }
pred semantics8[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range8
ev in used->range8
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range8 | (i.shift8_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range8 | (i.shift8_0) in (range8 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range8 | (i.shift8_0).future8 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range8 | (i.shift8_0).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range8 | loop8 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range8 | loop8 in (range8 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range8 | some (loop8 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range8 | some (loop8 & (range8 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range8 | (i.shift8_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range8 | (i.shift8_1) in (range8 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range8 | (i.shift8_1).future8 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range8 | (i.shift8_1).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range8 | (i.shift8_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range8 | (i.shift8_2) in (range8 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range8 | some ((i.shift8_2).future8 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range8 | some ((i.shift8_2).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range8 | (i.shift8_2).future8 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range8 | (i.shift8_2).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range8 | (i.shift8_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range8 | (i.shift8_3) in (range8 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range8 | some ((i.shift8_3).future8 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range8 | (i.shift8_3).future8 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range8 | (i.shift8_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range8 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next8.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range8 | some (i.future8 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range8 | i.future8 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range8 - left[a].ev) + right[a].ev)
}
fun range9: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop9: set Pos { ((P4 + P5) + (P6 + (P7 + P8))) }
fun next9: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P4)))) }
fun future9: Pos -> Pos { (*next9) & (range9->range9) }
fun shift9_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift9_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P4)))) }
fun shift9_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P4 + P8->P5)))) }
fun shift9_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P4 + (P7->P5 + P8->P6)))) }
fun shift9_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P4) + (P6->P5 + (P7->P6 + P8->P7)))) }
pred semantics9[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range9
ev in used->range9
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range9 | (i.shift9_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range9 | (i.shift9_0) in (range9 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range9 | (i.shift9_0).future9 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range9 | (i.shift9_0).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range9 | loop9 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range9 | loop9 in (range9 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range9 | some (loop9 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range9 | some (loop9 & (range9 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range9 | (i.shift9_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range9 | (i.shift9_1) in (range9 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range9 | (i.shift9_1).future9 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range9 | (i.shift9_1).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range9 | (i.shift9_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range9 | (i.shift9_2) in (range9 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range9 | some ((i.shift9_2).future9 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range9 | some ((i.shift9_2).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range9 | (i.shift9_2).future9 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range9 | (i.shift9_2).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range9 | (i.shift9_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range9 | (i.shift9_3) in (range9 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range9 | some ((i.shift9_3).future9 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range9 | (i.shift9_3).future9 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range9 | (i.shift9_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range9 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next9.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range9 | some (i.future9 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range9 | i.future9 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range9 - left[a].ev) + right[a].ev)
}
fun range10: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop10: set Pos { ((P3 + (P4 + P5)) + ((P6 + P7) + (P8 + P9))) }
fun next10: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P3)))) }
fun future10: Pos -> Pos { (*next10) & (range10->range10) }
fun shift10_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift10_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P3)))) }
fun shift10_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P3 + P9->P4)))) }
fun shift10_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P3 + (P8->P4 + P9->P5)))) }
fun shift10_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P3) + (P7->P4 + (P8->P5 + P9->P6)))) }
pred semantics10[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range10
ev in used->range10
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range10 | (i.shift10_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range10 | (i.shift10_0) in (range10 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range10 | (i.shift10_0).future10 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range10 | (i.shift10_0).future10 in (range10 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range10 | loop10 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range10 | loop10 in (range10 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range10 | some (loop10 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range10 | some (loop10 & (range10 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range10 | (i.shift10_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range10 | (i.shift10_1) in (range10 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range10 | some ((i.shift10_1).future10 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range10 | some ((i.shift10_1).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range10 | (i.shift10_1).future10 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range10 | (i.shift10_1).future10 in (range10 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range10 | (i.shift10_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range10 | (i.shift10_2) in (range10 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range10 | some ((i.shift10_2).future10 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range10 | some ((i.shift10_2).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range10 | (i.shift10_2).future10 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range10 | (i.shift10_2).future10 in (range10 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range10 | (i.shift10_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range10 | (i.shift10_3) in (range10 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range10 | some ((i.shift10_3).future10 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range10 | (i.shift10_3).future10 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range10 | (i.shift10_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range10 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next10.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range10 | some (i.future10 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range10 | i.future10 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range10 - left[a].ev) + right[a].ev)
}
fun range11: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop11: set Pos { ((P2 + (P3 + P4)) + ((P5 + P6) + (P7 + P8))) }
fun next11: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P2)))) }
fun future11: Pos -> Pos { (*next11) & (range11->range11) }
fun shift11_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift11_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P2)))) }
fun shift11_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P2 + P8->P3)))) }
fun shift11_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P2 + (P7->P3 + P8->P4)))) }
fun shift11_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P2) + (P6->P3 + (P7->P4 + P8->P5)))) }
pred semantics11[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range11
ev in used->range11
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range11 | (i.shift11_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range11 | (i.shift11_0) in (range11 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range11 | some ((i.shift11_0).future11 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range11 | some ((i.shift11_0).future11 & (range11 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range11 | (i.shift11_0).future11 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range11 | (i.shift11_0).future11 in (range11 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range11 | loop11 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range11 | loop11 in (range11 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range11 | some (loop11 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range11 | some (loop11 & (range11 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range11 | (i.shift11_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range11 | (i.shift11_1) in (range11 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range11 | some ((i.shift11_1).future11 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range11 | some ((i.shift11_1).future11 & (range11 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range11 | (i.shift11_1).future11 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range11 | (i.shift11_1).future11 in (range11 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range11 | (i.shift11_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range11 | (i.shift11_2) in (range11 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range11 | some ((i.shift11_2).future11 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range11 | some ((i.shift11_2).future11 & (range11 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range11 | (i.shift11_2).future11 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range11 | (i.shift11_2).future11 in (range11 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range11 | (i.shift11_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range11 | (i.shift11_3) in (range11 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range11 | some ((i.shift11_3).future11 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range11 | (i.shift11_3).future11 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range11 | (i.shift11_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range11 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next11.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range11 | some (i.future11 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range11 | i.future11 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range11 - left[a].ev) + right[a].ev)
}
fun range12: set Pos { ((P0 + (P1 + P2)) + (P3 + (P4 + P5))) }
fun loop12: set Pos { (P4 + P5) }
fun next12: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P4))) }
fun future12: Pos -> Pos { (*next12) & (range12->range12) }
fun shift12_0: Pos -> Pos { ((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) }
fun shift12_1: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P4))) }
fun shift12_2: Pos -> Pos { ((P0->P2 + (P1->P3 + P2->P4)) + (P3->P5 + (P4->P4 + P5->P5))) }
fun shift12_3: Pos -> Pos { ((P0->P3 + (P1->P4 + P2->P5)) + (P3->P4 + (P4->P5 + P5->P4))) }
fun shift12_4: Pos -> Pos { ((P0->P4 + (P1->P5 + P2->P4)) + (P3->P5 + (P4->P4 + P5->P5))) }
pred semantics12[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range12
ev in used->range12
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range12 | (i.shift12_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range12 | (i.shift12_0) in (range12 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range12 | some ((i.shift12_0).future12 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range12 | some ((i.shift12_0).future12 & (range12 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range12 | (i.shift12_0).future12 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range12 | (i.shift12_0).future12 in (range12 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range12 | loop12 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range12 | loop12 in (range12 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range12 | some (loop12 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range12 | some (loop12 & (range12 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range12 | (i.shift12_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range12 | (i.shift12_1) in (range12 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range12 | some ((i.shift12_1).future12 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range12 | some ((i.shift12_1).future12 & (range12 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range12 | (i.shift12_1).future12 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range12 | (i.shift12_1).future12 in (range12 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range12 | (i.shift12_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range12 | (i.shift12_2) in (range12 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range12 | some ((i.shift12_2).future12 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range12 | some ((i.shift12_2).future12 & (range12 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range12 | (i.shift12_2).future12 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range12 | (i.shift12_2).future12 in (range12 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range12 | (i.shift12_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range12 | (i.shift12_3) in (range12 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range12 | some ((i.shift12_3).future12 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range12 | (i.shift12_3).future12 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range12 | (i.shift12_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range12 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next12.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range12 | some (i.future12 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range12 | i.future12 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range12 - left[a].ev) + right[a].ev)
}
fun range13: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop13: set Pos { ((P5 + P6) + (P7 + P8)) }
fun next13: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P5)))) }
fun future13: Pos -> Pos { (*next13) & (range13->range13) }
fun shift13_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift13_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P5)))) }
fun shift13_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P5 + P8->P6)))) }
fun shift13_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P5 + (P7->P6 + P8->P7)))) }
fun shift13_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
pred semantics13[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range13
ev in used->range13
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range13 | (i.shift13_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range13 | (i.shift13_0) in (range13 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range13 | some ((i.shift13_0).future13 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range13 | some ((i.shift13_0).future13 & (range13 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range13 | (i.shift13_0).future13 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range13 | (i.shift13_0).future13 in (range13 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range13 | loop13 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range13 | loop13 in (range13 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range13 | some (loop13 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range13 | some (loop13 & (range13 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range13 | (i.shift13_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range13 | (i.shift13_1) in (range13 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range13 | some ((i.shift13_1).future13 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range13 | some ((i.shift13_1).future13 & (range13 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range13 | (i.shift13_1).future13 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range13 | (i.shift13_1).future13 in (range13 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range13 | (i.shift13_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range13 | (i.shift13_2) in (range13 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range13 | some ((i.shift13_2).future13 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range13 | some ((i.shift13_2).future13 & (range13 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range13 | (i.shift13_2).future13 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range13 | (i.shift13_2).future13 in (range13 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range13 | (i.shift13_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range13 | (i.shift13_3) in (range13 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range13 | some ((i.shift13_3).future13 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range13 | (i.shift13_3).future13 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range13 | (i.shift13_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range13 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next13.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range13 | some (i.future13 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range13 | i.future13 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range13 - left[a].ev) + right[a].ev)
}
fun range14: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop14: set Pos { P8 }
fun next14: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P8)))) }
fun future14: Pos -> Pos { (*next14) & (range14->range14) }
fun shift14_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift14_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P8)))) }
fun shift14_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P8 + P8->P8)))) }
fun shift14_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P8 + (P7->P8 + P8->P8)))) }
fun shift14_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P8) + (P6->P8 + (P7->P8 + P8->P8)))) }
pred semantics14[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range14
ev in used->range14
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range14 | (i.shift14_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range14 | (i.shift14_0) in (range14 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range14 | some ((i.shift14_0).future14 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range14 | some ((i.shift14_0).future14 & (range14 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range14 | (i.shift14_0).future14 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range14 | (i.shift14_0).future14 in (range14 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range14 | loop14 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range14 | loop14 in (range14 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range14 | some (loop14 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range14 | some (loop14 & (range14 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range14 | (i.shift14_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range14 | (i.shift14_1) in (range14 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range14 | some ((i.shift14_1).future14 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range14 | some ((i.shift14_1).future14 & (range14 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range14 | (i.shift14_1).future14 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range14 | (i.shift14_1).future14 in (range14 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range14 | (i.shift14_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range14 | (i.shift14_2) in (range14 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range14 | some ((i.shift14_2).future14 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range14 | some ((i.shift14_2).future14 & (range14 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range14 | (i.shift14_2).future14 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range14 | (i.shift14_2).future14 in (range14 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range14 | (i.shift14_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range14 | (i.shift14_3) in (range14 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range14 | some ((i.shift14_3).future14 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range14 | (i.shift14_3).future14 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range14 | (i.shift14_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range14 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next14.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range14 | some (i.future14 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range14 | i.future14 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range14 - left[a].ev) + right[a].ev)
}
fun range15: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop15: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun next15: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P0)))) }
fun future15: Pos -> Pos { (*next15) & (range15->range15) }
fun shift15_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift15_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P0)))) }
fun shift15_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P0 + P8->P1)))) }
fun shift15_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P0 + (P7->P1 + P8->P2)))) }
fun shift15_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P0) + (P6->P1 + (P7->P2 + P8->P3)))) }
pred semantics15[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range15
ev in used->range15
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range15 | (i.shift15_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range15 | (i.shift15_0) in (range15 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range15 | some ((i.shift15_0).future15 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range15 | some ((i.shift15_0).future15 & (range15 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range15 | (i.shift15_0).future15 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range15 | (i.shift15_0).future15 in (range15 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range15 | loop15 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range15 | loop15 in (range15 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range15 | some (loop15 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range15 | some (loop15 & (range15 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range15 | (i.shift15_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range15 | (i.shift15_1) in (range15 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range15 | some ((i.shift15_1).future15 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range15 | some ((i.shift15_1).future15 & (range15 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range15 | (i.shift15_1).future15 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range15 | (i.shift15_1).future15 in (range15 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range15 | (i.shift15_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range15 | (i.shift15_2) in (range15 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range15 | some ((i.shift15_2).future15 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range15 | some ((i.shift15_2).future15 & (range15 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range15 | (i.shift15_2).future15 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range15 | (i.shift15_2).future15 in (range15 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range15 | (i.shift15_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range15 | (i.shift15_3) in (range15 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range15 | some ((i.shift15_3).future15 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range15 | (i.shift15_3).future15 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range15 | (i.shift15_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range15 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next15.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range15 | some (i.future15 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range15 | i.future15 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range15 - left[a].ev) + right[a].ev)
}
fun range16: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop16: set Pos { ((P3 + (P4 + P5)) + (P6 + (P7 + P8))) }
fun next16: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P3)))) }
fun future16: Pos -> Pos { (*next16) & (range16->range16) }
fun shift16_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift16_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P3)))) }
fun shift16_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P3 + P8->P4)))) }
fun shift16_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P3 + (P7->P4 + P8->P5)))) }
fun shift16_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P3) + (P6->P4 + (P7->P5 + P8->P6)))) }
pred semantics16[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range16
ev in used->range16
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range16 | (i.shift16_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range16 | (i.shift16_0) in (range16 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range16 | some ((i.shift16_0).future16 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range16 | some ((i.shift16_0).future16 & (range16 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range16 | (i.shift16_0).future16 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range16 | (i.shift16_0).future16 in (range16 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range16 | loop16 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range16 | loop16 in (range16 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range16 | some (loop16 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range16 | some (loop16 & (range16 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range16 | (i.shift16_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range16 | (i.shift16_1) in (range16 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range16 | some ((i.shift16_1).future16 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range16 | some ((i.shift16_1).future16 & (range16 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range16 | (i.shift16_1).future16 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range16 | (i.shift16_1).future16 in (range16 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range16 | (i.shift16_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range16 | (i.shift16_2) in (range16 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range16 | some ((i.shift16_2).future16 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range16 | some ((i.shift16_2).future16 & (range16 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range16 | (i.shift16_2).future16 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range16 | (i.shift16_2).future16 in (range16 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range16 | (i.shift16_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range16 | (i.shift16_3) in (range16 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range16 | some ((i.shift16_3).future16 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range16 | (i.shift16_3).future16 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range16 | (i.shift16_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range16 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next16.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range16 | some (i.future16 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range16 | i.future16 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range16 - left[a].ev) + right[a].ev)
}
fun range17: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop17: set Pos { ((P4 + (P5 + P6)) + (P7 + (P8 + P9))) }
fun next17: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P4)))) }
fun future17: Pos -> Pos { (*next17) & (range17->range17) }
fun shift17_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift17_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P4)))) }
fun shift17_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P4 + P9->P5)))) }
fun shift17_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P4 + (P8->P5 + P9->P6)))) }
fun shift17_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P4) + (P7->P5 + (P8->P6 + P9->P7)))) }
pred semantics17[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range17
ev in used->range17
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range17 | (i.shift17_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range17 | (i.shift17_0) in (range17 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range17 | some ((i.shift17_0).future17 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range17 | some ((i.shift17_0).future17 & (range17 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range17 | (i.shift17_0).future17 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range17 | (i.shift17_0).future17 in (range17 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range17 | loop17 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range17 | loop17 in (range17 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range17 | some (loop17 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range17 | some (loop17 & (range17 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range17 | (i.shift17_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range17 | (i.shift17_1) in (range17 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range17 | some ((i.shift17_1).future17 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range17 | some ((i.shift17_1).future17 & (range17 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range17 | (i.shift17_1).future17 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range17 | (i.shift17_1).future17 in (range17 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range17 | (i.shift17_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range17 | (i.shift17_2) in (range17 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range17 | some ((i.shift17_2).future17 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range17 | some ((i.shift17_2).future17 & (range17 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range17 | (i.shift17_2).future17 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range17 | (i.shift17_2).future17 in (range17 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range17 | (i.shift17_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range17 | (i.shift17_3) in (range17 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range17 | some ((i.shift17_3).future17 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range17 | (i.shift17_3).future17 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range17 | (i.shift17_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range17 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next17.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range17 | some (i.future17 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range17 | i.future17 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range17 - left[a].ev) + right[a].ev)
}
fun range18: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop18: set Pos { P9 }
fun next18: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P9)))) }
fun future18: Pos -> Pos { (*next18) & (range18->range18) }
fun shift18_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift18_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P9)))) }
fun shift18_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P9 + P9->P9)))) }
fun shift18_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P9 + (P8->P9 + P9->P9)))) }
fun shift18_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P9) + (P7->P9 + (P8->P9 + P9->P9)))) }
pred semantics18[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range18
ev in used->range18
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range18 | (i.shift18_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range18 | (i.shift18_0) in (range18 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range18 | some ((i.shift18_0).future18 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range18 | some ((i.shift18_0).future18 & (range18 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range18 | (i.shift18_0).future18 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range18 | (i.shift18_0).future18 in (range18 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range18 | loop18 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range18 | loop18 in (range18 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range18 | some (loop18 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range18 | some (loop18 & (range18 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range18 | (i.shift18_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range18 | (i.shift18_1) in (range18 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range18 | some ((i.shift18_1).future18 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range18 | some ((i.shift18_1).future18 & (range18 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range18 | (i.shift18_1).future18 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range18 | (i.shift18_1).future18 in (range18 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range18 | (i.shift18_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range18 | (i.shift18_2) in (range18 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range18 | some ((i.shift18_2).future18 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range18 | some ((i.shift18_2).future18 & (range18 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range18 | (i.shift18_2).future18 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range18 | (i.shift18_2).future18 in (range18 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range18 | (i.shift18_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range18 | (i.shift18_3) in (range18 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range18 | some ((i.shift18_3).future18 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range18 | (i.shift18_3).future18 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range18 | (i.shift18_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range18 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next18.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range18 | some (i.future18 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range18 | i.future18 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range18 - left[a].ev) + right[a].ev)
}
fun range19: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop19: set Pos { (P7 + (P8 + P9)) }
fun next19: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P7)))) }
fun future19: Pos -> Pos { (*next19) & (range19->range19) }
fun shift19_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift19_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P7)))) }
fun shift19_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P7 + P9->P8)))) }
fun shift19_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift19_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P7) + (P7->P8 + (P8->P9 + P9->P7)))) }
pred semantics19[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range19
ev in used->range19
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range19 | (i.shift19_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range19 | (i.shift19_0) in (range19 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range19 | some ((i.shift19_0).future19 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range19 | some ((i.shift19_0).future19 & (range19 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range19 | (i.shift19_0).future19 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range19 | (i.shift19_0).future19 in (range19 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range19 | loop19 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range19 | loop19 in (range19 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range19 | some (loop19 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range19 | some (loop19 & (range19 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range19 | (i.shift19_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range19 | (i.shift19_1) in (range19 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range19 | some ((i.shift19_1).future19 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range19 | some ((i.shift19_1).future19 & (range19 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range19 | (i.shift19_1).future19 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range19 | (i.shift19_1).future19 in (range19 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range19 | (i.shift19_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range19 | (i.shift19_2) in (range19 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range19 | some ((i.shift19_2).future19 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range19 | some ((i.shift19_2).future19 & (range19 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range19 | (i.shift19_2).future19 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range19 | (i.shift19_2).future19 in (range19 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range19 | (i.shift19_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range19 | (i.shift19_3) in (range19 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range19 | some ((i.shift19_3).future19 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range19 | (i.shift19_3).future19 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range19 | (i.shift19_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range19 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next19.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range19 | some (i.future19 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range19 | i.future19 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range19 - left[a].ev) + right[a].ev)
}
fun range20: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) }
fun loop20: set Pos { ((P3 + P4) + (P5 + (P6 + P7))) }
fun next20: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P3))) }
fun future20: Pos -> Pos { (*next20) & (range20->range20) }
fun shift20_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) }
fun shift20_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P3))) }
fun shift20_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P3 + P7->P4))) }
fun shift20_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P3) + (P6->P4 + P7->P5))) }
fun shift20_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P3 + P5->P4) + (P6->P5 + P7->P6))) }
pred semantics20[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range20
ev in used->range20
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range20 | (i.shift20_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range20 | (i.shift20_0) in (range20 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range20 | some ((i.shift20_0).future20 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range20 | some ((i.shift20_0).future20 & (range20 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range20 | (i.shift20_0).future20 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range20 | (i.shift20_0).future20 in (range20 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range20 | loop20 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range20 | loop20 in (range20 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range20 | some (loop20 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range20 | some (loop20 & (range20 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range20 | (i.shift20_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range20 | (i.shift20_1) in (range20 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range20 | some ((i.shift20_1).future20 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range20 | some ((i.shift20_1).future20 & (range20 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range20 | (i.shift20_1).future20 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range20 | (i.shift20_1).future20 in (range20 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range20 | (i.shift20_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range20 | (i.shift20_2) in (range20 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range20 | some ((i.shift20_2).future20 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range20 | some ((i.shift20_2).future20 & (range20 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range20 | (i.shift20_2).future20 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range20 | (i.shift20_2).future20 in (range20 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range20 | (i.shift20_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range20 | (i.shift20_3) in (range20 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range20 | some ((i.shift20_3).future20 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range20 | (i.shift20_3).future20 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range20 | (i.shift20_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range20 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next20.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range20 | some (i.future20 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range20 | i.future20 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range20 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (none)
all a: lab.T1 | a.av0 = (((P1 + (P2 + P4)) + ((P5 + P6) + (P7 + P8))))
(R->P0 in ev0)
semantics1[av1, ev1]
all a: lab.T0 | a.av1 = (none)
all a: lab.T1 | a.av1 = (((P4 + P5) + (P6 + (P7 + P9))))
(R->P0 in ev1)
semantics2[av2, ev2]
all a: lab.T0 | a.av2 = (none)
all a: lab.T1 | a.av2 = (((P0 + P1) + (P2 + (P3 + P5))))
(R->P0 in ev2)
semantics3[av3, ev3]
all a: lab.T0 | a.av3 = (none)
all a: lab.T1 | a.av3 = (((P1 + P2) + (P8 + P9)))
(R->P0 in ev3)
semantics1[av4, ev4]
all a: lab.T0 | a.av4 = (none)
all a: lab.T1 | a.av4 = (((P3 + P4) + (P6 + (P8 + P9))))
(R->P0 in ev4)
semantics4[av5, ev5]
all a: lab.T0 | a.av5 = (none)
all a: lab.T1 | a.av5 = (((P0 + P1) + (P2 + P6)))
(R->P0 in ev5)
semantics5[av6, ev6]
all a: lab.T0 | a.av6 = (none)
all a: lab.T1 | a.av6 = ((P3 + P5))
(R->P0 in ev6)
semantics6[av7, ev7]
all a: lab.T0 | a.av7 = (((P0 + (P1 + P2)) + (P5 + (P6 + P9))))
all a: lab.T1 | a.av7 = ((P6 + (P8 + P9)))
not (R->P0 in ev7)
semantics1[av8, ev8]
all a: lab.T0 | a.av8 = (((P2 + (P3 + P6)) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av8 = ((P6 + P9))
not (R->P0 in ev8)
semantics7[av9, ev9]
all a: lab.T0 | a.av9 = (((P0 + P4) + (P5 + P8)))
all a: lab.T1 | a.av9 = (((P6 + P7) + (P8 + P9)))
not (R->P0 in ev9)
semantics8[av10, ev10]
all a: lab.T0 | a.av10 = (((P0 + P3) + (P4 + (P7 + P8))))
all a: lab.T1 | a.av10 = (((P0 + (P1 + P3)) + (P5 + (P6 + P8))))
not (R->P0 in ev10)
semantics9[av11, ev11]
all a: lab.T0 | a.av11 = (((P0 + (P2 + P5)) + (P6 + (P7 + P8))))
all a: lab.T1 | a.av11 = (((P0 + P3) + (P4 + (P5 + P7))))
not (R->P0 in ev11)
semantics10[av12, ev12]
all a: lab.T0 | a.av12 = (((P1 + P3) + (P4 + (P6 + P7))))
all a: lab.T1 | a.av12 = ((P8 + P9))
not (R->P0 in ev12)
semantics7[av13, ev13]
all a: lab.T0 | a.av13 = (((P4 + P5) + (P6 + (P7 + P9))))
all a: lab.T1 | a.av13 = (((P0 + P3) + (P4 + (P5 + P8))))
not (R->P0 in ev13)
semantics11[av14, ev14]
all a: lab.T0 | a.av14 = (((P0 + P2) + (P3 + (P4 + P8))))
all a: lab.T1 | a.av14 = (((P1 + P2) + (P4 + P7)))
not (R->P0 in ev14)
semantics7[av15, ev15]
all a: lab.T0 | a.av15 = (((P1 + P2) + (P4 + (P6 + P7))))
all a: lab.T1 | a.av15 = (((P1 + P2) + (P4 + (P5 + P6))))
not (R->P0 in ev15)
semantics10[av16, ev16]
all a: lab.T0 | a.av16 = (((P3 + P5) + (P7 + P8)))
all a: lab.T1 | a.av16 = (((P0 + (P2 + P3)) + (P4 + (P6 + P7))))
not (R->P0 in ev16)
semantics12[av17, ev17]
all a: lab.T0 | a.av17 = (((P0 + P1) + (P4 + P5)))
all a: lab.T1 | a.av17 = ((P0 + (P1 + P4)))
not (R->P0 in ev17)
semantics13[av18, ev18]
all a: lab.T0 | a.av18 = (((P0 + P1) + (P3 + (P6 + P8))))
all a: lab.T1 | a.av18 = (((P0 + P2) + (P3 + (P7 + P8))))
not (R->P0 in ev18)
semantics14[av19, ev19]
all a: lab.T0 | a.av19 = ((P2 + (P3 + P5)))
all a: lab.T1 | a.av19 = (((P0 + (P1 + P3)) + (P4 + (P6 + P8))))
not (R->P0 in ev19)
semantics10[av20, ev20]
all a: lab.T0 | a.av20 = (((P0 + P2) + (P3 + (P4 + P7))))
all a: lab.T1 | a.av20 = (((P2 + P3) + (P5 + (P6 + P8))))
not (R->P0 in ev20)
semantics15[av21, ev21]
all a: lab.T0 | a.av21 = (((P2 + P3) + (P4 + (P6 + P8))))
all a: lab.T1 | a.av21 = (((P0 + (P1 + P5)) + (P6 + (P7 + P8))))
not (R->P0 in ev21)
semantics8[av22, ev22]
all a: lab.T0 | a.av22 = (((P0 + P6) + (P8 + P9)))
all a: lab.T1 | a.av22 = (((P0 + P2) + (P5 + (P7 + P9))))
not (R->P0 in ev22)
semantics8[av23, ev23]
all a: lab.T0 | a.av23 = (((P0 + (P3 + P5)) + (P6 + (P7 + P8))))
all a: lab.T1 | a.av23 = (((P0 + P1) + (P2 + P6)))
not (R->P0 in ev23)
semantics10[av24, ev24]
all a: lab.T0 | a.av24 = ((P0 + (P3 + P7)))
all a: lab.T1 | a.av24 = (((P1 + P3) + (P4 + P9)))
not (R->P0 in ev24)
semantics16[av25, ev25]
all a: lab.T0 | a.av25 = ((P2 + P5))
all a: lab.T1 | a.av25 = (((P0 + P2) + (P3 + (P4 + P6))))
not (R->P0 in ev25)
semantics10[av26, ev26]
all a: lab.T0 | a.av26 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av26 = (((P0 + (P2 + P5)) + (P6 + (P7 + P8))))
not (R->P0 in ev26)
semantics17[av27, ev27]
all a: lab.T0 | a.av27 = (((P0 + (P1 + P2)) + (P3 + (P5 + P9))))
all a: lab.T1 | a.av27 = (((P0 + (P2 + P3)) + ((P5 + P6) + (P7 + P8))))
not (R->P0 in ev27)
semantics10[av28, ev28]
all a: lab.T0 | a.av28 = (((P0 + (P2 + P3)) + (P5 + (P6 + P8))))
all a: lab.T1 | a.av28 = (((P1 + P2) + (P3 + (P5 + P6))))
not (R->P0 in ev28)
semantics17[av29, ev29]
all a: lab.T0 | a.av29 = ((P0 + (P6 + P7)))
all a: lab.T1 | a.av29 = (((P1 + P3) + (P5 + (P6 + P7))))
not (R->P0 in ev29)
semantics3[av30, ev30]
all a: lab.T0 | a.av30 = (((P1 + P2) + (P3 + (P4 + P7))))
all a: lab.T1 | a.av30 = (((P5 + P6) + (P8 + P9)))
not (R->P0 in ev30)
semantics10[av31, ev31]
all a: lab.T0 | a.av31 = (((P2 + (P3 + P4)) + (P5 + (P7 + P8))))
all a: lab.T1 | a.av31 = (((P0 + (P1 + P2)) + ((P3 + P5) + (P8 + P9))))
not (R->P0 in ev31)
semantics7[av32, ev32]
all a: lab.T0 | a.av32 = (((P3 + P6) + (P7 + P9)))
all a: lab.T1 | a.av32 = (((P0 + (P1 + P2)) + (P3 + (P4 + P8))))
not (R->P0 in ev32)
semantics10[av33, ev33]
all a: lab.T0 | a.av33 = ((P2 + (P7 + P8)))
all a: lab.T1 | a.av33 = (((P1 + P3) + (P4 + P6)))
not (R->P0 in ev33)
semantics14[av34, ev34]
all a: lab.T0 | a.av34 = ((P0 + (P5 + P7)))
all a: lab.T1 | a.av34 = (((P0 + (P2 + P4)) + (P5 + (P6 + P7))))
not (R->P0 in ev34)
semantics18[av35, ev35]
all a: lab.T0 | a.av35 = (((P0 + (P3 + P4)) + (P5 + (P6 + P8))))
all a: lab.T1 | a.av35 = (((P1 + (P2 + P5)) + ((P6 + P7) + (P8 + P9))))
not (R->P0 in ev35)
semantics7[av36, ev36]
all a: lab.T0 | a.av36 = (((P2 + P3) + (P6 + (P8 + P9))))
all a: lab.T1 | a.av36 = (((P0 + P5) + (P6 + (P7 + P8))))
not (R->P0 in ev36)
semantics19[av37, ev37]
all a: lab.T0 | a.av37 = (((P0 + P2) + (P4 + (P8 + P9))))
all a: lab.T1 | a.av37 = ((P0 + (P4 + P5)))
not (R->P0 in ev37)
semantics8[av38, ev38]
all a: lab.T0 | a.av38 = (((P2 + P3) + (P8 + P9)))
all a: lab.T1 | a.av38 = (((P0 + (P2 + P3)) + ((P4 + P5) + (P6 + P7))))
not (R->P0 in ev38)
semantics19[av39, ev39]
all a: lab.T0 | a.av39 = (((P0 + (P1 + P2)) + ((P3 + P6) + (P7 + P8))))
all a: lab.T1 | a.av39 = (((P0 + P7) + (P8 + P9)))
not (R->P0 in ev39)
semantics19[av40, ev40]
all a: lab.T0 | a.av40 = (((P3 + P5) + (P6 + P7)))
all a: lab.T1 | a.av40 = (((P0 + (P2 + P5)) + ((P6 + P7) + (P8 + P9))))
not (R->P0 in ev40)
semantics19[av41, ev41]
all a: lab.T0 | a.av41 = ((P0 + (P2 + P7)))
all a: lab.T1 | a.av41 = (((P2 + P3) + (P5 + (P6 + P7))))
not (R->P0 in ev41)
semantics3[av42, ev42]
all a: lab.T0 | a.av42 = ((P0 + (P5 + P9)))
all a: lab.T1 | a.av42 = (((P2 + P6) + (P7 + (P8 + P9))))
not (R->P0 in ev42)
semantics7[av43, ev43]
all a: lab.T0 | a.av43 = ((P2 + (P3 + P9)))
all a: lab.T1 | a.av43 = ((P2 + (P6 + P7)))
not (R->P0 in ev43)
semantics8[av44, ev44]
all a: lab.T0 | a.av44 = (((P0 + P1) + (P3 + P8)))
all a: lab.T1 | a.av44 = (((P1 + P3) + (P5 + (P8 + P9))))
not (R->P0 in ev44)
semantics18[av45, ev45]
all a: lab.T0 | a.av45 = (((P0 + (P1 + P2)) + (P3 + (P5 + P7))))
all a: lab.T1 | a.av45 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P9))))
not (R->P0 in ev45)
semantics1[av46, ev46]
all a: lab.T0 | a.av46 = (((P0 + P4) + (P5 + (P6 + P9))))
all a: lab.T1 | a.av46 = ((((P1 + P2) + (P3 + P4)) + ((P5 + P7) + (P8 + P9))))
not (R->P0 in ev46)
semantics8[av47, ev47]
all a: lab.T0 | a.av47 = (((P2 + P7) + (P8 + P9)))
all a: lab.T1 | a.av47 = (((P0 + (P1 + P3)) + (P4 + (P6 + P7))))
not (R->P0 in ev47)
semantics8[av48, ev48]
all a: lab.T0 | a.av48 = (((P1 + (P4 + P5)) + ((P6 + P7) + (P8 + P9))))
all a: lab.T1 | a.av48 = (((P1 + P3) + (P6 + P7)))
not (R->P0 in ev48)
semantics14[av49, ev49]
all a: lab.T0 | a.av49 = (((P0 + (P1 + P2)) + ((P3 + P4) + (P6 + P8))))
all a: lab.T1 | a.av49 = (((P0 + P3) + (P4 + P5)))
not (R->P0 in ev49)
semantics19[av50, ev50]
all a: lab.T0 | a.av50 = (((P0 + (P2 + P3)) + (P5 + (P6 + P7))))
all a: lab.T1 | a.av50 = (none)
not (R->P0 in ev50)
semantics10[av51, ev51]
all a: lab.T0 | a.av51 = (((P1 + (P3 + P4)) + ((P5 + P6) + (P7 + P8))))
all a: lab.T1 | a.av51 = ((((P0 + P1) + (P3 + P4)) + ((P5 + P7) + (P8 + P9))))
not (R->P0 in ev51)
semantics8[av52, ev52]
all a: lab.T0 | a.av52 = (((P2 + P5) + (P6 + P8)))
all a: lab.T1 | a.av52 = (((P3 + (P4 + P5)) + (P6 + (P8 + P9))))
not (R->P0 in ev52)
semantics17[av53, ev53]
all a: lab.T0 | a.av53 = (((P1 + (P2 + P3)) + (P4 + (P6 + P8))))
all a: lab.T1 | a.av53 = (((P1 + P3) + (P4 + (P5 + P7))))
not (R->P0 in ev53)
semantics0[av54, ev54]
all a: lab.T0 | a.av54 = (((P1 + (P2 + P3)) + (P5 + (P6 + P7))))
all a: lab.T1 | a.av54 = (((P1 + (P2 + P3)) + (P4 + (P7 + P8))))
not (R->P0 in ev54)
semantics17[av55, ev55]
all a: lab.T0 | a.av55 = (((P0 + P3) + (P4 + (P6 + P7))))
all a: lab.T1 | a.av55 = (((P0 + (P3 + P4)) + ((P5 + P6) + (P8 + P9))))
not (R->P0 in ev55)
semantics3[av56, ev56]
all a: lab.T0 | a.av56 = (((P1 + P2) + (P4 + P6)))
all a: lab.T1 | a.av56 = (((P1 + (P3 + P6)) + (P7 + (P8 + P9))))
not (R->P0 in ev56)
semantics20[av57, ev57]
all a: lab.T0 | a.av57 = (((P1 + P2) + (P3 + P7)))
all a: lab.T1 | a.av57 = (((P0 + P1) + (P3 + P7)))
not (R->P0 in ev57)
semantics17[av58, ev58]
all a: lab.T0 | a.av58 = (((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P9))))
all a: lab.T1 | a.av58 = (((P0 + P1) + (P5 + (P6 + P9))))
not (R->P0 in ev58)
semantics18[av59, ev59]
all a: lab.T0 | a.av59 = ((P1 + (P5 + P9)))
all a: lab.T1 | a.av59 = (((P0 + P3) + (P4 + (P6 + P8))))
not (R->P0 in ev59)
semantics19[av60, ev60]
all a: lab.T0 | a.av60 = ((P4 + (P6 + P9)))
all a: lab.T1 | a.av60 = ((P7 + (P8 + P9)))
not (R->P0 in ev60)
semantics10[av61, ev61]
all a: lab.T0 | a.av61 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P6) + (P7 + P9))))
all a: lab.T1 | a.av61 = (((P1 + (P3 + P6)) + (P7 + (P8 + P9))))
not (R->P0 in ev61)
semantics6[av62, ev62]
all a: lab.T0 | a.av62 = (((P2 + P3) + (P4 + (P7 + P8))))
all a: lab.T1 | a.av62 = ((P4 + (P6 + P9)))
not (R->P0 in ev62)
semantics3[av63, ev63]
all a: lab.T0 | a.av63 = ((P6 + (P8 + P9)))
all a: lab.T1 | a.av63 = ((P6 + (P7 + P9)))
not (R->P0 in ev63)
semantics17[av64, ev64]
all a: lab.T0 | a.av64 = ((((P1 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + P9))))
all a: lab.T1 | a.av64 = (((P0 + (P1 + P2)) + (P4 + (P8 + P9))))
not (R->P0 in ev64)
semantics0[av65, ev65]
all a: lab.T0 | a.av65 = (((P0 + P2) + (P6 + P8)))
all a: lab.T1 | a.av65 = (((P0 + P4) + (P5 + (P6 + P7))))
not (R->P0 in ev65)
semantics11[av66, ev66]
all a: lab.T0 | a.av66 = ((P0 + (P1 + P5)))
all a: lab.T1 | a.av66 = (((P0 + (P3 + P4)) + (P5 + (P6 + P7))))
not (R->P0 in ev66)
semantics1[av67, ev67]
all a: lab.T0 | a.av67 = (((P1 + (P3 + P4)) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av67 = (((P0 + (P1 + P2)) + (P4 + (P5 + P7))))
not (R->P0 in ev67)
semantics8[av68, ev68]
all a: lab.T0 | a.av68 = (((P1 + P4) + (P5 + (P6 + P9))))
all a: lab.T1 | a.av68 = (((P0 + P3) + (P7 + P9)))
not (R->P0 in ev68)
semantics18[av69, ev69]
all a: lab.T0 | a.av69 = (((P0 + P1) + (P3 + (P6 + P9))))
all a: lab.T1 | a.av69 = (((P0 + P3) + (P4 + P7)))
not (R->P0 in ev69)
semantics18[av70, ev70]
all a: lab.T0 | a.av70 = (((P1 + (P3 + P4)) + (P5 + (P6 + P8))))
all a: lab.T1 | a.av70 = (((P1 + P4) + (P5 + P7)))
not (R->P0 in ev70)
semantics10[av71, ev71]
all a: lab.T0 | a.av71 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av71 = (((P0 + (P1 + P4)) + (P5 + (P6 + P9))))
not (R->P0 in ev71)
semantics18[av72, ev72]
all a: lab.T0 | a.av72 = (P6)
all a: lab.T1 | a.av72 = (((P1 + (P3 + P4)) + (P5 + (P7 + P8))))
not (R->P0 in ev72)
semantics3[av73, ev73]
all a: lab.T0 | a.av73 = (((P3 + P4) + (P5 + P7)))
all a: lab.T1 | a.av73 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P6) + (P7 + P8))))
not (R->P0 in ev73)
semantics1[av74, ev74]
all a: lab.T0 | a.av74 = (((P1 + (P2 + P3)) + (P5 + (P7 + P9))))
all a: lab.T1 | a.av74 = (((P0 + (P1 + P2)) + ((P3 + P5) + (P6 + P8))))
not (R->P0 in ev74)
semantics9[av75, ev75]
all a: lab.T0 | a.av75 = (((P1 + P2) + (P4 + (P6 + P7))))
all a: lab.T1 | a.av75 = (((P0 + P1) + (P3 + (P6 + P7))))
not (R->P0 in ev75)
semantics19[av76, ev76]
all a: lab.T0 | a.av76 = (((P2 + P5) + (P6 + (P7 + P9))))
all a: lab.T1 | a.av76 = (((P0 + P3) + (P5 + (P7 + P9))))
not (R->P0 in ev76)
semantics3[av77, ev77]
all a: lab.T0 | a.av77 = ((P6 + (P7 + P8)))
all a: lab.T1 | a.av77 = (((P1 + P3) + (P4 + P8)))
not (R->P0 in ev77)
semantics17[av78, ev78]
all a: lab.T0 | a.av78 = (((P0 + P1) + (P2 + (P4 + P5))))
all a: lab.T1 | a.av78 = (((P1 + P6) + (P7 + P9)))
not (R->P0 in ev78)
semantics8[av79, ev79]
all a: lab.T0 | a.av79 = (((P0 + P4) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av79 = (((P0 + (P3 + P4)) + ((P5 + P7) + (P8 + P9))))
not (R->P0 in ev79)
semantics1[av80, ev80]
all a: lab.T0 | a.av80 = (((P0 + (P2 + P3)) + (P6 + (P8 + P9))))
all a: lab.T1 | a.av80 = (((P0 + P1) + (P4 + (P5 + P7))))
not (R->P0 in ev80)
semantics0[av81, ev81]
all a: lab.T0 | a.av81 = (((P2 + P3) + (P4 + (P6 + P8))))
all a: lab.T1 | a.av81 = (((P2 + (P3 + P4)) + (P6 + (P7 + P9))))
not (R->P0 in ev81)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int

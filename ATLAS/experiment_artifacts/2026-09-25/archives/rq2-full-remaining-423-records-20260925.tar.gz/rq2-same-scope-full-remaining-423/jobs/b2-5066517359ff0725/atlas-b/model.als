open util/ordering[SeqIdx]

abstract sig DAGNode {
	l: set DAGNode,
	r: set DAGNode
}
fact {
	all n: DAGNode | n not in n.^(l + r)
}

sig And, Or, Imply extends DAGNode {} {
	one l
	one r
}

sig Neg, F, G, X extends DAGNode {} {
    one l
    no r
}
abstract sig Literal extends DAGNode {} {
	no l
	no r
}

abstract sig SeqIdx {}
abstract sig Trace {
	lasso: SeqIdx -> SeqIdx,
	valuation: DAGNode -> SeqIdx
} {
	// Negation
    all n: Neg, i: seqRange | n->i in valuation iff n.l->i not in valuation
	// Or
    all n: Or, i: seqRange | n->i in valuation iff (n.l->i in valuation or n.r->i in valuation)
	// And
    all n: And, i: seqRange | n->i in valuation iff (n.l->i in valuation and n.r->i in valuation)
	// Imply
    all n: Imply, i: seqRange | n->i in valuation iff (n.l->i not in valuation or n.r->i in valuation)
	// G
    all n: G, i: seqRange | n->i in valuation iff all i': futureIdx[i] | n.l->i' in valuation
    // X
    all n: X, i: seqRange | n->i in valuation iff n.l->i.((next :> seqRange) + lasso) in valuation
	// F
    all n: F, i: seqRange | n->i in valuation iff some i': futureIdx[i] | n.l->i' in valuation
	// Until
    
}
fun seqRange[t: Trace]: set SeqIdx {
	let lastOfTrace = t.lasso.SeqIdx | lastOfTrace.prevs + lastOfTrace
}
fun futureIdx[t: Trace, i: SeqIdx]: set SeqIdx {
	i.^((next :> seqRange[t]) + t.lasso) + i
}
abstract sig PositiveTrace extends Trace {}
abstract sig NegativeTrace extends Trace {}
one sig x0, x1, x2 extends Literal {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9 extends SeqIdx {}
fact {
    first = T0
    next = T0->T1 + T1->T2 + T2->T3 + T3->T4 + T4->T5 + T5->T6 + T6->T7 + T7->T8 + T8->T9
}

one sig PT0 extends PositiveTrace {} {
    lasso = T9->T5
    x0->T0 + x2->T0 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T6 + x1->T8 + x1->T9 + x2->T9 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x0->T5 + x2->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9) & valuation
}

one sig PT1 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x2->T6 + x2->T8 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}


one sig NT0 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x0->T3 + x2->T4 + x0->T5 + x1->T5 + x0->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x1->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T5 + x1->T6 + x2->T6 + x0->T9 + x2->T9) & valuation
}

one sig NT1 extends NegativeTrace {} {
    lasso = T9->T5
    x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T4 + x2->T4 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x1->T8 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T3 + x2->T3 + x0->T4 + x0->T5 + x1->T5 + x1->T6 + x1->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig NT2 extends NegativeTrace {} {
    lasso = T9->T3
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T1 + x2->T1 + x0->T3 + x2->T3 + x1->T4 + x2->T4 + x0->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8) & valuation
}

one sig NT3 extends NegativeTrace {} {
    lasso = T9->T9
    x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T7 + x1->T7 + x0->T8 + x0->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x2->T7 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT4 extends NegativeTrace {} {
    lasso = T9->T9
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T3 + x2->T3 + x1->T4 + x0->T5 + x2->T5 + x2->T6 + x1->T9 + x2->T9 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9) & valuation
}

one sig LearnedLTL {
    Root: DAGNode
}
fun root: one DAGNode { LearnedLTL.Root }
fun childrenOf[n: DAGNode]: set DAGNode { n.^(l+r) }
fun childrenAndSelfOf[n: DAGNode]: set DAGNode { n.*(l+r) }
fun ancestorsOf[n: DAGNode]: set DAGNode { n.~^(l+r) }
fun ancestorsAndSelfOf[n: DAGNode]: set DAGNode { n.~*(l+r) }
fun subDAG[n: DAGNode]: DAGNode -> DAGNode { n.*(l+r) <: (l+r) }



fun experimentReach: set DAGNode { childrenAndSelfOf[root] }
fun experimentKept: DAGNode -> DAGNode { (none->none) & subDAG[root] }
one sig ExperimentCost { used: set DAGNode }
fact { ExperimentCost.used = experimentReach }
fact ExperimentBounds {
  DAGNode = experimentReach + Literal + (none)
  #experimentReach <= 5
  #(experimentReach & (And + Or + Imply)) <= 2
  minsome ExperimentCost.used
}
run {
    all t: PositiveTrace | root->T0 in t.valuation
    all t: NegativeTrace | root->T0 not in t.valuation
    
} for 8 DAGNode, 5 Int
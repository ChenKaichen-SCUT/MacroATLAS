abstract sig Unit {}
one sig U0, U1, U2, U3, U4, U5, U6, U7, U8, U9, U10, U11, U12, U13, U14 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9 extends Label {}
abstract sig Q {}
one sig Q0 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E26, E27, E28, E29, E30, E31, E32, E33, E34, E35, E36, E37, E38, E39, E40, E41, E42, E43, E44, E45, E46, E47, E48, E49 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos, av20: set Pos, av21: set Pos, av22: set Pos, av23: set Pos, av24: set Pos, av25: set Pos, av26: set Pos, av27: set Pos, av28: set Pos, av29: set Pos, av30: set Pos, av31: set Pos, av32: set Pos, av33: set Pos, av34: set Pos, av35: set Pos, av36: set Pos, av37: set Pos, av38: set Pos, av39: set Pos, av40: set Pos, av41: set Pos, av42: set Pos, av43: set Pos, av44: set Pos, av45: set Pos, av46: set Pos, av47: set Pos, av48: set Pos, av49: set Pos, av50: set Pos, av51: set Pos, av52: set Pos, av53: set Pos, av54: set Pos, av55: set Pos, av56: set Pos, av57: set Pos, av58: set Pos, av59: set Pos, av60: set Pos, av61: set Pos, av62: set Pos, av63: set Pos, av64: set Pos, av65: set Pos, av66: set Pos, av67: set Pos, av68: set Pos, av69: set Pos, av70: set Pos, av71: set Pos, av72: set Pos, av73: set Pos, av74: set Pos, av75: set Pos, av76: set Pos, av77: set Pos, av78: set Pos, av79: set Pos, av80: set Pos, av81: set Pos, av82: set Pos, av83: set Pos, av84: set Pos, av85: set Pos, av86: set Pos, av87: set Pos, av88: set Pos, av89: set Pos, av90: set Pos, av91: set Pos, av92: set Pos, av93: set Pos, av94: set Pos, av95: set Pos, av96: set Pos, av97: set Pos, av98: set Pos, av99: set Pos }
one sig A0, A1, A2, A3, A4, A5, A6, A7 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos, ev20: set Pos, ev21: set Pos, ev22: set Pos, ev23: set Pos, ev24: set Pos, ev25: set Pos, ev26: set Pos, ev27: set Pos, ev28: set Pos, ev29: set Pos, ev30: set Pos, ev31: set Pos, ev32: set Pos, ev33: set Pos, ev34: set Pos, ev35: set Pos, ev36: set Pos, ev37: set Pos, ev38: set Pos, ev39: set Pos, ev40: set Pos, ev41: set Pos, ev42: set Pos, ev43: set Pos, ev44: set Pos, ev45: set Pos, ev46: set Pos, ev47: set Pos, ev48: set Pos, ev49: set Pos, ev50: set Pos, ev51: set Pos, ev52: set Pos, ev53: set Pos, ev54: set Pos, ev55: set Pos, ev56: set Pos, ev57: set Pos, ev58: set Pos, ev59: set Pos, ev60: set Pos, ev61: set Pos, ev62: set Pos, ev63: set Pos, ev64: set Pos, ev65: set Pos, ev66: set Pos, ev67: set Pos, ev68: set Pos, ev69: set Pos, ev70: set Pos, ev71: set Pos, ev72: set Pos, ev73: set Pos, ev74: set Pos, ev75: set Pos, ev76: set Pos, ev77: set Pos, ev78: set Pos, ev79: set Pos, ev80: set Pos, ev81: set Pos, ev82: set Pos, ev83: set Pos, ev84: set Pos, ev85: set Pos, ev86: set Pos, ev87: set Pos, ev88: set Pos, ev89: set Pos, ev90: set Pos, ev91: set Pos, ev92: set Pos, ev93: set Pos, ev94: set Pos, ev95: set Pos, ev96: set Pos, ev97: set Pos, ev98: set Pos, ev99: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4, C5, L5, D5, C6, L6, D6, C7, L7, D7 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (T0 + (T1 + T2)) }
fun un: set Label { ((T3 + T4) + (T5 + T6)) }
fun bin: set Label { (T7 + (T8 + T9)) }
fun nonempty: set Fiber { (((((E1 + (E2 + E3)) + (E4 + (E5 + E6))) + ((E7 + (E8 + E9)) + (E10 + (E11 + E12)))) + (((E13 + (E14 + E15)) + (E16 + (E17 + E18))) + ((E19 + (E20 + E21)) + (E22 + (E23 + E24))))) + ((((E25 + (E26 + E27)) + (E28 + (E29 + E30))) + ((E31 + (E32 + E33)) + (E34 + (E35 + E36)))) + (((E37 + (E38 + E39)) + (E40 + (E41 + E42))) + ((E43 + (E44 + E45)) + ((E46 + E47) + (E48 + E49)))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { (((U0->U1 + (U1->U2 + U2->U3)) + ((U3->U4 + U4->U5) + (U5->U6 + U6->U7))) + ((U7->U8 + (U8->U9 + U9->U10)) + ((U10->U11 + U11->U12) + (U12->U13 + U13->U14)))) }
fun carrierNext: Carrier -> Carrier { (((((A0->A1 + A1->A2) + (A2->A3 + A3->A4)) + ((A4->A5 + A5->A6) + (A6->A7 + A7->R))) + (((R->C0 + C0->L0) + (L0->D0 + D0->C1)) + ((C1->L1 + L1->D1) + (D1->C2 + C2->L2)))) + ((((L2->D2 + D2->C3) + (C3->L3 + L3->D3)) + ((D3->C4 + C4->L4) + (L4->D4 + D4->C5))) + (((C5->L5 + L5->D5) + (D5->C6 + C6->L6)) + ((L6->D6 + D6->C7) + (C7->L7 + L7->D7))))) }
fun child[a: Anchor]: set Port { a.((((A0->C0 + A1->C1) + (A2->C2 + A3->C3)) + ((A4->C4 + A5->C5) + (A6->C6 + A7->C7)))) }
fun left[a: Anchor]: set Port { a.((((A0->L0 + A1->L1) + (A2->L2 + A3->L3)) + ((A4->L4 + A5->L5) + (A6->L6 + A7->L7)))) }
fun right[a: Anchor]: set Port { a.((((A0->D0 + A1->D1) + (A2->D2 + A3->D3)) + ((A4->D4 + A5->D5) + (A6->D6 + A7->D7)))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
C5.src = A5
L5.src = A5
D5.src = A5
(some C5.target iff A5.lab in un and some A5.lab)
(some L5.target iff A5.lab in bin and some A5.lab)
(some D5.target iff A5.lab in bin and some A5.lab)
C6.src = A6
L6.src = A6
D6.src = A6
(some C6.target iff A6.lab in un and some A6.lab)
(some L6.target iff A6.lab in bin and some A6.lab)
(some D6.target iff A6.lab in bin and some A6.lab)
C7.src = A7
L7.src = A7
D7.src = A7
(some C7.target iff A7.lab in un and some A7.lab)
(some L7.target iff A7.lab in bin and some A7.lab)
(some D7.target iff A7.lab in bin and some A7.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
no A3.graph & (((A0 + A1) + (A2 + A3)))
no A4.graph & (((A0 + A1) + (A2 + (A3 + A4))))
no A5.graph & (((A0 + (A1 + A2)) + (A3 + (A4 + A5))))
no A6.graph & (((A0 + (A1 + A2)) + ((A3 + A4) + (A5 + A6))))
no A7.graph & ((((A0 + A1) + (A2 + A3)) + ((A4 + A5) + (A6 + A7))))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
lone lab.T2
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un implies #(target.A2) > 1
some A2.lab implies some A1.lab
some A3.lab and A3.lab in un implies #(target.A3) > 1
some A3.lab implies some A2.lab
some A4.lab and A4.lab in un implies #(target.A4) > 1
some A4.lab implies some A3.lab
some A5.lab and A5.lab in un implies #(target.A5) > 1
some A5.lab implies some A4.lab
some A6.lab and A6.lab in un implies #(target.A6) > 1
some A6.lab implies some A5.lab
some A7.lab and A7.lab in un implies #(target.A7) > 1
some A7.lab implies some A6.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q0
E7.qo = Q0
E8.qi = Q0
E8.qo = Q0
E9.qi = Q0
E9.qo = Q0
E10.qi = Q0
E10.qo = Q0
E11.qi = Q0
E11.qo = Q0
E12.qi = Q0
E12.qo = Q0
E13.qi = Q0
E13.qo = Q0
E14.qi = Q0
E14.qo = Q0
E15.qi = Q0
E15.qo = Q0
E16.qi = Q0
E16.qo = Q0
E17.qi = Q0
E17.qo = Q0
E18.qi = Q0
E18.qo = Q0
E19.qi = Q0
E19.qo = Q0
E20.qi = Q0
E20.qo = Q0
E21.qi = Q0
E21.qo = Q0
E22.qi = Q0
E22.qo = Q0
E23.qi = Q0
E23.qo = Q0
E24.qi = Q0
E24.qo = Q0
E25.qi = Q0
E25.qo = Q0
E26.qi = Q0
E26.qo = Q0
E27.qi = Q0
E27.qo = Q0
E28.qi = Q0
E28.qo = Q0
E29.qi = Q0
E29.qo = Q0
E30.qi = Q0
E30.qo = Q0
E31.qi = Q0
E31.qo = Q0
E32.qi = Q0
E32.qo = Q0
E33.qi = Q0
E33.qo = Q0
E34.qi = Q0
E34.qo = Q0
E35.qi = Q0
E35.qo = Q0
E36.qi = Q0
E36.qo = Q0
E37.qi = Q0
E37.qo = Q0
E38.qi = Q0
E38.qo = Q0
E39.qi = Q0
E39.qo = Q0
E40.qi = Q0
E40.qo = Q0
E41.qi = Q0
E41.qo = Q0
E42.qi = Q0
E42.qo = Q0
E43.qi = Q0
E43.qo = Q0
E44.qi = Q0
E44.qo = Q0
E45.qi = Q0
E45.qo = Q0
E46.qi = Q0
E46.qo = Q0
E47.qi = Q0
E47.qo = Q0
E48.qi = Q0
E48.qo = Q0
E49.qi = Q0
E49.qo = Q0
all e: used | e.fiber in (E0) implies #e.cost = 0
all e: used | e.fiber in ((((E1 + E4) + (E6 + E7)) + ((E9 + E12) + (E13 + (E15 + E17))))) implies #e.cost = 2
all e: used | e.fiber in (((E2 + E3) + (E5 + E11))) implies #e.cost = 1
all e: used | e.fiber in ((((E8 + E10) + (E14 + E16)) + ((E18 + E19) + (E21 + E23)))) implies #e.cost = 3
all e: used | e.fiber in (((E20 + (E22 + E24)) + (E25 + (E27 + E29)))) implies #e.cost = 4
all e: used | e.fiber in (((E26 + E28) + (E30 + E31))) implies #e.cost = 5
all e: used | e.fiber in ((E32 + E33)) implies #e.cost = 6
all e: used | e.fiber in ((E34 + E35)) implies #e.cost = 7
all e: used | e.fiber in ((E36 + E37)) implies #e.cost = 8
all e: used | e.fiber in ((E38 + E39)) implies #e.cost = 9
all e: used | e.fiber in ((E40 + E41)) implies #e.cost = 10
all e: used | e.fiber in ((E42 + E43)) implies #e.cost = 11
all e: used | e.fiber in ((E44 + E45)) implies #e.cost = 12
all e: used | e.fiber in ((E46 + E47)) implies #e.cost = 13
all e: used | e.fiber in ((E48 + E49)) implies #e.cost = 14
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q0)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 implies a.state = Q0
all a: active | a.lab = T3 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T4 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T5 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T6 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T8 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T9 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
}
fun range0: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop0: set Pos { (P2 + (P3 + P4)) }
fun next0: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift0_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun shift0_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P2 + P4->P3))) }
fun shift0_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift0_4: Pos -> Pos { ((P0->P4 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range0 | loop0 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range0 | loop0 in (range0 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range0 | some (loop0 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range0 | some (loop0 & (range0 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range0 | (i.shift0_1) in (range0 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range0 | (i.shift0_1).future0 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range0 | (i.shift0_1).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (((E17 + E31) + (E37 + (E43 + E49)))) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all e: used | e.fiber in (((E18 + E32) + (E38 + E44))) implies e.ev = {i: range0 | (i.shift0_2) in (range0 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range0 | (i.shift0_2).future0 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range0 | (i.shift0_2).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (((E23 + E33) + (E39 + E45))) implies e.ev = {i: range0 | (i.shift0_3) in (e.target.av)}
all e: used | e.fiber in (((E24 + E34) + (E40 + E46))) implies e.ev = {i: range0 | (i.shift0_3) in (range0 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range0 | some ((i.shift0_3).future0 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range0 | some ((i.shift0_3).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range0 | (i.shift0_3).future0 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range0 | (i.shift0_3).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (((E29 + E35) + (E41 + E47))) implies e.ev = {i: range0 | (i.shift0_4) in (e.target.av)}
all e: used | e.fiber in (((E30 + E36) + (E42 + E48))) implies e.ev = {i: range0 | (i.shift0_4) in (range0 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next0.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop1: set Pos { ((P1 + P2) + (P3 + P4)) }
fun next1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift1_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun shift1_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P1 + P4->P2))) }
fun shift1_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P1 + (P3->P2 + P4->P3))) }
fun shift1_4: Pos -> Pos { ((P0->P4 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range1 | loop1 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range1 | loop1 in (range1 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range1 | some (loop1 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range1 | some (loop1 & (range1 - e.target.av))}
all e: used | e.fiber in (((E11 + E31) + (E39 + E47))) implies e.ev = {i: range1 | (i.shift1_1) in (e.target.av)}
all e: used | e.fiber in (((E12 + E32) + (E40 + E48))) implies e.ev = {i: range1 | (i.shift1_1) in (range1 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range1 | (i.shift1_1).future1 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range1 | (i.shift1_1).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (((E17 + E33) + (E41 + E49))) implies e.ev = {i: range1 | (i.shift1_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + (E34 + E42))) implies e.ev = {i: range1 | (i.shift1_2) in (range1 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range1 | (i.shift1_2).future1 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range1 | (i.shift1_2).future1 in (range1 - e.target.av)}
all e: used | e.fiber in ((E23 + (E35 + E43))) implies e.ev = {i: range1 | (i.shift1_3) in (e.target.av)}
all e: used | e.fiber in ((E24 + (E36 + E44))) implies e.ev = {i: range1 | (i.shift1_3) in (range1 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range1 | some ((i.shift1_3).future1 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range1 | some ((i.shift1_3).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range1 | (i.shift1_3).future1 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range1 | (i.shift1_3).future1 in (range1 - e.target.av)}
all e: used | e.fiber in ((E29 + (E37 + E45))) implies e.ev = {i: range1 | (i.shift1_4) in (e.target.av)}
all e: used | e.fiber in ((E30 + (E38 + E46))) implies e.ev = {i: range1 | (i.shift1_4) in (range1 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next1.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fun range2: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop2: set Pos { (P3 + P4) }
fun next2: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift2_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun shift2_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P3 + P4->P4))) }
fun shift2_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P3 + (P3->P4 + P4->P3))) }
fun shift2_4: Pos -> Pos { ((P0->P4 + P1->P3) + (P2->P4 + (P3->P3 + P4->P4))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range2 | (i.shift2_0) in (range2 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range2 | (i.shift2_0).future2 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range2 | (i.shift2_0).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range2 | loop2 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range2 | loop2 in (range2 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range2 | some (loop2 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range2 | some (loop2 & (range2 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range2 | (i.shift2_1) in (range2 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range2 | (i.shift2_1).future2 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range2 | (i.shift2_1).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range2 | (i.shift2_2) in (range2 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range2 | (i.shift2_2).future2 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range2 | (i.shift2_2).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (((E23 + (E31 + E35)) + (E39 + (E43 + E47)))) implies e.ev = {i: range2 | (i.shift2_3) in (e.target.av)}
all e: used | e.fiber in (((E24 + (E32 + E36)) + (E40 + (E44 + E48)))) implies e.ev = {i: range2 | (i.shift2_3) in (range2 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range2 | some ((i.shift2_3).future2 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range2 | some ((i.shift2_3).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range2 | (i.shift2_3).future2 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range2 | (i.shift2_3).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (((E29 + (E33 + E37)) + (E41 + (E45 + E49)))) implies e.ev = {i: range2 | (i.shift2_4) in (e.target.av)}
all e: used | e.fiber in (((E30 + E34) + (E38 + (E42 + E46)))) implies e.ev = {i: range2 | (i.shift2_4) in (range2 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range2 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next2.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range2 | some (i.future2 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range2 | i.future2 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range2 - left[a].ev) + right[a].ev)
}
fun range3: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop3: set Pos { P3 }
fun next3: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift3_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun shift3_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P3 + P3->P3)) }
fun shift3_3: Pos -> Pos { ((P0->P3 + P1->P3) + (P2->P3 + P3->P3)) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range3 | (i.shift3_0) in (range3 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range3 | (i.shift3_0).future3 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range3 | (i.shift3_0).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range3 | loop3 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range3 | loop3 in (range3 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range3 | some (loop3 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range3 | some (loop3 & (range3 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range3 | (i.shift3_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range3 | (i.shift3_1) in (range3 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range3 | (i.shift3_1).future3 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range3 | (i.shift3_1).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range3 | (i.shift3_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range3 | (i.shift3_2) in (range3 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range3 | (i.shift3_2).future3 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range3 | (i.shift3_2).future3 in (range3 - e.target.av)}
all e: used | e.fiber in ((((E23 + (E29 + E31)) + (E33 + (E35 + E37))) + ((E39 + (E41 + E43)) + (E45 + (E47 + E49))))) implies e.ev = {i: range3 | (i.shift3_3) in (e.target.av)}
all e: used | e.fiber in ((((E24 + E30) + (E32 + (E34 + E36))) + ((E38 + (E40 + E42)) + (E44 + (E46 + E48))))) implies e.ev = {i: range3 | (i.shift3_3) in (range3 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range3 | some ((i.shift3_3).future3 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range3 | some ((i.shift3_3).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range3 | (i.shift3_3).future3 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range3 | (i.shift3_3).future3 in (range3 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range3 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next3.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range3 | some (i.future3 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range3 | i.future3 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range3 - left[a].ev) + right[a].ev)
}
fun range4: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop4: set Pos { (P2 + P3) }
fun next4: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P2)) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift4_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P2)) }
fun shift4_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P2 + P3->P3)) }
fun shift4_3: Pos -> Pos { ((P0->P3 + P1->P2) + (P2->P3 + P3->P2)) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range4 | (i.shift4_0) in (range4 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range4 | (i.shift4_0).future4 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range4 | (i.shift4_0).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range4 | loop4 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range4 | loop4 in (range4 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range4 | some (loop4 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range4 | some (loop4 & (range4 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range4 | (i.shift4_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range4 | (i.shift4_1) in (range4 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range4 | (i.shift4_1).future4 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range4 | (i.shift4_1).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (((E17 + (E29 + E33)) + ((E37 + E41) + (E45 + E49)))) implies e.ev = {i: range4 | (i.shift4_2) in (e.target.av)}
all e: used | e.fiber in (((E18 + (E30 + E34)) + (E38 + (E42 + E46)))) implies e.ev = {i: range4 | (i.shift4_2) in (range4 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range4 | (i.shift4_2).future4 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range4 | (i.shift4_2).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (((E23 + (E31 + E35)) + (E39 + (E43 + E47)))) implies e.ev = {i: range4 | (i.shift4_3) in (e.target.av)}
all e: used | e.fiber in (((E24 + (E32 + E36)) + (E40 + (E44 + E48)))) implies e.ev = {i: range4 | (i.shift4_3) in (range4 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range4 | some ((i.shift4_3).future4 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range4 | some ((i.shift4_3).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range4 | (i.shift4_3).future4 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range4 | (i.shift4_3).future4 in (range4 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range4 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next4.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range4 | some (i.future4 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range4 | i.future4 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range4 - left[a].ev) + right[a].ev)
}
fun range5: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop5: set Pos { P4 }
fun next5: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift5_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun shift5_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift5_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift5_4: Pos -> Pos { ((P0->P4 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range5 | (i.shift5_0) in (range5 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range5 | (i.shift5_0).future5 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range5 | (i.shift5_0).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range5 | loop5 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range5 | loop5 in (range5 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range5 | some (loop5 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range5 | some (loop5 & (range5 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range5 | (i.shift5_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range5 | (i.shift5_1) in (range5 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range5 | (i.shift5_1).future5 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range5 | (i.shift5_1).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range5 | (i.shift5_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range5 | (i.shift5_2) in (range5 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range5 | (i.shift5_2).future5 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range5 | (i.shift5_2).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range5 | (i.shift5_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range5 | (i.shift5_3) in (range5 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range5 | some ((i.shift5_3).future5 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range5 | some ((i.shift5_3).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range5 | (i.shift5_3).future5 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range5 | (i.shift5_3).future5 in (range5 - e.target.av)}
all e: used | e.fiber in ((((E29 + E31) + (E33 + (E35 + E37))) + ((E39 + (E41 + E43)) + (E45 + (E47 + E49))))) implies e.ev = {i: range5 | (i.shift5_4) in (e.target.av)}
all e: used | e.fiber in ((((E30 + E32) + (E34 + (E36 + E38))) + ((E40 + E42) + (E44 + (E46 + E48))))) implies e.ev = {i: range5 | (i.shift5_4) in (range5 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range5 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next5.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range5 | some (i.future5 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range5 | i.future5 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range5 - left[a].ev) + right[a].ev)
}
fun range6: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop6: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun next6: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun future6: Pos -> Pos { (*next6) & (range6->range6) }
fun shift6_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift6_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun shift6_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P0 + P4->P1))) }
fun shift6_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P0 + (P3->P1 + P4->P2))) }
fun shift6_4: Pos -> Pos { ((P0->P4 + P1->P0) + (P2->P1 + (P3->P2 + P4->P3))) }
pred semantics6[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range6
ev in used->range6
all e: used | e.fiber in (((E0 + E1) + (E31 + E41))) implies e.ev = {i: range6 | (i.shift6_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + (E32 + E42))) implies e.ev = {i: range6 | (i.shift6_0) in (range6 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range6 | (i.shift6_0).future6 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range6 | (i.shift6_0).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range6 | loop6 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range6 | loop6 in (range6 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range6 | some (loop6 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range6 | some (loop6 & (range6 - e.target.av))}
all e: used | e.fiber in ((E11 + (E33 + E43))) implies e.ev = {i: range6 | (i.shift6_1) in (e.target.av)}
all e: used | e.fiber in ((E12 + (E34 + E44))) implies e.ev = {i: range6 | (i.shift6_1) in (range6 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range6 | (i.shift6_1).future6 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range6 | (i.shift6_1).future6 in (range6 - e.target.av)}
all e: used | e.fiber in ((E17 + (E35 + E45))) implies e.ev = {i: range6 | (i.shift6_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + (E36 + E46))) implies e.ev = {i: range6 | (i.shift6_2) in (range6 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range6 | (i.shift6_2).future6 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range6 | (i.shift6_2).future6 in (range6 - e.target.av)}
all e: used | e.fiber in ((E23 + (E37 + E47))) implies e.ev = {i: range6 | (i.shift6_3) in (e.target.av)}
all e: used | e.fiber in ((E24 + (E38 + E48))) implies e.ev = {i: range6 | (i.shift6_3) in (range6 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range6 | some ((i.shift6_3).future6 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range6 | some ((i.shift6_3).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range6 | (i.shift6_3).future6 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range6 | (i.shift6_3).future6 in (range6 - e.target.av)}
all e: used | e.fiber in ((E29 + (E39 + E49))) implies e.ev = {i: range6 | (i.shift6_4) in (e.target.av)}
all e: used | e.fiber in ((E30 + E40)) implies e.ev = {i: range6 | (i.shift6_4) in (range6 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range6 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next6.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range6 | some (i.future6 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range6 | i.future6 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range6 - left[a].ev) + right[a].ev)
}
fun range7: set Pos { (P0 + P1) }
fun loop7: set Pos { P1 }
fun next7: Pos -> Pos { (P0->P1 + P1->P1) }
fun future7: Pos -> Pos { (*next7) & (range7->range7) }
fun shift7_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift7_1: Pos -> Pos { (P0->P1 + P1->P1) }
pred semantics7[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range7
ev in used->range7
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range7 | (i.shift7_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range7 | (i.shift7_0) in (range7 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range7 | (i.shift7_0).future7 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range7 | (i.shift7_0).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range7 | loop7 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range7 | loop7 in (range7 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range7 | some (loop7 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range7 | some (loop7 & (range7 - e.target.av))}
all e: used | e.fiber in ((((E11 + (E17 + E23)) + ((E29 + E31) + (E33 + E35))) + ((E37 + (E39 + E41)) + ((E43 + E45) + (E47 + E49))))) implies e.ev = {i: range7 | (i.shift7_1) in (e.target.av)}
all e: used | e.fiber in ((((E12 + (E18 + E24)) + (E30 + (E32 + E34))) + ((E36 + (E38 + E40)) + ((E42 + E44) + (E46 + E48))))) implies e.ev = {i: range7 | (i.shift7_1) in (range7 - e.target.av)}
all e: used | e.fiber in ((E13 + (E19 + E25))) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (e.target.av))}
all e: used | e.fiber in ((E14 + (E20 + E26))) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (range7 - e.target.av))}
all e: used | e.fiber in ((E15 + (E21 + E27))) implies e.ev = {i: range7 | (i.shift7_1).future7 in (e.target.av)}
all e: used | e.fiber in ((E16 + (E22 + E28))) implies e.ev = {i: range7 | (i.shift7_1).future7 in (range7 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range7 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next7.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range7 | some (i.future7 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range7 | i.future7 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range7 - left[a].ev) + right[a].ev)
}
fun range8: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop8: set Pos { (P1 + (P2 + P3)) }
fun next8: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P1)) }
fun future8: Pos -> Pos { (*next8) & (range8->range8) }
fun shift8_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift8_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P1)) }
fun shift8_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P1 + P3->P2)) }
fun shift8_3: Pos -> Pos { ((P0->P3 + P1->P1) + (P2->P2 + P3->P3)) }
pred semantics8[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range8
ev in used->range8
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range8 | (i.shift8_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range8 | (i.shift8_0) in (range8 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range8 | (i.shift8_0).future8 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range8 | (i.shift8_0).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range8 | loop8 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range8 | loop8 in (range8 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range8 | some (loop8 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range8 | some (loop8 & (range8 - e.target.av))}
all e: used | e.fiber in (((E11 + E29) + (E35 + (E41 + E47)))) implies e.ev = {i: range8 | (i.shift8_1) in (e.target.av)}
all e: used | e.fiber in (((E12 + E30) + (E36 + (E42 + E48)))) implies e.ev = {i: range8 | (i.shift8_1) in (range8 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range8 | (i.shift8_1).future8 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range8 | (i.shift8_1).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (((E17 + E31) + (E37 + (E43 + E49)))) implies e.ev = {i: range8 | (i.shift8_2) in (e.target.av)}
all e: used | e.fiber in (((E18 + E32) + (E38 + E44))) implies e.ev = {i: range8 | (i.shift8_2) in (range8 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range8 | some ((i.shift8_2).future8 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range8 | some ((i.shift8_2).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range8 | (i.shift8_2).future8 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range8 | (i.shift8_2).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (((E23 + E33) + (E39 + E45))) implies e.ev = {i: range8 | (i.shift8_3) in (e.target.av)}
all e: used | e.fiber in (((E24 + E34) + (E40 + E46))) implies e.ev = {i: range8 | (i.shift8_3) in (range8 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range8 | some ((i.shift8_3).future8 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range8 | some ((i.shift8_3).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range8 | (i.shift8_3).future8 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range8 | (i.shift8_3).future8 in (range8 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range8 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next8.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range8 | some (i.future8 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range8 | i.future8 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range8 - left[a].ev) + right[a].ev)
}
fun range9: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop9: set Pos { ((P0 + P1) + (P2 + P3)) }
fun next9: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun future9: Pos -> Pos { (*next9) & (range9->range9) }
fun shift9_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift9_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun shift9_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P0 + P3->P1)) }
fun shift9_3: Pos -> Pos { ((P0->P3 + P1->P0) + (P2->P1 + P3->P2)) }
pred semantics9[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range9
ev in used->range9
all e: used | e.fiber in (((E0 + E1) + (E29 + (E37 + E45)))) implies e.ev = {i: range9 | (i.shift9_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E30) + (E38 + E46))) implies e.ev = {i: range9 | (i.shift9_0) in (range9 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range9 | (i.shift9_0).future9 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range9 | (i.shift9_0).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range9 | loop9 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range9 | loop9 in (range9 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range9 | some (loop9 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range9 | some (loop9 & (range9 - e.target.av))}
all e: used | e.fiber in (((E11 + E31) + (E39 + E47))) implies e.ev = {i: range9 | (i.shift9_1) in (e.target.av)}
all e: used | e.fiber in (((E12 + E32) + (E40 + E48))) implies e.ev = {i: range9 | (i.shift9_1) in (range9 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range9 | (i.shift9_1).future9 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range9 | (i.shift9_1).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (((E17 + E33) + (E41 + E49))) implies e.ev = {i: range9 | (i.shift9_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + (E34 + E42))) implies e.ev = {i: range9 | (i.shift9_2) in (range9 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range9 | some ((i.shift9_2).future9 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range9 | some ((i.shift9_2).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range9 | (i.shift9_2).future9 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range9 | (i.shift9_2).future9 in (range9 - e.target.av)}
all e: used | e.fiber in ((E23 + (E35 + E43))) implies e.ev = {i: range9 | (i.shift9_3) in (e.target.av)}
all e: used | e.fiber in ((E24 + (E36 + E44))) implies e.ev = {i: range9 | (i.shift9_3) in (range9 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range9 | some ((i.shift9_3).future9 & (e.target.av))}
all e: used | e.fiber in (E26) implies e.ev = {i: range9 | some ((i.shift9_3).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range9 | (i.shift9_3).future9 in (e.target.av)}
all e: used | e.fiber in (E28) implies e.ev = {i: range9 | (i.shift9_3).future9 in (range9 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range9 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next9.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range9 | some (i.future9 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range9 | i.future9 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range9 - left[a].ev) + right[a].ev)
}
fun range10: set Pos { (P0 + (P1 + P2)) }
fun loop10: set Pos { P2 }
fun next10: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun future10: Pos -> Pos { (*next10) & (range10->range10) }
fun shift10_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift10_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun shift10_2: Pos -> Pos { (P0->P2 + (P1->P2 + P2->P2)) }
pred semantics10[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range10
ev in used->range10
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range10 | (i.shift10_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range10 | (i.shift10_0) in (range10 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range10 | (i.shift10_0).future10 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range10 | (i.shift10_0).future10 in (range10 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range10 | loop10 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range10 | loop10 in (range10 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range10 | some (loop10 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range10 | some (loop10 & (range10 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range10 | (i.shift10_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range10 | (i.shift10_1) in (range10 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range10 | some ((i.shift10_1).future10 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range10 | some ((i.shift10_1).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range10 | (i.shift10_1).future10 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range10 | (i.shift10_1).future10 in (range10 - e.target.av)}
all e: used | e.fiber in ((((E17 + (E23 + E29)) + (E31 + (E33 + E35))) + ((E37 + (E39 + E41)) + ((E43 + E45) + (E47 + E49))))) implies e.ev = {i: range10 | (i.shift10_2) in (e.target.av)}
all e: used | e.fiber in ((((E18 + (E24 + E30)) + (E32 + (E34 + E36))) + ((E38 + (E40 + E42)) + (E44 + (E46 + E48))))) implies e.ev = {i: range10 | (i.shift10_2) in (range10 - e.target.av)}
all e: used | e.fiber in ((E19 + E25)) implies e.ev = {i: range10 | some ((i.shift10_2).future10 & (e.target.av))}
all e: used | e.fiber in ((E20 + E26)) implies e.ev = {i: range10 | some ((i.shift10_2).future10 & (range10 - e.target.av))}
all e: used | e.fiber in ((E21 + E27)) implies e.ev = {i: range10 | (i.shift10_2).future10 in (e.target.av)}
all e: used | e.fiber in ((E22 + E28)) implies e.ev = {i: range10 | (i.shift10_2).future10 in (range10 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range10 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next10.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range10 | some (i.future10 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range10 | i.future10 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range10 - left[a].ev) + right[a].ev)
}
fun range11: set Pos { (P0 + (P1 + P2)) }
fun loop11: set Pos { (P1 + P2) }
fun next11: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P1)) }
fun future11: Pos -> Pos { (*next11) & (range11->range11) }
fun shift11_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift11_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P1)) }
fun shift11_2: Pos -> Pos { (P0->P2 + (P1->P1 + P2->P2)) }
pred semantics11[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range11
ev in used->range11
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range11 | (i.shift11_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range11 | (i.shift11_0) in (range11 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range11 | some ((i.shift11_0).future11 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range11 | some ((i.shift11_0).future11 & (range11 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range11 | (i.shift11_0).future11 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range11 | (i.shift11_0).future11 in (range11 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range11 | loop11 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range11 | loop11 in (range11 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range11 | some (loop11 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range11 | some (loop11 & (range11 - e.target.av))}
all e: used | e.fiber in (((E11 + (E23 + E31)) + ((E35 + E39) + (E43 + E47)))) implies e.ev = {i: range11 | (i.shift11_1) in (e.target.av)}
all e: used | e.fiber in (((E12 + (E24 + E32)) + ((E36 + E40) + (E44 + E48)))) implies e.ev = {i: range11 | (i.shift11_1) in (range11 - e.target.av)}
all e: used | e.fiber in ((E13 + E25)) implies e.ev = {i: range11 | some ((i.shift11_1).future11 & (e.target.av))}
all e: used | e.fiber in ((E14 + E26)) implies e.ev = {i: range11 | some ((i.shift11_1).future11 & (range11 - e.target.av))}
all e: used | e.fiber in ((E15 + E27)) implies e.ev = {i: range11 | (i.shift11_1).future11 in (e.target.av)}
all e: used | e.fiber in ((E16 + E28)) implies e.ev = {i: range11 | (i.shift11_1).future11 in (range11 - e.target.av)}
all e: used | e.fiber in (((E17 + (E29 + E33)) + ((E37 + E41) + (E45 + E49)))) implies e.ev = {i: range11 | (i.shift11_2) in (e.target.av)}
all e: used | e.fiber in (((E18 + (E30 + E34)) + (E38 + (E42 + E46)))) implies e.ev = {i: range11 | (i.shift11_2) in (range11 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range11 | some ((i.shift11_2).future11 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range11 | some ((i.shift11_2).future11 & (range11 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range11 | (i.shift11_2).future11 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range11 | (i.shift11_2).future11 in (range11 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range11 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next11.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range11 | some (i.future11 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range11 | i.future11 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range11 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (P1)
all a: lab.T1 | a.av0 = ((P2 + P4))
all a: lab.T2 | a.av0 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev0)
semantics1[av1, ev1]
all a: lab.T0 | a.av1 = (P0)
all a: lab.T1 | a.av1 = ((P2 + P4))
all a: lab.T2 | a.av1 = ((P0 + P1))
(R->P0 in ev1)
semantics2[av2, ev2]
all a: lab.T0 | a.av2 = ((P0 + P2))
all a: lab.T1 | a.av2 = (P4)
all a: lab.T2 | a.av2 = (P2)
(R->P0 in ev2)
semantics3[av3, ev3]
all a: lab.T0 | a.av3 = (none)
all a: lab.T1 | a.av3 = ((P2 + P3))
all a: lab.T2 | a.av3 = ((P0 + P3))
(R->P0 in ev3)
semantics0[av4, ev4]
all a: lab.T0 | a.av4 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av4 = (none)
all a: lab.T2 | a.av4 = ((P1 + (P2 + P3)))
(R->P0 in ev4)
semantics0[av5, ev5]
all a: lab.T0 | a.av5 = (P0)
all a: lab.T1 | a.av5 = (P1)
all a: lab.T2 | a.av5 = ((P0 + P4))
(R->P0 in ev5)
semantics0[av6, ev6]
all a: lab.T0 | a.av6 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av6 = (none)
all a: lab.T2 | a.av6 = ((P3 + P4))
(R->P0 in ev6)
semantics3[av7, ev7]
all a: lab.T0 | a.av7 = (P1)
all a: lab.T1 | a.av7 = (P2)
all a: lab.T2 | a.av7 = ((P0 + (P2 + P3)))
(R->P0 in ev7)
semantics4[av8, ev8]
all a: lab.T0 | a.av8 = (P3)
all a: lab.T1 | a.av8 = (none)
all a: lab.T2 | a.av8 = ((P0 + (P2 + P3)))
(R->P0 in ev8)
semantics1[av9, ev9]
all a: lab.T0 | a.av9 = (none)
all a: lab.T1 | a.av9 = ((P0 + P1))
all a: lab.T2 | a.av9 = ((P0 + (P1 + P2)))
(R->P0 in ev9)
semantics2[av10, ev10]
all a: lab.T0 | a.av10 = (none)
all a: lab.T1 | a.av10 = (P2)
all a: lab.T2 | a.av10 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev10)
semantics5[av11, ev11]
all a: lab.T0 | a.av11 = (P0)
all a: lab.T1 | a.av11 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av11 = (P3)
(R->P0 in ev11)
semantics2[av12, ev12]
all a: lab.T0 | a.av12 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av12 = (none)
all a: lab.T2 | a.av12 = (P1)
(R->P0 in ev12)
semantics6[av13, ev13]
all a: lab.T0 | a.av13 = (none)
all a: lab.T1 | a.av13 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av13 = ((P1 + (P3 + P4)))
(R->P0 in ev13)
semantics5[av14, ev14]
all a: lab.T0 | a.av14 = (P4)
all a: lab.T1 | a.av14 = (none)
all a: lab.T2 | a.av14 = ((P0 + (P3 + P4)))
(R->P0 in ev14)
semantics5[av15, ev15]
all a: lab.T0 | a.av15 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av15 = (none)
all a: lab.T2 | a.av15 = (P4)
(R->P0 in ev15)
semantics1[av16, ev16]
all a: lab.T0 | a.av16 = (none)
all a: lab.T1 | a.av16 = (P1)
all a: lab.T2 | a.av16 = ((P1 + P4))
(R->P0 in ev16)
semantics3[av17, ev17]
all a: lab.T0 | a.av17 = (P0)
all a: lab.T1 | a.av17 = (P2)
all a: lab.T2 | a.av17 = (P0)
(R->P0 in ev17)
semantics2[av18, ev18]
all a: lab.T0 | a.av18 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av18 = (none)
all a: lab.T2 | a.av18 = ((P2 + P3))
(R->P0 in ev18)
semantics7[av19, ev19]
all a: lab.T0 | a.av19 = (none)
all a: lab.T1 | a.av19 = (P1)
all a: lab.T2 | a.av19 = (P0)
(R->P0 in ev19)
semantics8[av20, ev20]
all a: lab.T0 | a.av20 = ((P2 + P3))
all a: lab.T1 | a.av20 = (none)
all a: lab.T2 | a.av20 = (P1)
(R->P0 in ev20)
semantics4[av21, ev21]
all a: lab.T0 | a.av21 = (none)
all a: lab.T1 | a.av21 = (P2)
all a: lab.T2 | a.av21 = ((P0 + P1))
(R->P0 in ev21)
semantics5[av22, ev22]
all a: lab.T0 | a.av22 = ((P0 + P2))
all a: lab.T1 | a.av22 = (P4)
all a: lab.T2 | a.av22 = ((P0 + (P3 + P4)))
(R->P0 in ev22)
semantics5[av23, ev23]
all a: lab.T0 | a.av23 = (none)
all a: lab.T1 | a.av23 = ((P2 + P3))
all a: lab.T2 | a.av23 = ((P1 + P3))
(R->P0 in ev23)
semantics6[av24, ev24]
all a: lab.T0 | a.av24 = ((P1 + P2))
all a: lab.T1 | a.av24 = (none)
all a: lab.T2 | a.av24 = (P4)
(R->P0 in ev24)
semantics5[av25, ev25]
all a: lab.T0 | a.av25 = (P4)
all a: lab.T1 | a.av25 = (none)
all a: lab.T2 | a.av25 = ((P0 + (P2 + P3)))
(R->P0 in ev25)
semantics5[av26, ev26]
all a: lab.T0 | a.av26 = (P2)
all a: lab.T1 | a.av26 = ((P3 + P4))
all a: lab.T2 | a.av26 = ((P2 + P3))
(R->P0 in ev26)
semantics3[av27, ev27]
all a: lab.T0 | a.av27 = (none)
all a: lab.T1 | a.av27 = (P0)
all a: lab.T2 | a.av27 = ((P0 + (P1 + P3)))
(R->P0 in ev27)
semantics2[av28, ev28]
all a: lab.T0 | a.av28 = (none)
all a: lab.T1 | a.av28 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av28 = ((P0 + P3))
(R->P0 in ev28)
semantics2[av29, ev29]
all a: lab.T0 | a.av29 = (P1)
all a: lab.T1 | a.av29 = (P2)
all a: lab.T2 | a.av29 = (P3)
(R->P0 in ev29)
semantics1[av30, ev30]
all a: lab.T0 | a.av30 = (P1)
all a: lab.T1 | a.av30 = (none)
all a: lab.T2 | a.av30 = ((P0 + (P2 + P3)))
(R->P0 in ev30)
semantics5[av31, ev31]
all a: lab.T0 | a.av31 = (none)
all a: lab.T1 | a.av31 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av31 = (P0)
(R->P0 in ev31)
semantics5[av32, ev32]
all a: lab.T0 | a.av32 = (none)
all a: lab.T1 | a.av32 = (P3)
all a: lab.T2 | a.av32 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev32)
semantics6[av33, ev33]
all a: lab.T0 | a.av33 = ((P1 + P4))
all a: lab.T1 | a.av33 = (none)
all a: lab.T2 | a.av33 = ((P1 + P2))
(R->P0 in ev33)
semantics0[av34, ev34]
all a: lab.T0 | a.av34 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av34 = (none)
all a: lab.T2 | a.av34 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev34)
semantics9[av35, ev35]
all a: lab.T0 | a.av35 = (P3)
all a: lab.T1 | a.av35 = (none)
all a: lab.T2 | a.av35 = ((P1 + P2))
(R->P0 in ev35)
semantics5[av36, ev36]
all a: lab.T0 | a.av36 = (none)
all a: lab.T1 | a.av36 = (P0)
all a: lab.T2 | a.av36 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev36)
semantics6[av37, ev37]
all a: lab.T0 | a.av37 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av37 = (none)
all a: lab.T2 | a.av37 = ((P0 + P3))
(R->P0 in ev37)
semantics4[av38, ev38]
all a: lab.T0 | a.av38 = (P0)
all a: lab.T1 | a.av38 = (P1)
all a: lab.T2 | a.av38 = ((P0 + P2))
(R->P0 in ev38)
semantics6[av39, ev39]
all a: lab.T0 | a.av39 = (none)
all a: lab.T1 | a.av39 = ((P3 + P4))
all a: lab.T2 | a.av39 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev39)
semantics2[av40, ev40]
all a: lab.T0 | a.av40 = (none)
all a: lab.T1 | a.av40 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av40 = ((P0 + P4))
(R->P0 in ev40)
semantics2[av41, ev41]
all a: lab.T0 | a.av41 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av41 = (none)
all a: lab.T2 | a.av41 = (P4)
(R->P0 in ev41)
semantics0[av42, ev42]
all a: lab.T0 | a.av42 = (none)
all a: lab.T1 | a.av42 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av42 = ((P2 + P4))
(R->P0 in ev42)
semantics1[av43, ev43]
all a: lab.T0 | a.av43 = (none)
all a: lab.T1 | a.av43 = ((P0 + P1))
all a: lab.T2 | a.av43 = ((P2 + P3))
(R->P0 in ev43)
semantics0[av44, ev44]
all a: lab.T0 | a.av44 = (P1)
all a: lab.T1 | a.av44 = (P2)
all a: lab.T2 | a.av44 = (P0)
(R->P0 in ev44)
semantics3[av45, ev45]
all a: lab.T0 | a.av45 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av45 = (none)
all a: lab.T2 | a.av45 = ((P0 + P2))
(R->P0 in ev45)
semantics5[av46, ev46]
all a: lab.T0 | a.av46 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av46 = (none)
all a: lab.T2 | a.av46 = ((P0 + P2))
(R->P0 in ev46)
semantics1[av47, ev47]
all a: lab.T0 | a.av47 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av47 = (none)
all a: lab.T2 | a.av47 = ((P0 + (P1 + P4)))
(R->P0 in ev47)
semantics5[av48, ev48]
all a: lab.T0 | a.av48 = (none)
all a: lab.T1 | a.av48 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av48 = ((P1 + (P3 + P4)))
(R->P0 in ev48)
semantics10[av49, ev49]
all a: lab.T0 | a.av49 = (P1)
all a: lab.T1 | a.av49 = (P2)
all a: lab.T2 | a.av49 = ((P1 + P2))
(R->P0 in ev49)
semantics1[av50, ev50]
all a: lab.T0 | a.av50 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av50 = ((P2 + P3))
all a: lab.T2 | a.av50 = (P0)
not (R->P0 in ev50)
semantics1[av51, ev51]
all a: lab.T0 | a.av51 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av51 = ((P1 + P4))
all a: lab.T2 | a.av51 = ((P0 + P2))
not (R->P0 in ev51)
semantics2[av52, ev52]
all a: lab.T0 | a.av52 = ((P0 + P4))
all a: lab.T1 | a.av52 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av52 = ((P0 + P1))
not (R->P0 in ev52)
semantics1[av53, ev53]
all a: lab.T0 | a.av53 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av53 = (P4)
all a: lab.T2 | a.av53 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev53)
semantics2[av54, ev54]
all a: lab.T0 | a.av54 = ((P2 + P4))
all a: lab.T1 | a.av54 = (P4)
all a: lab.T2 | a.av54 = ((P2 + P3))
not (R->P0 in ev54)
semantics6[av55, ev55]
all a: lab.T0 | a.av55 = ((P1 + P3))
all a: lab.T1 | a.av55 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av55 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev55)
semantics6[av56, ev56]
all a: lab.T0 | a.av56 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av56 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av56 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev56)
semantics2[av57, ev57]
all a: lab.T0 | a.av57 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av57 = (P2)
all a: lab.T2 | a.av57 = (P4)
not (R->P0 in ev57)
semantics0[av58, ev58]
all a: lab.T0 | a.av58 = (P0)
all a: lab.T1 | a.av58 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av58 = ((P2 + P4))
not (R->P0 in ev58)
semantics2[av59, ev59]
all a: lab.T0 | a.av59 = ((P0 + P2))
all a: lab.T1 | a.av59 = ((P1 + P2))
all a: lab.T2 | a.av59 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev59)
semantics2[av60, ev60]
all a: lab.T0 | a.av60 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av60 = ((P1 + P2))
all a: lab.T2 | a.av60 = ((P0 + (P2 + P3)))
not (R->P0 in ev60)
semantics10[av61, ev61]
all a: lab.T0 | a.av61 = (P1)
all a: lab.T1 | a.av61 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av61 = (P0)
not (R->P0 in ev61)
semantics5[av62, ev62]
all a: lab.T0 | a.av62 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av62 = (P1)
all a: lab.T2 | a.av62 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev62)
semantics6[av63, ev63]
all a: lab.T0 | a.av63 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av63 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av63 = ((P0 + (P2 + P3)))
not (R->P0 in ev63)
semantics5[av64, ev64]
all a: lab.T0 | a.av64 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av64 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av64 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev64)
semantics11[av65, ev65]
all a: lab.T0 | a.av65 = (P2)
all a: lab.T1 | a.av65 = ((P1 + P2))
all a: lab.T2 | a.av65 = ((P0 + P1))
not (R->P0 in ev65)
semantics0[av66, ev66]
all a: lab.T0 | a.av66 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av66 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av66 = (P4)
not (R->P0 in ev66)
semantics0[av67, ev67]
all a: lab.T0 | a.av67 = ((P1 + P4))
all a: lab.T1 | a.av67 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av67 = ((P1 + P3))
not (R->P0 in ev67)
semantics3[av68, ev68]
all a: lab.T0 | a.av68 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av68 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av68 = ((P1 + P2))
not (R->P0 in ev68)
semantics2[av69, ev69]
all a: lab.T0 | a.av69 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av69 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av69 = ((P3 + P4))
not (R->P0 in ev69)
semantics0[av70, ev70]
all a: lab.T0 | a.av70 = (P1)
all a: lab.T1 | a.av70 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av70 = (P4)
not (R->P0 in ev70)
semantics1[av71, ev71]
all a: lab.T0 | a.av71 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av71 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av71 = ((P0 + (P3 + P4)))
not (R->P0 in ev71)
semantics0[av72, ev72]
all a: lab.T0 | a.av72 = ((P1 + P2))
all a: lab.T1 | a.av72 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av72 = ((P0 + P3))
not (R->P0 in ev72)
semantics1[av73, ev73]
all a: lab.T0 | a.av73 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av73 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av73 = ((P2 + (P3 + P4)))
not (R->P0 in ev73)
semantics0[av74, ev74]
all a: lab.T0 | a.av74 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av74 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av74 = ((P2 + (P3 + P4)))
not (R->P0 in ev74)
semantics6[av75, ev75]
all a: lab.T0 | a.av75 = (P2)
all a: lab.T1 | a.av75 = (P3)
all a: lab.T2 | a.av75 = ((P0 + (P1 + P4)))
not (R->P0 in ev75)
semantics2[av76, ev76]
all a: lab.T0 | a.av76 = ((P2 + P3))
all a: lab.T1 | a.av76 = ((P2 + P4))
all a: lab.T2 | a.av76 = ((P1 + (P2 + P3)))
not (R->P0 in ev76)
semantics2[av77, ev77]
all a: lab.T0 | a.av77 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av77 = (P3)
all a: lab.T2 | a.av77 = (P1)
not (R->P0 in ev77)
semantics3[av78, ev78]
all a: lab.T0 | a.av78 = ((P0 + P1))
all a: lab.T1 | a.av78 = (P1)
all a: lab.T2 | a.av78 = ((P0 + (P1 + P3)))
not (R->P0 in ev78)
semantics5[av79, ev79]
all a: lab.T0 | a.av79 = ((P0 + P4))
all a: lab.T1 | a.av79 = ((P1 + P2))
all a: lab.T2 | a.av79 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev79)
semantics1[av80, ev80]
all a: lab.T0 | a.av80 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av80 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av80 = ((P2 + P4))
not (R->P0 in ev80)
semantics3[av81, ev81]
all a: lab.T0 | a.av81 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av81 = ((P1 + P3))
all a: lab.T2 | a.av81 = (none)
not (R->P0 in ev81)
semantics0[av82, ev82]
all a: lab.T0 | a.av82 = (P4)
all a: lab.T1 | a.av82 = (P4)
all a: lab.T2 | a.av82 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev82)
semantics4[av83, ev83]
all a: lab.T0 | a.av83 = ((P2 + P3))
all a: lab.T1 | a.av83 = (P3)
all a: lab.T2 | a.av83 = ((P0 + (P1 + P3)))
not (R->P0 in ev83)
semantics2[av84, ev84]
all a: lab.T0 | a.av84 = ((P1 + P4))
all a: lab.T1 | a.av84 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av84 = ((P2 + (P3 + P4)))
not (R->P0 in ev84)
semantics5[av85, ev85]
all a: lab.T0 | a.av85 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av85 = ((P1 + P2))
all a: lab.T2 | a.av85 = ((P0 + P4))
not (R->P0 in ev85)
semantics1[av86, ev86]
all a: lab.T0 | a.av86 = ((P0 + P3))
all a: lab.T1 | a.av86 = ((P1 + P4))
all a: lab.T2 | a.av86 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev86)
semantics0[av87, ev87]
all a: lab.T0 | a.av87 = ((P0 + P1))
all a: lab.T1 | a.av87 = (P1)
all a: lab.T2 | a.av87 = ((P1 + (P2 + P4)))
not (R->P0 in ev87)
semantics6[av88, ev88]
all a: lab.T0 | a.av88 = (P1)
all a: lab.T1 | a.av88 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av88 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev88)
semantics6[av89, ev89]
all a: lab.T0 | a.av89 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av89 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av89 = ((P3 + P4))
not (R->P0 in ev89)
semantics8[av90, ev90]
all a: lab.T0 | a.av90 = ((P0 + P2))
all a: lab.T1 | a.av90 = (P2)
all a: lab.T2 | a.av90 = ((P1 + P3))
not (R->P0 in ev90)
semantics6[av91, ev91]
all a: lab.T0 | a.av91 = ((P0 + P1))
all a: lab.T1 | a.av91 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av91 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev91)
semantics5[av92, ev92]
all a: lab.T0 | a.av92 = (P1)
all a: lab.T1 | a.av92 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av92 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev92)
semantics2[av93, ev93]
all a: lab.T0 | a.av93 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av93 = (P1)
all a: lab.T2 | a.av93 = ((P1 + (P2 + P3)))
not (R->P0 in ev93)
semantics2[av94, ev94]
all a: lab.T0 | a.av94 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av94 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av94 = ((P0 + (P1 + P3)))
not (R->P0 in ev94)
semantics1[av95, ev95]
all a: lab.T0 | a.av95 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av95 = ((P0 + P3))
all a: lab.T2 | a.av95 = ((P1 + P2))
not (R->P0 in ev95)
semantics1[av96, ev96]
all a: lab.T0 | a.av96 = (P4)
all a: lab.T1 | a.av96 = ((P0 + P4))
all a: lab.T2 | a.av96 = ((P0 + P1))
not (R->P0 in ev96)
semantics1[av97, ev97]
all a: lab.T0 | a.av97 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av97 = (P0)
all a: lab.T2 | a.av97 = ((P0 + P3))
not (R->P0 in ev97)
semantics0[av98, ev98]
all a: lab.T0 | a.av98 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av98 = ((P1 + P4))
all a: lab.T2 | a.av98 = ((P0 + (P3 + P4)))
not (R->P0 in ev98)
semantics1[av99, ev99]
all a: lab.T0 | a.av99 = (P1)
all a: lab.T1 | a.av99 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av99 = ((P1 + P2))
not (R->P0 in ev99)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int

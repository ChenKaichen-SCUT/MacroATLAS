open util/ordering[SeqIdx]

abstract sig DAGNode {
	l: set DAGNode,
	r: set DAGNode
}
fact {
	all n: DAGNode | n not in n.^(l + r)
}

sig And, Or, Imply extends DAGNode {} {
	one l
	one r
}

sig Neg, F, G, X extends DAGNode {} {
    one l
    no r
}
abstract sig Literal extends DAGNode {} {
	no l
	no r
}

abstract sig SeqIdx {}
abstract sig Trace {
	lasso: SeqIdx -> SeqIdx,
	valuation: DAGNode -> SeqIdx
} {
	// Negation
    all n: Neg, i: seqRange | n->i in valuation iff n.l->i not in valuation
	// Or
    all n: Or, i: seqRange | n->i in valuation iff (n.l->i in valuation or n.r->i in valuation)
	// And
    all n: And, i: seqRange | n->i in valuation iff (n.l->i in valuation and n.r->i in valuation)
	// Imply
    all n: Imply, i: seqRange | n->i in valuation iff (n.l->i not in valuation or n.r->i in valuation)
	// G
    all n: G, i: seqRange | n->i in valuation iff all i': futureIdx[i] | n.l->i' in valuation
    // X
    all n: X, i: seqRange | n->i in valuation iff n.l->i.((next :> seqRange) + lasso) in valuation
	// F
    all n: F, i: seqRange | n->i in valuation iff some i': futureIdx[i] | n.l->i' in valuation
	// Until
    
}
fun seqRange[t: Trace]: set SeqIdx {
	let lastOfTrace = t.lasso.SeqIdx | lastOfTrace.prevs + lastOfTrace
}
fun futureIdx[t: Trace, i: SeqIdx]: set SeqIdx {
	i.^((next :> seqRange[t]) + t.lasso) + i
}
abstract sig PositiveTrace extends Trace {}
abstract sig NegativeTrace extends Trace {}
one sig x0, x1, x2, x3, x4 extends Literal {}
one sig T0, T1, T2, T3, T4 extends SeqIdx {}
fact {
    first = T0
    next = T0->T1 + T1->T2 + T2->T3 + T3->T4
}

one sig PT0 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x3->T0 + x4->T0 + x1->T1 + x4->T1 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x2->T0 + x0->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x1->T3 + x3->T3 + x1->T4 + x3->T4) & valuation
}

one sig PT1 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4) & valuation
}

one sig PT2 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x2->T1 + x4->T1 + x2->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T1 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x2->T3 + x0->T4 + x3->T4) & valuation
}

one sig PT3 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x4->T3 + x1->T4 in valuation
    no (x1->T1 + x2->T1 + x3->T1 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT4 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x3->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x4->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x4->T0 + x0->T1 + x1->T1 + x1->T2 + x3->T2 + x2->T3 + x3->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT5 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T1 + x4->T1 + x1->T2 + x2->T3 + x3->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT6 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x3->T3 in valuation
    no (x0->T0 + x3->T0 + x0->T1 + x1->T1 + x0->T2 + x3->T2 + x4->T2 + x0->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT7 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x1->T1 + x1->T2 + x4->T3 + x0->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT8 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x4->T0 + x0->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x2->T2 + x0->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT9 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x3->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T4 + x4->T4 in valuation
    no (x2->T0 + x4->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig PT10 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x4->T0 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3) & valuation
}

one sig PT11 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x3->T1 + x4->T1 + x1->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x2->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT12 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x4->T0 + x0->T1 + x4->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x3->T3 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x4->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT13 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT14 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x2->T1 + x4->T1 + x2->T2 + x4->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4 in valuation
    no (x4->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT15 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x4->T0 + x0->T2 + x2->T2 + x3->T2 + x0->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x4->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x4->T4) & valuation
}

one sig PT16 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4 in valuation
    no (x2->T0 + x3->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT17 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x3->T1 + x4->T1 + x1->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 in valuation
    no (x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT18 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x4->T0 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT19 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x4->T3 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x4->T1 + x1->T2 + x4->T2 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig PT20 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x4->T3 + x0->T4 in valuation
    no (x2->T0 + x3->T0 + x0->T2 + x1->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT21 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x3->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x2->T1 + x0->T2 + x4->T2 + x1->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT22 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x2->T2 + x4->T2 + x3->T3 + x4->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT23 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x1->T4) & valuation
}

one sig PT24 extends PositiveTrace {} {
    lasso = T4->T0
    x4->T0 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x2->T3 + x4->T3 + x1->T4) & valuation
}

one sig PT25 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x4->T0 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT26 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x2->T4 + x3->T4) & valuation
}

one sig PT27 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x4->T0 + x0->T1 + x1->T2 + x2->T2 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4) & valuation
}

one sig PT28 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x3->T0 + x0->T1 + x3->T1 + x4->T1 + x2->T2 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x4->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3) & valuation
}

one sig PT29 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x3->T1 + x3->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x3->T0 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT30 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x1->T3 + x3->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT31 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T4) & valuation
}

one sig PT32 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x3->T0 + x0->T1 + x2->T1 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x4->T3 + x0->T4 in valuation
    no (x2->T0 + x4->T0 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x1->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT33 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x3->T0 + x0->T1 + x0->T2 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x3->T2 + x3->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT34 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x3->T0 + x4->T0 + x0->T2 + x2->T2 + x3->T2 + x2->T3 + x1->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT35 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x3->T0 + x4->T0 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x3->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x3->T1 + x1->T2 + x4->T2 + x0->T3 + x3->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT36 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x3->T2 + x4->T2 + x4->T4 in valuation
    no (x0->T0 + x3->T0 + x0->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT37 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x4->T0 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4 in valuation
    no (x2->T0 + x3->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT38 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x3->T0 + x0->T2 + x1->T2 + x3->T2 + x1->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT39 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x0->T3 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x2->T1 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT40 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x3->T3 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT41 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x3->T1 + x0->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x4->T0 + x1->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4) & valuation
}

one sig PT42 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x2->T1 + x3->T1 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x3->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT43 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x3->T0 + x1->T1 + x2->T1 + x3->T1 + x1->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4) & valuation
}

one sig PT44 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x3->T0 + x1->T1 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x2->T3 + x0->T4 + x3->T4) & valuation
}

one sig PT45 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x3->T2 + x4->T2 + x0->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x4->T4) & valuation
}

one sig PT46 extends PositiveTrace {} {
    lasso = T4->T2
    x4->T0 + x1->T1 + x1->T2 + x2->T2 + x4->T2 + x2->T3 + x4->T3 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT47 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x4->T1 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x4->T0 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x4->T4) & valuation
}

one sig PT48 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x3->T0 + x1->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x1->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x1->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT49 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x3->T3 + x4->T3 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x1->T1 + x4->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x4->T4) & valuation
}

one sig PT50 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x4->T4 in valuation
    no (x1->T0 + x3->T0 + x4->T0 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x2->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4) & valuation
}

one sig PT51 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x1->T2 + x4->T2 + x3->T3 + x4->T4 in valuation
    no (x1->T0 + x1->T1 + x3->T1 + x0->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT52 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x4->T4) & valuation
}

one sig PT53 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x3->T0 + x4->T0 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T3 + x2->T3 + x0->T4 + x4->T4) & valuation
}

one sig PT54 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x3->T0 + x3->T1 + x0->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x4->T4 in valuation
    no (x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x0->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT55 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x3->T0 + x4->T0 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T2 + x3->T2 + x0->T3 + x3->T3 + x0->T4 + x4->T4) & valuation
}

one sig PT56 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x3->T0 + x4->T0 + x2->T1 + x4->T1 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x1->T4 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x4->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT57 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x2->T1 + x3->T1 + x3->T2 + x4->T2 + x3->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT58 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x1->T2 + x2->T3 + x4->T3 + x2->T4 + x4->T4) & valuation
}

one sig PT59 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x4->T1 + x2->T2 + x2->T3 + x2->T4 + x4->T4) & valuation
}

one sig PT60 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x4->T0 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x1->T4 + x3->T4 in valuation
    no (x1->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT61 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x3->T1 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x4->T3 + x3->T4) & valuation
}

one sig PT62 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x2->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T1 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x4->T2 + x1->T3 + x3->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT63 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x3->T4 in valuation
    no (x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT64 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x3->T0 + x0->T1 + x4->T1 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x4->T2 + x4->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT65 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x2->T1 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x3->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x3->T4) & valuation
}

one sig PT66 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x4->T1 + x2->T2 + x1->T4) & valuation
}

one sig PT67 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x2->T4) & valuation
}

one sig PT68 extends PositiveTrace {} {
    lasso = T4->T0
    x3->T0 + x1->T1 + x2->T1 + x4->T1 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x3->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT69 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x4->T0 + x0->T1 + x3->T1 + x4->T1 + x1->T2 + x4->T2 + x0->T3 + x3->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT70 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x4->T0 + x2->T1 + x4->T1 + x0->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x3->T0 + x0->T1 + x1->T1 + x3->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x2->T3 + x4->T3 + x2->T4 + x4->T4) & valuation
}

one sig PT71 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x0->T4 + x4->T4 in valuation
    no (x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT72 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T1 + x3->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x3->T3 + x4->T3 + x1->T4) & valuation
}

one sig PT73 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x3->T0 + x2->T1 + x3->T1 + x1->T2 + x4->T2 + x2->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT74 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x4->T1 + x3->T2 + x0->T3 + x2->T3 + x2->T4 + x4->T4) & valuation
}

one sig PT75 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x4->T0 + x2->T1 + x1->T3 + x2->T4 + x3->T4) & valuation
}

one sig PT76 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT77 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x0->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x3->T1 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4) & valuation
}

one sig PT78 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x3->T0 + x4->T0 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x4->T3 + x0->T4 + x3->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT79 extends PositiveTrace {} {
    lasso = T4->T3
    x4->T0 + x1->T1 + x3->T1 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x3->T3 + x2->T4 + x3->T4) & valuation
}

one sig PT80 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x3->T4 in valuation
    no (x2->T1 + x3->T1 + x0->T2 + x2->T2 + x4->T3 + x0->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT81 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x0->T2 + x0->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig PT82 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x4->T0 + x0->T1 + x1->T1 + x1->T2 + x3->T2 + x4->T2 + x3->T3 + x4->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT83 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x3->T2 + x4->T2 + x1->T3 + x0->T4 in valuation
    no (x4->T0 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT84 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x2->T3 + x0->T4 + x3->T4 in valuation
    no (x1->T0 + x3->T0 + x1->T1 + x4->T1 + x2->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT85 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x3->T0 + x3->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT86 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x3->T2 + x4->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x3->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x3->T4) & valuation
}

one sig PT87 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x3->T0 + x0->T1 + x2->T1 + x3->T1 + x1->T2 + x4->T2 + x0->T3 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x4->T0 + x1->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x4->T4) & valuation
}

one sig PT88 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x3->T0 + x4->T0 + x0->T1 + x3->T1 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x3->T4) & valuation
}

one sig PT89 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x3->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x1->T3 + x3->T3 + x4->T3) & valuation
}

one sig PT90 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x1->T3 + x2->T4 in valuation
    no (x3->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT91 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x3->T0 + x0->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x4->T4 in valuation
    no (x1->T0 + x4->T0 + x1->T1 + x2->T1 + x0->T2 + x4->T2 + x1->T3 + x0->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT92 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x4->T0 + x0->T1 + x4->T2 + x2->T3 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x4->T4) & valuation
}

one sig PT93 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x3->T2 + x1->T3 + x0->T4 + x3->T4 in valuation
    no (x1->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT94 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x3->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T2 + x3->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT95 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x4->T0 + x1->T1 + x3->T1 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig PT96 extends PositiveTrace {} {
    lasso = T4->T2
    x3->T0 + x4->T0 + x0->T1 + x2->T1 + x0->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x0->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT97 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x3->T0 + x2->T1 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x1->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT98 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x3->T2 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x4->T0 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x2->T4 + x3->T4) & valuation
}

one sig PT99 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T1 + x3->T1 + x0->T2 + x3->T2 + x0->T3 + x3->T3 + x4->T3 + x3->T4) & valuation
}

one sig PT100 extends PositiveTrace {} {
    lasso = T4->T2
    x4->T0 + x0->T1 + x4->T1 + x3->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x4->T4) & valuation
}

one sig PT101 extends PositiveTrace {} {
    lasso = T4->T1
    x4->T0 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x3->T3 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x4->T1 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT102 extends PositiveTrace {} {
    lasso = T4->T1
    x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x2->T3 + x4->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT103 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x0->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x4->T1 + x2->T2 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4) & valuation
}

one sig PT104 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x3->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x1->T1 + x3->T1 + x4->T1 + x0->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT105 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T2 + x1->T3 + x2->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT106 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x4->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT107 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x4->T0 + x1->T1 + x2->T1 + x0->T2 + x3->T2 + x4->T2 + x1->T3 + x4->T3 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x3->T0 + x0->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x4->T4) & valuation
}

one sig PT108 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x1->T1 + x3->T1 + x1->T2 + x4->T2 + x2->T3 + x0->T4 + x1->T4 + x4->T4) & valuation
}

one sig PT109 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x4->T0 + x0->T1 + x1->T1 + x3->T1 + x1->T2 + x1->T3 + x4->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT110 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x3->T0 + x0->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x4->T0 + x1->T1 + x2->T1 + x4->T1 + x4->T2 + x0->T3 + x1->T3 + x4->T3 + x3->T4) & valuation
}

one sig PT111 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x3->T0 + x4->T0 + x3->T1 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T4) & valuation
}

one sig PT112 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x2->T3 + x3->T3 + x2->T4 in valuation
    no (x3->T0 + x0->T1 + x1->T1 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT113 extends PositiveTrace {} {
    lasso = T4->T0
    x3->T0 + x4->T0 + x1->T1 + x4->T1 + x2->T2 + x3->T2 + x4->T2 + x4->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT114 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T1 + x3->T1 + x1->T2 + x3->T2 + x1->T3 + x3->T3 + x4->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT115 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x1->T1 + x3->T1 + x4->T1 + x2->T2 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT116 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x0->T2 + x0->T3 + x2->T3 + x4->T3 + x0->T4 + x3->T4 in valuation
    no (x1->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT117 extends PositiveTrace {} {
    lasso = T4->T3
    x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x1->T3 + x2->T3 + x4->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x2->T2 + x4->T2 + x0->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT118 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x3->T0 + x4->T0 + x2->T1 + x0->T2 + x2->T2 + x2->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x4->T4) & valuation
}

one sig PT119 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x0->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT120 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x3->T0 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x1->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT121 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x3->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x4->T4) & valuation
}

one sig PT122 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x2->T1 + x4->T2 + x2->T3 + x4->T3) & valuation
}

one sig PT123 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x4->T2 + x4->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x4->T0 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT124 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x3->T0 + x4->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x3->T3 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT125 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x1->T1 + x1->T2 + x2->T2 + x4->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4) & valuation
}

one sig PT126 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x3->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x2->T0 + x4->T0 + x1->T1 + x3->T1 + x1->T2 + x2->T2 + x0->T3 + x3->T3 + x1->T4 + x3->T4) & valuation
}

one sig PT127 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x3->T2 + x0->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x3->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x3->T4 + x4->T4) & valuation
}

one sig PT128 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x1->T1 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x3->T4 + x4->T4 in valuation
    no (x3->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x0->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT129 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x3->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x2->T0 + x4->T0 + x1->T1 + x2->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x4->T3 + x1->T4 + x3->T4) & valuation
}

one sig PT130 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T3 + x2->T4 + x4->T4 in valuation
    no (x4->T0 + x1->T1 + x3->T1 + x4->T1 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig PT131 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x3->T0 + x1->T1 + x2->T1 + x0->T2 + x3->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x0->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3) & valuation
}

one sig PT132 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x4->T3 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x2->T1 + x4->T1 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT133 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x4->T2 + x3->T4 + x4->T4) & valuation
}

one sig PT134 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x3->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T3 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT135 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x0->T3 + x1->T3 + x4->T3 + x1->T4 + x3->T4) & valuation
}

one sig PT136 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x2->T2 + x4->T2 + x2->T3 + x4->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x1->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT137 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x3->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x4->T3 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x4->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x4->T2 + x0->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT138 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x2->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 in valuation
    no (x1->T0 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x2->T4 + x4->T4) & valuation
}

one sig PT139 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x3->T1 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 + x1->T4 + x4->T4 in valuation
    no (x3->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x2->T3 + x3->T3 + x2->T4 + x3->T4) & valuation
}

one sig PT140 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x2->T1 + x3->T1 + x1->T2 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 + x3->T4) & valuation
}

one sig PT141 extends PositiveTrace {} {
    lasso = T4->T4
    x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x0->T3 + x4->T3 + x3->T4 + x4->T4) & valuation
}

one sig PT142 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x4->T0 + x1->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x0->T1 + x2->T1 + x3->T1 + x3->T2 + x0->T3 + x4->T3) & valuation
}

one sig PT143 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x1->T1 + x1->T2 + x3->T2 + x4->T2 + x4->T3 + x0->T4 + x4->T4) & valuation
}

one sig PT144 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x3->T0 + x0->T1 + x3->T1 + x4->T1 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x4->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x3->T3 + x1->T4 + x3->T4) & valuation
}

one sig PT145 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x3->T1 + x4->T1 + x3->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT146 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x4->T0 + x0->T1 + x3->T1 + x0->T2 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x0->T4 + x4->T4) & valuation
}

one sig PT147 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x3->T0 + x0->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4 in valuation
    no (x1->T0 + x4->T0 + x1->T1 + x2->T1 + x4->T1 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT148 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x3->T2 + x1->T3 + x0->T4 + x4->T4) & valuation
}

one sig PT149 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x1->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x3->T3 + x4->T3 + x3->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT150 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT151 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x4->T0 + x2->T1 + x3->T1 + x0->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x4->T1 + x1->T2 + x3->T2 + x0->T3 + x4->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT152 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x3->T1 + x3->T2 + x3->T3 + x0->T4 + x1->T4 in valuation
    no (x3->T0 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT153 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T4 in valuation
    no (x1->T0 + x3->T0 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT154 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x0->T2 + x4->T2 + x2->T3 + x0->T4 + x1->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4) & valuation
}

one sig PT155 extends PositiveTrace {} {
    lasso = T4->T1
    x3->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x2->T3 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT156 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x1->T4 in valuation
    no (x2->T0 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x4->T2 + x2->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT157 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x1->T1 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 in valuation
    no (x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T4 + x4->T4) & valuation
}

one sig PT158 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x4->T4 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT159 extends PositiveTrace {} {
    lasso = T4->T2
    x3->T0 + x0->T1 + x1->T1 + x1->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x1->T3 + x4->T3 + x0->T4 + x4->T4) & valuation
}

one sig PT160 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x1->T2 + x3->T2 + x2->T3 + x3->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x2->T1 + x3->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x4->T3 + x1->T4 + x3->T4) & valuation
}

one sig PT161 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T1 + x1->T1 + x3->T1 + x4->T1 + x3->T2 + x0->T3 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x4->T4) & valuation
}

one sig PT162 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x3->T0 + x2->T1 + x0->T2 + x2->T2 + x3->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x4->T2 + x1->T3 + x2->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT163 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x3->T0 + x0->T1 + x0->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x4->T3 + x2->T4) & valuation
}

one sig PT164 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x4->T4 in valuation
    no (x1->T0 + x4->T0 + x0->T1 + x4->T1 + x0->T2 + x4->T2 + x0->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT165 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x4->T0 + x2->T1 + x4->T1 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x2->T3 + x4->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT166 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x0->T2 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT167 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x3->T1 + x0->T2 + x2->T2 + x2->T3 + x3->T3 + x0->T4) & valuation
}

one sig PT168 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x1->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4) & valuation
}

one sig PT169 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x3->T1 + x0->T2 + x2->T2 + x3->T3 + x4->T3 in valuation
    no (x1->T0 + x3->T0 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT170 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x3->T0 + x2->T1 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x1->T3 + x3->T3 + x4->T3 + x0->T4) & valuation
}

one sig PT171 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x3->T0 + x0->T1 + x2->T2 + x4->T2 + x0->T3 + x2->T4 + x3->T4 in valuation
    no (x2->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x4->T4) & valuation
}

one sig PT172 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x4->T1 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x2->T3 + x4->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT173 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x3->T0 + x2->T1 + x3->T1 + x4->T1 + x1->T3 in valuation
    no (x1->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT174 extends PositiveTrace {} {
    lasso = T4->T2
    x4->T0 + x2->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT175 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x4->T0 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT176 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T1 + x2->T1 + x4->T1 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x3->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT177 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT178 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x1->T3 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x1->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT179 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x0->T1 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x4->T3 + x3->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT180 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x3->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x4->T3 + x1->T4) & valuation
}

one sig PT181 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x4->T0 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x0->T1 + x3->T1 + x2->T2 + x4->T2 + x4->T3 + x3->T4) & valuation
}

one sig PT182 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x3->T1 + x3->T2 + x0->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT183 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x2->T1 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT184 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT185 extends PositiveTrace {} {
    lasso = T4->T2
    x4->T0 + x4->T1 + x0->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT186 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T2 + x0->T3 + x3->T3 + x2->T4 + x4->T4) & valuation
}

one sig PT187 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x4->T0 + x0->T1 + x3->T1 + x0->T2 + x3->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x3->T0 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x4->T4) & valuation
}

one sig PT188 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x3->T0 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x0->T4 + x1->T4 + x4->T4) & valuation
}

one sig PT189 extends PositiveTrace {} {
    lasso = T4->T0
    x3->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x2->T3 + x4->T3 + x0->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT190 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 in valuation
    no (x1->T0 + x3->T0 + x2->T1 + x4->T1 + x3->T2 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT191 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T2 + x4->T2 + x1->T3 + x4->T3 + x0->T4 + x1->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x4->T0 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x3->T3 + x2->T4 + x3->T4) & valuation
}

one sig PT192 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x1->T3 + x3->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T2 + x4->T2 + x0->T3 + x2->T3 + x4->T3 + x1->T4 + x3->T4) & valuation
}

one sig PT193 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T1 + x1->T1 + x3->T1 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x4->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT194 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 + x3->T1 + x1->T2 + x3->T2 + x2->T3 + x4->T3 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT195 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T1 + x4->T1 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT196 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x3->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x4->T0 + x1->T1 + x2->T1 + x1->T2 + x3->T2 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig PT197 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x4->T1 + x2->T2 + x3->T2 + x4->T2 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x4->T0 + x0->T1 + x3->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT198 extends PositiveTrace {} {
    lasso = T4->T0
    x3->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x4->T2 + x1->T3 + x4->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x3->T1 + x0->T2 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT199 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x1->T1 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x0->T2 + x3->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT200 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x3->T1 + x4->T2 + x1->T3 + x2->T3 + x0->T4 + x3->T4) & valuation
}

one sig PT201 extends PositiveTrace {} {
    lasso = T4->T1
    x4->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x3->T2 + x4->T2 + x1->T3 + x3->T4) & valuation
}

one sig PT202 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x2->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT203 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x4->T0 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x0->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4) & valuation
}

one sig PT204 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x3->T2 + x4->T2 + x2->T3 + x0->T4 in valuation
    no (x2->T0 + x3->T0 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT205 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x2->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT206 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x3->T0 + x3->T1 + x1->T2 + x2->T2 + x3->T2 + x0->T4 + x3->T4) & valuation
}

one sig PT207 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x3->T1 + x4->T2 + x2->T3 + x1->T4 + x3->T4 in valuation
    no (x1->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT208 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4) & valuation
}

one sig PT209 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x1->T1 + x3->T1 + x1->T2 + x4->T2 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT210 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x0->T1 + x1->T2 + x3->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT211 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x3->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x3->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x2->T4) & valuation
}

one sig PT212 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x2->T4 in valuation
    no (x3->T0 + x4->T0 + x0->T2 + x3->T2 + x4->T2 + x3->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT213 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x0->T2 + x0->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3) & valuation
}

one sig PT214 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x3->T0 + x3->T1 + x4->T1 + x0->T2 + x3->T3 + x4->T3) & valuation
}

one sig PT215 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x4->T0 + x1->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT216 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x1->T4) & valuation
}

one sig PT217 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x4->T0 + x3->T1 + x2->T2 + x0->T3 + x1->T4) & valuation
}

one sig PT218 extends PositiveTrace {} {
    lasso = T4->T1
    x4->T0 + x2->T1 + x3->T1 + x0->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x2->T3 + x4->T3 + x0->T4) & valuation
}

one sig PT219 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x3->T0 + x4->T1 + x1->T2 + x4->T3 + x1->T4 in valuation
    no (x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT220 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4) & valuation
}

one sig PT221 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x4->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x3->T0 + x4->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4) & valuation
}

one sig PT222 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x4->T0 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x2->T2 + x4->T2 + x0->T3 + x1->T3) & valuation
}

one sig PT223 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x3->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x2->T2 + x0->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x2->T0 + x4->T0 + x2->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4) & valuation
}

one sig PT224 extends PositiveTrace {} {
    lasso = T4->T0
    x4->T0 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 + x1->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x4->T1 + x2->T3 + x3->T3 + x2->T4 + x3->T4) & valuation
}

one sig PT225 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x3->T3 + x4->T3 in valuation
    no (x0->T0 + x1->T0 + x4->T0 + x4->T1 + x0->T2 + x3->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT226 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x3->T0 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x2->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x4->T0 + x0->T1 + x3->T1 + x0->T2 + x3->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT227 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x2->T0 + x0->T1 + x3->T1 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x4->T4) & valuation
}

one sig PT228 extends PositiveTrace {} {
    lasso = T4->T4
    x2->T0 + x4->T0 + x1->T1 + x3->T1 + x1->T2 + x0->T3 + x4->T3 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT229 extends PositiveTrace {} {
    lasso = T4->T3
    x3->T0 + x4->T0 + x0->T1 + x3->T1 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x4->T3 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT230 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x1->T1 + x4->T1 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T4) & valuation
}

one sig PT231 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x2->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x4->T0 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x2->T4) & valuation
}

one sig PT232 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x3->T0 + x0->T1 + x2->T1 + x4->T1 + x2->T2 + x1->T3 + x2->T3 + x3->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT233 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x4->T0 + x3->T1 + x1->T2 + x3->T2 + x1->T3 + x3->T3 + x4->T3 + x1->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT234 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x4->T4 in valuation
    no (x1->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x2->T2 + x3->T2 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT235 extends PositiveTrace {} {
    lasso = T4->T1
    x4->T0 + x0->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x1->T1 + x3->T1 + x0->T2 + x2->T3 + x3->T3 + x4->T3 + x2->T4 + x4->T4) & valuation
}

one sig PT236 extends PositiveTrace {} {
    lasso = T4->T3
    x3->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x3->T1 + x3->T2 + x4->T2 + x3->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT237 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x4->T0 + x0->T1 + x3->T1 + x0->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x0->T3 + x3->T3 + x4->T3) & valuation
}

one sig PT238 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x4->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T3 + x4->T3 + x2->T4) & valuation
}

one sig PT239 extends PositiveTrace {} {
    lasso = T4->T1
    x4->T0 + x2->T1 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x0->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT240 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT241 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x3->T0 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x3->T4) & valuation
}

one sig PT242 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x1->T2 + x0->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x3->T0 + x2->T1 + x3->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x4->T4) & valuation
}

one sig PT243 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T1 + x0->T2 + x2->T2 + x4->T2 + x3->T3 + x0->T4) & valuation
}

one sig PT244 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x3->T2 + x2->T3 + x3->T3 + x4->T3 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x3->T1 + x4->T1 + x0->T2 + x4->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig PT245 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x2->T1 + x4->T1 + x2->T2 + x3->T2 + x1->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT246 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x2->T4 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x3->T2 + x0->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT247 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x3->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x3->T1 + x1->T2 + x2->T2 + x4->T2 + x2->T3 + x3->T3 + x1->T4 + x3->T4) & valuation
}

one sig PT248 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x2->T2 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x3->T0 + x2->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig PT249 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x1->T1 + x3->T1 + x4->T1 + x3->T2 + x1->T3 + x3->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT250 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x4->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT251 extends PositiveTrace {} {
    lasso = T4->T4
    x4->T0 + x0->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x4->T1 + x3->T2 + x4->T2 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig PT252 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x4->T3) & valuation
}

one sig PT253 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x3->T0 + x3->T1 + x4->T1 + x0->T2 + x4->T2 + x1->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x1->T4 + x4->T4) & valuation
}

one sig PT254 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x2->T3 + x3->T3 + x4->T4 in valuation
    no (x1->T0 + x3->T0 + x2->T1 + x3->T1 + x0->T2 + x4->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT255 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x4->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T4 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x4->T4) & valuation
}

one sig PT256 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x2->T4 + x3->T4 in valuation
    no (x3->T0 + x2->T1 + x1->T2 + x3->T2 + x3->T3 + x0->T4 + x1->T4 + x4->T4) & valuation
}

one sig PT257 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x4->T1 + x1->T2 + x4->T2 + x0->T3 + x4->T3 + x2->T4 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x3->T1 + x0->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT258 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T1 + x3->T1 + x4->T2 + x1->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT259 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x3->T0 + x1->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x4->T3 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x0->T2 + x2->T2 + x2->T3 + x3->T3 + x0->T4 + x3->T4) & valuation
}

one sig PT260 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x3->T0 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x2->T0 + x4->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x3->T3 + x3->T4) & valuation
}

one sig PT261 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x2->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x4->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT262 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x3->T0 + x0->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x4->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T3 + x3->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT263 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x3->T0 + x4->T0 + x3->T1 + x4->T1 + x3->T2 + x4->T2 + x3->T3 + x4->T3 + x3->T4) & valuation
}

one sig PT264 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x3->T1 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x2->T4) & valuation
}

one sig PT265 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x4->T2 + x1->T3 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x3->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT266 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x4->T2 + x0->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x3->T0 + x2->T1 + x0->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x3->T4 + x4->T4) & valuation
}

one sig PT267 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x4->T1 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x4->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT268 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x3->T0 + x4->T0 + x3->T1 + x0->T2 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x0->T4 + x2->T4) & valuation
}

one sig PT269 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x3->T0 + x3->T1 + x4->T1 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x4->T3 + x2->T4 + x4->T4) & valuation
}

one sig PT270 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x2->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x1->T1 + x3->T1 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x1->T4) & valuation
}

one sig PT271 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T1 + x3->T1 + x4->T1 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x3->T2 + x2->T3 + x4->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT272 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x4->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x2->T3 + x4->T3 + x3->T4) & valuation
}

one sig PT273 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x0->T1 + x2->T2 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4) & valuation
}

one sig PT274 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x0->T1 + x4->T1 + x3->T2 + x4->T2 + x1->T3 + x4->T3) & valuation
}

one sig PT275 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T2 + x4->T2 + x3->T3 + x2->T4) & valuation
}

one sig PT276 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x1->T1 + x2->T1 + x1->T3 + x3->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT277 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x3->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4) & valuation
}

one sig PT278 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT279 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x3->T2 + x0->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT280 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x4->T3 + x1->T4 + x3->T4 in valuation
    no (x1->T0 + x3->T0 + x4->T0 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x0->T3 + x2->T3 + x3->T3 + x0->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT281 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x4->T0 + x3->T1 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4) & valuation
}

one sig PT282 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x3->T0 + x4->T1 + x3->T2 + x0->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig PT283 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x4->T0 + x2->T1 + x3->T1 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x0->T1 + x1->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T4) & valuation
}

one sig PT284 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x4->T0 + x2->T1 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T4 + x4->T4) & valuation
}

one sig PT285 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x4->T3 + x1->T4 + x4->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T3 + x3->T3 + x0->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT286 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x4->T4 in valuation
    no (x1->T1 + x2->T1 + x3->T1 + x2->T2 + x4->T2 + x1->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT287 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x4->T0 + x0->T2 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x3->T2 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT288 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T3 + x2->T4) & valuation
}

one sig PT289 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x3->T0 + x4->T0 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x1->T3 + x3->T3 + x1->T4 + x3->T4) & valuation
}

one sig PT290 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x3->T0 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x3->T3 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x2->T0 + x4->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x4->T4) & valuation
}

one sig PT291 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x3->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT292 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x3->T0 + x4->T0 + x2->T1 + x4->T1 + x4->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x2->T3 + x3->T3 + x4->T4) & valuation
}

one sig PT293 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT294 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x3->T2 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4) & valuation
}

one sig PT295 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T2 + x3->T2 + x0->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x3->T4 + x4->T4) & valuation
}

one sig PT296 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x4->T0 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4) & valuation
}

one sig PT297 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T1 + x1->T2 + x3->T2 + x0->T3 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT298 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x4->T1 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT299 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x1->T1 + x2->T1 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x3->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x2->T3 + x3->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT300 extends PositiveTrace {} {
    lasso = T4->T3
    x4->T0 + x0->T1 + x1->T2 + x3->T2 + x1->T3 + x4->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT301 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x3->T0 + x4->T0 + x0->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x4->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT302 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x3->T0 + x3->T1 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT303 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x3->T2 + x4->T2 + x3->T3 + x4->T3 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT304 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x2->T1 + x3->T1 + x1->T2 + x3->T2 + x3->T3 + x0->T4 + x3->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT305 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x4->T0 + x2->T2 + x0->T3 + x2->T3 + x3->T3 + x0->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x4->T3 + x1->T4 + x4->T4) & valuation
}

one sig PT306 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x4->T2 + x0->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x3->T0 + x4->T0 + x2->T1 + x4->T1 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x3->T4) & valuation
}

one sig PT307 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x3->T0 + x1->T1 + x3->T1 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 in valuation
    no (x0->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT308 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x4->T3 + x3->T4 in valuation
    no (x1->T1 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT309 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x3->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x2->T3 + x4->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x4->T0 + x1->T1 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT310 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x2->T2 + x4->T2 + x2->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT311 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x1->T1 + x4->T1 + x2->T2 + x4->T2 + x2->T3 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x4->T0 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT312 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x3->T0 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x1->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x4->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT313 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T1 + x2->T1 + x3->T1 + x1->T2 + x4->T2 + x2->T3 + x3->T3 + x4->T3 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x1->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT314 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x3->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x3->T4 in valuation
    no (x2->T0 + x4->T0 + x1->T1 + x2->T1 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT315 extends PositiveTrace {} {
    lasso = T4->T3
    x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x3->T2 + x4->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x3->T4 + x4->T4) & valuation
}

one sig PT316 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x4->T0 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT317 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x4->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x2->T1 + x3->T1 + x4->T1 + x3->T2 + x1->T3 + x1->T4 + x4->T4) & valuation
}

one sig PT318 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x0->T2 + x4->T2 + x0->T3 + x4->T3 + x0->T4) & valuation
}

one sig PT319 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x2->T4 in valuation
    no (x1->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x1->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT320 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x1->T4 + x4->T4 in valuation
    no (x0->T0 + x3->T0 + x0->T1 + x1->T2 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT321 extends PositiveTrace {} {
    lasso = T4->T4
    x4->T1 + x3->T2 + x4->T3 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT322 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x4->T2 + x0->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT323 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x3->T1 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x4->T4 in valuation
    no (x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x4->T3 + x2->T4 + x3->T4) & valuation
}

one sig PT324 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x4->T1 + x4->T2 + x0->T3 + x1->T3 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x3->T0 + x4->T0 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig PT325 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x1->T3 + x3->T4 + x4->T4) & valuation
}

one sig PT326 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x4->T0 + x0->T1 + x3->T1 + x0->T2 + x2->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T4) & valuation
}

one sig PT327 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x3->T0 + x2->T1 + x3->T1 + x1->T2 + x3->T2 + x2->T3 + x4->T3) & valuation
}

one sig PT328 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x4->T0 + x3->T1 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x1->T4 + x4->T4) & valuation
}

one sig PT329 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x0->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x0->T4) & valuation
}

one sig PT330 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x3->T3 + x4->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x2->T1 + x3->T1 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT331 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T1 + x0->T2 + x3->T2 + x4->T2 + x3->T3 + x4->T3) & valuation
}

one sig PT332 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T2 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT333 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x2->T2 + x3->T2 + x4->T2 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x3->T0 + x4->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x0->T4) & valuation
}

one sig PT334 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x4->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x3->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x3->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT335 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x4->T0 + x0->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x4->T3) & valuation
}

one sig PT336 extends PositiveTrace {} {
    lasso = T4->T4
    x3->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x4->T4) & valuation
}

one sig PT337 extends PositiveTrace {} {
    lasso = T4->T4
    x3->T0 + x4->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x1->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x3->T1 + x4->T1 + x2->T2 + x2->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT338 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T1 + x0->T2 + x1->T2 + x4->T2 + x0->T3 + x0->T4 + x1->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4) & valuation
}

one sig PT339 extends PositiveTrace {} {
    lasso = T4->T2
    x4->T0 + x0->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x3->T3 + x3->T4 + x4->T4) & valuation
}

one sig PT340 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x4->T0 + x4->T1 + x2->T2 + x3->T2 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x3->T4 + x4->T4) & valuation
}

one sig PT341 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x4->T0 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x4->T4) & valuation
}

one sig PT342 extends PositiveTrace {} {
    lasso = T4->T2
    x3->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x4->T2 + x2->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT343 extends PositiveTrace {} {
    lasso = T4->T3
    x4->T0 + x0->T1 + x2->T1 + x2->T2 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x0->T4) & valuation
}

one sig PT344 extends PositiveTrace {} {
    lasso = T4->T4
    x4->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x4->T2 + x2->T3 + x4->T3 + x2->T4) & valuation
}

one sig PT345 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x3->T0 + x3->T1 + x4->T1 + x3->T2 + x0->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x2->T4 + x4->T4) & valuation
}

one sig PT346 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x3->T1 + x0->T2 + x1->T2 + x4->T3 + x0->T4 + x4->T4 in valuation
    no (x0->T1 + x1->T1 + x2->T1 + x4->T1 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT347 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x1->T4 in valuation
    no (x2->T0 + x3->T0 + x4->T0 + x0->T1 + x4->T1 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT348 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT349 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x3->T2 + x4->T2 + x0->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT350 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x4->T0 + x1->T1 + x0->T2 + x4->T2 + x0->T3 + x2->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x3->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x3->T3 + x1->T4 + x4->T4) & valuation
}

one sig PT351 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x2->T3 + x3->T3 + x4->T3 + x2->T4 in valuation
    no (x3->T0 + x0->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT352 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x2->T2 + x4->T2 + x2->T3 + x1->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT353 extends PositiveTrace {} {
    lasso = T4->T2
    x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x2->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x3->T4) & valuation
}

one sig PT354 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x3->T2 + x4->T2 + x4->T3 + x3->T4 in valuation
    no (x1->T0 + x3->T0 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT355 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x2->T4 + x3->T4 in valuation
    no (x0->T1 + x2->T1 + x3->T1 + x1->T2 + x3->T2 + x4->T3 + x1->T4 + x4->T4) & valuation
}

one sig PT356 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T3 + x3->T3 + x4->T3 + x0->T4 in valuation
    no (x1->T0 + x3->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT357 extends PositiveTrace {} {
    lasso = T4->T0
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x3->T3 + x0->T4 + x4->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x4->T1 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT358 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x4->T0 + x4->T1 + x2->T2 + x3->T2 + x2->T3 + x3->T3 + x4->T3 + x2->T4) & valuation
}

one sig PT359 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x3->T0 + x4->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x3->T2 + x1->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT360 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x4->T4 in valuation
    no (x2->T1 + x3->T1 + x0->T2 + x2->T2 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT361 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x0->T3) & valuation
}

one sig PT362 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x4->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x3->T2 + x0->T3 + x3->T3 + x0->T4 + x1->T4) & valuation
}

one sig PT363 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x2->T3 + x3->T3 + x0->T4 + x2->T4 in valuation
    no (x3->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT364 extends PositiveTrace {} {
    lasso = T4->T3
    x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x3->T4) & valuation
}

one sig PT365 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x3->T0 + x4->T0 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x4->T3) & valuation
}

one sig PT366 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x3->T1 + x0->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig PT367 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x3->T4 in valuation
    no (x4->T0 + x1->T1 + x2->T1 + x1->T2 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x4->T4) & valuation
}

one sig PT368 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x2->T0 + x3->T0 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x1->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x4->T3 + x3->T4 + x4->T4) & valuation
}

one sig PT369 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x3->T0 + x3->T1 + x4->T1 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x4->T2 + x3->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT370 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x1->T1 + x3->T1 + x4->T1 + x4->T2 + x1->T3 + x4->T3 + x1->T4 in valuation
    no (x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT371 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x2->T0 + x4->T0 + x3->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x3->T4) & valuation
}

one sig PT372 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 in valuation
    no (x4->T0 + x2->T1 + x4->T1 + x3->T2 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT373 extends PositiveTrace {} {
    lasso = T4->T1
    x1->T0 + x3->T0 + x4->T0 + x2->T1 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x3->T3 + x1->T4) & valuation
}

one sig PT374 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x2->T0 + x3->T0 + x4->T0 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x3->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x4->T4) & valuation
}

one sig PT375 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T1 + x1->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x4->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x2->T1 + x3->T1 + x3->T2 + x2->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT376 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x3->T0 + x4->T0 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x1->T4 + x4->T4 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x2->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT377 extends PositiveTrace {} {
    lasso = T4->T2
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x2->T3 + x4->T3 + x0->T4 + x1->T4 in valuation
    no (x3->T0 + x1->T1 + x3->T1 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT378 extends PositiveTrace {} {
    lasso = T4->T1
    x2->T0 + x0->T1 + x3->T1 + x0->T2 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x4->T1 + x2->T2 + x3->T2 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT379 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x4->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x2->T4 + x3->T4 in valuation
    no (x2->T0 + x3->T0 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x4->T4) & valuation
}

one sig PT380 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x2->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T4 + x2->T4) & valuation
}

one sig PT381 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x3->T0 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x2->T0 + x4->T0 + x0->T1 + x3->T1 + x1->T2 + x3->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x3->T4) & valuation
}

one sig PT382 extends PositiveTrace {} {
    lasso = T4->T2
    x1->T0 + x4->T0 + x3->T1 + x4->T1 + x0->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x3->T2 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT383 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 in valuation
    no (x3->T0 + x4->T0 + x0->T1 + x4->T1 + x3->T2 + x2->T3 + x3->T3 + x4->T3 + x4->T4) & valuation
}

one sig PT384 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x2->T0 + x3->T0 + x2->T1 + x4->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T4 + x3->T4 in valuation
    no (x1->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x4->T4) & valuation
}

one sig PT385 extends PositiveTrace {} {
    lasso = T4->T0
    x2->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x2->T2 + x3->T2 + x3->T3 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x4->T1 + x1->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT386 extends PositiveTrace {} {
    lasso = T4->T3
    x2->T3 + x4->T3 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig PT387 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x2->T0 + x4->T0 + x0->T1 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4) & valuation
}

one sig PT388 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x4->T0 + x1->T1 + x0->T2 + x1->T2 + x3->T2 + x2->T3 + x4->T3 + x0->T4) & valuation
}

one sig PT389 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x3->T0 + x4->T0 + x2->T3 + x3->T3 + x4->T3 + x0->T4) & valuation
}

one sig PT390 extends PositiveTrace {} {
    lasso = T4->T2
    x2->T0 + x3->T0 + x4->T0 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x2->T2 + x4->T3 + x2->T4 + x4->T4) & valuation
}

one sig PT391 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T1 + x3->T1 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x3->T3 + x0->T4) & valuation
}

one sig PT392 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x2->T1 + x4->T1 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4) & valuation
}

one sig PT393 extends PositiveTrace {} {
    lasso = T4->T3
    x0->T0 + x1->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x1->T3 + x3->T3 + x0->T4 + x2->T4 in valuation
    no (x2->T0 + x3->T0 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT394 extends PositiveTrace {} {
    lasso = T4->T0
    x0->T0 + x1->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x2->T2 + x3->T2 + x0->T3 + x4->T3 + x3->T4 + x4->T4 in valuation
    no (x2->T0 + x3->T0 + x1->T1 + x4->T1 + x0->T2 + x1->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig PT395 extends PositiveTrace {} {
    lasso = T4->T4
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x2->T1 + x0->T2 + x1->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x4->T4 in valuation
    no (x3->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x2->T2 + x3->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig PT396 extends PositiveTrace {} {
    lasso = T4->T1
    x3->T0 + x2->T1 + x4->T1 + x1->T2 + x3->T3 + x0->T4 + x1->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x3->T4 + x4->T4) & valuation
}

one sig PT397 extends PositiveTrace {} {
    lasso = T4->T1
    x0->T0 + x1->T0 + x2->T0 + x4->T0 + x1->T2 + x2->T2 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4 in valuation
    no (x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T4) & valuation
}

one sig PT398 extends PositiveTrace {} {
    lasso = T4->T3
    x1->T0 + x2->T0 + x0->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x2->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x3->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig PT399 extends PositiveTrace {} {
    lasso = T4->T4
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x2->T4 + x3->T4 in valuation
    no (x0->T0 + x3->T0 + x4->T0 + x2->T1 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x4->T4) & valuation
}


one sig NT0 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x4->T1 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x3->T4) & valuation
}

one sig NT1 extends NegativeTrace {} {
    lasso = T4->T2
    x3->T0 + x1->T1 + x3->T1 + x4->T1 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT2 extends NegativeTrace {} {
    lasso = T4->T2
    x3->T1 + x0->T2 + x4->T2 + x2->T3 + x4->T3 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT3 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x3->T0 + x4->T0 + x0->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x3->T4) & valuation
}

one sig NT4 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x4->T1 + x3->T2 + x0->T3 + x4->T3 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig NT5 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x3->T1 + x1->T2 + x3->T3 + x0->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT6 extends NegativeTrace {} {
    lasso = T4->T2
    x3->T0 + x0->T2 + x2->T2 + x2->T3 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT7 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x4->T0 + x0->T1 + x3->T1 + x4->T2 + x0->T3 + x3->T3 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT8 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x3->T0 + x4->T0 + x0->T1 + x4->T1 + x0->T2 + x0->T3 + x2->T3 + x4->T3 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT9 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x3->T0 + x0->T1 + x4->T2 + x3->T3 + x4->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT10 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x3->T0 + x1->T1 + x2->T1 + x0->T2 + x4->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x0->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4) & valuation
}

one sig NT11 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x3->T0 + x3->T1 + x4->T1 + x4->T3 + x0->T4 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig NT12 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x4->T0 + x0->T1 + x3->T1 + x0->T2 + x3->T2 + x0->T3 + x3->T3 + x4->T3 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT13 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x3->T0 + x1->T1 + x4->T1 + x2->T2 + x1->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT14 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x3->T0 + x2->T1 + x4->T1 + x0->T2 + x2->T2 + x0->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x3->T4) & valuation
}

one sig NT15 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x3->T0 + x4->T0 + x0->T1 + x0->T2 + x3->T2 + x4->T2 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT16 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x2->T2 + x4->T2 + x0->T3 + x0->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT17 extends NegativeTrace {} {
    lasso = T4->T4
    x3->T0 + x4->T0 + x2->T1 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x4->T3 + x0->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT18 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x4->T0 + x0->T1 + x3->T2 + x2->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4) & valuation
}

one sig NT19 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x3->T0 + x2->T1 + x0->T2 + x2->T2 + x4->T2 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT20 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x3->T0 + x4->T0 + x2->T1 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x4->T3 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig NT21 extends NegativeTrace {} {
    lasso = T4->T1
    x3->T0 + x0->T1 + x3->T1 + x4->T1 + x4->T2 + x3->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT22 extends NegativeTrace {} {
    lasso = T4->T3
    x3->T0 + x4->T0 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x4->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT23 extends NegativeTrace {} {
    lasso = T4->T0
    x3->T0 + x4->T0 + x3->T1 + x4->T1 + x0->T2 + x4->T2 + x4->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT24 extends NegativeTrace {} {
    lasso = T4->T1
    x0->T0 + x3->T0 + x0->T1 + x4->T1 + x0->T2 + x4->T2 + x0->T3 + x3->T3 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig NT25 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x3->T0 + x4->T0 + x3->T1 + x0->T2 + x4->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT26 extends NegativeTrace {} {
    lasso = T4->T2
    x3->T0 + x3->T1 + x4->T1 + x2->T2 + x0->T3 + x4->T3 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT27 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x3->T0 + x4->T1 + x1->T2 + x2->T2 + x0->T3 + x4->T3 + x0->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT28 extends NegativeTrace {} {
    lasso = T4->T4
    x3->T0 + x4->T0 + x4->T1 + x0->T2 + x3->T2 + x0->T3 + x2->T3 + x0->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT29 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x3->T0 + x1->T1 + x0->T2 + x3->T2 + x3->T3 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT30 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x3->T0 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT31 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x3->T0 + x4->T0 + x2->T1 + x0->T3 + x4->T3 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig NT32 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x3->T1 + x4->T1 + x0->T2 + x0->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT33 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x3->T0 + x4->T0 + x0->T2 + x4->T2 + x0->T3 + x3->T3 + x2->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig NT34 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x3->T1 + x4->T1 + x0->T3 + x2->T3 + x4->T3 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT35 extends NegativeTrace {} {
    lasso = T4->T1
    x3->T0 + x4->T0 + x0->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x2->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x3->T1 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4) & valuation
}

one sig NT36 extends NegativeTrace {} {
    lasso = T4->T3
    x3->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT37 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T1 + x1->T2 + x3->T2 + x0->T3 + x2->T3 + x4->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT38 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x4->T0 + x0->T1 + x0->T2 + x0->T3 + x3->T3 + x4->T3 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT39 extends NegativeTrace {} {
    lasso = T4->T2
    x3->T0 + x0->T1 + x3->T1 + x4->T1 + x4->T2 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT40 extends NegativeTrace {} {
    lasso = T4->T3
    x3->T0 + x4->T0 + x1->T1 + x3->T1 + x4->T1 + x3->T2 + x4->T2 + x0->T3 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4) & valuation
}

one sig NT41 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x4->T1 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x2->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT42 extends NegativeTrace {} {
    lasso = T4->T2
    x3->T0 + x1->T1 + x4->T2 + x3->T3 + x4->T3 + x0->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig NT43 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x4->T0 + x1->T1 + x3->T1 + x4->T1 + x3->T2 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT44 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T1 + x3->T1 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT45 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x4->T2 + x0->T3 + x2->T3 + x4->T3 + x0->T4 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x3->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT46 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T0 + x3->T0 + x2->T2 + x0->T3 + x2->T3 in valuation
    no (x1->T0 + x2->T0 + x4->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT47 extends NegativeTrace {} {
    lasso = T4->T4
    x3->T0 + x4->T0 + x1->T1 + x2->T1 + x4->T1 + x2->T2 + x0->T3 + x2->T3 + x4->T3 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x3->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT48 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x3->T0 + x4->T0 + x1->T1 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT49 extends NegativeTrace {} {
    lasso = T4->T3
    x3->T0 + x1->T1 + x4->T1 + x0->T2 + x4->T2 + x2->T3 + x4->T3 + x0->T4 + x2->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x1->T4 + x3->T4) & valuation
}

one sig NT50 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T1 + x3->T1 + x4->T2 + x0->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT51 extends NegativeTrace {} {
    lasso = T4->T0
    x0->T0 + x3->T0 + x0->T1 + x4->T1 + x0->T2 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x4->T4 in valuation
    no (x1->T0 + x2->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT52 extends NegativeTrace {} {
    lasso = T4->T3
    x3->T0 + x4->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT53 extends NegativeTrace {} {
    lasso = T4->T4
    x0->T0 + x3->T0 + x4->T0 + x3->T1 + x0->T2 + x0->T3 + x3->T3 + x2->T4 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT54 extends NegativeTrace {} {
    lasso = T4->T2
    x3->T0 + x1->T1 + x3->T1 + x3->T2 + x4->T2 + x4->T3 + x0->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT55 extends NegativeTrace {} {
    lasso = T4->T3
    x0->T0 + x0->T1 + x3->T1 + x0->T2 + x3->T2 + x3->T4 in valuation
    no (x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig NT56 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x3->T0 + x4->T0 + x0->T1 + x0->T2 + x4->T2 + x0->T3 + x3->T3 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT57 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x3->T0 + x4->T0 + x0->T1 + x4->T1 + x3->T3 + x0->T4 in valuation
    no (x0->T0 + x2->T0 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x4->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT58 extends NegativeTrace {} {
    lasso = T4->T4
    x3->T0 + x1->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x0->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x4->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT59 extends NegativeTrace {} {
    lasso = T4->T1
    x1->T0 + x3->T0 + x0->T1 + x4->T1 + x0->T2 + x2->T2 + x4->T2 + x2->T3 + x4->T3 in valuation
    no (x0->T0 + x2->T0 + x4->T0 + x1->T1 + x2->T1 + x3->T1 + x1->T2 + x3->T2 + x0->T3 + x1->T3 + x3->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT60 extends NegativeTrace {} {
    lasso = T4->T2
    x0->T1 + x3->T1 + x0->T2 + x3->T2 + x4->T2 + x4->T3 + x0->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x1->T1 + x2->T1 + x4->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig NT61 extends NegativeTrace {} {
    lasso = T4->T0
    x3->T0 + x4->T0 + x0->T1 + x0->T2 + x4->T2 + x0->T3 + x0->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x3->T3 + x4->T3 + x1->T4 + x2->T4 + x3->T4 + x4->T4) & valuation
}

one sig NT62 extends NegativeTrace {} {
    lasso = T4->T4
    x1->T0 + x3->T0 + x4->T0 + x0->T2 + x2->T2 + x4->T2 + x0->T3 + x2->T3 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x4->T1 + x1->T2 + x3->T2 + x1->T3 + x3->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4 + x3->T4) & valuation
}

one sig NT63 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x4->T0 + x1->T1 + x1->T2 + x4->T2 + x0->T3 + x3->T3 + x4->T3 + x0->T4 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x2->T2 + x3->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4) & valuation
}

one sig NT64 extends NegativeTrace {} {
    lasso = T4->T3
    x4->T0 + x4->T1 + x3->T2 + x4->T2 + x0->T3 + x3->T3 + x3->T4 + x4->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x0->T1 + x1->T1 + x2->T1 + x3->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x4->T3 + x0->T4 + x1->T4 + x2->T4) & valuation
}

one sig NT65 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T0 + x3->T0 + x4->T0 + x3->T1 + x4->T1 + x4->T2 + x3->T3 + x0->T4 + x3->T4 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x3->T2 + x0->T3 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig NT66 extends NegativeTrace {} {
    lasso = T4->T2
    x1->T1 + x3->T2 + x0->T3 + x3->T3 + x0->T4 + x3->T4 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x3->T0 + x4->T0 + x0->T1 + x2->T1 + x3->T1 + x4->T1 + x0->T2 + x1->T2 + x2->T2 + x4->T2 + x1->T3 + x2->T3 + x4->T3 + x1->T4 + x2->T4 + x4->T4) & valuation
}

one sig NT67 extends NegativeTrace {} {
    lasso = T4->T3
    x1->T0 + x4->T0 + x1->T1 + x3->T1 + x4->T1 + x2->T2 + x0->T3 + x4->T3 + x0->T4 + x2->T4 in valuation
    no (x0->T0 + x2->T0 + x3->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x3->T2 + x4->T2 + x1->T3 + x2->T3 + x3->T3 + x1->T4 + x3->T4 + x4->T4) & valuation
}

one sig LearnedLTL {
    Root: DAGNode
}
fun root: one DAGNode { LearnedLTL.Root }
fun childrenOf[n: DAGNode]: set DAGNode { n.^(l+r) }
fun childrenAndSelfOf[n: DAGNode]: set DAGNode { n.*(l+r) }
fun ancestorsOf[n: DAGNode]: set DAGNode { n.~^(l+r) }
fun ancestorsAndSelfOf[n: DAGNode]: set DAGNode { n.~*(l+r) }
fun subDAG[n: DAGNode]: DAGNode -> DAGNode { n.*(l+r) <: (l+r) }



fun experimentReach: set DAGNode { childrenAndSelfOf[root] }
fun experimentKept: DAGNode -> DAGNode { (none->none) & subDAG[root] }
one sig ExperimentCost { used: set DAGNode }
fact { ExperimentCost.used = experimentReach }
fact ExperimentBounds {
  DAGNode = experimentReach + Literal + (none)
  #experimentReach <= 9
  #(experimentReach & (And + Or + Imply)) <= 2
  minsome ExperimentCost.used
}
run {
    all t: PositiveTrace | root->T0 in t.valuation
    all t: NegativeTrace | root->T0 not in t.valuation
    
} for 14 DAGNode, 5 Int
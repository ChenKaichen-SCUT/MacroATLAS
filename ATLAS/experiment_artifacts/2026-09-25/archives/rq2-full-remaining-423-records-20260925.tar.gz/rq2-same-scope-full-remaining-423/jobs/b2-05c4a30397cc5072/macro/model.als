abstract sig Unit {}
one sig U0, U1, U2, U3, U4 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8 extends Label {}
abstract sig Q {}
one sig Q0 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E27, E29 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4, P5, P6, P7, P8, P9 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos, av20: set Pos, av21: set Pos, av22: set Pos, av23: set Pos, av24: set Pos, av25: set Pos, av26: set Pos, av27: set Pos, av28: set Pos, av29: set Pos, av30: set Pos, av31: set Pos, av32: set Pos, av33: set Pos, av34: set Pos, av35: set Pos, av36: set Pos, av37: set Pos, av38: set Pos, av39: set Pos, av40: set Pos, av41: set Pos, av42: set Pos, av43: set Pos, av44: set Pos, av45: set Pos, av46: set Pos, av47: set Pos, av48: set Pos, av49: set Pos, av50: set Pos, av51: set Pos, av52: set Pos, av53: set Pos, av54: set Pos, av55: set Pos, av56: set Pos, av57: set Pos, av58: set Pos, av59: set Pos, av60: set Pos, av61: set Pos, av62: set Pos, av63: set Pos, av64: set Pos, av65: set Pos, av66: set Pos, av67: set Pos, av68: set Pos, av69: set Pos, av70: set Pos, av71: set Pos, av72: set Pos, av73: set Pos, av74: set Pos, av75: set Pos, av76: set Pos, av77: set Pos, av78: set Pos, av79: set Pos, av80: set Pos, av81: set Pos, av82: set Pos, av83: set Pos, av84: set Pos, av85: set Pos, av86: set Pos, av87: set Pos, av88: set Pos, av89: set Pos, av90: set Pos, av91: set Pos, av92: set Pos, av93: set Pos, av94: set Pos, av95: set Pos, av96: set Pos, av97: set Pos, av98: set Pos, av99: set Pos, av100: set Pos, av101: set Pos, av102: set Pos, av103: set Pos, av104: set Pos, av105: set Pos, av106: set Pos, av107: set Pos, av108: set Pos, av109: set Pos, av110: set Pos, av111: set Pos, av112: set Pos, av113: set Pos, av114: set Pos, av115: set Pos, av116: set Pos, av117: set Pos, av118: set Pos, av119: set Pos, av120: set Pos, av121: set Pos, av122: set Pos, av123: set Pos, av124: set Pos, av125: set Pos, av126: set Pos, av127: set Pos, av128: set Pos, av129: set Pos, av130: set Pos, av131: set Pos, av132: set Pos, av133: set Pos, av134: set Pos, av135: set Pos, av136: set Pos, av137: set Pos, av138: set Pos, av139: set Pos, av140: set Pos, av141: set Pos, av142: set Pos, av143: set Pos, av144: set Pos, av145: set Pos, av146: set Pos, av147: set Pos, av148: set Pos, av149: set Pos, av150: set Pos, av151: set Pos, av152: set Pos, av153: set Pos, av154: set Pos, av155: set Pos, av156: set Pos, av157: set Pos, av158: set Pos, av159: set Pos, av160: set Pos, av161: set Pos, av162: set Pos, av163: set Pos, av164: set Pos, av165: set Pos, av166: set Pos, av167: set Pos, av168: set Pos, av169: set Pos, av170: set Pos, av171: set Pos, av172: set Pos, av173: set Pos, av174: set Pos, av175: set Pos, av176: set Pos, av177: set Pos, av178: set Pos, av179: set Pos, av180: set Pos, av181: set Pos, av182: set Pos, av183: set Pos, av184: set Pos, av185: set Pos, av186: set Pos, av187: set Pos, av188: set Pos, av189: set Pos, av190: set Pos, av191: set Pos, av192: set Pos, av193: set Pos, av194: set Pos, av195: set Pos, av196: set Pos, av197: set Pos, av198: set Pos, av199: set Pos, av200: set Pos, av201: set Pos, av202: set Pos, av203: set Pos, av204: set Pos, av205: set Pos, av206: set Pos, av207: set Pos }
one sig A0, A1, A2, A3, A4 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos, ev20: set Pos, ev21: set Pos, ev22: set Pos, ev23: set Pos, ev24: set Pos, ev25: set Pos, ev26: set Pos, ev27: set Pos, ev28: set Pos, ev29: set Pos, ev30: set Pos, ev31: set Pos, ev32: set Pos, ev33: set Pos, ev34: set Pos, ev35: set Pos, ev36: set Pos, ev37: set Pos, ev38: set Pos, ev39: set Pos, ev40: set Pos, ev41: set Pos, ev42: set Pos, ev43: set Pos, ev44: set Pos, ev45: set Pos, ev46: set Pos, ev47: set Pos, ev48: set Pos, ev49: set Pos, ev50: set Pos, ev51: set Pos, ev52: set Pos, ev53: set Pos, ev54: set Pos, ev55: set Pos, ev56: set Pos, ev57: set Pos, ev58: set Pos, ev59: set Pos, ev60: set Pos, ev61: set Pos, ev62: set Pos, ev63: set Pos, ev64: set Pos, ev65: set Pos, ev66: set Pos, ev67: set Pos, ev68: set Pos, ev69: set Pos, ev70: set Pos, ev71: set Pos, ev72: set Pos, ev73: set Pos, ev74: set Pos, ev75: set Pos, ev76: set Pos, ev77: set Pos, ev78: set Pos, ev79: set Pos, ev80: set Pos, ev81: set Pos, ev82: set Pos, ev83: set Pos, ev84: set Pos, ev85: set Pos, ev86: set Pos, ev87: set Pos, ev88: set Pos, ev89: set Pos, ev90: set Pos, ev91: set Pos, ev92: set Pos, ev93: set Pos, ev94: set Pos, ev95: set Pos, ev96: set Pos, ev97: set Pos, ev98: set Pos, ev99: set Pos, ev100: set Pos, ev101: set Pos, ev102: set Pos, ev103: set Pos, ev104: set Pos, ev105: set Pos, ev106: set Pos, ev107: set Pos, ev108: set Pos, ev109: set Pos, ev110: set Pos, ev111: set Pos, ev112: set Pos, ev113: set Pos, ev114: set Pos, ev115: set Pos, ev116: set Pos, ev117: set Pos, ev118: set Pos, ev119: set Pos, ev120: set Pos, ev121: set Pos, ev122: set Pos, ev123: set Pos, ev124: set Pos, ev125: set Pos, ev126: set Pos, ev127: set Pos, ev128: set Pos, ev129: set Pos, ev130: set Pos, ev131: set Pos, ev132: set Pos, ev133: set Pos, ev134: set Pos, ev135: set Pos, ev136: set Pos, ev137: set Pos, ev138: set Pos, ev139: set Pos, ev140: set Pos, ev141: set Pos, ev142: set Pos, ev143: set Pos, ev144: set Pos, ev145: set Pos, ev146: set Pos, ev147: set Pos, ev148: set Pos, ev149: set Pos, ev150: set Pos, ev151: set Pos, ev152: set Pos, ev153: set Pos, ev154: set Pos, ev155: set Pos, ev156: set Pos, ev157: set Pos, ev158: set Pos, ev159: set Pos, ev160: set Pos, ev161: set Pos, ev162: set Pos, ev163: set Pos, ev164: set Pos, ev165: set Pos, ev166: set Pos, ev167: set Pos, ev168: set Pos, ev169: set Pos, ev170: set Pos, ev171: set Pos, ev172: set Pos, ev173: set Pos, ev174: set Pos, ev175: set Pos, ev176: set Pos, ev177: set Pos, ev178: set Pos, ev179: set Pos, ev180: set Pos, ev181: set Pos, ev182: set Pos, ev183: set Pos, ev184: set Pos, ev185: set Pos, ev186: set Pos, ev187: set Pos, ev188: set Pos, ev189: set Pos, ev190: set Pos, ev191: set Pos, ev192: set Pos, ev193: set Pos, ev194: set Pos, ev195: set Pos, ev196: set Pos, ev197: set Pos, ev198: set Pos, ev199: set Pos, ev200: set Pos, ev201: set Pos, ev202: set Pos, ev203: set Pos, ev204: set Pos, ev205: set Pos, ev206: set Pos, ev207: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (T0 + T1) }
fun un: set Label { ((T2 + T3) + (T4 + T5)) }
fun bin: set Label { (T6 + (T7 + T8)) }
fun nonempty: set Fiber { ((((E1 + (E2 + E3)) + (E4 + (E5 + E6))) + ((E7 + (E8 + E9)) + ((E10 + E11) + (E12 + E13)))) + (((E14 + (E15 + E16)) + ((E17 + E18) + (E19 + E20))) + ((E21 + (E22 + E23)) + ((E24 + E25) + (E27 + E29))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { ((U0->U1 + U1->U2) + (U2->U3 + U3->U4)) }
fun carrierNext: Carrier -> Carrier { ((((A0->A1 + A1->A2) + (A2->A3 + (A3->A4 + A4->R))) + ((R->C0 + C0->L0) + (L0->D0 + (D0->C1 + C1->L1)))) + (((L1->D1 + D1->C2) + (C2->L2 + (L2->D2 + D2->C3))) + ((C3->L3 + L3->D3) + (D3->C4 + (C4->L4 + L4->D4))))) }
fun child[a: Anchor]: set Port { a.(((A0->C0 + A1->C1) + (A2->C2 + (A3->C3 + A4->C4)))) }
fun left[a: Anchor]: set Port { a.(((A0->L0 + A1->L1) + (A2->L2 + (A3->L3 + A4->L4)))) }
fun right[a: Anchor]: set Port { a.(((A0->D0 + A1->D1) + (A2->D2 + (A3->D3 + A4->D4)))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
no A3.graph & (((A0 + A1) + (A2 + A3)))
no A4.graph & (((A0 + A1) + (A2 + (A3 + A4))))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un implies #(target.A2) > 1
some A2.lab implies some A1.lab
some A3.lab and A3.lab in un implies #(target.A3) > 1
some A3.lab implies some A2.lab
some A4.lab and A4.lab in un implies #(target.A4) > 1
some A4.lab implies some A3.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q0
E7.qo = Q0
E8.qi = Q0
E8.qo = Q0
E9.qi = Q0
E9.qo = Q0
E10.qi = Q0
E10.qo = Q0
E11.qi = Q0
E11.qo = Q0
E12.qi = Q0
E12.qo = Q0
E13.qi = Q0
E13.qo = Q0
E14.qi = Q0
E14.qo = Q0
E15.qi = Q0
E15.qo = Q0
E16.qi = Q0
E16.qo = Q0
E17.qi = Q0
E17.qo = Q0
E18.qi = Q0
E18.qo = Q0
E19.qi = Q0
E19.qo = Q0
E20.qi = Q0
E20.qo = Q0
E21.qi = Q0
E21.qo = Q0
E22.qi = Q0
E22.qo = Q0
E23.qi = Q0
E23.qo = Q0
E24.qi = Q0
E24.qo = Q0
E25.qi = Q0
E25.qo = Q0
E27.qi = Q0
E27.qo = Q0
E29.qi = Q0
E29.qo = Q0
all e: used | e.fiber in (E0) implies #e.cost = 0
all e: used | e.fiber in ((((E1 + E4) + (E6 + E7)) + ((E9 + E12) + (E13 + (E15 + E17))))) implies #e.cost = 2
all e: used | e.fiber in (((E2 + E3) + (E5 + E11))) implies #e.cost = 1
all e: used | e.fiber in ((((E8 + E10) + (E14 + E16)) + ((E18 + E19) + (E21 + E23)))) implies #e.cost = 3
all e: used | e.fiber in (((E20 + (E22 + E24)) + (E25 + (E27 + E29)))) implies #e.cost = 4
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q0)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T3 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T4 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T5 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T8 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
}
fun range0: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop0: set Pos { ((P3 + (P4 + P5)) + (P6 + (P7 + P8))) }
fun next0: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P3)))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift0_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P3)))) }
fun shift0_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P3 + P8->P4)))) }
fun shift0_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P3 + (P7->P4 + P8->P5)))) }
fun shift0_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P3) + (P6->P4 + (P7->P5 + P8->P6)))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range0 | loop0 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range0 | loop0 in (range0 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range0 | some (loop0 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range0 | some (loop0 & (range0 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range0 | (i.shift0_1) in (range0 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range0 | (i.shift0_1).future0 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range0 | (i.shift0_1).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range0 | (i.shift0_2) in (range0 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range0 | (i.shift0_2).future0 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range0 | (i.shift0_2).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range0 | (i.shift0_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range0 | (i.shift0_3) in (range0 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range0 | some ((i.shift0_3).future0 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range0 | (i.shift0_3).future0 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range0 | (i.shift0_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next0.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop1: set Pos { P3 }
fun next1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift1_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun shift1_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P3 + P3->P3)) }
fun shift1_3: Pos -> Pos { ((P0->P3 + P1->P3) + (P2->P3 + P3->P3)) }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range1 | loop1 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range1 | loop1 in (range1 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range1 | some (loop1 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range1 | some (loop1 & (range1 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range1 | (i.shift1_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range1 | (i.shift1_1) in (range1 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range1 | (i.shift1_1).future1 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range1 | (i.shift1_1).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range1 | (i.shift1_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range1 | (i.shift1_2) in (range1 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range1 | (i.shift1_2).future1 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range1 | (i.shift1_2).future1 in (range1 - e.target.av)}
all e: used | e.fiber in ((E23 + E29)) implies e.ev = {i: range1 | (i.shift1_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range1 | (i.shift1_3) in (range1 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range1 | some ((i.shift1_3).future1 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range1 | (i.shift1_3).future1 in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next1.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fun range2: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop2: set Pos { ((P4 + P5) + (P6 + (P7 + P8))) }
fun next2: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P4)))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift2_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P4)))) }
fun shift2_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P4 + P8->P5)))) }
fun shift2_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P4 + (P7->P5 + P8->P6)))) }
fun shift2_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P4) + (P6->P5 + (P7->P6 + P8->P7)))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range2 | (i.shift2_0) in (range2 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range2 | (i.shift2_0).future2 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range2 | (i.shift2_0).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range2 | loop2 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range2 | loop2 in (range2 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range2 | some (loop2 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range2 | some (loop2 & (range2 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range2 | (i.shift2_1) in (range2 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range2 | (i.shift2_1).future2 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range2 | (i.shift2_1).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range2 | (i.shift2_2) in (range2 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range2 | (i.shift2_2).future2 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range2 | (i.shift2_2).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range2 | (i.shift2_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range2 | (i.shift2_3) in (range2 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range2 | some ((i.shift2_3).future2 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range2 | (i.shift2_3).future2 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range2 | (i.shift2_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range2 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next2.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range2 | some (i.future2 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range2 | i.future2 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range2 - left[a].ev) + right[a].ev)
}
fun range3: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop3: set Pos { ((P5 + P6) + (P7 + (P8 + P9))) }
fun next3: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P5)))) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift3_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P5)))) }
fun shift3_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P5 + P9->P6)))) }
fun shift3_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P5 + (P8->P6 + P9->P7)))) }
fun shift3_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P5) + (P7->P6 + (P8->P7 + P9->P8)))) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range3 | (i.shift3_0) in (range3 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range3 | (i.shift3_0).future3 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range3 | (i.shift3_0).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range3 | loop3 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range3 | loop3 in (range3 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range3 | some (loop3 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range3 | some (loop3 & (range3 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range3 | (i.shift3_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range3 | (i.shift3_1) in (range3 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range3 | (i.shift3_1).future3 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range3 | (i.shift3_1).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range3 | (i.shift3_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range3 | (i.shift3_2) in (range3 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range3 | (i.shift3_2).future3 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range3 | (i.shift3_2).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range3 | (i.shift3_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range3 | (i.shift3_3) in (range3 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range3 | some ((i.shift3_3).future3 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range3 | (i.shift3_3).future3 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range3 | (i.shift3_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range3 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next3.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range3 | some (i.future3 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range3 | i.future3 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range3 - left[a].ev) + right[a].ev)
}
fun range4: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop4: set Pos { ((P4 + (P5 + P6)) + (P7 + (P8 + P9))) }
fun next4: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P4)))) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift4_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P4)))) }
fun shift4_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P4 + P9->P5)))) }
fun shift4_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P4 + (P8->P5 + P9->P6)))) }
fun shift4_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P4) + (P7->P5 + (P8->P6 + P9->P7)))) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range4 | (i.shift4_0) in (range4 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range4 | (i.shift4_0).future4 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range4 | (i.shift4_0).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range4 | loop4 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range4 | loop4 in (range4 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range4 | some (loop4 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range4 | some (loop4 & (range4 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range4 | (i.shift4_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range4 | (i.shift4_1) in (range4 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range4 | (i.shift4_1).future4 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range4 | (i.shift4_1).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range4 | (i.shift4_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range4 | (i.shift4_2) in (range4 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range4 | (i.shift4_2).future4 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range4 | (i.shift4_2).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range4 | (i.shift4_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range4 | (i.shift4_3) in (range4 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range4 | some ((i.shift4_3).future4 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range4 | (i.shift4_3).future4 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range4 | (i.shift4_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range4 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next4.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range4 | some (i.future4 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range4 | i.future4 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range4 - left[a].ev) + right[a].ev)
}
fun range5: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop5: set Pos { (P8 + P9) }
fun next5: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P8)))) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift5_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P8)))) }
fun shift5_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P8 + P9->P9)))) }
fun shift5_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P8 + (P8->P9 + P9->P8)))) }
fun shift5_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P8) + (P7->P9 + (P8->P8 + P9->P9)))) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range5 | (i.shift5_0) in (range5 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range5 | (i.shift5_0).future5 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range5 | (i.shift5_0).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range5 | loop5 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range5 | loop5 in (range5 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range5 | some (loop5 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range5 | some (loop5 & (range5 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range5 | (i.shift5_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range5 | (i.shift5_1) in (range5 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range5 | (i.shift5_1).future5 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range5 | (i.shift5_1).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range5 | (i.shift5_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range5 | (i.shift5_2) in (range5 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range5 | (i.shift5_2).future5 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range5 | (i.shift5_2).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range5 | (i.shift5_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range5 | (i.shift5_3) in (range5 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range5 | some ((i.shift5_3).future5 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range5 | (i.shift5_3).future5 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range5 | (i.shift5_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range5 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next5.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range5 | some (i.future5 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range5 | i.future5 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range5 - left[a].ev) + right[a].ev)
}
fun range6: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop6: set Pos { (P7 + P8) }
fun next6: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P7)))) }
fun future6: Pos -> Pos { (*next6) & (range6->range6) }
fun shift6_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift6_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P7)))) }
fun shift6_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P7 + P8->P8)))) }
fun shift6_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P7 + (P7->P8 + P8->P7)))) }
fun shift6_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P7) + (P6->P8 + (P7->P7 + P8->P8)))) }
pred semantics6[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range6
ev in used->range6
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range6 | (i.shift6_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range6 | (i.shift6_0) in (range6 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range6 | (i.shift6_0).future6 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range6 | (i.shift6_0).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range6 | loop6 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range6 | loop6 in (range6 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range6 | some (loop6 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range6 | some (loop6 & (range6 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range6 | (i.shift6_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range6 | (i.shift6_1) in (range6 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range6 | (i.shift6_1).future6 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range6 | (i.shift6_1).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range6 | (i.shift6_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range6 | (i.shift6_2) in (range6 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range6 | (i.shift6_2).future6 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range6 | (i.shift6_2).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range6 | (i.shift6_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range6 | (i.shift6_3) in (range6 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range6 | some ((i.shift6_3).future6 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range6 | (i.shift6_3).future6 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range6 | (i.shift6_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range6 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next6.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range6 | some (i.future6 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range6 | i.future6 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range6 - left[a].ev) + right[a].ev)
}
fun range7: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop7: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun next7: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P0)))) }
fun future7: Pos -> Pos { (*next7) & (range7->range7) }
fun shift7_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift7_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P0)))) }
fun shift7_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P0 + P9->P1)))) }
fun shift7_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P0 + (P8->P1 + P9->P2)))) }
fun shift7_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P0) + (P7->P1 + (P8->P2 + P9->P3)))) }
pred semantics7[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range7
ev in used->range7
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range7 | (i.shift7_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range7 | (i.shift7_0) in (range7 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range7 | (i.shift7_0).future7 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range7 | (i.shift7_0).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range7 | loop7 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range7 | loop7 in (range7 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range7 | some (loop7 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range7 | some (loop7 & (range7 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range7 | (i.shift7_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range7 | (i.shift7_1) in (range7 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range7 | (i.shift7_1).future7 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range7 | (i.shift7_1).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range7 | (i.shift7_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range7 | (i.shift7_2) in (range7 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range7 | some ((i.shift7_2).future7 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range7 | some ((i.shift7_2).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range7 | (i.shift7_2).future7 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range7 | (i.shift7_2).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range7 | (i.shift7_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range7 | (i.shift7_3) in (range7 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range7 | some ((i.shift7_3).future7 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range7 | (i.shift7_3).future7 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range7 | (i.shift7_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range7 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next7.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range7 | some (i.future7 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range7 | i.future7 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range7 - left[a].ev) + right[a].ev)
}
fun range8: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop8: set Pos { P9 }
fun next8: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P9)))) }
fun future8: Pos -> Pos { (*next8) & (range8->range8) }
fun shift8_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift8_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P9)))) }
fun shift8_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P9 + P9->P9)))) }
fun shift8_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P9 + (P8->P9 + P9->P9)))) }
fun shift8_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P9) + (P7->P9 + (P8->P9 + P9->P9)))) }
pred semantics8[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range8
ev in used->range8
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range8 | (i.shift8_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range8 | (i.shift8_0) in (range8 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range8 | (i.shift8_0).future8 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range8 | (i.shift8_0).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range8 | loop8 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range8 | loop8 in (range8 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range8 | some (loop8 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range8 | some (loop8 & (range8 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range8 | (i.shift8_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range8 | (i.shift8_1) in (range8 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range8 | (i.shift8_1).future8 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range8 | (i.shift8_1).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range8 | (i.shift8_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range8 | (i.shift8_2) in (range8 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range8 | some ((i.shift8_2).future8 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range8 | some ((i.shift8_2).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range8 | (i.shift8_2).future8 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range8 | (i.shift8_2).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range8 | (i.shift8_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range8 | (i.shift8_3) in (range8 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range8 | some ((i.shift8_3).future8 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range8 | (i.shift8_3).future8 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range8 | (i.shift8_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range8 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next8.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range8 | some (i.future8 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range8 | i.future8 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range8 - left[a].ev) + right[a].ev)
}
fun range9: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop9: set Pos { (((P2 + P3) + (P4 + P5)) + ((P6 + P7) + (P8 + P9))) }
fun next9: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P2)))) }
fun future9: Pos -> Pos { (*next9) & (range9->range9) }
fun shift9_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift9_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P2)))) }
fun shift9_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P2 + P9->P3)))) }
fun shift9_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P2 + (P8->P3 + P9->P4)))) }
fun shift9_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P2) + (P7->P3 + (P8->P4 + P9->P5)))) }
pred semantics9[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range9
ev in used->range9
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range9 | (i.shift9_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range9 | (i.shift9_0) in (range9 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range9 | (i.shift9_0).future9 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range9 | (i.shift9_0).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range9 | loop9 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range9 | loop9 in (range9 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range9 | some (loop9 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range9 | some (loop9 & (range9 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range9 | (i.shift9_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range9 | (i.shift9_1) in (range9 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range9 | (i.shift9_1).future9 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range9 | (i.shift9_1).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range9 | (i.shift9_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range9 | (i.shift9_2) in (range9 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range9 | some ((i.shift9_2).future9 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range9 | some ((i.shift9_2).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range9 | (i.shift9_2).future9 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range9 | (i.shift9_2).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range9 | (i.shift9_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range9 | (i.shift9_3) in (range9 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range9 | some ((i.shift9_3).future9 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range9 | (i.shift9_3).future9 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range9 | (i.shift9_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range9 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next9.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range9 | some (i.future9 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range9 | i.future9 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range9 - left[a].ev) + right[a].ev)
}
fun range10: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop10: set Pos { (P7 + (P8 + P9)) }
fun next10: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P7)))) }
fun future10: Pos -> Pos { (*next10) & (range10->range10) }
fun shift10_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift10_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P7)))) }
fun shift10_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P7 + P9->P8)))) }
fun shift10_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift10_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P7) + (P7->P8 + (P8->P9 + P9->P7)))) }
pred semantics10[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range10
ev in used->range10
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range10 | (i.shift10_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range10 | (i.shift10_0) in (range10 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range10 | (i.shift10_0).future10 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range10 | (i.shift10_0).future10 in (range10 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range10 | loop10 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range10 | loop10 in (range10 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range10 | some (loop10 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range10 | some (loop10 & (range10 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range10 | (i.shift10_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range10 | (i.shift10_1) in (range10 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range10 | some ((i.shift10_1).future10 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range10 | some ((i.shift10_1).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range10 | (i.shift10_1).future10 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range10 | (i.shift10_1).future10 in (range10 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range10 | (i.shift10_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range10 | (i.shift10_2) in (range10 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range10 | some ((i.shift10_2).future10 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range10 | some ((i.shift10_2).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range10 | (i.shift10_2).future10 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range10 | (i.shift10_2).future10 in (range10 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range10 | (i.shift10_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range10 | (i.shift10_3) in (range10 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range10 | some ((i.shift10_3).future10 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range10 | (i.shift10_3).future10 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range10 | (i.shift10_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range10 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next10.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range10 | some (i.future10 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range10 | i.future10 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range10 - left[a].ev) + right[a].ev)
}
fun range11: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop11: set Pos { ((P6 + P7) + (P8 + P9)) }
fun next11: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P6)))) }
fun future11: Pos -> Pos { (*next11) & (range11->range11) }
fun shift11_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift11_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P6)))) }
fun shift11_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P6 + P9->P7)))) }
fun shift11_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P6 + (P8->P7 + P9->P8)))) }
fun shift11_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
pred semantics11[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range11
ev in used->range11
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range11 | (i.shift11_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range11 | (i.shift11_0) in (range11 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range11 | some ((i.shift11_0).future11 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range11 | some ((i.shift11_0).future11 & (range11 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range11 | (i.shift11_0).future11 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range11 | (i.shift11_0).future11 in (range11 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range11 | loop11 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range11 | loop11 in (range11 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range11 | some (loop11 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range11 | some (loop11 & (range11 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range11 | (i.shift11_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range11 | (i.shift11_1) in (range11 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range11 | some ((i.shift11_1).future11 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range11 | some ((i.shift11_1).future11 & (range11 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range11 | (i.shift11_1).future11 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range11 | (i.shift11_1).future11 in (range11 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range11 | (i.shift11_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range11 | (i.shift11_2) in (range11 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range11 | some ((i.shift11_2).future11 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range11 | some ((i.shift11_2).future11 & (range11 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range11 | (i.shift11_2).future11 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range11 | (i.shift11_2).future11 in (range11 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range11 | (i.shift11_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range11 | (i.shift11_3) in (range11 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range11 | some ((i.shift11_3).future11 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range11 | (i.shift11_3).future11 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range11 | (i.shift11_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range11 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next11.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range11 | some (i.future11 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range11 | i.future11 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range11 - left[a].ev) + right[a].ev)
}
fun range12: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop12: set Pos { (((P1 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun next12: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P1)))) }
fun future12: Pos -> Pos { (*next12) & (range12->range12) }
fun shift12_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift12_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P1)))) }
fun shift12_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P1 + P9->P2)))) }
fun shift12_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P1 + (P8->P2 + P9->P3)))) }
fun shift12_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P1) + (P7->P2 + (P8->P3 + P9->P4)))) }
pred semantics12[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range12
ev in used->range12
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range12 | (i.shift12_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range12 | (i.shift12_0) in (range12 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range12 | some ((i.shift12_0).future12 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range12 | some ((i.shift12_0).future12 & (range12 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range12 | (i.shift12_0).future12 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range12 | (i.shift12_0).future12 in (range12 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range12 | loop12 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range12 | loop12 in (range12 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range12 | some (loop12 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range12 | some (loop12 & (range12 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range12 | (i.shift12_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range12 | (i.shift12_1) in (range12 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range12 | some ((i.shift12_1).future12 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range12 | some ((i.shift12_1).future12 & (range12 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range12 | (i.shift12_1).future12 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range12 | (i.shift12_1).future12 in (range12 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range12 | (i.shift12_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range12 | (i.shift12_2) in (range12 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range12 | some ((i.shift12_2).future12 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range12 | some ((i.shift12_2).future12 & (range12 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range12 | (i.shift12_2).future12 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range12 | (i.shift12_2).future12 in (range12 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range12 | (i.shift12_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range12 | (i.shift12_3) in (range12 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range12 | some ((i.shift12_3).future12 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range12 | (i.shift12_3).future12 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range12 | (i.shift12_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range12 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next12.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range12 | some (i.future12 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range12 | i.future12 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range12 - left[a].ev) + right[a].ev)
}
fun range13: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) }
fun loop13: set Pos { (P5 + (P6 + P7)) }
fun next13: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P5))) }
fun future13: Pos -> Pos { (*next13) & (range13->range13) }
fun shift13_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) }
fun shift13_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P5))) }
fun shift13_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P5 + P7->P6))) }
fun shift13_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P5) + (P6->P6 + P7->P7))) }
fun shift13_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P5))) }
pred semantics13[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range13
ev in used->range13
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range13 | (i.shift13_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range13 | (i.shift13_0) in (range13 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range13 | some ((i.shift13_0).future13 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range13 | some ((i.shift13_0).future13 & (range13 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range13 | (i.shift13_0).future13 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range13 | (i.shift13_0).future13 in (range13 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range13 | loop13 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range13 | loop13 in (range13 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range13 | some (loop13 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range13 | some (loop13 & (range13 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range13 | (i.shift13_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range13 | (i.shift13_1) in (range13 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range13 | some ((i.shift13_1).future13 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range13 | some ((i.shift13_1).future13 & (range13 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range13 | (i.shift13_1).future13 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range13 | (i.shift13_1).future13 in (range13 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range13 | (i.shift13_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range13 | (i.shift13_2) in (range13 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range13 | some ((i.shift13_2).future13 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range13 | some ((i.shift13_2).future13 & (range13 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range13 | (i.shift13_2).future13 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range13 | (i.shift13_2).future13 in (range13 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range13 | (i.shift13_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range13 | (i.shift13_3) in (range13 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range13 | some ((i.shift13_3).future13 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range13 | (i.shift13_3).future13 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range13 | (i.shift13_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range13 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next13.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range13 | some (i.future13 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range13 | i.future13 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range13 - left[a].ev) + right[a].ev)
}
fun range14: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop14: set Pos { P8 }
fun next14: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P8)))) }
fun future14: Pos -> Pos { (*next14) & (range14->range14) }
fun shift14_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift14_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P8)))) }
fun shift14_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P8 + P8->P8)))) }
fun shift14_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P8 + (P7->P8 + P8->P8)))) }
fun shift14_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P8) + (P6->P8 + (P7->P8 + P8->P8)))) }
pred semantics14[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range14
ev in used->range14
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range14 | (i.shift14_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range14 | (i.shift14_0) in (range14 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range14 | some ((i.shift14_0).future14 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range14 | some ((i.shift14_0).future14 & (range14 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range14 | (i.shift14_0).future14 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range14 | (i.shift14_0).future14 in (range14 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range14 | loop14 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range14 | loop14 in (range14 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range14 | some (loop14 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range14 | some (loop14 & (range14 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range14 | (i.shift14_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range14 | (i.shift14_1) in (range14 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range14 | some ((i.shift14_1).future14 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range14 | some ((i.shift14_1).future14 & (range14 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range14 | (i.shift14_1).future14 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range14 | (i.shift14_1).future14 in (range14 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range14 | (i.shift14_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range14 | (i.shift14_2) in (range14 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range14 | some ((i.shift14_2).future14 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range14 | some ((i.shift14_2).future14 & (range14 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range14 | (i.shift14_2).future14 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range14 | (i.shift14_2).future14 in (range14 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range14 | (i.shift14_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range14 | (i.shift14_3) in (range14 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range14 | some ((i.shift14_3).future14 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range14 | (i.shift14_3).future14 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range14 | (i.shift14_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range14 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next14.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range14 | some (i.future14 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range14 | i.future14 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range14 - left[a].ev) + right[a].ev)
}
fun range15: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop15: set Pos { (((P1 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + P8))) }
fun next15: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P1)))) }
fun future15: Pos -> Pos { (*next15) & (range15->range15) }
fun shift15_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift15_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P1)))) }
fun shift15_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P1 + P8->P2)))) }
fun shift15_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P1 + (P7->P2 + P8->P3)))) }
fun shift15_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P1) + (P6->P2 + (P7->P3 + P8->P4)))) }
pred semantics15[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range15
ev in used->range15
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range15 | (i.shift15_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range15 | (i.shift15_0) in (range15 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range15 | some ((i.shift15_0).future15 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range15 | some ((i.shift15_0).future15 & (range15 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range15 | (i.shift15_0).future15 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range15 | (i.shift15_0).future15 in (range15 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range15 | loop15 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range15 | loop15 in (range15 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range15 | some (loop15 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range15 | some (loop15 & (range15 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range15 | (i.shift15_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range15 | (i.shift15_1) in (range15 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range15 | some ((i.shift15_1).future15 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range15 | some ((i.shift15_1).future15 & (range15 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range15 | (i.shift15_1).future15 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range15 | (i.shift15_1).future15 in (range15 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range15 | (i.shift15_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range15 | (i.shift15_2) in (range15 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range15 | some ((i.shift15_2).future15 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range15 | some ((i.shift15_2).future15 & (range15 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range15 | (i.shift15_2).future15 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range15 | (i.shift15_2).future15 in (range15 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range15 | (i.shift15_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range15 | (i.shift15_3) in (range15 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range15 | some ((i.shift15_3).future15 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range15 | (i.shift15_3).future15 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range15 | (i.shift15_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range15 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next15.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range15 | some (i.future15 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range15 | i.future15 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range15 - left[a].ev) + right[a].ev)
}
fun range16: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) }
fun loop16: set Pos { ((P4 + P5) + (P6 + P7)) }
fun next16: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P4))) }
fun future16: Pos -> Pos { (*next16) & (range16->range16) }
fun shift16_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) }
fun shift16_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P4))) }
fun shift16_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P4 + P7->P5))) }
fun shift16_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P4) + (P6->P5 + P7->P6))) }
fun shift16_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) }
pred semantics16[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range16
ev in used->range16
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range16 | (i.shift16_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range16 | (i.shift16_0) in (range16 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range16 | some ((i.shift16_0).future16 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range16 | some ((i.shift16_0).future16 & (range16 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range16 | (i.shift16_0).future16 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range16 | (i.shift16_0).future16 in (range16 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range16 | loop16 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range16 | loop16 in (range16 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range16 | some (loop16 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range16 | some (loop16 & (range16 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range16 | (i.shift16_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range16 | (i.shift16_1) in (range16 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range16 | some ((i.shift16_1).future16 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range16 | some ((i.shift16_1).future16 & (range16 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range16 | (i.shift16_1).future16 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range16 | (i.shift16_1).future16 in (range16 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range16 | (i.shift16_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range16 | (i.shift16_2) in (range16 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range16 | some ((i.shift16_2).future16 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range16 | some ((i.shift16_2).future16 & (range16 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range16 | (i.shift16_2).future16 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range16 | (i.shift16_2).future16 in (range16 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range16 | (i.shift16_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range16 | (i.shift16_3) in (range16 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range16 | some ((i.shift16_3).future16 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range16 | (i.shift16_3).future16 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range16 | (i.shift16_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range16 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next16.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range16 | some (i.future16 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range16 | i.future16 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range16 - left[a].ev) + right[a].ev)
}
fun range17: set Pos { (((P0 + P1) + (P2 + (P3 + P4))) + ((P5 + P6) + (P7 + (P8 + P9)))) }
fun loop17: set Pos { ((P3 + (P4 + P5)) + ((P6 + P7) + (P8 + P9))) }
fun next17: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P3)))) }
fun future17: Pos -> Pos { (*next17) & (range17->range17) }
fun shift17_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) + ((P5->P5 + P6->P6) + (P7->P7 + (P8->P8 + P9->P9)))) }
fun shift17_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P5))) + ((P5->P6 + P6->P7) + (P7->P8 + (P8->P9 + P9->P3)))) }
fun shift17_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + (P3->P5 + P4->P6))) + ((P5->P7 + P6->P8) + (P7->P9 + (P8->P3 + P9->P4)))) }
fun shift17_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + (P3->P6 + P4->P7))) + ((P5->P8 + P6->P9) + (P7->P3 + (P8->P4 + P9->P5)))) }
fun shift17_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + (P3->P7 + P4->P8))) + ((P5->P9 + P6->P3) + (P7->P4 + (P8->P5 + P9->P6)))) }
pred semantics17[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range17
ev in used->range17
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range17 | (i.shift17_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range17 | (i.shift17_0) in (range17 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range17 | some ((i.shift17_0).future17 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range17 | some ((i.shift17_0).future17 & (range17 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range17 | (i.shift17_0).future17 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range17 | (i.shift17_0).future17 in (range17 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range17 | loop17 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range17 | loop17 in (range17 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range17 | some (loop17 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range17 | some (loop17 & (range17 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range17 | (i.shift17_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range17 | (i.shift17_1) in (range17 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range17 | some ((i.shift17_1).future17 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range17 | some ((i.shift17_1).future17 & (range17 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range17 | (i.shift17_1).future17 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range17 | (i.shift17_1).future17 in (range17 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range17 | (i.shift17_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range17 | (i.shift17_2) in (range17 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range17 | some ((i.shift17_2).future17 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range17 | some ((i.shift17_2).future17 & (range17 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range17 | (i.shift17_2).future17 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range17 | (i.shift17_2).future17 in (range17 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range17 | (i.shift17_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range17 | (i.shift17_3) in (range17 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range17 | some ((i.shift17_3).future17 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range17 | (i.shift17_3).future17 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range17 | (i.shift17_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range17 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next17.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range17 | some (i.future17 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range17 | i.future17 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range17 - left[a].ev) + right[a].ev)
}
fun range18: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) }
fun loop18: set Pos { ((P2 + (P3 + P4)) + (P5 + (P6 + P7))) }
fun next18: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P2))) }
fun future18: Pos -> Pos { (*next18) & (range18->range18) }
fun shift18_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) }
fun shift18_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P2))) }
fun shift18_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P2 + P7->P3))) }
fun shift18_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P2) + (P6->P3 + P7->P4))) }
fun shift18_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P2 + P5->P3) + (P6->P4 + P7->P5))) }
pred semantics18[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range18
ev in used->range18
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range18 | (i.shift18_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range18 | (i.shift18_0) in (range18 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range18 | some ((i.shift18_0).future18 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range18 | some ((i.shift18_0).future18 & (range18 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range18 | (i.shift18_0).future18 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range18 | (i.shift18_0).future18 in (range18 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range18 | loop18 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range18 | loop18 in (range18 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range18 | some (loop18 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range18 | some (loop18 & (range18 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range18 | (i.shift18_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range18 | (i.shift18_1) in (range18 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range18 | some ((i.shift18_1).future18 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range18 | some ((i.shift18_1).future18 & (range18 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range18 | (i.shift18_1).future18 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range18 | (i.shift18_1).future18 in (range18 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range18 | (i.shift18_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range18 | (i.shift18_2) in (range18 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range18 | some ((i.shift18_2).future18 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range18 | some ((i.shift18_2).future18 & (range18 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range18 | (i.shift18_2).future18 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range18 | (i.shift18_2).future18 in (range18 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range18 | (i.shift18_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range18 | (i.shift18_3) in (range18 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range18 | some ((i.shift18_3).future18 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range18 | (i.shift18_3).future18 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range18 | (i.shift18_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range18 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next18.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range18 | some (i.future18 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range18 | i.future18 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range18 - left[a].ev) + right[a].ev)
}
fun range19: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop19: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun next19: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P0)))) }
fun future19: Pos -> Pos { (*next19) & (range19->range19) }
fun shift19_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift19_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P0)))) }
fun shift19_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P0 + P8->P1)))) }
fun shift19_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P0 + (P7->P1 + P8->P2)))) }
fun shift19_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P0) + (P6->P1 + (P7->P2 + P8->P3)))) }
pred semantics19[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range19
ev in used->range19
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range19 | (i.shift19_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range19 | (i.shift19_0) in (range19 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range19 | some ((i.shift19_0).future19 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range19 | some ((i.shift19_0).future19 & (range19 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range19 | (i.shift19_0).future19 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range19 | (i.shift19_0).future19 in (range19 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range19 | loop19 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range19 | loop19 in (range19 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range19 | some (loop19 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range19 | some (loop19 & (range19 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range19 | (i.shift19_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range19 | (i.shift19_1) in (range19 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range19 | some ((i.shift19_1).future19 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range19 | some ((i.shift19_1).future19 & (range19 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range19 | (i.shift19_1).future19 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range19 | (i.shift19_1).future19 in (range19 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range19 | (i.shift19_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range19 | (i.shift19_2) in (range19 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range19 | some ((i.shift19_2).future19 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range19 | some ((i.shift19_2).future19 & (range19 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range19 | (i.shift19_2).future19 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range19 | (i.shift19_2).future19 in (range19 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range19 | (i.shift19_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range19 | (i.shift19_3) in (range19 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range19 | some ((i.shift19_3).future19 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range19 | (i.shift19_3).future19 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range19 | (i.shift19_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range19 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next19.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range19 | some (i.future19 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range19 | i.future19 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range19 - left[a].ev) + right[a].ev)
}
fun range20: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) }
fun loop20: set Pos { ((P3 + P4) + (P5 + (P6 + P7))) }
fun next20: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P3))) }
fun future20: Pos -> Pos { (*next20) & (range20->range20) }
fun shift20_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) }
fun shift20_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P3))) }
fun shift20_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P3 + P7->P4))) }
fun shift20_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P3) + (P6->P4 + P7->P5))) }
fun shift20_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P3 + P5->P4) + (P6->P5 + P7->P6))) }
pred semantics20[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range20
ev in used->range20
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range20 | (i.shift20_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range20 | (i.shift20_0) in (range20 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range20 | some ((i.shift20_0).future20 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range20 | some ((i.shift20_0).future20 & (range20 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range20 | (i.shift20_0).future20 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range20 | (i.shift20_0).future20 in (range20 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range20 | loop20 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range20 | loop20 in (range20 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range20 | some (loop20 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range20 | some (loop20 & (range20 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range20 | (i.shift20_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range20 | (i.shift20_1) in (range20 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range20 | some ((i.shift20_1).future20 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range20 | some ((i.shift20_1).future20 & (range20 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range20 | (i.shift20_1).future20 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range20 | (i.shift20_1).future20 in (range20 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range20 | (i.shift20_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range20 | (i.shift20_2) in (range20 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range20 | some ((i.shift20_2).future20 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range20 | some ((i.shift20_2).future20 & (range20 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range20 | (i.shift20_2).future20 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range20 | (i.shift20_2).future20 in (range20 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range20 | (i.shift20_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range20 | (i.shift20_3) in (range20 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range20 | some ((i.shift20_3).future20 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range20 | (i.shift20_3).future20 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range20 | (i.shift20_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range20 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next20.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range20 | some (i.future20 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range20 | i.future20 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range20 - left[a].ev) + right[a].ev)
}
fun range21: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) }
fun loop21: set Pos { (P6 + P7) }
fun next21: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P6))) }
fun future21: Pos -> Pos { (*next21) & (range21->range21) }
fun shift21_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) }
fun shift21_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P6))) }
fun shift21_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P6 + P7->P7))) }
fun shift21_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P6) + (P6->P7 + P7->P6))) }
fun shift21_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P6 + P5->P7) + (P6->P6 + P7->P7))) }
pred semantics21[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range21
ev in used->range21
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range21 | (i.shift21_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range21 | (i.shift21_0) in (range21 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range21 | some ((i.shift21_0).future21 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range21 | some ((i.shift21_0).future21 & (range21 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range21 | (i.shift21_0).future21 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range21 | (i.shift21_0).future21 in (range21 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range21 | loop21 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range21 | loop21 in (range21 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range21 | some (loop21 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range21 | some (loop21 & (range21 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range21 | (i.shift21_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range21 | (i.shift21_1) in (range21 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range21 | some ((i.shift21_1).future21 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range21 | some ((i.shift21_1).future21 & (range21 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range21 | (i.shift21_1).future21 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range21 | (i.shift21_1).future21 in (range21 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range21 | (i.shift21_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range21 | (i.shift21_2) in (range21 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range21 | some ((i.shift21_2).future21 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range21 | some ((i.shift21_2).future21 & (range21 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range21 | (i.shift21_2).future21 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range21 | (i.shift21_2).future21 in (range21 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range21 | (i.shift21_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range21 | (i.shift21_3) in (range21 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range21 | some ((i.shift21_3).future21 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range21 | (i.shift21_3).future21 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range21 | (i.shift21_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range21 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next21.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range21 | some (i.future21 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range21 | i.future21 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range21 - left[a].ev) + right[a].ev)
}
fun range22: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) }
fun loop22: set Pos { P7 }
fun next22: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P7))) }
fun future22: Pos -> Pos { (*next22) & (range22->range22) }
fun shift22_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) }
fun shift22_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P7))) }
fun shift22_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P7 + P7->P7))) }
fun shift22_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P7) + (P6->P7 + P7->P7))) }
fun shift22_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P7 + P5->P7) + (P6->P7 + P7->P7))) }
pred semantics22[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range22
ev in used->range22
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range22 | (i.shift22_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range22 | (i.shift22_0) in (range22 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range22 | some ((i.shift22_0).future22 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range22 | some ((i.shift22_0).future22 & (range22 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range22 | (i.shift22_0).future22 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range22 | (i.shift22_0).future22 in (range22 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range22 | loop22 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range22 | loop22 in (range22 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range22 | some (loop22 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range22 | some (loop22 & (range22 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range22 | (i.shift22_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range22 | (i.shift22_1) in (range22 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range22 | some ((i.shift22_1).future22 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range22 | some ((i.shift22_1).future22 & (range22 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range22 | (i.shift22_1).future22 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range22 | (i.shift22_1).future22 in (range22 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range22 | (i.shift22_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range22 | (i.shift22_2) in (range22 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range22 | some ((i.shift22_2).future22 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range22 | some ((i.shift22_2).future22 & (range22 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range22 | (i.shift22_2).future22 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range22 | (i.shift22_2).future22 in (range22 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range22 | (i.shift22_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range22 | (i.shift22_3) in (range22 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range22 | some ((i.shift22_3).future22 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range22 | (i.shift22_3).future22 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range22 | (i.shift22_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range22 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next22.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range22 | some (i.future22 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range22 | i.future22 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range22 - left[a].ev) + right[a].ev)
}
fun range23: set Pos { ((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) }
fun loop23: set Pos { (P4 + (P5 + P6)) }
fun next23: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P4))) }
fun future23: Pos -> Pos { (*next23) & (range23->range23) }
fun shift23_0: Pos -> Pos { ((P0->P0 + (P1->P1 + P2->P2)) + ((P3->P3 + P4->P4) + (P5->P5 + P6->P6))) }
fun shift23_1: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P4))) }
fun shift23_2: Pos -> Pos { ((P0->P2 + (P1->P3 + P2->P4)) + ((P3->P5 + P4->P6) + (P5->P4 + P6->P5))) }
fun shift23_3: Pos -> Pos { ((P0->P3 + (P1->P4 + P2->P5)) + ((P3->P6 + P4->P4) + (P5->P5 + P6->P6))) }
fun shift23_4: Pos -> Pos { ((P0->P4 + (P1->P5 + P2->P6)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P4))) }
pred semantics23[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range23
ev in used->range23
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range23 | (i.shift23_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range23 | (i.shift23_0) in (range23 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range23 | some ((i.shift23_0).future23 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range23 | some ((i.shift23_0).future23 & (range23 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range23 | (i.shift23_0).future23 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range23 | (i.shift23_0).future23 in (range23 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range23 | loop23 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range23 | loop23 in (range23 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range23 | some (loop23 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range23 | some (loop23 & (range23 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range23 | (i.shift23_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range23 | (i.shift23_1) in (range23 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range23 | some ((i.shift23_1).future23 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range23 | some ((i.shift23_1).future23 & (range23 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range23 | (i.shift23_1).future23 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range23 | (i.shift23_1).future23 in (range23 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range23 | (i.shift23_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range23 | (i.shift23_2) in (range23 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range23 | some ((i.shift23_2).future23 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range23 | some ((i.shift23_2).future23 & (range23 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range23 | (i.shift23_2).future23 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range23 | (i.shift23_2).future23 in (range23 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range23 | (i.shift23_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range23 | (i.shift23_3) in (range23 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range23 | some ((i.shift23_3).future23 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range23 | (i.shift23_3).future23 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range23 | (i.shift23_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range23 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next23.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range23 | some (i.future23 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range23 | i.future23 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range23 - left[a].ev) + right[a].ev)
}
fun range24: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop24: set Pos { (P6 + (P7 + P8)) }
fun next24: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P6)))) }
fun future24: Pos -> Pos { (*next24) & (range24->range24) }
fun shift24_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift24_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P6)))) }
fun shift24_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P6 + P8->P7)))) }
fun shift24_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift24_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P6) + (P6->P7 + (P7->P8 + P8->P6)))) }
pred semantics24[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range24
ev in used->range24
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range24 | (i.shift24_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range24 | (i.shift24_0) in (range24 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range24 | some ((i.shift24_0).future24 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range24 | some ((i.shift24_0).future24 & (range24 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range24 | (i.shift24_0).future24 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range24 | (i.shift24_0).future24 in (range24 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range24 | loop24 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range24 | loop24 in (range24 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range24 | some (loop24 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range24 | some (loop24 & (range24 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range24 | (i.shift24_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range24 | (i.shift24_1) in (range24 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range24 | some ((i.shift24_1).future24 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range24 | some ((i.shift24_1).future24 & (range24 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range24 | (i.shift24_1).future24 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range24 | (i.shift24_1).future24 in (range24 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range24 | (i.shift24_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range24 | (i.shift24_2) in (range24 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range24 | some ((i.shift24_2).future24 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range24 | some ((i.shift24_2).future24 & (range24 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range24 | (i.shift24_2).future24 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range24 | (i.shift24_2).future24 in (range24 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range24 | (i.shift24_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range24 | (i.shift24_3) in (range24 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range24 | some ((i.shift24_3).future24 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range24 | (i.shift24_3).future24 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range24 | (i.shift24_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range24 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next24.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range24 | some (i.future24 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range24 | i.future24 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range24 - left[a].ev) + right[a].ev)
}
fun range25: set Pos { ((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) }
fun loop25: set Pos { P6 }
fun next25: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P6))) }
fun future25: Pos -> Pos { (*next25) & (range25->range25) }
fun shift25_0: Pos -> Pos { ((P0->P0 + (P1->P1 + P2->P2)) + ((P3->P3 + P4->P4) + (P5->P5 + P6->P6))) }
fun shift25_1: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P6))) }
fun shift25_2: Pos -> Pos { ((P0->P2 + (P1->P3 + P2->P4)) + ((P3->P5 + P4->P6) + (P5->P6 + P6->P6))) }
fun shift25_3: Pos -> Pos { ((P0->P3 + (P1->P4 + P2->P5)) + ((P3->P6 + P4->P6) + (P5->P6 + P6->P6))) }
fun shift25_4: Pos -> Pos { ((P0->P4 + (P1->P5 + P2->P6)) + ((P3->P6 + P4->P6) + (P5->P6 + P6->P6))) }
pred semantics25[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range25
ev in used->range25
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range25 | (i.shift25_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range25 | (i.shift25_0) in (range25 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range25 | some ((i.shift25_0).future25 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range25 | some ((i.shift25_0).future25 & (range25 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range25 | (i.shift25_0).future25 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range25 | (i.shift25_0).future25 in (range25 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range25 | loop25 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range25 | loop25 in (range25 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range25 | some (loop25 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range25 | some (loop25 & (range25 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range25 | (i.shift25_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range25 | (i.shift25_1) in (range25 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range25 | some ((i.shift25_1).future25 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range25 | some ((i.shift25_1).future25 & (range25 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range25 | (i.shift25_1).future25 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range25 | (i.shift25_1).future25 in (range25 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range25 | (i.shift25_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range25 | (i.shift25_2) in (range25 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range25 | some ((i.shift25_2).future25 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range25 | some ((i.shift25_2).future25 & (range25 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range25 | (i.shift25_2).future25 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range25 | (i.shift25_2).future25 in (range25 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range25 | (i.shift25_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range25 | (i.shift25_3) in (range25 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range25 | some ((i.shift25_3).future25 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range25 | (i.shift25_3).future25 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range25 | (i.shift25_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range25 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next25.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range25 | some (i.future25 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range25 | i.future25 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range25 - left[a].ev) + right[a].ev)
}
fun range26: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop26: set Pos { ((P5 + P6) + (P7 + P8)) }
fun next26: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P5)))) }
fun future26: Pos -> Pos { (*next26) & (range26->range26) }
fun shift26_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift26_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P5)))) }
fun shift26_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P5 + P8->P6)))) }
fun shift26_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P5 + (P7->P6 + P8->P7)))) }
fun shift26_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
pred semantics26[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range26
ev in used->range26
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range26 | (i.shift26_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range26 | (i.shift26_0) in (range26 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range26 | some ((i.shift26_0).future26 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range26 | some ((i.shift26_0).future26 & (range26 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range26 | (i.shift26_0).future26 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range26 | (i.shift26_0).future26 in (range26 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range26 | loop26 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range26 | loop26 in (range26 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range26 | some (loop26 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range26 | some (loop26 & (range26 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range26 | (i.shift26_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range26 | (i.shift26_1) in (range26 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range26 | some ((i.shift26_1).future26 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range26 | some ((i.shift26_1).future26 & (range26 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range26 | (i.shift26_1).future26 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range26 | (i.shift26_1).future26 in (range26 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range26 | (i.shift26_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range26 | (i.shift26_2) in (range26 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range26 | some ((i.shift26_2).future26 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range26 | some ((i.shift26_2).future26 & (range26 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range26 | (i.shift26_2).future26 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range26 | (i.shift26_2).future26 in (range26 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range26 | (i.shift26_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range26 | (i.shift26_3) in (range26 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range26 | some ((i.shift26_3).future26 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range26 | (i.shift26_3).future26 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range26 | (i.shift26_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range26 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next26.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range26 | some (i.future26 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range26 | i.future26 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range26 - left[a].ev) + right[a].ev)
}
fun range27: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + (P7 + P8)))) }
fun loop27: set Pos { ((P2 + (P3 + P4)) + ((P5 + P6) + (P7 + P8))) }
fun next27: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P2)))) }
fun future27: Pos -> Pos { (*next27) & (range27->range27) }
fun shift27_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + (P7->P7 + P8->P8)))) }
fun shift27_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + (P7->P8 + P8->P2)))) }
fun shift27_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P8 + (P7->P2 + P8->P3)))) }
fun shift27_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P8) + (P6->P2 + (P7->P3 + P8->P4)))) }
fun shift27_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P8 + P5->P2) + (P6->P3 + (P7->P4 + P8->P5)))) }
pred semantics27[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range27
ev in used->range27
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range27 | (i.shift27_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range27 | (i.shift27_0) in (range27 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range27 | some ((i.shift27_0).future27 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range27 | some ((i.shift27_0).future27 & (range27 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range27 | (i.shift27_0).future27 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range27 | (i.shift27_0).future27 in (range27 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range27 | loop27 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range27 | loop27 in (range27 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range27 | some (loop27 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range27 | some (loop27 & (range27 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range27 | (i.shift27_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range27 | (i.shift27_1) in (range27 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range27 | some ((i.shift27_1).future27 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range27 | some ((i.shift27_1).future27 & (range27 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range27 | (i.shift27_1).future27 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range27 | (i.shift27_1).future27 in (range27 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range27 | (i.shift27_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range27 | (i.shift27_2) in (range27 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range27 | some ((i.shift27_2).future27 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range27 | some ((i.shift27_2).future27 & (range27 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range27 | (i.shift27_2).future27 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range27 | (i.shift27_2).future27 in (range27 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range27 | (i.shift27_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range27 | (i.shift27_3) in (range27 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range27 | some ((i.shift27_3).future27 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range27 | (i.shift27_3).future27 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range27 | (i.shift27_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range27 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next27.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range27 | some (i.future27 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range27 | i.future27 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range27 - left[a].ev) + right[a].ev)
}
fun range28: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop28: set Pos { (P2 + (P3 + P4)) }
fun next28: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun future28: Pos -> Pos { (*next28) & (range28->range28) }
fun shift28_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift28_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun shift28_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P2 + P4->P3))) }
fun shift28_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift28_4: Pos -> Pos { ((P0->P4 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
pred semantics28[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range28
ev in used->range28
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range28 | (i.shift28_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range28 | (i.shift28_0) in (range28 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range28 | some ((i.shift28_0).future28 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range28 | some ((i.shift28_0).future28 & (range28 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range28 | (i.shift28_0).future28 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range28 | (i.shift28_0).future28 in (range28 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range28 | loop28 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range28 | loop28 in (range28 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range28 | some (loop28 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range28 | some (loop28 & (range28 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range28 | (i.shift28_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range28 | (i.shift28_1) in (range28 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range28 | some ((i.shift28_1).future28 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range28 | some ((i.shift28_1).future28 & (range28 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range28 | (i.shift28_1).future28 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range28 | (i.shift28_1).future28 in (range28 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range28 | (i.shift28_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range28 | (i.shift28_2) in (range28 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range28 | some ((i.shift28_2).future28 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range28 | some ((i.shift28_2).future28 & (range28 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range28 | (i.shift28_2).future28 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range28 | (i.shift28_2).future28 in (range28 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range28 | (i.shift28_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range28 | (i.shift28_3) in (range28 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range28 | some ((i.shift28_3).future28 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range28 | (i.shift28_3).future28 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range28 | (i.shift28_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range28 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next28.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range28 | some (i.future28 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range28 | i.future28 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range28 - left[a].ev) + right[a].ev)
}
fun range29: set Pos { (((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) }
fun loop29: set Pos { ((P1 + (P2 + P3)) + ((P4 + P5) + (P6 + P7))) }
fun next29: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P1))) }
fun future29: Pos -> Pos { (*next29) & (range29->range29) }
fun shift29_0: Pos -> Pos { (((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) + ((P4->P4 + P5->P5) + (P6->P6 + P7->P7))) }
fun shift29_1: Pos -> Pos { (((P0->P1 + P1->P2) + (P2->P3 + P3->P4)) + ((P4->P5 + P5->P6) + (P6->P7 + P7->P1))) }
fun shift29_2: Pos -> Pos { (((P0->P2 + P1->P3) + (P2->P4 + P3->P5)) + ((P4->P6 + P5->P7) + (P6->P1 + P7->P2))) }
fun shift29_3: Pos -> Pos { (((P0->P3 + P1->P4) + (P2->P5 + P3->P6)) + ((P4->P7 + P5->P1) + (P6->P2 + P7->P3))) }
fun shift29_4: Pos -> Pos { (((P0->P4 + P1->P5) + (P2->P6 + P3->P7)) + ((P4->P1 + P5->P2) + (P6->P3 + P7->P4))) }
pred semantics29[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range29
ev in used->range29
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range29 | (i.shift29_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range29 | (i.shift29_0) in (range29 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range29 | some ((i.shift29_0).future29 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range29 | some ((i.shift29_0).future29 & (range29 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range29 | (i.shift29_0).future29 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range29 | (i.shift29_0).future29 in (range29 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range29 | loop29 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range29 | loop29 in (range29 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range29 | some (loop29 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range29 | some (loop29 & (range29 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range29 | (i.shift29_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range29 | (i.shift29_1) in (range29 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range29 | some ((i.shift29_1).future29 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range29 | some ((i.shift29_1).future29 & (range29 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range29 | (i.shift29_1).future29 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range29 | (i.shift29_1).future29 in (range29 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range29 | (i.shift29_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range29 | (i.shift29_2) in (range29 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range29 | some ((i.shift29_2).future29 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range29 | some ((i.shift29_2).future29 & (range29 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range29 | (i.shift29_2).future29 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range29 | (i.shift29_2).future29 in (range29 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range29 | (i.shift29_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range29 | (i.shift29_3) in (range29 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range29 | some ((i.shift29_3).future29 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range29 | (i.shift29_3).future29 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range29 | (i.shift29_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range29 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next29.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range29 | some (i.future29 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range29 | i.future29 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range29 - left[a].ev) + right[a].ev)
}
fun range30: set Pos { ((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) }
fun loop30: set Pos { ((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) }
fun next30: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P0))) }
fun future30: Pos -> Pos { (*next30) & (range30->range30) }
fun shift30_0: Pos -> Pos { ((P0->P0 + (P1->P1 + P2->P2)) + ((P3->P3 + P4->P4) + (P5->P5 + P6->P6))) }
fun shift30_1: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P0))) }
fun shift30_2: Pos -> Pos { ((P0->P2 + (P1->P3 + P2->P4)) + ((P3->P5 + P4->P6) + (P5->P0 + P6->P1))) }
fun shift30_3: Pos -> Pos { ((P0->P3 + (P1->P4 + P2->P5)) + ((P3->P6 + P4->P0) + (P5->P1 + P6->P2))) }
fun shift30_4: Pos -> Pos { ((P0->P4 + (P1->P5 + P2->P6)) + ((P3->P0 + P4->P1) + (P5->P2 + P6->P3))) }
pred semantics30[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range30
ev in used->range30
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range30 | (i.shift30_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range30 | (i.shift30_0) in (range30 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range30 | some ((i.shift30_0).future30 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range30 | some ((i.shift30_0).future30 & (range30 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range30 | (i.shift30_0).future30 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range30 | (i.shift30_0).future30 in (range30 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range30 | loop30 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range30 | loop30 in (range30 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range30 | some (loop30 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range30 | some (loop30 & (range30 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range30 | (i.shift30_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range30 | (i.shift30_1) in (range30 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range30 | some ((i.shift30_1).future30 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range30 | some ((i.shift30_1).future30 & (range30 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range30 | (i.shift30_1).future30 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range30 | (i.shift30_1).future30 in (range30 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range30 | (i.shift30_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range30 | (i.shift30_2) in (range30 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range30 | some ((i.shift30_2).future30 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range30 | some ((i.shift30_2).future30 & (range30 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range30 | (i.shift30_2).future30 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range30 | (i.shift30_2).future30 in (range30 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range30 | (i.shift30_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range30 | (i.shift30_3) in (range30 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range30 | some ((i.shift30_3).future30 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range30 | (i.shift30_3).future30 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range30 | (i.shift30_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range30 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next30.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range30 | some (i.future30 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range30 | i.future30 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range30 - left[a].ev) + right[a].ev)
}
fun range31: set Pos { ((P0 + (P1 + P2)) + (P3 + (P4 + P5))) }
fun loop31: set Pos { ((P2 + P3) + (P4 + P5)) }
fun next31: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P2))) }
fun future31: Pos -> Pos { (*next31) & (range31->range31) }
fun shift31_0: Pos -> Pos { ((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) }
fun shift31_1: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P2))) }
fun shift31_2: Pos -> Pos { ((P0->P2 + (P1->P3 + P2->P4)) + (P3->P5 + (P4->P2 + P5->P3))) }
fun shift31_3: Pos -> Pos { ((P0->P3 + (P1->P4 + P2->P5)) + (P3->P2 + (P4->P3 + P5->P4))) }
fun shift31_4: Pos -> Pos { ((P0->P4 + (P1->P5 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) }
pred semantics31[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range31
ev in used->range31
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range31 | (i.shift31_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range31 | (i.shift31_0) in (range31 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range31 | some ((i.shift31_0).future31 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range31 | some ((i.shift31_0).future31 & (range31 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range31 | (i.shift31_0).future31 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range31 | (i.shift31_0).future31 in (range31 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range31 | loop31 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range31 | loop31 in (range31 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range31 | some (loop31 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range31 | some (loop31 & (range31 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range31 | (i.shift31_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range31 | (i.shift31_1) in (range31 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range31 | some ((i.shift31_1).future31 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range31 | some ((i.shift31_1).future31 & (range31 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range31 | (i.shift31_1).future31 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range31 | (i.shift31_1).future31 in (range31 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range31 | (i.shift31_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range31 | (i.shift31_2) in (range31 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range31 | some ((i.shift31_2).future31 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range31 | some ((i.shift31_2).future31 & (range31 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range31 | (i.shift31_2).future31 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range31 | (i.shift31_2).future31 in (range31 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range31 | (i.shift31_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range31 | (i.shift31_3) in (range31 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range31 | some ((i.shift31_3).future31 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range31 | (i.shift31_3).future31 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range31 | (i.shift31_4) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range31 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next31.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range31 | some (i.future31 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range31 | i.future31 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range31 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (none)
all a: lab.T1 | a.av0 = (((P0 + (P1 + P2)) + (P3 + (P5 + P6))))
(R->P0 in ev0)
semantics1[av1, ev1]
all a: lab.T0 | a.av1 = (none)
all a: lab.T1 | a.av1 = ((P0 + (P1 + P3)))
(R->P0 in ev1)
semantics2[av2, ev2]
all a: lab.T0 | a.av2 = (none)
all a: lab.T1 | a.av2 = (((P1 + P2) + (P4 + (P7 + P8))))
(R->P0 in ev2)
semantics3[av3, ev3]
all a: lab.T0 | a.av3 = (none)
all a: lab.T1 | a.av3 = ((P2 + (P4 + P5)))
(R->P0 in ev3)
semantics4[av4, ev4]
all a: lab.T0 | a.av4 = (none)
all a: lab.T1 | a.av4 = (((P1 + P4) + (P7 + P9)))
(R->P0 in ev4)
semantics5[av5, ev5]
all a: lab.T0 | a.av5 = (none)
all a: lab.T1 | a.av5 = (((P0 + P1) + (P5 + P9)))
(R->P0 in ev5)
semantics6[av6, ev6]
all a: lab.T0 | a.av6 = (none)
all a: lab.T1 | a.av6 = (((P0 + P2) + (P4 + P8)))
(R->P0 in ev6)
semantics7[av7, ev7]
all a: lab.T0 | a.av7 = (none)
all a: lab.T1 | a.av7 = (((P0 + P2) + (P4 + P8)))
(R->P0 in ev7)
semantics3[av8, ev8]
all a: lab.T0 | a.av8 = (((P1 + P3) + (P4 + P6)))
all a: lab.T1 | a.av8 = (((P0 + P1) + (P3 + (P6 + P8))))
not (R->P0 in ev8)
semantics8[av9, ev9]
all a: lab.T0 | a.av9 = (((P0 + (P2 + P4)) + ((P5 + P6) + (P7 + P9))))
all a: lab.T1 | a.av9 = ((P0 + (P4 + P6)))
not (R->P0 in ev9)
semantics9[av10, ev10]
all a: lab.T0 | a.av10 = (((P3 + (P4 + P6)) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av10 = (((P0 + P2) + (P3 + P6)))
not (R->P0 in ev10)
semantics4[av11, ev11]
all a: lab.T0 | a.av11 = (((P1 + P2) + (P3 + (P4 + P8))))
all a: lab.T1 | a.av11 = ((P4 + (P6 + P8)))
not (R->P0 in ev11)
semantics9[av12, ev12]
all a: lab.T0 | a.av12 = (((P3 + (P5 + P6)) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av12 = (((P1 + (P3 + P4)) + (P6 + (P7 + P8))))
not (R->P0 in ev12)
semantics7[av13, ev13]
all a: lab.T0 | a.av13 = ((P4 + P8))
all a: lab.T1 | a.av13 = (((P1 + P2) + (P3 + (P5 + P6))))
not (R->P0 in ev13)
semantics8[av14, ev14]
all a: lab.T0 | a.av14 = (((P2 + P3) + (P4 + (P6 + P9))))
all a: lab.T1 | a.av14 = ((((P0 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + P8))))
not (R->P0 in ev14)
semantics10[av15, ev15]
all a: lab.T0 | a.av15 = (((P0 + (P1 + P2)) + ((P3 + P5) + (P6 + P7))))
all a: lab.T1 | a.av15 = (((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P9))))
not (R->P0 in ev15)
semantics2[av16, ev16]
all a: lab.T0 | a.av16 = (((P0 + P3) + (P5 + (P6 + P8))))
all a: lab.T1 | a.av16 = (((P1 + P5) + (P6 + (P7 + P8))))
not (R->P0 in ev16)
semantics11[av17, ev17]
all a: lab.T0 | a.av17 = (((P1 + (P2 + P3)) + ((P4 + P5) + (P6 + P7))))
all a: lab.T1 | a.av17 = (((P0 + (P3 + P5)) + (P6 + (P7 + P8))))
not (R->P0 in ev17)
semantics12[av18, ev18]
all a: lab.T0 | a.av18 = (((P0 + P6) + (P7 + P9)))
all a: lab.T1 | a.av18 = (((P0 + (P2 + P3)) + ((P5 + P6) + (P7 + P8))))
not (R->P0 in ev18)
semantics13[av19, ev19]
all a: lab.T0 | a.av19 = (((P3 + P4) + (P5 + (P6 + P7))))
all a: lab.T1 | a.av19 = (((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))))
not (R->P0 in ev19)
semantics12[av20, ev20]
all a: lab.T0 | a.av20 = ((P3 + (P4 + P5)))
all a: lab.T1 | a.av20 = (((P4 + P6) + (P8 + P9)))
not (R->P0 in ev20)
semantics14[av21, ev21]
all a: lab.T0 | a.av21 = (((P0 + P1) + (P4 + (P5 + P6))))
all a: lab.T1 | a.av21 = (((P2 + P4) + (P5 + (P6 + P7))))
not (R->P0 in ev21)
semantics11[av22, ev22]
all a: lab.T0 | a.av22 = (((P2 + P4) + (P8 + P9)))
all a: lab.T1 | a.av22 = (((P4 + P5) + (P8 + P9)))
not (R->P0 in ev22)
semantics11[av23, ev23]
all a: lab.T0 | a.av23 = (((P2 + P4) + (P5 + P6)))
all a: lab.T1 | a.av23 = (((P0 + (P1 + P3)) + ((P5 + P6) + (P8 + P9))))
not (R->P0 in ev23)
semantics15[av24, ev24]
all a: lab.T0 | a.av24 = (((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))))
all a: lab.T1 | a.av24 = (P8)
not (R->P0 in ev24)
semantics11[av25, ev25]
all a: lab.T0 | a.av25 = (((P1 + P2) + (P3 + (P5 + P7))))
all a: lab.T1 | a.av25 = (((P3 + P5) + (P7 + P8)))
not (R->P0 in ev25)
semantics7[av26, ev26]
all a: lab.T0 | a.av26 = (((P2 + (P3 + P5)) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av26 = (((P1 + P2) + (P4 + (P6 + P9))))
not (R->P0 in ev26)
semantics8[av27, ev27]
all a: lab.T0 | a.av27 = ((P6 + (P7 + P9)))
all a: lab.T1 | a.av27 = (((P1 + P2) + (P4 + (P5 + P6))))
not (R->P0 in ev27)
semantics16[av28, ev28]
all a: lab.T0 | a.av28 = (((P0 + P2) + (P5 + (P6 + P7))))
all a: lab.T1 | a.av28 = (P5)
not (R->P0 in ev28)
semantics10[av29, ev29]
all a: lab.T0 | a.av29 = (((P0 + (P1 + P2)) + ((P4 + P5) + (P6 + P7))))
all a: lab.T1 | a.av29 = (((P0 + (P2 + P3)) + (P4 + (P6 + P8))))
not (R->P0 in ev29)
semantics9[av30, ev30]
all a: lab.T0 | a.av30 = (((P2 + P3) + (P4 + (P7 + P9))))
all a: lab.T1 | a.av30 = (((P1 + (P3 + P4)) + (P5 + (P6 + P8))))
not (R->P0 in ev30)
semantics4[av31, ev31]
all a: lab.T0 | a.av31 = (((P0 + (P1 + P4)) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av31 = ((P1 + (P6 + P8)))
not (R->P0 in ev31)
semantics12[av32, ev32]
all a: lab.T0 | a.av32 = ((P4 + (P5 + P8)))
all a: lab.T1 | a.av32 = (((P1 + (P2 + P3)) + ((P4 + P5) + (P7 + P9))))
not (R->P0 in ev32)
semantics17[av33, ev33]
all a: lab.T0 | a.av33 = (((P1 + (P2 + P5)) + (P6 + (P8 + P9))))
all a: lab.T1 | a.av33 = (((P1 + P2) + (P3 + (P6 + P8))))
not (R->P0 in ev33)
semantics18[av34, ev34]
all a: lab.T0 | a.av34 = ((P2 + P4))
all a: lab.T1 | a.av34 = (((P0 + P1) + (P3 + (P4 + P5))))
not (R->P0 in ev34)
semantics17[av35, ev35]
all a: lab.T0 | a.av35 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av35 = (((P2 + P5) + (P7 + P9)))
not (R->P0 in ev35)
semantics19[av36, ev36]
all a: lab.T0 | a.av36 = (((P0 + P3) + (P4 + (P6 + P8))))
all a: lab.T1 | a.av36 = (((P0 + P1) + (P5 + (P6 + P8))))
not (R->P0 in ev36)
semantics20[av37, ev37]
all a: lab.T0 | a.av37 = (((P0 + P2) + (P4 + P6)))
all a: lab.T1 | a.av37 = ((P0 + (P5 + P7)))
not (R->P0 in ev37)
semantics5[av38, ev38]
all a: lab.T0 | a.av38 = ((P1 + (P5 + P8)))
all a: lab.T1 | a.av38 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P7 + P8))))
not (R->P0 in ev38)
semantics4[av39, ev39]
all a: lab.T0 | a.av39 = (((P0 + (P1 + P2)) + (P6 + (P7 + P9))))
all a: lab.T1 | a.av39 = (((P0 + P4) + (P7 + P9)))
not (R->P0 in ev39)
semantics17[av40, ev40]
all a: lab.T0 | a.av40 = (((P1 + (P3 + P4)) + ((P5 + P6) + (P8 + P9))))
all a: lab.T1 | a.av40 = (((P2 + P3) + (P7 + (P8 + P9))))
not (R->P0 in ev40)
semantics21[av41, ev41]
all a: lab.T0 | a.av41 = (((P0 + (P1 + P2)) + (P3 + (P5 + P7))))
all a: lab.T1 | a.av41 = (((P1 + P2) + (P3 + (P6 + P7))))
not (R->P0 in ev41)
semantics11[av42, ev42]
all a: lab.T0 | a.av42 = ((P4 + (P5 + P6)))
all a: lab.T1 | a.av42 = ((((P0 + P2) + (P3 + P4)) + ((P5 + P7) + (P8 + P9))))
not (R->P0 in ev42)
semantics8[av43, ev43]
all a: lab.T0 | a.av43 = ((P6 + P8))
all a: lab.T1 | a.av43 = (((P2 + (P3 + P4)) + ((P5 + P6) + (P8 + P9))))
not (R->P0 in ev43)
semantics19[av44, ev44]
all a: lab.T0 | a.av44 = ((P0 + (P5 + P8)))
all a: lab.T1 | a.av44 = ((P3 + P6))
not (R->P0 in ev44)
semantics17[av45, ev45]
all a: lab.T0 | a.av45 = (((P0 + (P1 + P4)) + ((P5 + P6) + (P8 + P9))))
all a: lab.T1 | a.av45 = (((P0 + (P1 + P4)) + (P5 + (P6 + P7))))
not (R->P0 in ev45)
semantics3[av46, ev46]
all a: lab.T0 | a.av46 = ((P3 + P6))
all a: lab.T1 | a.av46 = (((P0 + (P1 + P3)) + ((P5 + P6) + (P8 + P9))))
not (R->P0 in ev46)
semantics9[av47, ev47]
all a: lab.T0 | a.av47 = (((P0 + P3) + (P4 + (P7 + P9))))
all a: lab.T1 | a.av47 = (((P1 + (P2 + P3)) + (P6 + (P7 + P9))))
not (R->P0 in ev47)
semantics10[av48, ev48]
all a: lab.T0 | a.av48 = (((P0 + (P2 + P3)) + ((P5 + P7) + (P8 + P9))))
all a: lab.T1 | a.av48 = (((P1 + (P4 + P5)) + (P6 + (P7 + P9))))
not (R->P0 in ev48)
semantics22[av49, ev49]
all a: lab.T0 | a.av49 = ((P2 + P7))
all a: lab.T1 | a.av49 = (((P0 + P4) + (P5 + (P6 + P7))))
not (R->P0 in ev49)
semantics12[av50, ev50]
all a: lab.T0 | a.av50 = (((P1 + (P4 + P5)) + (P6 + (P7 + P9))))
all a: lab.T1 | a.av50 = (((P0 + (P2 + P3)) + (P4 + (P5 + P9))))
not (R->P0 in ev50)
semantics10[av51, ev51]
all a: lab.T0 | a.av51 = (((P0 + (P2 + P3)) + ((P5 + P6) + (P7 + P9))))
all a: lab.T1 | a.av51 = (((P2 + (P3 + P4)) + (P5 + (P6 + P8))))
not (R->P0 in ev51)
semantics6[av52, ev52]
all a: lab.T0 | a.av52 = (((P0 + (P1 + P3)) + (P4 + (P6 + P7))))
all a: lab.T1 | a.av52 = (((P3 + P5) + (P7 + P8)))
not (R->P0 in ev52)
semantics8[av53, ev53]
all a: lab.T0 | a.av53 = ((P0 + (P1 + P5)))
all a: lab.T1 | a.av53 = (((P0 + P3) + (P7 + P8)))
not (R->P0 in ev53)
semantics23[av54, ev54]
all a: lab.T0 | a.av54 = (((P1 + P3) + (P4 + P5)))
all a: lab.T1 | a.av54 = ((P1 + (P2 + P4)))
not (R->P0 in ev54)
semantics12[av55, ev55]
all a: lab.T0 | a.av55 = (((P0 + P4) + (P6 + (P7 + P8))))
all a: lab.T1 | a.av55 = (((P1 + P4) + (P7 + (P8 + P9))))
not (R->P0 in ev55)
semantics2[av56, ev56]
all a: lab.T0 | a.av56 = ((P2 + P7))
all a: lab.T1 | a.av56 = (((P0 + P2) + (P6 + P8)))
not (R->P0 in ev56)
semantics17[av57, ev57]
all a: lab.T0 | a.av57 = (((P1 + P4) + (P5 + (P7 + P8))))
all a: lab.T1 | a.av57 = (((P1 + P3) + (P8 + P9)))
not (R->P0 in ev57)
semantics17[av58, ev58]
all a: lab.T0 | a.av58 = (((P0 + P2) + (P3 + (P5 + P8))))
all a: lab.T1 | a.av58 = (((P0 + (P2 + P5)) + (P7 + (P8 + P9))))
not (R->P0 in ev58)
semantics8[av59, ev59]
all a: lab.T0 | a.av59 = (((P0 + (P3 + P4)) + (P5 + (P6 + P7))))
all a: lab.T1 | a.av59 = (((P1 + (P4 + P5)) + (P6 + (P7 + P8))))
not (R->P0 in ev59)
semantics7[av60, ev60]
all a: lab.T0 | a.av60 = (((P1 + P3) + (P5 + (P6 + P8))))
all a: lab.T1 | a.av60 = (((P0 + (P1 + P3)) + ((P5 + P6) + (P7 + P9))))
not (R->P0 in ev60)
semantics24[av61, ev61]
all a: lab.T0 | a.av61 = ((P2 + P8))
all a: lab.T1 | a.av61 = (((P2 + P5) + (P6 + (P7 + P8))))
not (R->P0 in ev61)
semantics17[av62, ev62]
all a: lab.T0 | a.av62 = ((P1 + (P3 + P9)))
all a: lab.T1 | a.av62 = ((P3 + P8))
not (R->P0 in ev62)
semantics19[av63, ev63]
all a: lab.T0 | a.av63 = (((P3 + P4) + (P5 + P7)))
all a: lab.T1 | a.av63 = ((P1 + P7))
not (R->P0 in ev63)
semantics9[av64, ev64]
all a: lab.T0 | a.av64 = (((P1 + P3) + (P6 + P8)))
all a: lab.T1 | a.av64 = (((P2 + P3) + (P6 + (P7 + P8))))
not (R->P0 in ev64)
semantics5[av65, ev65]
all a: lab.T0 | a.av65 = (((P0 + P1) + (P7 + P8)))
all a: lab.T1 | a.av65 = (((P3 + (P4 + P6)) + (P7 + (P8 + P9))))
not (R->P0 in ev65)
semantics17[av66, ev66]
all a: lab.T0 | a.av66 = ((P1 + (P4 + P5)))
all a: lab.T1 | a.av66 = (((P1 + (P2 + P3)) + (P5 + (P6 + P8))))
not (R->P0 in ev66)
semantics7[av67, ev67]
all a: lab.T0 | a.av67 = (((P0 + (P1 + P4)) + (P5 + (P8 + P9))))
all a: lab.T1 | a.av67 = (((P0 + P4) + (P5 + (P7 + P8))))
not (R->P0 in ev67)
semantics3[av68, ev68]
all a: lab.T0 | a.av68 = (((P4 + P5) + (P6 + (P7 + P9))))
all a: lab.T1 | a.av68 = (((P0 + P1) + (P3 + (P4 + P6))))
not (R->P0 in ev68)
semantics5[av69, ev69]
all a: lab.T0 | a.av69 = (((P0 + P2) + (P5 + (P6 + P9))))
all a: lab.T1 | a.av69 = (((P1 + (P2 + P3)) + (P5 + (P6 + P8))))
not (R->P0 in ev69)
semantics17[av70, ev70]
all a: lab.T0 | a.av70 = (((P2 + (P3 + P4)) + (P5 + (P6 + P7))))
all a: lab.T1 | a.av70 = ((P0 + (P1 + P8)))
not (R->P0 in ev70)
semantics19[av71, ev71]
all a: lab.T0 | a.av71 = (((P0 + P3) + (P5 + (P6 + P7))))
all a: lab.T1 | a.av71 = (((P2 + P3) + (P4 + P5)))
not (R->P0 in ev71)
semantics25[av72, ev72]
all a: lab.T0 | a.av72 = (P5)
all a: lab.T1 | a.av72 = (((P0 + P3) + (P4 + P6)))
not (R->P0 in ev72)
semantics0[av73, ev73]
all a: lab.T0 | a.av73 = (((P0 + (P2 + P3)) + (P4 + (P6 + P8))))
all a: lab.T1 | a.av73 = (((P1 + (P2 + P3)) + (P4 + (P5 + P7))))
not (R->P0 in ev73)
semantics22[av74, ev74]
all a: lab.T0 | a.av74 = (P3)
all a: lab.T1 | a.av74 = (((P1 + P2) + (P3 + P6)))
not (R->P0 in ev74)
semantics17[av75, ev75]
all a: lab.T0 | a.av75 = ((P0 + (P5 + P8)))
all a: lab.T1 | a.av75 = (((P0 + P2) + (P4 + P8)))
not (R->P0 in ev75)
semantics25[av76, ev76]
all a: lab.T0 | a.av76 = (((P2 + P3) + (P4 + (P5 + P6))))
all a: lab.T1 | a.av76 = (((P0 + P1) + (P2 + (P4 + P6))))
not (R->P0 in ev76)
semantics8[av77, ev77]
all a: lab.T0 | a.av77 = (((P0 + P2) + (P3 + P8)))
all a: lab.T1 | a.av77 = (((P0 + P5) + (P6 + P9)))
not (R->P0 in ev77)
semantics8[av78, ev78]
all a: lab.T0 | a.av78 = ((P2 + (P6 + P9)))
all a: lab.T1 | a.av78 = (((P1 + P3) + (P4 + P7)))
not (R->P0 in ev78)
semantics26[av79, ev79]
all a: lab.T0 | a.av79 = (((P1 + P2) + (P3 + P5)))
all a: lab.T1 | a.av79 = (((P2 + P3) + (P6 + P8)))
not (R->P0 in ev79)
semantics8[av80, ev80]
all a: lab.T0 | a.av80 = (((P1 + P6) + (P7 + P8)))
all a: lab.T1 | a.av80 = (((P1 + (P2 + P3)) + (P5 + (P6 + P9))))
not (R->P0 in ev80)
semantics12[av81, ev81]
all a: lab.T0 | a.av81 = (((P0 + P1) + (P4 + (P6 + P7))))
all a: lab.T1 | a.av81 = (((P0 + (P3 + P4)) + (P5 + (P8 + P9))))
not (R->P0 in ev81)
semantics6[av82, ev82]
all a: lab.T0 | a.av82 = (((P1 + P2) + (P4 + (P7 + P8))))
all a: lab.T1 | a.av82 = (((P0 + P4) + (P6 + P8)))
not (R->P0 in ev82)
semantics4[av83, ev83]
all a: lab.T0 | a.av83 = (((P0 + (P4 + P5)) + (P6 + (P8 + P9))))
all a: lab.T1 | a.av83 = (((P3 + P5) + (P6 + P8)))
not (R->P0 in ev83)
semantics2[av84, ev84]
all a: lab.T0 | a.av84 = ((P0 + (P1 + P6)))
all a: lab.T1 | a.av84 = (((P0 + P2) + (P4 + (P7 + P8))))
not (R->P0 in ev84)
semantics17[av85, ev85]
all a: lab.T0 | a.av85 = (((P2 + P4) + (P5 + (P8 + P9))))
all a: lab.T1 | a.av85 = (((P1 + P3) + (P5 + (P7 + P9))))
not (R->P0 in ev85)
semantics12[av86, ev86]
all a: lab.T0 | a.av86 = (((P0 + (P3 + P5)) + (P6 + (P8 + P9))))
all a: lab.T1 | a.av86 = (((P0 + P2) + (P4 + (P6 + P7))))
not (R->P0 in ev86)
semantics4[av87, ev87]
all a: lab.T0 | a.av87 = (((P1 + P4) + (P6 + P9)))
all a: lab.T1 | a.av87 = (((P1 + P3) + (P7 + (P8 + P9))))
not (R->P0 in ev87)
semantics9[av88, ev88]
all a: lab.T0 | a.av88 = (((P0 + P5) + (P7 + P9)))
all a: lab.T1 | a.av88 = (((P0 + (P2 + P4)) + (P7 + (P8 + P9))))
not (R->P0 in ev88)
semantics10[av89, ev89]
all a: lab.T0 | a.av89 = (((P0 + (P1 + P3)) + (P4 + (P5 + P7))))
all a: lab.T1 | a.av89 = (((P0 + P2) + (P5 + P6)))
not (R->P0 in ev89)
semantics5[av90, ev90]
all a: lab.T0 | a.av90 = (((P0 + P1) + (P4 + (P6 + P9))))
all a: lab.T1 | a.av90 = ((P8 + P9))
not (R->P0 in ev90)
semantics7[av91, ev91]
all a: lab.T0 | a.av91 = (((P0 + (P2 + P3)) + (P4 + (P8 + P9))))
all a: lab.T1 | a.av91 = (((P0 + P3) + (P5 + (P8 + P9))))
not (R->P0 in ev91)
semantics10[av92, ev92]
all a: lab.T0 | a.av92 = (((P0 + (P2 + P3)) + (P4 + (P7 + P9))))
all a: lab.T1 | a.av92 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P7 + P8))))
not (R->P0 in ev92)
semantics14[av93, ev93]
all a: lab.T0 | a.av93 = ((P5 + P8))
all a: lab.T1 | a.av93 = (((P1 + P3) + (P5 + P8)))
not (R->P0 in ev93)
semantics7[av94, ev94]
all a: lab.T0 | a.av94 = (((P0 + (P3 + P4)) + (P5 + (P7 + P8))))
all a: lab.T1 | a.av94 = (((P1 + (P3 + P4)) + (P6 + (P8 + P9))))
not (R->P0 in ev94)
semantics27[av95, ev95]
all a: lab.T0 | a.av95 = (((P0 + (P1 + P2)) + (P3 + (P4 + P8))))
all a: lab.T1 | a.av95 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev95)
semantics27[av96, ev96]
all a: lab.T0 | a.av96 = (((P3 + P4) + (P5 + (P6 + P7))))
all a: lab.T1 | a.av96 = (((P2 + P3) + (P4 + (P6 + P8))))
not (R->P0 in ev96)
semantics10[av97, ev97]
all a: lab.T0 | a.av97 = (((P0 + P1) + (P2 + (P5 + P9))))
all a: lab.T1 | a.av97 = (((P0 + P5) + (P6 + (P7 + P9))))
not (R->P0 in ev97)
semantics7[av98, ev98]
all a: lab.T0 | a.av98 = (((P0 + P1) + (P3 + (P4 + P5))))
all a: lab.T1 | a.av98 = ((P1 + (P4 + P6)))
not (R->P0 in ev98)
semantics10[av99, ev99]
all a: lab.T0 | a.av99 = (((P1 + P2) + (P3 + (P7 + P9))))
all a: lab.T1 | a.av99 = (((P3 + P4) + (P5 + (P6 + P7))))
not (R->P0 in ev99)
semantics8[av100, ev100]
all a: lab.T0 | a.av100 = (((P0 + P1) + (P5 + (P8 + P9))))
all a: lab.T1 | a.av100 = (((P4 + P5) + (P6 + P9)))
not (R->P0 in ev100)
semantics9[av101, ev101]
all a: lab.T0 | a.av101 = ((P1 + (P5 + P7)))
all a: lab.T1 | a.av101 = (((P0 + P2) + (P7 + (P8 + P9))))
not (R->P0 in ev101)
semantics2[av102, ev102]
all a: lab.T0 | a.av102 = (((P1 + (P3 + P4)) + (P6 + (P7 + P8))))
all a: lab.T1 | a.av102 = (((P1 + P4) + (P5 + (P7 + P8))))
not (R->P0 in ev102)
semantics17[av103, ev103]
all a: lab.T0 | a.av103 = (((P0 + P1) + (P2 + (P3 + P5))))
all a: lab.T1 | a.av103 = ((P0 + (P2 + P8)))
not (R->P0 in ev103)
semantics9[av104, ev104]
all a: lab.T0 | a.av104 = (((P0 + (P1 + P3)) + ((P4 + P5) + (P6 + P7))))
all a: lab.T1 | a.av104 = (((P0 + (P1 + P2)) + ((P3 + P4) + (P7 + P8))))
not (R->P0 in ev104)
semantics17[av105, ev105]
all a: lab.T0 | a.av105 = (((P0 + (P2 + P3)) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av105 = (((P0 + P4) + (P5 + (P7 + P9))))
not (R->P0 in ev105)
semantics24[av106, ev106]
all a: lab.T0 | a.av106 = (((P0 + (P1 + P3)) + (P6 + (P7 + P8))))
all a: lab.T1 | a.av106 = (((P0 + (P1 + P2)) + (P4 + (P7 + P8))))
not (R->P0 in ev106)
semantics7[av107, ev107]
all a: lab.T0 | a.av107 = (((P0 + P2) + (P5 + P9)))
all a: lab.T1 | a.av107 = (((P1 + P2) + (P3 + (P4 + P6))))
not (R->P0 in ev107)
semantics14[av108, ev108]
all a: lab.T0 | a.av108 = ((P5 + P8))
all a: lab.T1 | a.av108 = (((P0 + P2) + (P3 + P7)))
not (R->P0 in ev108)
semantics3[av109, ev109]
all a: lab.T0 | a.av109 = (((P0 + P4) + (P5 + (P6 + P7))))
all a: lab.T1 | a.av109 = (((P0 + P1) + (P2 + (P5 + P9))))
not (R->P0 in ev109)
semantics10[av110, ev110]
all a: lab.T0 | a.av110 = (((P0 + (P3 + P4)) + ((P5 + P6) + (P7 + P8))))
all a: lab.T1 | a.av110 = (((P1 + P2) + (P3 + (P7 + P9))))
not (R->P0 in ev110)
semantics17[av111, ev111]
all a: lab.T0 | a.av111 = (((P0 + (P1 + P2)) + ((P3 + P7) + (P8 + P9))))
all a: lab.T1 | a.av111 = (((P1 + P2) + (P4 + (P5 + P8))))
not (R->P0 in ev111)
semantics3[av112, ev112]
all a: lab.T0 | a.av112 = ((P1 + (P8 + P9)))
all a: lab.T1 | a.av112 = (((P4 + P5) + (P6 + P8)))
not (R->P0 in ev112)
semantics12[av113, ev113]
all a: lab.T0 | a.av113 = (((P1 + P4) + (P6 + (P7 + P9))))
all a: lab.T1 | a.av113 = (((P0 + (P1 + P4)) + (P5 + (P6 + P7))))
not (R->P0 in ev113)
semantics4[av114, ev114]
all a: lab.T0 | a.av114 = (((P3 + P4) + (P6 + P7)))
all a: lab.T1 | a.av114 = (((P0 + P2) + (P4 + (P8 + P9))))
not (R->P0 in ev114)
semantics4[av115, ev115]
all a: lab.T0 | a.av115 = (((P1 + P6) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av115 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P7) + (P8 + P9))))
not (R->P0 in ev115)
semantics21[av116, ev116]
all a: lab.T0 | a.av116 = ((P0 + (P4 + P5)))
all a: lab.T1 | a.av116 = (P6)
not (R->P0 in ev116)
semantics3[av117, ev117]
all a: lab.T0 | a.av117 = (((P0 + (P1 + P5)) + ((P6 + P7) + (P8 + P9))))
all a: lab.T1 | a.av117 = (((P0 + P4) + (P5 + P9)))
not (R->P0 in ev117)
semantics6[av118, ev118]
all a: lab.T0 | a.av118 = ((P1 + (P3 + P8)))
all a: lab.T1 | a.av118 = (((P2 + P3) + (P7 + P8)))
not (R->P0 in ev118)
semantics26[av119, ev119]
all a: lab.T0 | a.av119 = (((P0 + P1) + (P2 + P7)))
all a: lab.T1 | a.av119 = (((P0 + P2) + (P5 + (P6 + P8))))
not (R->P0 in ev119)
semantics7[av120, ev120]
all a: lab.T0 | a.av120 = ((P0 + (P4 + P9)))
all a: lab.T1 | a.av120 = (((P0 + P2) + (P6 + P8)))
not (R->P0 in ev120)
semantics14[av121, ev121]
all a: lab.T0 | a.av121 = ((P1 + P3))
all a: lab.T1 | a.av121 = (((P0 + (P2 + P4)) + (P5 + (P6 + P7))))
not (R->P0 in ev121)
semantics7[av122, ev122]
all a: lab.T0 | a.av122 = (((P0 + P3) + (P5 + (P8 + P9))))
all a: lab.T1 | a.av122 = ((P2 + (P6 + P7)))
not (R->P0 in ev122)
semantics4[av123, ev123]
all a: lab.T0 | a.av123 = (((P0 + (P1 + P4)) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av123 = (((P3 + P4) + (P6 + (P7 + P8))))
not (R->P0 in ev123)
semantics11[av124, ev124]
all a: lab.T0 | a.av124 = (((P1 + (P2 + P6)) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av124 = (((P0 + (P2 + P3)) + (P5 + (P6 + P9))))
not (R->P0 in ev124)
semantics3[av125, ev125]
all a: lab.T0 | a.av125 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P6 + P8))))
all a: lab.T1 | a.av125 = (((P0 + (P1 + P4)) + ((P6 + P7) + (P8 + P9))))
not (R->P0 in ev125)
semantics5[av126, ev126]
all a: lab.T0 | a.av126 = (((P0 + P5) + (P6 + P7)))
all a: lab.T1 | a.av126 = (((P3 + P5) + (P7 + P9)))
not (R->P0 in ev126)
semantics25[av127, ev127]
all a: lab.T0 | a.av127 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av127 = ((P0 + (P1 + P5)))
not (R->P0 in ev127)
semantics10[av128, ev128]
all a: lab.T0 | a.av128 = ((P2 + (P3 + P7)))
all a: lab.T1 | a.av128 = (((P2 + P3) + (P6 + (P7 + P8))))
not (R->P0 in ev128)
semantics14[av129, ev129]
all a: lab.T0 | a.av129 = ((P3 + P6))
all a: lab.T1 | a.av129 = (((P1 + (P2 + P4)) + (P5 + (P6 + P8))))
not (R->P0 in ev129)
semantics7[av130, ev130]
all a: lab.T0 | a.av130 = (((P2 + P5) + (P8 + P9)))
all a: lab.T1 | a.av130 = (((P2 + P4) + (P6 + (P7 + P8))))
not (R->P0 in ev130)
semantics7[av131, ev131]
all a: lab.T0 | a.av131 = (((P3 + P5) + (P6 + P8)))
all a: lab.T1 | a.av131 = (((P0 + (P2 + P3)) + ((P5 + P6) + (P7 + P8))))
not (R->P0 in ev131)
semantics7[av132, ev132]
all a: lab.T0 | a.av132 = ((P1 + P8))
all a: lab.T1 | a.av132 = (((P0 + P1) + (P3 + P9)))
not (R->P0 in ev132)
semantics8[av133, ev133]
all a: lab.T0 | a.av133 = (((P3 + P6) + (P7 + P8)))
all a: lab.T1 | a.av133 = (((P3 + P6) + (P7 + P9)))
not (R->P0 in ev133)
semantics3[av134, ev134]
all a: lab.T0 | a.av134 = ((P0 + (P2 + P5)))
all a: lab.T1 | a.av134 = ((((P0 + P1) + (P2 + P3)) + ((P6 + P7) + (P8 + P9))))
not (R->P0 in ev134)
semantics10[av135, ev135]
all a: lab.T0 | a.av135 = (((P0 + P2) + (P4 + P7)))
all a: lab.T1 | a.av135 = (((P0 + (P2 + P3)) + ((P4 + P5) + (P6 + P7))))
not (R->P0 in ev135)
semantics9[av136, ev136]
all a: lab.T0 | a.av136 = (((P1 + P3) + (P4 + P5)))
all a: lab.T1 | a.av136 = ((P5 + P9))
not (R->P0 in ev136)
semantics12[av137, ev137]
all a: lab.T0 | a.av137 = (((P0 + P1) + (P4 + (P5 + P6))))
all a: lab.T1 | a.av137 = (((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P7))))
not (R->P0 in ev137)
semantics17[av138, ev138]
all a: lab.T0 | a.av138 = (((P0 + (P2 + P3)) + (P4 + (P5 + P7))))
all a: lab.T1 | a.av138 = (((P0 + (P1 + P2)) + ((P3 + P6) + (P7 + P8))))
not (R->P0 in ev138)
semantics3[av139, ev139]
all a: lab.T0 | a.av139 = (((P2 + P3) + (P4 + (P6 + P9))))
all a: lab.T1 | a.av139 = (((P0 + P1) + (P8 + P9)))
not (R->P0 in ev139)
semantics14[av140, ev140]
all a: lab.T0 | a.av140 = (((P1 + (P2 + P4)) + (P5 + (P6 + P7))))
all a: lab.T1 | a.av140 = ((P3 + (P4 + P7)))
not (R->P0 in ev140)
semantics5[av141, ev141]
all a: lab.T0 | a.av141 = ((P0 + (P4 + P9)))
all a: lab.T1 | a.av141 = (((P0 + P5) + (P6 + P8)))
not (R->P0 in ev141)
semantics7[av142, ev142]
all a: lab.T0 | a.av142 = (((P1 + (P3 + P4)) + (P5 + (P7 + P8))))
all a: lab.T1 | a.av142 = (((P0 + P7) + (P8 + P9)))
not (R->P0 in ev142)
semantics7[av143, ev143]
all a: lab.T0 | a.av143 = (((P2 + P4) + (P5 + P7)))
all a: lab.T1 | a.av143 = (((P3 + P5) + (P6 + (P7 + P9))))
not (R->P0 in ev143)
semantics3[av144, ev144]
all a: lab.T0 | a.av144 = (((P1 + (P2 + P3)) + ((P5 + P7) + (P8 + P9))))
all a: lab.T1 | a.av144 = (((P0 + (P1 + P2)) + (P4 + (P7 + P8))))
not (R->P0 in ev144)
semantics26[av145, ev145]
all a: lab.T0 | a.av145 = (((P0 + (P1 + P3)) + (P4 + (P5 + P8))))
all a: lab.T1 | a.av145 = (((P1 + P2) + (P3 + (P4 + P7))))
not (R->P0 in ev145)
semantics8[av146, ev146]
all a: lab.T0 | a.av146 = (((P0 + (P1 + P2)) + (P4 + (P5 + P8))))
all a: lab.T1 | a.av146 = (((P0 + (P2 + P3)) + (P4 + (P6 + P7))))
not (R->P0 in ev146)
semantics19[av147, ev147]
all a: lab.T0 | a.av147 = ((P1 + P5))
all a: lab.T1 | a.av147 = ((P3 + (P4 + P7)))
not (R->P0 in ev147)
semantics11[av148, ev148]
all a: lab.T0 | a.av148 = (((P0 + P2) + (P3 + (P4 + P8))))
all a: lab.T1 | a.av148 = (((P0 + (P2 + P5)) + (P6 + (P7 + P8))))
not (R->P0 in ev148)
semantics4[av149, ev149]
all a: lab.T0 | a.av149 = (((P4 + P5) + (P8 + P9)))
all a: lab.T1 | a.av149 = (((P0 + P5) + (P7 + P8)))
not (R->P0 in ev149)
semantics10[av150, ev150]
all a: lab.T0 | a.av150 = ((P1 + (P5 + P6)))
all a: lab.T1 | a.av150 = (((P0 + P3) + (P4 + P9)))
not (R->P0 in ev150)
semantics12[av151, ev151]
all a: lab.T0 | a.av151 = (((P4 + P5) + (P6 + P9)))
all a: lab.T1 | a.av151 = (((P1 + P3) + (P4 + (P7 + P9))))
not (R->P0 in ev151)
semantics9[av152, ev152]
all a: lab.T0 | a.av152 = (((P1 + (P2 + P4)) + (P5 + (P8 + P9))))
all a: lab.T1 | a.av152 = ((P0 + (P1 + P7)))
not (R->P0 in ev152)
semantics11[av153, ev153]
all a: lab.T0 | a.av153 = (((P0 + (P1 + P4)) + (P5 + (P6 + P9))))
all a: lab.T1 | a.av153 = (((P2 + (P3 + P4)) + ((P6 + P7) + (P8 + P9))))
not (R->P0 in ev153)
semantics8[av154, ev154]
all a: lab.T0 | a.av154 = ((P0 + (P4 + P9)))
all a: lab.T1 | a.av154 = (((P4 + P7) + (P8 + P9)))
not (R->P0 in ev154)
semantics11[av155, ev155]
all a: lab.T0 | a.av155 = (((P0 + (P2 + P3)) + (P4 + (P8 + P9))))
all a: lab.T1 | a.av155 = (((P0 + (P1 + P5)) + (P6 + (P7 + P9))))
not (R->P0 in ev155)
semantics7[av156, ev156]
all a: lab.T0 | a.av156 = (((P1 + P2) + (P3 + (P5 + P8))))
all a: lab.T1 | a.av156 = (((P0 + P3) + (P6 + (P7 + P9))))
not (R->P0 in ev156)
semantics7[av157, ev157]
all a: lab.T0 | a.av157 = (((P0 + P4) + (P7 + P8)))
all a: lab.T1 | a.av157 = (((P0 + P1) + (P4 + P9)))
not (R->P0 in ev157)
semantics28[av158, ev158]
all a: lab.T0 | a.av158 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av158 = (P0)
not (R->P0 in ev158)
semantics12[av159, ev159]
all a: lab.T0 | a.av159 = (((P0 + P1) + (P7 + P8)))
all a: lab.T1 | a.av159 = (((P2 + P3) + (P4 + P9)))
not (R->P0 in ev159)
semantics9[av160, ev160]
all a: lab.T0 | a.av160 = (((P0 + (P1 + P2)) + ((P3 + P6) + (P7 + P8))))
all a: lab.T1 | a.av160 = (((P1 + (P2 + P3)) + (P5 + (P7 + P8))))
not (R->P0 in ev160)
semantics16[av161, ev161]
all a: lab.T0 | a.av161 = (((P0 + P3) + (P5 + P6)))
all a: lab.T1 | a.av161 = ((P1 + (P5 + P7)))
not (R->P0 in ev161)
semantics7[av162, ev162]
all a: lab.T0 | a.av162 = (((P0 + (P1 + P3)) + ((P4 + P6) + (P7 + P9))))
all a: lab.T1 | a.av162 = (((P1 + P3) + (P4 + P5)))
not (R->P0 in ev162)
semantics29[av163, ev163]
all a: lab.T0 | a.av163 = (((P0 + (P1 + P2)) + (P3 + (P4 + P5))))
all a: lab.T1 | a.av163 = (((P0 + P2) + (P5 + P7)))
not (R->P0 in ev163)
semantics16[av164, ev164]
all a: lab.T0 | a.av164 = (P0)
all a: lab.T1 | a.av164 = ((P1 + (P3 + P5)))
not (R->P0 in ev164)
semantics11[av165, ev165]
all a: lab.T0 | a.av165 = (((P0 + P1) + (P3 + P8)))
all a: lab.T1 | a.av165 = (((P0 + (P3 + P4)) + (P5 + (P7 + P8))))
not (R->P0 in ev165)
semantics29[av166, ev166]
all a: lab.T0 | a.av166 = (((P1 + P2) + (P4 + (P6 + P7))))
all a: lab.T1 | a.av166 = (((P0 + (P1 + P2)) + (P4 + (P5 + P7))))
not (R->P0 in ev166)
semantics10[av167, ev167]
all a: lab.T0 | a.av167 = (((P0 + (P1 + P2)) + ((P3 + P5) + (P6 + P8))))
all a: lab.T1 | a.av167 = ((P0 + (P1 + P7)))
not (R->P0 in ev167)
semantics9[av168, ev168]
all a: lab.T0 | a.av168 = (((P0 + P4) + (P7 + P9)))
all a: lab.T1 | a.av168 = (((P1 + (P2 + P4)) + (P6 + (P8 + P9))))
not (R->P0 in ev168)
semantics11[av169, ev169]
all a: lab.T0 | a.av169 = (((P2 + (P3 + P4)) + (P6 + (P7 + P9))))
all a: lab.T1 | a.av169 = (((P0 + P2) + (P3 + (P4 + P5))))
not (R->P0 in ev169)
semantics14[av170, ev170]
all a: lab.T0 | a.av170 = (((P0 + P2) + (P5 + P6)))
all a: lab.T1 | a.av170 = (((P0 + P1) + (P4 + (P6 + P7))))
not (R->P0 in ev170)
semantics7[av171, ev171]
all a: lab.T0 | a.av171 = ((((P1 + P2) + (P3 + P4)) + ((P5 + P7) + (P8 + P9))))
all a: lab.T1 | a.av171 = (((P1 + P2) + (P3 + (P4 + P6))))
not (R->P0 in ev171)
semantics6[av172, ev172]
all a: lab.T0 | a.av172 = ((P0 + (P2 + P7)))
all a: lab.T1 | a.av172 = ((P1 + (P3 + P8)))
not (R->P0 in ev172)
semantics8[av173, ev173]
all a: lab.T0 | a.av173 = ((P6 + (P7 + P8)))
all a: lab.T1 | a.av173 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P7 + P8))))
not (R->P0 in ev173)
semantics4[av174, ev174]
all a: lab.T0 | a.av174 = ((((P0 + P2) + (P3 + P4)) + ((P5 + P6) + (P7 + P8))))
all a: lab.T1 | a.av174 = (((P1 + P2) + (P5 + P6)))
not (R->P0 in ev174)
semantics18[av175, ev175]
all a: lab.T0 | a.av175 = ((P5 + (P6 + P7)))
all a: lab.T1 | a.av175 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev175)
semantics30[av176, ev176]
all a: lab.T0 | a.av176 = (((P3 + P4) + (P5 + P6)))
all a: lab.T1 | a.av176 = ((P0 + (P2 + P3)))
not (R->P0 in ev176)
semantics11[av177, ev177]
all a: lab.T0 | a.av177 = (((P0 + P1) + (P5 + P8)))
all a: lab.T1 | a.av177 = (((P0 + (P1 + P3)) + (P6 + (P8 + P9))))
not (R->P0 in ev177)
semantics10[av178, ev178]
all a: lab.T0 | a.av178 = ((((P0 + P1) + (P2 + P4)) + ((P5 + P6) + (P8 + P9))))
all a: lab.T1 | a.av178 = (((P0 + P1) + (P4 + (P5 + P6))))
not (R->P0 in ev178)
semantics3[av179, ev179]
all a: lab.T0 | a.av179 = (((P0 + P4) + (P6 + (P7 + P8))))
all a: lab.T1 | a.av179 = (((P1 + P3) + (P5 + (P6 + P7))))
not (R->P0 in ev179)
semantics17[av180, ev180]
all a: lab.T0 | a.av180 = ((((P0 + P1) + (P3 + P4)) + ((P6 + P7) + (P8 + P9))))
all a: lab.T1 | a.av180 = (((P1 + (P2 + P3)) + (P5 + (P6 + P8))))
not (R->P0 in ev180)
semantics31[av181, ev181]
all a: lab.T0 | a.av181 = ((P3 + (P4 + P5)))
all a: lab.T1 | a.av181 = ((P3 + P4))
not (R->P0 in ev181)
semantics3[av182, ev182]
all a: lab.T0 | a.av182 = (((P1 + (P3 + P5)) + ((P6 + P7) + (P8 + P9))))
all a: lab.T1 | a.av182 = (((P1 + (P2 + P4)) + ((P5 + P6) + (P7 + P9))))
not (R->P0 in ev182)
semantics20[av183, ev183]
all a: lab.T0 | a.av183 = (((P0 + P4) + (P6 + P7)))
all a: lab.T1 | a.av183 = (((P2 + P4) + (P5 + (P6 + P7))))
not (R->P0 in ev183)
semantics2[av184, ev184]
all a: lab.T0 | a.av184 = (((P0 + (P1 + P2)) + ((P5 + P6) + (P7 + P8))))
all a: lab.T1 | a.av184 = (((P2 + P5) + (P7 + P8)))
not (R->P0 in ev184)
semantics15[av185, ev185]
all a: lab.T0 | a.av185 = (((P0 + P4) + (P6 + (P7 + P8))))
all a: lab.T1 | a.av185 = (((P1 + P2) + (P3 + (P4 + P8))))
not (R->P0 in ev185)
semantics8[av186, ev186]
all a: lab.T0 | a.av186 = (((P1 + (P2 + P3)) + (P5 + (P6 + P8))))
all a: lab.T1 | a.av186 = (((P0 + (P1 + P3)) + ((P4 + P5) + (P6 + P9))))
not (R->P0 in ev186)
semantics5[av187, ev187]
all a: lab.T0 | a.av187 = (((P0 + (P1 + P3)) + (P4 + (P7 + P8))))
all a: lab.T1 | a.av187 = ((P1 + (P4 + P5)))
not (R->P0 in ev187)
semantics17[av188, ev188]
all a: lab.T0 | a.av188 = (((P1 + (P2 + P4)) + ((P6 + P7) + (P8 + P9))))
all a: lab.T1 | a.av188 = (((P1 + (P2 + P5)) + (P6 + (P7 + P8))))
not (R->P0 in ev188)
semantics11[av189, ev189]
all a: lab.T0 | a.av189 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P5) + (P8 + P9))))
all a: lab.T1 | a.av189 = ((P1 + P9))
not (R->P0 in ev189)
semantics4[av190, ev190]
all a: lab.T0 | a.av190 = ((P0 + (P5 + P9)))
all a: lab.T1 | a.av190 = (((P0 + P1) + (P2 + (P8 + P9))))
not (R->P0 in ev190)
semantics11[av191, ev191]
all a: lab.T0 | a.av191 = (((P2 + P4) + (P5 + (P6 + P8))))
all a: lab.T1 | a.av191 = (((P1 + (P2 + P3)) + ((P4 + P6) + (P8 + P9))))
not (R->P0 in ev191)
semantics2[av192, ev192]
all a: lab.T0 | a.av192 = (((P0 + (P1 + P2)) + ((P3 + P5) + (P6 + P8))))
all a: lab.T1 | a.av192 = (((P1 + P3) + (P4 + (P5 + P6))))
not (R->P0 in ev192)
semantics16[av193, ev193]
all a: lab.T0 | a.av193 = (((P1 + P2) + (P3 + (P4 + P6))))
all a: lab.T1 | a.av193 = (P7)
not (R->P0 in ev193)
semantics10[av194, ev194]
all a: lab.T0 | a.av194 = (((P0 + (P2 + P3)) + ((P4 + P5) + (P8 + P9))))
all a: lab.T1 | a.av194 = (((P1 + P4) + (P5 + (P6 + P8))))
not (R->P0 in ev194)
semantics3[av195, ev195]
all a: lab.T0 | a.av195 = ((P2 + (P4 + P6)))
all a: lab.T1 | a.av195 = (((P0 + P1) + (P5 + (P7 + P9))))
not (R->P0 in ev195)
semantics10[av196, ev196]
all a: lab.T0 | a.av196 = (((P0 + P3) + (P4 + (P6 + P7))))
all a: lab.T1 | a.av196 = (((P0 + (P4 + P6)) + (P7 + (P8 + P9))))
not (R->P0 in ev196)
semantics5[av197, ev197]
all a: lab.T0 | a.av197 = (((P0 + (P1 + P2)) + (P3 + (P6 + P9))))
all a: lab.T1 | a.av197 = (((P0 + (P3 + P4)) + ((P5 + P6) + (P8 + P9))))
not (R->P0 in ev197)
semantics4[av198, ev198]
all a: lab.T0 | a.av198 = (((P1 + P2) + (P4 + (P7 + P9))))
all a: lab.T1 | a.av198 = ((P2 + (P6 + P7)))
not (R->P0 in ev198)
semantics9[av199, ev199]
all a: lab.T0 | a.av199 = (((P0 + (P1 + P2)) + (P4 + (P6 + P9))))
all a: lab.T1 | a.av199 = (((P1 + P2) + (P6 + (P7 + P8))))
not (R->P0 in ev199)
semantics4[av200, ev200]
all a: lab.T0 | a.av200 = (((P0 + (P1 + P2)) + (P3 + (P4 + P5))))
all a: lab.T1 | a.av200 = ((((P0 + P1) + (P2 + P3)) + ((P4 + P6) + (P7 + (P8 + P9)))))
not (R->P0 in ev200)
semantics11[av201, ev201]
all a: lab.T0 | a.av201 = (((P1 + (P2 + P4)) + (P6 + (P7 + P9))))
all a: lab.T1 | a.av201 = (((P1 + (P2 + P4)) + ((P6 + P7) + (P8 + P9))))
not (R->P0 in ev201)
semantics12[av202, ev202]
all a: lab.T0 | a.av202 = (((P1 + (P2 + P3)) + ((P4 + P5) + (P6 + P9))))
all a: lab.T1 | a.av202 = ((P1 + (P2 + P9)))
not (R->P0 in ev202)
semantics0[av203, ev203]
all a: lab.T0 | a.av203 = (((P1 + P3) + (P5 + P8)))
all a: lab.T1 | a.av203 = (((P0 + (P2 + P3)) + (P5 + (P7 + P8))))
not (R->P0 in ev203)
semantics8[av204, ev204]
all a: lab.T0 | a.av204 = (((P1 + (P2 + P3)) + (P4 + (P6 + P8))))
all a: lab.T1 | a.av204 = (((P0 + P2) + (P4 + P7)))
not (R->P0 in ev204)
semantics4[av205, ev205]
all a: lab.T0 | a.av205 = (((P1 + (P2 + P3)) + (P5 + (P6 + P7))))
all a: lab.T1 | a.av205 = (((P0 + (P1 + P5)) + (P6 + (P8 + P9))))
not (R->P0 in ev205)
semantics7[av206, ev206]
all a: lab.T0 | a.av206 = (((P0 + P1) + (P4 + (P6 + P8))))
all a: lab.T1 | a.av206 = (((P0 + P3) + (P4 + (P7 + P8))))
not (R->P0 in ev206)
semantics7[av207, ev207]
all a: lab.T0 | a.av207 = (((P2 + P3) + (P7 + (P8 + P9))))
all a: lab.T1 | a.av207 = (P2)
not (R->P0 in ev207)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int

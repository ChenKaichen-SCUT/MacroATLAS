open util/ordering[SeqIdx]

abstract sig DAGNode {
	l: set DAGNode,
	r: set DAGNode
}
fact {
	all n: DAGNode | n not in n.^(l + r)
}

sig And, Or, Imply extends DAGNode {} {
	one l
	one r
}

sig Neg, F, G, X extends DAGNode {} {
    one l
    no r
}
abstract sig Literal extends DAGNode {} {
	no l
	no r
}

abstract sig SeqIdx {}
abstract sig Trace {
	lasso: SeqIdx -> SeqIdx,
	valuation: DAGNode -> SeqIdx
} {
	// Negation
    all n: Neg, i: seqRange | n->i in valuation iff n.l->i not in valuation
	// Or
    all n: Or, i: seqRange | n->i in valuation iff (n.l->i in valuation or n.r->i in valuation)
	// And
    all n: And, i: seqRange | n->i in valuation iff (n.l->i in valuation and n.r->i in valuation)
	// Imply
    all n: Imply, i: seqRange | n->i in valuation iff (n.l->i not in valuation or n.r->i in valuation)
	// G
    all n: G, i: seqRange | n->i in valuation iff all i': futureIdx[i] | n.l->i' in valuation
    // X
    all n: X, i: seqRange | n->i in valuation iff n.l->i.((next :> seqRange) + lasso) in valuation
	// F
    all n: F, i: seqRange | n->i in valuation iff some i': futureIdx[i] | n.l->i' in valuation
	// Until
    
}
fun seqRange[t: Trace]: set SeqIdx {
	let lastOfTrace = t.lasso.SeqIdx | lastOfTrace.prevs + lastOfTrace
}
fun futureIdx[t: Trace, i: SeqIdx]: set SeqIdx {
	i.^((next :> seqRange[t]) + t.lasso) + i
}
abstract sig PositiveTrace extends Trace {}
abstract sig NegativeTrace extends Trace {}
one sig x0, x1 extends Literal {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9 extends SeqIdx {}
fact {
    first = T0
    next = T0->T1 + T1->T2 + T2->T3 + T3->T4 + T4->T5 + T5->T6 + T6->T7 + T7->T8 + T8->T9
}

one sig PT0 extends PositiveTrace {} {
    lasso = T9->T2
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T5 + x1->T6 + x0->T8 + x1->T8 in valuation
    no (x1->T0 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x0->T7 + x1->T7 + x0->T9 + x1->T9) & valuation
}

one sig PT1 extends PositiveTrace {} {
    lasso = T9->T8
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x0->T7 + x0->T8 + x0->T9 in valuation
    no (x1->T2 + x0->T3 + x1->T3 + x0->T6 + x1->T6 + x1->T7 + x1->T8 + x1->T9) & valuation
}

one sig PT2 extends PositiveTrace {} {
    lasso = T9->T9
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T8 + x1->T9 in valuation
    no (x0->T0 + x0->T3 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x0->T9) & valuation
}

one sig PT3 extends PositiveTrace {} {
    lasso = T9->T4
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x0->T5 + x1->T5 + x0->T8 + x1->T8 + x1->T9 in valuation
    no (x0->T0 + x0->T1 + x0->T3 + x1->T4 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T9) & valuation
}

one sig PT4 extends PositiveTrace {} {
    lasso = T9->T2
    x1->T0 + x0->T3 + x0->T5 + x1->T5 + x0->T8 + x0->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x1->T8 + x1->T9) & valuation
}

one sig PT5 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x1->T2 + x1->T4 + x0->T5 + x1->T5 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x0->T6 + x1->T6 + x1->T9) & valuation
}

one sig PT6 extends PositiveTrace {} {
    lasso = T9->T9
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x0->T7 + x1->T7 + x0->T8 + x0->T9 in valuation
    no (x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T6 + x1->T8 + x1->T9) & valuation
}

one sig PT7 extends PositiveTrace {} {
    lasso = T9->T6
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x1->T4 + x0->T6 + x0->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x1->T8) & valuation
}

one sig PT8 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x1->T7 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x0->T8) & valuation
}

one sig PT9 extends PositiveTrace {} {
    lasso = T9->T8
    x0->T0 + x0->T3 + x1->T3 + x1->T4 + x0->T5 + x1->T5 + x0->T8 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT10 extends PositiveTrace {} {
    lasso = T9->T4
    x1->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T7 + x0->T8 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T6 + x0->T7 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT11 extends PositiveTrace {} {
    lasso = T9->T7
    x0->T0 + x1->T1 + x1->T3 + x1->T4 + x1->T5 + x0->T6 + x0->T7 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x0->T5 + x1->T6 + x1->T7 + x0->T8) & valuation
}

one sig PT12 extends PositiveTrace {} {
    lasso = T9->T3
    x0->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T9 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig PT13 extends PositiveTrace {} {
    lasso = T9->T2
    x0->T1 + x0->T2 + x0->T3 + x1->T4 + x1->T5 + x0->T6 + x0->T7 + x1->T7 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x1->T2 + x1->T3 + x0->T4 + x0->T5 + x1->T6 + x0->T8) & valuation
}

one sig PT14 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T9 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T4 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x1->T9) & valuation
}

one sig PT15 extends PositiveTrace {} {
    lasso = T9->T7
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x1->T6 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x1->T1 + x0->T2 + x1->T3 + x0->T6 + x0->T7 + x1->T7 + x1->T9) & valuation
}

one sig PT16 extends PositiveTrace {} {
    lasso = T9->T5
    x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T7 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T5 + x0->T6 + x1->T6 + x1->T7 + x1->T9) & valuation
}

one sig PT17 extends PositiveTrace {} {
    lasso = T9->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T4 + x0->T5 + x1->T6 + x0->T8 + x1->T9 in valuation
    no (x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T5 + x0->T6 + x0->T7 + x1->T7 + x1->T8 + x0->T9) & valuation
}

one sig PT18 extends PositiveTrace {} {
    lasso = T9->T3
    x0->T1 + x1->T3 + x1->T4 + x0->T5 + x0->T6 + x1->T6 + x1->T7 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T5 + x0->T7 + x0->T8 + x1->T9) & valuation
}

one sig PT19 extends PositiveTrace {} {
    lasso = T9->T3
    x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x0->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x0->T2 + x1->T2 + x1->T4 + x1->T5 + x1->T9) & valuation
}

one sig PT20 extends PositiveTrace {} {
    lasso = T9->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x0->T5 + x1->T6 + x1->T7 + x1->T9 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x1->T5 + x0->T6 + x0->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig PT21 extends PositiveTrace {} {
    lasso = T9->T4
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x0->T6 + x0->T7 + x1->T7 + x1->T8 in valuation
    no (x0->T2 + x1->T4 + x0->T5 + x1->T5 + x1->T6 + x0->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT22 extends PositiveTrace {} {
    lasso = T9->T9
    x0->T0 + x1->T1 + x1->T5 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x1->T6 + x0->T7) & valuation
}

one sig PT23 extends PositiveTrace {} {
    lasso = T9->T1
    x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T5 + x1->T5 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 + x0->T6 + x1->T6 + x1->T9) & valuation
}

one sig PT24 extends PositiveTrace {} {
    lasso = T9->T3
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x0->T6 + x1->T6 + x1->T9 in valuation
    no (x1->T0 + x0->T1 + x0->T4 + x0->T5 + x1->T5 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig PT25 extends PositiveTrace {} {
    lasso = T9->T7
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 + x0->T6 + x0->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x0->T5 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x1->T9) & valuation
}

one sig PT26 extends PositiveTrace {} {
    lasso = T9->T6
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T5 + x1->T7 in valuation
    no (x0->T0 + x1->T1 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x1->T6 + x0->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT27 extends PositiveTrace {} {
    lasso = T9->T2
    x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T5 + x0->T6 + x1->T6 + x1->T7 + x1->T8 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 + x0->T5 + x0->T7 + x0->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT28 extends PositiveTrace {} {
    lasso = T9->T6
    x1->T0 + x0->T1 + x0->T3 + x1->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T5 + x1->T6 + x1->T7) & valuation
}

one sig PT29 extends PositiveTrace {} {
    lasso = T9->T6
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T6 + x1->T6 + x1->T7 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x0->T7 + x1->T9) & valuation
}

one sig PT30 extends PositiveTrace {} {
    lasso = T9->T6
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T7 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x1->T2 + x1->T3 + x0->T4 + x1->T6 + x0->T7 + x0->T8) & valuation
}

one sig PT31 extends PositiveTrace {} {
    lasso = T9->T4
    x1->T0 + x1->T2 + x1->T3 + x0->T5 + x0->T6 + x1->T6 + x1->T8 + x1->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x1->T5 + x0->T7 + x1->T7 + x0->T8 + x0->T9) & valuation
}

one sig PT32 extends PositiveTrace {} {
    lasso = T9->T4
    x1->T0 + x1->T2 + x1->T3 + x0->T4 + x1->T5 + x1->T6 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T4 + x0->T5 + x0->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T9) & valuation
}

one sig PT33 extends PositiveTrace {} {
    lasso = T9->T7
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x1->T2 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x1->T9) & valuation
}

one sig PT34 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 + x1->T5 + x1->T6 + x0->T7 + x0->T8 + x1->T8 + x1->T9 in valuation
    no (x1->T0 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x1->T7 + x0->T9) & valuation
}

one sig PT35 extends PositiveTrace {} {
    lasso = T9->T2
    x0->T0 + x1->T0 + x0->T3 + x1->T4 + x0->T5 + x0->T6 + x1->T6 + x1->T7 + x0->T8 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T5 + x0->T7 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT36 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T7 + x1->T8 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x1->T6 + x0->T7 + x0->T8 + x0->T9) & valuation
}

one sig PT37 extends PositiveTrace {} {
    lasso = T9->T3
    x1->T0 + x1->T1 + x0->T5 + x0->T6 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T9) & valuation
}

one sig PT38 extends PositiveTrace {} {
    lasso = T9->T6
    x0->T1 + x1->T2 + x1->T3 + x1->T4 + x0->T5 + x0->T6 + x0->T7 + x1->T7 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T5 + x1->T6 + x0->T8 + x1->T8) & valuation
}

one sig PT39 extends PositiveTrace {} {
    lasso = T9->T7
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T7 in valuation
    no (x0->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT40 extends PositiveTrace {} {
    lasso = T9->T6
    x0->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T5 + x0->T6 + x1->T6 + x0->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 + x1->T5 + x1->T7) & valuation
}

one sig PT41 extends PositiveTrace {} {
    lasso = T9->T5
    x1->T0 + x0->T1 + x1->T2 + x1->T3 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x0->T9 + x1->T9) & valuation
}

one sig PT42 extends PositiveTrace {} {
    lasso = T9->T8
    x0->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T6 + x0->T7 + x1->T7 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x1->T0 + x0->T1 + x1->T2 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x0->T8) & valuation
}

one sig PT43 extends PositiveTrace {} {
    lasso = T9->T3
    x0->T0 + x0->T1 + x0->T4 + x0->T6 + x1->T6 + x1->T7 + x0->T9 + x1->T9 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x1->T4 + x0->T5 + x1->T5 + x0->T7 + x0->T8 + x1->T8) & valuation
}

one sig PT44 extends PositiveTrace {} {
    lasso = T9->T9
    x0->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T5 + x1->T5 + x0->T6 + x1->T7 + x1->T8 in valuation
    no (x1->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x1->T6 + x0->T7 + x0->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT45 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T5 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T4 + x1->T4 + x1->T5 + x0->T6 + x0->T9) & valuation
}

one sig PT46 extends PositiveTrace {} {
    lasso = T9->T3
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x1->T5 + x0->T6 + x1->T7 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x1->T1 + x0->T5 + x1->T6 + x0->T7 + x0->T8 + x1->T9) & valuation
}

one sig PT47 extends PositiveTrace {} {
    lasso = T9->T2
    x1->T0 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x0->T7 + x1->T7 + x1->T8 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT48 extends PositiveTrace {} {
    lasso = T9->T9
    x0->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T5 + x1->T5 + x0->T6 + x0->T7 + x1->T7 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 + x1->T6 + x0->T8 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT49 extends PositiveTrace {} {
    lasso = T9->T8
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T5 + x1->T5 + x1->T7 + x1->T9 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x0->T6 + x1->T6 + x0->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig PT50 extends PositiveTrace {} {
    lasso = T9->T7
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x0->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T8 + x1->T8 + x1->T9) & valuation
}

one sig PT51 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x1->T2 + x1->T4 + x0->T5 + x1->T6 + x0->T7 + x1->T7 + x1->T8 + x0->T9 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T5 + x0->T6 + x0->T8 + x1->T9) & valuation
}

one sig PT52 extends PositiveTrace {} {
    lasso = T9->T6
    x1->T1 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x1->T6 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT53 extends PositiveTrace {} {
    lasso = T9->T1
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T5 + x1->T5 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x0->T4 + x1->T4 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T9) & valuation
}

one sig PT54 extends PositiveTrace {} {
    lasso = T9->T7
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x1->T0 + x1->T1 + x1->T2 + x0->T6 + x1->T6 + x1->T9) & valuation
}

one sig PT55 extends PositiveTrace {} {
    lasso = T9->T3
    x0->T0 + x1->T0 + x1->T2 + x0->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x1->T8 + x0->T9 in valuation
    no (x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 + x0->T8 + x1->T9) & valuation
}

one sig PT56 extends PositiveTrace {} {
    lasso = T9->T6
    x0->T2 + x1->T2 + x0->T3 + x0->T5 + x1->T6 + x0->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 + x1->T5 + x0->T6 + x1->T7) & valuation
}

one sig PT57 extends PositiveTrace {} {
    lasso = T9->T5
    x0->T0 + x1->T0 + x0->T2 + x1->T3 + x0->T4 + x1->T5 + x0->T6 + x0->T7 + x1->T7 + x0->T9 + x1->T9 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T4 + x0->T5 + x1->T6 + x0->T8 + x1->T8) & valuation
}

one sig PT58 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x1->T5 + x0->T6 + x1->T6 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T5 + x0->T7 + x1->T7 + x1->T9) & valuation
}

one sig PT59 extends PositiveTrace {} {
    lasso = T9->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T5 + x0->T6 + x0->T7 + x1->T8 + x1->T9 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T6 + x1->T7 + x0->T8 + x0->T9) & valuation
}

one sig PT60 extends PositiveTrace {} {
    lasso = T9->T5
    x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x0->T6 + x0->T7 + x1->T7 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x1->T1 + x0->T2 + x1->T4 + x0->T5 + x1->T5 + x1->T6 + x0->T8 + x1->T9) & valuation
}

one sig PT61 extends PositiveTrace {} {
    lasso = T9->T9
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T6 + x1->T6 + x0->T8 + x0->T9 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x1->T4 + x0->T5 + x1->T5 + x0->T7 + x1->T7 + x1->T8 + x1->T9) & valuation
}

one sig PT62 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T4 + x1->T4 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T5) & valuation
}

one sig PT63 extends PositiveTrace {} {
    lasso = T9->T2
    x0->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 + x1->T5 + x0->T6 + x1->T6 + x0->T9 + x1->T9 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x0->T4 + x0->T5 + x0->T7 + x1->T7 + x0->T8 + x1->T8) & valuation
}

one sig PT64 extends PositiveTrace {} {
    lasso = T9->T4
    x0->T0 + x1->T0 + x1->T1 + x1->T2 + x0->T3 + x1->T6 + x0->T7 + x1->T7 + x1->T8 + x1->T9 in valuation
    no (x0->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x0->T8 + x0->T9) & valuation
}

one sig PT65 extends PositiveTrace {} {
    lasso = T9->T6
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T3 + x0->T5 + x0->T6 + x1->T7 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x1->T5 + x1->T6 + x0->T7 + x0->T8) & valuation
}

one sig PT66 extends PositiveTrace {} {
    lasso = T9->T4
    x0->T1 + x1->T1 + x1->T2 + x0->T4 + x1->T4 + x1->T5 + x1->T6 + x0->T7 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x0->T3 + x1->T3 + x0->T5 + x0->T6 + x1->T7 + x0->T8) & valuation
}

one sig PT67 extends PositiveTrace {} {
    lasso = T9->T4
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T1 + x1->T2 + x0->T4 + x0->T5 + x1->T8) & valuation
}

one sig PT68 extends PositiveTrace {} {
    lasso = T9->T8
    x1->T2 + x0->T3 + x0->T6 + x1->T6 + x0->T7 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x1->T7 + x0->T8 + x1->T8) & valuation
}

one sig PT69 extends PositiveTrace {} {
    lasso = T9->T4
    x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T7 + x1->T8 + x1->T9 in valuation
    no (x1->T0 + x1->T1 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x0->T8 + x0->T9) & valuation
}

one sig PT70 extends PositiveTrace {} {
    lasso = T9->T9
    x1->T0 + x1->T3 + x1->T4 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x0->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T8 + x1->T8 + x1->T9) & valuation
}

one sig PT71 extends PositiveTrace {} {
    lasso = T9->T9
    x0->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T5 + x1->T5 + x1->T8 + x0->T9 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x1->T3 + x0->T4 + x1->T4 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T9) & valuation
}

one sig PT72 extends PositiveTrace {} {
    lasso = T9->T7
    x1->T0 + x0->T2 + x1->T2 + x1->T5 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x1->T6) & valuation
}

one sig PT73 extends PositiveTrace {} {
    lasso = T9->T5
    x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T6 + x0->T7 + x1->T7 + x1->T8 in valuation
    no (x0->T0 + x1->T0 + x1->T2 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x1->T6 + x0->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT74 extends PositiveTrace {} {
    lasso = T9->T6
    x0->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T5 + x1->T5 + x1->T7 + x0->T8 + x1->T8 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T4 + x1->T4 + x0->T6 + x1->T6 + x0->T7 + x0->T9) & valuation
}

one sig PT75 extends PositiveTrace {} {
    lasso = T9->T3
    x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T5 + x1->T6 + x0->T7 + x0->T8 + x1->T9 in valuation
    no (x0->T0 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x1->T5 + x0->T6 + x1->T7 + x1->T8 + x0->T9) & valuation
}

one sig PT76 extends PositiveTrace {} {
    lasso = T9->T4
    x0->T2 + x1->T3 + x1->T5 + x0->T7 + x0->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x1->T6 + x1->T7 + x1->T8) & valuation
}

one sig PT77 extends PositiveTrace {} {
    lasso = T9->T9
    x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T5 + x1->T5 + x0->T6 + x1->T8 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T4 + x1->T4 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT78 extends PositiveTrace {} {
    lasso = T9->T1
    x1->T0 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T6 + x0->T7 + x1->T7 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x1->T3 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x0->T8 + x1->T9) & valuation
}

one sig PT79 extends PositiveTrace {} {
    lasso = T9->T9
    x0->T0 + x1->T0 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x1->T6 + x1->T8 + x1->T9 in valuation
    no (x0->T1 + x1->T1 + x0->T3 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x0->T7 + x1->T7 + x0->T8 + x0->T9) & valuation
}

one sig PT80 extends PositiveTrace {} {
    lasso = T9->T3
    x1->T1 + x1->T2 + x0->T5 + x1->T5 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT81 extends PositiveTrace {} {
    lasso = T9->T5
    x0->T0 + x1->T0 + x0->T1 + x1->T3 + x0->T4 + x1->T4 + x0->T9 + x1->T9 in valuation
    no (x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8) & valuation
}

one sig PT82 extends PositiveTrace {} {
    lasso = T9->T2
    x0->T2 + x1->T3 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8) & valuation
}

one sig PT83 extends PositiveTrace {} {
    lasso = T9->T9
    x1->T0 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x1->T5 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8) & valuation
}

one sig PT84 extends PositiveTrace {} {
    lasso = T9->T7
    x0->T1 + x1->T1 + x1->T3 + x0->T4 + x0->T6 + x0->T8 + x0->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T2 + x1->T2 + x0->T3 + x1->T4 + x0->T5 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x1->T8 + x1->T9) & valuation
}

one sig PT85 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x1->T6 + x0->T7 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x1->T1 + x1->T3 + x0->T5 + x1->T5 + x0->T6 + x1->T7 + x0->T8 + x1->T9) & valuation
}

one sig PT86 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T6 + x1->T7 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T1 + x1->T2 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x1->T6 + x0->T7 + x0->T8) & valuation
}

one sig PT87 extends PositiveTrace {} {
    lasso = T9->T2
    x0->T0 + x0->T2 + x1->T2 + x1->T3 + x1->T4 + x1->T5 + x1->T6 + x0->T7 + x0->T8 + x1->T9 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x1->T7 + x1->T8 + x0->T9) & valuation
}

one sig PT88 extends PositiveTrace {} {
    lasso = T9->T8
    x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x1->T6 + x1->T7 + x0->T8 + x0->T9 + x1->T9 in valuation
    no (x1->T0 + x1->T2 + x1->T3 + x1->T5 + x0->T7 + x1->T8) & valuation
}

one sig PT89 extends PositiveTrace {} {
    lasso = T9->T2
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T3 + x1->T4 + x0->T5 + x1->T5 + x1->T6 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x1->T1 + x0->T2 + x1->T3 + x0->T4 + x0->T6 + x0->T7 + x1->T7 + x1->T9) & valuation
}

one sig PT90 extends PositiveTrace {} {
    lasso = T9->T8
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T3 + x1->T3 + x1->T4 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x0->T2 + x1->T2 + x0->T4 + x0->T5 + x1->T9) & valuation
}

one sig PT91 extends PositiveTrace {} {
    lasso = T9->T6
    x1->T0 + x1->T1 + x0->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x0->T9 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T6 + x1->T8 + x1->T9) & valuation
}

one sig PT92 extends PositiveTrace {} {
    lasso = T9->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T4 + x1->T5 + x1->T6 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT93 extends PositiveTrace {} {
    lasso = T9->T6
    x0->T0 + x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x1->T4 + x0->T6 + x1->T8 in valuation
    no (x0->T1 + x1->T2 + x0->T4 + x0->T5 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT94 extends PositiveTrace {} {
    lasso = T9->T9
    x0->T0 + x0->T1 + x1->T2 + x1->T3 + x0->T4 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x0->T8 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T4 + x0->T5 + x0->T6 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT95 extends PositiveTrace {} {
    lasso = T9->T3
    x0->T1 + x1->T3 + x1->T5 + x0->T6 + x0->T7 + x1->T7 + x1->T8 + x0->T9 in valuation
    no (x0->T0 + x1->T0 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T6 + x0->T8 + x1->T9) & valuation
}

one sig PT96 extends PositiveTrace {} {
    lasso = T9->T1
    x1->T1 + x0->T2 + x1->T2 + x0->T5 + x1->T5 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8) & valuation
}

one sig PT97 extends PositiveTrace {} {
    lasso = T9->T5
    x0->T0 + x1->T0 + x1->T1 + x0->T3 + x1->T4 + x1->T6 + x1->T8 + x1->T9 in valuation
    no (x0->T1 + x0->T2 + x1->T2 + x1->T3 + x0->T4 + x0->T5 + x1->T5 + x0->T6 + x0->T7 + x1->T7 + x0->T8 + x0->T9) & valuation
}

one sig PT98 extends PositiveTrace {} {
    lasso = T9->T5
    x0->T0 + x1->T0 + x0->T2 + x0->T5 + x1->T5 + x1->T7 + x1->T9 in valuation
    no (x0->T1 + x1->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x0->T6 + x1->T6 + x0->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig PT99 extends PositiveTrace {} {
    lasso = T9->T1
    x0->T0 + x1->T0 + x0->T1 + x1->T2 + x0->T4 + x1->T4 + x0->T6 + x0->T8 + x0->T9 in valuation
    no (x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T5 + x1->T5 + x1->T6 + x0->T7 + x1->T7 + x1->T8 + x1->T9) & valuation
}


one sig NT0 extends NegativeTrace {} {
    lasso = T9->T7
    x1->T2 + x1->T5 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig NT1 extends NegativeTrace {} {
    lasso = T9->T5
    x1->T0 + x1->T2 + x1->T4 + x1->T5 + x1->T7 + x1->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x0->T5 + x0->T6 + x1->T6 + x0->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig NT2 extends NegativeTrace {} {
    lasso = T9->T1
    x1->T2 + x1->T3 + x1->T4 + x1->T5 + x1->T6 + x1->T7 + x1->T8 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x1->T9) & valuation
}

one sig NT3 extends NegativeTrace {} {
    lasso = T9->T3
    x1->T0 + x1->T1 + x1->T2 + x1->T4 + x1->T6 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x0->T3 + x1->T3 + x0->T4 + x0->T5 + x1->T5 + x0->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig LearnedLTL {
    Root: DAGNode
}
fun root: one DAGNode { LearnedLTL.Root }
fun childrenOf[n: DAGNode]: set DAGNode { n.^(l+r) }
fun childrenAndSelfOf[n: DAGNode]: set DAGNode { n.*(l+r) }
fun ancestorsOf[n: DAGNode]: set DAGNode { n.~^(l+r) }
fun ancestorsAndSelfOf[n: DAGNode]: set DAGNode { n.~*(l+r) }
fun subDAG[n: DAGNode]: DAGNode -> DAGNode { n.*(l+r) <: (l+r) }



fun experimentReach: set DAGNode { childrenAndSelfOf[root] }
fun experimentKept: DAGNode -> DAGNode { (none->none) & subDAG[root] }
one sig ExperimentCost { used: set DAGNode }
fact { ExperimentCost.used = experimentReach }
fact ExperimentBounds {
  DAGNode = experimentReach + Literal + (none)
  #experimentReach <= 3
  #(experimentReach & (And + Or + Imply)) <= 2
  minsome ExperimentCost.used
}
run {
    all t: PositiveTrace | root->T0 in t.valuation
    all t: NegativeTrace | root->T0 not in t.valuation
    
} for 5 DAGNode, 4 Int
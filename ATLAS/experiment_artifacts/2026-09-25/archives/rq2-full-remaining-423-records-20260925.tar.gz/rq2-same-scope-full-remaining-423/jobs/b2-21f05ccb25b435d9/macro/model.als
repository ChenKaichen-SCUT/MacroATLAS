abstract sig Unit {}
one sig U0, U1, U2, U3, U4 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9 extends Label {}
abstract sig Q {}
one sig Q0 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E13, E14, E15, E16, E17, E18, E19, E20, E21, E22, E23, E24, E25, E27, E29 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos, av20: set Pos, av21: set Pos, av22: set Pos, av23: set Pos, av24: set Pos, av25: set Pos, av26: set Pos, av27: set Pos, av28: set Pos, av29: set Pos, av30: set Pos, av31: set Pos, av32: set Pos, av33: set Pos, av34: set Pos, av35: set Pos, av36: set Pos, av37: set Pos, av38: set Pos, av39: set Pos, av40: set Pos, av41: set Pos, av42: set Pos, av43: set Pos, av44: set Pos, av45: set Pos, av46: set Pos, av47: set Pos, av48: set Pos, av49: set Pos, av50: set Pos, av51: set Pos, av52: set Pos, av53: set Pos, av54: set Pos, av55: set Pos, av56: set Pos, av57: set Pos, av58: set Pos, av59: set Pos, av60: set Pos, av61: set Pos, av62: set Pos, av63: set Pos, av64: set Pos, av65: set Pos, av66: set Pos, av67: set Pos, av68: set Pos, av69: set Pos, av70: set Pos, av71: set Pos, av72: set Pos, av73: set Pos, av74: set Pos, av75: set Pos, av76: set Pos, av77: set Pos, av78: set Pos, av79: set Pos, av80: set Pos, av81: set Pos, av82: set Pos, av83: set Pos, av84: set Pos, av85: set Pos, av86: set Pos, av87: set Pos, av88: set Pos, av89: set Pos, av90: set Pos, av91: set Pos, av92: set Pos, av93: set Pos, av94: set Pos, av95: set Pos, av96: set Pos, av97: set Pos, av98: set Pos, av99: set Pos, av100: set Pos, av101: set Pos, av102: set Pos, av103: set Pos, av104: set Pos, av105: set Pos, av106: set Pos, av107: set Pos, av108: set Pos, av109: set Pos, av110: set Pos, av111: set Pos, av112: set Pos, av113: set Pos, av114: set Pos, av115: set Pos, av116: set Pos, av117: set Pos, av118: set Pos, av119: set Pos, av120: set Pos, av121: set Pos, av122: set Pos, av123: set Pos, av124: set Pos, av125: set Pos, av126: set Pos, av127: set Pos, av128: set Pos, av129: set Pos, av130: set Pos, av131: set Pos, av132: set Pos, av133: set Pos, av134: set Pos, av135: set Pos, av136: set Pos, av137: set Pos, av138: set Pos, av139: set Pos, av140: set Pos, av141: set Pos, av142: set Pos, av143: set Pos, av144: set Pos, av145: set Pos, av146: set Pos, av147: set Pos, av148: set Pos, av149: set Pos, av150: set Pos, av151: set Pos, av152: set Pos, av153: set Pos, av154: set Pos, av155: set Pos, av156: set Pos, av157: set Pos, av158: set Pos, av159: set Pos, av160: set Pos, av161: set Pos, av162: set Pos, av163: set Pos, av164: set Pos, av165: set Pos, av166: set Pos, av167: set Pos, av168: set Pos, av169: set Pos, av170: set Pos, av171: set Pos, av172: set Pos, av173: set Pos, av174: set Pos, av175: set Pos, av176: set Pos, av177: set Pos, av178: set Pos, av179: set Pos, av180: set Pos, av181: set Pos, av182: set Pos, av183: set Pos, av184: set Pos, av185: set Pos, av186: set Pos, av187: set Pos, av188: set Pos, av189: set Pos, av190: set Pos, av191: set Pos, av192: set Pos, av193: set Pos, av194: set Pos, av195: set Pos, av196: set Pos, av197: set Pos, av198: set Pos, av199: set Pos, av200: set Pos, av201: set Pos, av202: set Pos, av203: set Pos, av204: set Pos, av205: set Pos, av206: set Pos, av207: set Pos, av208: set Pos, av209: set Pos, av210: set Pos, av211: set Pos, av212: set Pos, av213: set Pos, av214: set Pos, av215: set Pos, av216: set Pos, av217: set Pos, av218: set Pos, av219: set Pos, av220: set Pos, av221: set Pos, av222: set Pos, av223: set Pos, av224: set Pos, av225: set Pos, av226: set Pos, av227: set Pos, av228: set Pos, av229: set Pos, av230: set Pos, av231: set Pos, av232: set Pos, av233: set Pos, av234: set Pos, av235: set Pos, av236: set Pos, av237: set Pos, av238: set Pos, av239: set Pos, av240: set Pos, av241: set Pos, av242: set Pos, av243: set Pos, av244: set Pos, av245: set Pos, av246: set Pos, av247: set Pos, av248: set Pos, av249: set Pos, av250: set Pos, av251: set Pos, av252: set Pos, av253: set Pos, av254: set Pos, av255: set Pos, av256: set Pos, av257: set Pos, av258: set Pos, av259: set Pos, av260: set Pos, av261: set Pos, av262: set Pos, av263: set Pos, av264: set Pos, av265: set Pos, av266: set Pos, av267: set Pos, av268: set Pos, av269: set Pos, av270: set Pos, av271: set Pos, av272: set Pos, av273: set Pos, av274: set Pos, av275: set Pos, av276: set Pos, av277: set Pos, av278: set Pos, av279: set Pos, av280: set Pos, av281: set Pos, av282: set Pos, av283: set Pos, av284: set Pos, av285: set Pos, av286: set Pos, av287: set Pos, av288: set Pos, av289: set Pos, av290: set Pos, av291: set Pos, av292: set Pos, av293: set Pos, av294: set Pos, av295: set Pos, av296: set Pos, av297: set Pos, av298: set Pos, av299: set Pos, av300: set Pos, av301: set Pos, av302: set Pos, av303: set Pos, av304: set Pos, av305: set Pos, av306: set Pos, av307: set Pos, av308: set Pos, av309: set Pos, av310: set Pos, av311: set Pos, av312: set Pos, av313: set Pos, av314: set Pos, av315: set Pos, av316: set Pos, av317: set Pos, av318: set Pos, av319: set Pos, av320: set Pos, av321: set Pos, av322: set Pos, av323: set Pos, av324: set Pos, av325: set Pos, av326: set Pos, av327: set Pos, av328: set Pos, av329: set Pos, av330: set Pos, av331: set Pos, av332: set Pos, av333: set Pos, av334: set Pos, av335: set Pos, av336: set Pos, av337: set Pos, av338: set Pos, av339: set Pos, av340: set Pos, av341: set Pos, av342: set Pos, av343: set Pos, av344: set Pos, av345: set Pos, av346: set Pos, av347: set Pos, av348: set Pos, av349: set Pos, av350: set Pos, av351: set Pos, av352: set Pos, av353: set Pos, av354: set Pos, av355: set Pos, av356: set Pos, av357: set Pos, av358: set Pos, av359: set Pos, av360: set Pos, av361: set Pos, av362: set Pos, av363: set Pos, av364: set Pos, av365: set Pos, av366: set Pos, av367: set Pos, av368: set Pos, av369: set Pos, av370: set Pos, av371: set Pos, av372: set Pos, av373: set Pos, av374: set Pos, av375: set Pos, av376: set Pos, av377: set Pos, av378: set Pos, av379: set Pos, av380: set Pos, av381: set Pos, av382: set Pos, av383: set Pos, av384: set Pos, av385: set Pos, av386: set Pos, av387: set Pos, av388: set Pos, av389: set Pos, av390: set Pos, av391: set Pos, av392: set Pos, av393: set Pos, av394: set Pos, av395: set Pos, av396: set Pos, av397: set Pos, av398: set Pos, av399: set Pos, av400: set Pos, av401: set Pos, av402: set Pos, av403: set Pos, av404: set Pos, av405: set Pos, av406: set Pos, av407: set Pos, av408: set Pos, av409: set Pos, av410: set Pos, av411: set Pos, av412: set Pos, av413: set Pos, av414: set Pos, av415: set Pos, av416: set Pos, av417: set Pos, av418: set Pos, av419: set Pos, av420: set Pos, av421: set Pos, av422: set Pos, av423: set Pos, av424: set Pos, av425: set Pos, av426: set Pos, av427: set Pos, av428: set Pos, av429: set Pos, av430: set Pos, av431: set Pos, av432: set Pos, av433: set Pos, av434: set Pos, av435: set Pos, av436: set Pos, av437: set Pos, av438: set Pos, av439: set Pos, av440: set Pos, av441: set Pos, av442: set Pos, av443: set Pos, av444: set Pos, av445: set Pos, av446: set Pos, av447: set Pos, av448: set Pos, av449: set Pos, av450: set Pos, av451: set Pos, av452: set Pos, av453: set Pos, av454: set Pos, av455: set Pos, av456: set Pos, av457: set Pos, av458: set Pos, av459: set Pos, av460: set Pos, av461: set Pos, av462: set Pos, av463: set Pos, av464: set Pos, av465: set Pos, av466: set Pos, av467: set Pos, av468: set Pos, av469: set Pos, av470: set Pos, av471: set Pos, av472: set Pos, av473: set Pos, av474: set Pos, av475: set Pos, av476: set Pos, av477: set Pos, av478: set Pos, av479: set Pos, av480: set Pos, av481: set Pos, av482: set Pos, av483: set Pos, av484: set Pos, av485: set Pos, av486: set Pos, av487: set Pos, av488: set Pos, av489: set Pos, av490: set Pos, av491: set Pos, av492: set Pos, av493: set Pos, av494: set Pos, av495: set Pos, av496: set Pos, av497: set Pos, av498: set Pos, av499: set Pos, av500: set Pos, av501: set Pos, av502: set Pos, av503: set Pos, av504: set Pos, av505: set Pos, av506: set Pos, av507: set Pos, av508: set Pos, av509: set Pos, av510: set Pos, av511: set Pos, av512: set Pos, av513: set Pos, av514: set Pos, av515: set Pos, av516: set Pos, av517: set Pos, av518: set Pos, av519: set Pos, av520: set Pos, av521: set Pos, av522: set Pos, av523: set Pos, av524: set Pos, av525: set Pos, av526: set Pos, av527: set Pos, av528: set Pos, av529: set Pos, av530: set Pos, av531: set Pos, av532: set Pos, av533: set Pos, av534: set Pos, av535: set Pos, av536: set Pos, av537: set Pos, av538: set Pos, av539: set Pos, av540: set Pos, av541: set Pos, av542: set Pos, av543: set Pos, av544: set Pos, av545: set Pos, av546: set Pos, av547: set Pos, av548: set Pos, av549: set Pos, av550: set Pos, av551: set Pos, av552: set Pos, av553: set Pos, av554: set Pos, av555: set Pos, av556: set Pos, av557: set Pos, av558: set Pos, av559: set Pos, av560: set Pos, av561: set Pos, av562: set Pos, av563: set Pos, av564: set Pos, av565: set Pos, av566: set Pos, av567: set Pos, av568: set Pos, av569: set Pos, av570: set Pos, av571: set Pos, av572: set Pos, av573: set Pos, av574: set Pos, av575: set Pos, av576: set Pos, av577: set Pos, av578: set Pos, av579: set Pos, av580: set Pos, av581: set Pos, av582: set Pos, av583: set Pos, av584: set Pos, av585: set Pos, av586: set Pos, av587: set Pos, av588: set Pos, av589: set Pos, av590: set Pos, av591: set Pos, av592: set Pos, av593: set Pos, av594: set Pos, av595: set Pos, av596: set Pos, av597: set Pos, av598: set Pos, av599: set Pos, av600: set Pos, av601: set Pos, av602: set Pos, av603: set Pos, av604: set Pos, av605: set Pos, av606: set Pos, av607: set Pos, av608: set Pos, av609: set Pos, av610: set Pos, av611: set Pos, av612: set Pos, av613: set Pos, av614: set Pos, av615: set Pos, av616: set Pos, av617: set Pos, av618: set Pos, av619: set Pos, av620: set Pos, av621: set Pos, av622: set Pos, av623: set Pos, av624: set Pos, av625: set Pos, av626: set Pos, av627: set Pos, av628: set Pos, av629: set Pos, av630: set Pos, av631: set Pos, av632: set Pos, av633: set Pos, av634: set Pos, av635: set Pos, av636: set Pos, av637: set Pos, av638: set Pos, av639: set Pos, av640: set Pos, av641: set Pos, av642: set Pos, av643: set Pos, av644: set Pos, av645: set Pos, av646: set Pos, av647: set Pos, av648: set Pos, av649: set Pos, av650: set Pos, av651: set Pos, av652: set Pos, av653: set Pos, av654: set Pos, av655: set Pos, av656: set Pos, av657: set Pos, av658: set Pos, av659: set Pos, av660: set Pos, av661: set Pos, av662: set Pos, av663: set Pos, av664: set Pos, av665: set Pos, av666: set Pos, av667: set Pos, av668: set Pos, av669: set Pos, av670: set Pos, av671: set Pos, av672: set Pos, av673: set Pos, av674: set Pos, av675: set Pos, av676: set Pos, av677: set Pos, av678: set Pos, av679: set Pos, av680: set Pos, av681: set Pos, av682: set Pos, av683: set Pos, av684: set Pos, av685: set Pos, av686: set Pos, av687: set Pos, av688: set Pos, av689: set Pos, av690: set Pos, av691: set Pos, av692: set Pos, av693: set Pos, av694: set Pos, av695: set Pos, av696: set Pos, av697: set Pos, av698: set Pos, av699: set Pos, av700: set Pos, av701: set Pos, av702: set Pos, av703: set Pos, av704: set Pos, av705: set Pos, av706: set Pos, av707: set Pos, av708: set Pos, av709: set Pos, av710: set Pos, av711: set Pos, av712: set Pos, av713: set Pos, av714: set Pos, av715: set Pos, av716: set Pos, av717: set Pos, av718: set Pos, av719: set Pos, av720: set Pos, av721: set Pos, av722: set Pos, av723: set Pos, av724: set Pos, av725: set Pos, av726: set Pos, av727: set Pos, av728: set Pos, av729: set Pos, av730: set Pos, av731: set Pos, av732: set Pos, av733: set Pos, av734: set Pos, av735: set Pos, av736: set Pos, av737: set Pos, av738: set Pos, av739: set Pos, av740: set Pos, av741: set Pos, av742: set Pos, av743: set Pos, av744: set Pos, av745: set Pos, av746: set Pos, av747: set Pos, av748: set Pos, av749: set Pos, av750: set Pos, av751: set Pos, av752: set Pos, av753: set Pos, av754: set Pos, av755: set Pos, av756: set Pos, av757: set Pos, av758: set Pos, av759: set Pos, av760: set Pos, av761: set Pos, av762: set Pos, av763: set Pos, av764: set Pos, av765: set Pos, av766: set Pos, av767: set Pos, av768: set Pos, av769: set Pos, av770: set Pos, av771: set Pos, av772: set Pos, av773: set Pos, av774: set Pos, av775: set Pos, av776: set Pos, av777: set Pos, av778: set Pos, av779: set Pos, av780: set Pos, av781: set Pos, av782: set Pos, av783: set Pos, av784: set Pos, av785: set Pos, av786: set Pos, av787: set Pos, av788: set Pos, av789: set Pos, av790: set Pos, av791: set Pos, av792: set Pos, av793: set Pos, av794: set Pos, av795: set Pos, av796: set Pos, av797: set Pos, av798: set Pos, av799: set Pos, av800: set Pos, av801: set Pos, av802: set Pos, av803: set Pos, av804: set Pos, av805: set Pos, av806: set Pos, av807: set Pos, av808: set Pos, av809: set Pos, av810: set Pos, av811: set Pos, av812: set Pos, av813: set Pos, av814: set Pos, av815: set Pos, av816: set Pos, av817: set Pos, av818: set Pos, av819: set Pos, av820: set Pos, av821: set Pos, av822: set Pos, av823: set Pos, av824: set Pos, av825: set Pos, av826: set Pos, av827: set Pos, av828: set Pos, av829: set Pos, av830: set Pos, av831: set Pos, av832: set Pos, av833: set Pos, av834: set Pos, av835: set Pos, av836: set Pos, av837: set Pos, av838: set Pos, av839: set Pos, av840: set Pos, av841: set Pos, av842: set Pos, av843: set Pos, av844: set Pos, av845: set Pos, av846: set Pos, av847: set Pos, av848: set Pos, av849: set Pos, av850: set Pos, av851: set Pos, av852: set Pos, av853: set Pos, av854: set Pos, av855: set Pos, av856: set Pos, av857: set Pos, av858: set Pos, av859: set Pos, av860: set Pos, av861: set Pos, av862: set Pos, av863: set Pos, av864: set Pos, av865: set Pos, av866: set Pos, av867: set Pos, av868: set Pos, av869: set Pos, av870: set Pos, av871: set Pos, av872: set Pos, av873: set Pos, av874: set Pos, av875: set Pos, av876: set Pos, av877: set Pos, av878: set Pos, av879: set Pos, av880: set Pos, av881: set Pos, av882: set Pos, av883: set Pos, av884: set Pos, av885: set Pos, av886: set Pos, av887: set Pos, av888: set Pos, av889: set Pos, av890: set Pos, av891: set Pos, av892: set Pos, av893: set Pos, av894: set Pos, av895: set Pos, av896: set Pos, av897: set Pos, av898: set Pos, av899: set Pos, av900: set Pos, av901: set Pos, av902: set Pos, av903: set Pos, av904: set Pos, av905: set Pos, av906: set Pos, av907: set Pos, av908: set Pos, av909: set Pos, av910: set Pos, av911: set Pos, av912: set Pos, av913: set Pos, av914: set Pos, av915: set Pos, av916: set Pos, av917: set Pos, av918: set Pos, av919: set Pos, av920: set Pos, av921: set Pos, av922: set Pos, av923: set Pos, av924: set Pos, av925: set Pos, av926: set Pos, av927: set Pos, av928: set Pos, av929: set Pos, av930: set Pos, av931: set Pos, av932: set Pos, av933: set Pos, av934: set Pos, av935: set Pos, av936: set Pos, av937: set Pos, av938: set Pos, av939: set Pos, av940: set Pos, av941: set Pos, av942: set Pos, av943: set Pos, av944: set Pos, av945: set Pos, av946: set Pos, av947: set Pos, av948: set Pos, av949: set Pos, av950: set Pos, av951: set Pos, av952: set Pos, av953: set Pos, av954: set Pos, av955: set Pos, av956: set Pos, av957: set Pos, av958: set Pos, av959: set Pos, av960: set Pos, av961: set Pos, av962: set Pos, av963: set Pos, av964: set Pos, av965: set Pos, av966: set Pos, av967: set Pos, av968: set Pos, av969: set Pos, av970: set Pos, av971: set Pos, av972: set Pos, av973: set Pos, av974: set Pos, av975: set Pos, av976: set Pos, av977: set Pos, av978: set Pos, av979: set Pos, av980: set Pos, av981: set Pos, av982: set Pos, av983: set Pos, av984: set Pos, av985: set Pos }
one sig A0, A1, A2, A3, A4 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos, ev20: set Pos, ev21: set Pos, ev22: set Pos, ev23: set Pos, ev24: set Pos, ev25: set Pos, ev26: set Pos, ev27: set Pos, ev28: set Pos, ev29: set Pos, ev30: set Pos, ev31: set Pos, ev32: set Pos, ev33: set Pos, ev34: set Pos, ev35: set Pos, ev36: set Pos, ev37: set Pos, ev38: set Pos, ev39: set Pos, ev40: set Pos, ev41: set Pos, ev42: set Pos, ev43: set Pos, ev44: set Pos, ev45: set Pos, ev46: set Pos, ev47: set Pos, ev48: set Pos, ev49: set Pos, ev50: set Pos, ev51: set Pos, ev52: set Pos, ev53: set Pos, ev54: set Pos, ev55: set Pos, ev56: set Pos, ev57: set Pos, ev58: set Pos, ev59: set Pos, ev60: set Pos, ev61: set Pos, ev62: set Pos, ev63: set Pos, ev64: set Pos, ev65: set Pos, ev66: set Pos, ev67: set Pos, ev68: set Pos, ev69: set Pos, ev70: set Pos, ev71: set Pos, ev72: set Pos, ev73: set Pos, ev74: set Pos, ev75: set Pos, ev76: set Pos, ev77: set Pos, ev78: set Pos, ev79: set Pos, ev80: set Pos, ev81: set Pos, ev82: set Pos, ev83: set Pos, ev84: set Pos, ev85: set Pos, ev86: set Pos, ev87: set Pos, ev88: set Pos, ev89: set Pos, ev90: set Pos, ev91: set Pos, ev92: set Pos, ev93: set Pos, ev94: set Pos, ev95: set Pos, ev96: set Pos, ev97: set Pos, ev98: set Pos, ev99: set Pos, ev100: set Pos, ev101: set Pos, ev102: set Pos, ev103: set Pos, ev104: set Pos, ev105: set Pos, ev106: set Pos, ev107: set Pos, ev108: set Pos, ev109: set Pos, ev110: set Pos, ev111: set Pos, ev112: set Pos, ev113: set Pos, ev114: set Pos, ev115: set Pos, ev116: set Pos, ev117: set Pos, ev118: set Pos, ev119: set Pos, ev120: set Pos, ev121: set Pos, ev122: set Pos, ev123: set Pos, ev124: set Pos, ev125: set Pos, ev126: set Pos, ev127: set Pos, ev128: set Pos, ev129: set Pos, ev130: set Pos, ev131: set Pos, ev132: set Pos, ev133: set Pos, ev134: set Pos, ev135: set Pos, ev136: set Pos, ev137: set Pos, ev138: set Pos, ev139: set Pos, ev140: set Pos, ev141: set Pos, ev142: set Pos, ev143: set Pos, ev144: set Pos, ev145: set Pos, ev146: set Pos, ev147: set Pos, ev148: set Pos, ev149: set Pos, ev150: set Pos, ev151: set Pos, ev152: set Pos, ev153: set Pos, ev154: set Pos, ev155: set Pos, ev156: set Pos, ev157: set Pos, ev158: set Pos, ev159: set Pos, ev160: set Pos, ev161: set Pos, ev162: set Pos, ev163: set Pos, ev164: set Pos, ev165: set Pos, ev166: set Pos, ev167: set Pos, ev168: set Pos, ev169: set Pos, ev170: set Pos, ev171: set Pos, ev172: set Pos, ev173: set Pos, ev174: set Pos, ev175: set Pos, ev176: set Pos, ev177: set Pos, ev178: set Pos, ev179: set Pos, ev180: set Pos, ev181: set Pos, ev182: set Pos, ev183: set Pos, ev184: set Pos, ev185: set Pos, ev186: set Pos, ev187: set Pos, ev188: set Pos, ev189: set Pos, ev190: set Pos, ev191: set Pos, ev192: set Pos, ev193: set Pos, ev194: set Pos, ev195: set Pos, ev196: set Pos, ev197: set Pos, ev198: set Pos, ev199: set Pos, ev200: set Pos, ev201: set Pos, ev202: set Pos, ev203: set Pos, ev204: set Pos, ev205: set Pos, ev206: set Pos, ev207: set Pos, ev208: set Pos, ev209: set Pos, ev210: set Pos, ev211: set Pos, ev212: set Pos, ev213: set Pos, ev214: set Pos, ev215: set Pos, ev216: set Pos, ev217: set Pos, ev218: set Pos, ev219: set Pos, ev220: set Pos, ev221: set Pos, ev222: set Pos, ev223: set Pos, ev224: set Pos, ev225: set Pos, ev226: set Pos, ev227: set Pos, ev228: set Pos, ev229: set Pos, ev230: set Pos, ev231: set Pos, ev232: set Pos, ev233: set Pos, ev234: set Pos, ev235: set Pos, ev236: set Pos, ev237: set Pos, ev238: set Pos, ev239: set Pos, ev240: set Pos, ev241: set Pos, ev242: set Pos, ev243: set Pos, ev244: set Pos, ev245: set Pos, ev246: set Pos, ev247: set Pos, ev248: set Pos, ev249: set Pos, ev250: set Pos, ev251: set Pos, ev252: set Pos, ev253: set Pos, ev254: set Pos, ev255: set Pos, ev256: set Pos, ev257: set Pos, ev258: set Pos, ev259: set Pos, ev260: set Pos, ev261: set Pos, ev262: set Pos, ev263: set Pos, ev264: set Pos, ev265: set Pos, ev266: set Pos, ev267: set Pos, ev268: set Pos, ev269: set Pos, ev270: set Pos, ev271: set Pos, ev272: set Pos, ev273: set Pos, ev274: set Pos, ev275: set Pos, ev276: set Pos, ev277: set Pos, ev278: set Pos, ev279: set Pos, ev280: set Pos, ev281: set Pos, ev282: set Pos, ev283: set Pos, ev284: set Pos, ev285: set Pos, ev286: set Pos, ev287: set Pos, ev288: set Pos, ev289: set Pos, ev290: set Pos, ev291: set Pos, ev292: set Pos, ev293: set Pos, ev294: set Pos, ev295: set Pos, ev296: set Pos, ev297: set Pos, ev298: set Pos, ev299: set Pos, ev300: set Pos, ev301: set Pos, ev302: set Pos, ev303: set Pos, ev304: set Pos, ev305: set Pos, ev306: set Pos, ev307: set Pos, ev308: set Pos, ev309: set Pos, ev310: set Pos, ev311: set Pos, ev312: set Pos, ev313: set Pos, ev314: set Pos, ev315: set Pos, ev316: set Pos, ev317: set Pos, ev318: set Pos, ev319: set Pos, ev320: set Pos, ev321: set Pos, ev322: set Pos, ev323: set Pos, ev324: set Pos, ev325: set Pos, ev326: set Pos, ev327: set Pos, ev328: set Pos, ev329: set Pos, ev330: set Pos, ev331: set Pos, ev332: set Pos, ev333: set Pos, ev334: set Pos, ev335: set Pos, ev336: set Pos, ev337: set Pos, ev338: set Pos, ev339: set Pos, ev340: set Pos, ev341: set Pos, ev342: set Pos, ev343: set Pos, ev344: set Pos, ev345: set Pos, ev346: set Pos, ev347: set Pos, ev348: set Pos, ev349: set Pos, ev350: set Pos, ev351: set Pos, ev352: set Pos, ev353: set Pos, ev354: set Pos, ev355: set Pos, ev356: set Pos, ev357: set Pos, ev358: set Pos, ev359: set Pos, ev360: set Pos, ev361: set Pos, ev362: set Pos, ev363: set Pos, ev364: set Pos, ev365: set Pos, ev366: set Pos, ev367: set Pos, ev368: set Pos, ev369: set Pos, ev370: set Pos, ev371: set Pos, ev372: set Pos, ev373: set Pos, ev374: set Pos, ev375: set Pos, ev376: set Pos, ev377: set Pos, ev378: set Pos, ev379: set Pos, ev380: set Pos, ev381: set Pos, ev382: set Pos, ev383: set Pos, ev384: set Pos, ev385: set Pos, ev386: set Pos, ev387: set Pos, ev388: set Pos, ev389: set Pos, ev390: set Pos, ev391: set Pos, ev392: set Pos, ev393: set Pos, ev394: set Pos, ev395: set Pos, ev396: set Pos, ev397: set Pos, ev398: set Pos, ev399: set Pos, ev400: set Pos, ev401: set Pos, ev402: set Pos, ev403: set Pos, ev404: set Pos, ev405: set Pos, ev406: set Pos, ev407: set Pos, ev408: set Pos, ev409: set Pos, ev410: set Pos, ev411: set Pos, ev412: set Pos, ev413: set Pos, ev414: set Pos, ev415: set Pos, ev416: set Pos, ev417: set Pos, ev418: set Pos, ev419: set Pos, ev420: set Pos, ev421: set Pos, ev422: set Pos, ev423: set Pos, ev424: set Pos, ev425: set Pos, ev426: set Pos, ev427: set Pos, ev428: set Pos, ev429: set Pos, ev430: set Pos, ev431: set Pos, ev432: set Pos, ev433: set Pos, ev434: set Pos, ev435: set Pos, ev436: set Pos, ev437: set Pos, ev438: set Pos, ev439: set Pos, ev440: set Pos, ev441: set Pos, ev442: set Pos, ev443: set Pos, ev444: set Pos, ev445: set Pos, ev446: set Pos, ev447: set Pos, ev448: set Pos, ev449: set Pos, ev450: set Pos, ev451: set Pos, ev452: set Pos, ev453: set Pos, ev454: set Pos, ev455: set Pos, ev456: set Pos, ev457: set Pos, ev458: set Pos, ev459: set Pos, ev460: set Pos, ev461: set Pos, ev462: set Pos, ev463: set Pos, ev464: set Pos, ev465: set Pos, ev466: set Pos, ev467: set Pos, ev468: set Pos, ev469: set Pos, ev470: set Pos, ev471: set Pos, ev472: set Pos, ev473: set Pos, ev474: set Pos, ev475: set Pos, ev476: set Pos, ev477: set Pos, ev478: set Pos, ev479: set Pos, ev480: set Pos, ev481: set Pos, ev482: set Pos, ev483: set Pos, ev484: set Pos, ev485: set Pos, ev486: set Pos, ev487: set Pos, ev488: set Pos, ev489: set Pos, ev490: set Pos, ev491: set Pos, ev492: set Pos, ev493: set Pos, ev494: set Pos, ev495: set Pos, ev496: set Pos, ev497: set Pos, ev498: set Pos, ev499: set Pos, ev500: set Pos, ev501: set Pos, ev502: set Pos, ev503: set Pos, ev504: set Pos, ev505: set Pos, ev506: set Pos, ev507: set Pos, ev508: set Pos, ev509: set Pos, ev510: set Pos, ev511: set Pos, ev512: set Pos, ev513: set Pos, ev514: set Pos, ev515: set Pos, ev516: set Pos, ev517: set Pos, ev518: set Pos, ev519: set Pos, ev520: set Pos, ev521: set Pos, ev522: set Pos, ev523: set Pos, ev524: set Pos, ev525: set Pos, ev526: set Pos, ev527: set Pos, ev528: set Pos, ev529: set Pos, ev530: set Pos, ev531: set Pos, ev532: set Pos, ev533: set Pos, ev534: set Pos, ev535: set Pos, ev536: set Pos, ev537: set Pos, ev538: set Pos, ev539: set Pos, ev540: set Pos, ev541: set Pos, ev542: set Pos, ev543: set Pos, ev544: set Pos, ev545: set Pos, ev546: set Pos, ev547: set Pos, ev548: set Pos, ev549: set Pos, ev550: set Pos, ev551: set Pos, ev552: set Pos, ev553: set Pos, ev554: set Pos, ev555: set Pos, ev556: set Pos, ev557: set Pos, ev558: set Pos, ev559: set Pos, ev560: set Pos, ev561: set Pos, ev562: set Pos, ev563: set Pos, ev564: set Pos, ev565: set Pos, ev566: set Pos, ev567: set Pos, ev568: set Pos, ev569: set Pos, ev570: set Pos, ev571: set Pos, ev572: set Pos, ev573: set Pos, ev574: set Pos, ev575: set Pos, ev576: set Pos, ev577: set Pos, ev578: set Pos, ev579: set Pos, ev580: set Pos, ev581: set Pos, ev582: set Pos, ev583: set Pos, ev584: set Pos, ev585: set Pos, ev586: set Pos, ev587: set Pos, ev588: set Pos, ev589: set Pos, ev590: set Pos, ev591: set Pos, ev592: set Pos, ev593: set Pos, ev594: set Pos, ev595: set Pos, ev596: set Pos, ev597: set Pos, ev598: set Pos, ev599: set Pos, ev600: set Pos, ev601: set Pos, ev602: set Pos, ev603: set Pos, ev604: set Pos, ev605: set Pos, ev606: set Pos, ev607: set Pos, ev608: set Pos, ev609: set Pos, ev610: set Pos, ev611: set Pos, ev612: set Pos, ev613: set Pos, ev614: set Pos, ev615: set Pos, ev616: set Pos, ev617: set Pos, ev618: set Pos, ev619: set Pos, ev620: set Pos, ev621: set Pos, ev622: set Pos, ev623: set Pos, ev624: set Pos, ev625: set Pos, ev626: set Pos, ev627: set Pos, ev628: set Pos, ev629: set Pos, ev630: set Pos, ev631: set Pos, ev632: set Pos, ev633: set Pos, ev634: set Pos, ev635: set Pos, ev636: set Pos, ev637: set Pos, ev638: set Pos, ev639: set Pos, ev640: set Pos, ev641: set Pos, ev642: set Pos, ev643: set Pos, ev644: set Pos, ev645: set Pos, ev646: set Pos, ev647: set Pos, ev648: set Pos, ev649: set Pos, ev650: set Pos, ev651: set Pos, ev652: set Pos, ev653: set Pos, ev654: set Pos, ev655: set Pos, ev656: set Pos, ev657: set Pos, ev658: set Pos, ev659: set Pos, ev660: set Pos, ev661: set Pos, ev662: set Pos, ev663: set Pos, ev664: set Pos, ev665: set Pos, ev666: set Pos, ev667: set Pos, ev668: set Pos, ev669: set Pos, ev670: set Pos, ev671: set Pos, ev672: set Pos, ev673: set Pos, ev674: set Pos, ev675: set Pos, ev676: set Pos, ev677: set Pos, ev678: set Pos, ev679: set Pos, ev680: set Pos, ev681: set Pos, ev682: set Pos, ev683: set Pos, ev684: set Pos, ev685: set Pos, ev686: set Pos, ev687: set Pos, ev688: set Pos, ev689: set Pos, ev690: set Pos, ev691: set Pos, ev692: set Pos, ev693: set Pos, ev694: set Pos, ev695: set Pos, ev696: set Pos, ev697: set Pos, ev698: set Pos, ev699: set Pos, ev700: set Pos, ev701: set Pos, ev702: set Pos, ev703: set Pos, ev704: set Pos, ev705: set Pos, ev706: set Pos, ev707: set Pos, ev708: set Pos, ev709: set Pos, ev710: set Pos, ev711: set Pos, ev712: set Pos, ev713: set Pos, ev714: set Pos, ev715: set Pos, ev716: set Pos, ev717: set Pos, ev718: set Pos, ev719: set Pos, ev720: set Pos, ev721: set Pos, ev722: set Pos, ev723: set Pos, ev724: set Pos, ev725: set Pos, ev726: set Pos, ev727: set Pos, ev728: set Pos, ev729: set Pos, ev730: set Pos, ev731: set Pos, ev732: set Pos, ev733: set Pos, ev734: set Pos, ev735: set Pos, ev736: set Pos, ev737: set Pos, ev738: set Pos, ev739: set Pos, ev740: set Pos, ev741: set Pos, ev742: set Pos, ev743: set Pos, ev744: set Pos, ev745: set Pos, ev746: set Pos, ev747: set Pos, ev748: set Pos, ev749: set Pos, ev750: set Pos, ev751: set Pos, ev752: set Pos, ev753: set Pos, ev754: set Pos, ev755: set Pos, ev756: set Pos, ev757: set Pos, ev758: set Pos, ev759: set Pos, ev760: set Pos, ev761: set Pos, ev762: set Pos, ev763: set Pos, ev764: set Pos, ev765: set Pos, ev766: set Pos, ev767: set Pos, ev768: set Pos, ev769: set Pos, ev770: set Pos, ev771: set Pos, ev772: set Pos, ev773: set Pos, ev774: set Pos, ev775: set Pos, ev776: set Pos, ev777: set Pos, ev778: set Pos, ev779: set Pos, ev780: set Pos, ev781: set Pos, ev782: set Pos, ev783: set Pos, ev784: set Pos, ev785: set Pos, ev786: set Pos, ev787: set Pos, ev788: set Pos, ev789: set Pos, ev790: set Pos, ev791: set Pos, ev792: set Pos, ev793: set Pos, ev794: set Pos, ev795: set Pos, ev796: set Pos, ev797: set Pos, ev798: set Pos, ev799: set Pos, ev800: set Pos, ev801: set Pos, ev802: set Pos, ev803: set Pos, ev804: set Pos, ev805: set Pos, ev806: set Pos, ev807: set Pos, ev808: set Pos, ev809: set Pos, ev810: set Pos, ev811: set Pos, ev812: set Pos, ev813: set Pos, ev814: set Pos, ev815: set Pos, ev816: set Pos, ev817: set Pos, ev818: set Pos, ev819: set Pos, ev820: set Pos, ev821: set Pos, ev822: set Pos, ev823: set Pos, ev824: set Pos, ev825: set Pos, ev826: set Pos, ev827: set Pos, ev828: set Pos, ev829: set Pos, ev830: set Pos, ev831: set Pos, ev832: set Pos, ev833: set Pos, ev834: set Pos, ev835: set Pos, ev836: set Pos, ev837: set Pos, ev838: set Pos, ev839: set Pos, ev840: set Pos, ev841: set Pos, ev842: set Pos, ev843: set Pos, ev844: set Pos, ev845: set Pos, ev846: set Pos, ev847: set Pos, ev848: set Pos, ev849: set Pos, ev850: set Pos, ev851: set Pos, ev852: set Pos, ev853: set Pos, ev854: set Pos, ev855: set Pos, ev856: set Pos, ev857: set Pos, ev858: set Pos, ev859: set Pos, ev860: set Pos, ev861: set Pos, ev862: set Pos, ev863: set Pos, ev864: set Pos, ev865: set Pos, ev866: set Pos, ev867: set Pos, ev868: set Pos, ev869: set Pos, ev870: set Pos, ev871: set Pos, ev872: set Pos, ev873: set Pos, ev874: set Pos, ev875: set Pos, ev876: set Pos, ev877: set Pos, ev878: set Pos, ev879: set Pos, ev880: set Pos, ev881: set Pos, ev882: set Pos, ev883: set Pos, ev884: set Pos, ev885: set Pos, ev886: set Pos, ev887: set Pos, ev888: set Pos, ev889: set Pos, ev890: set Pos, ev891: set Pos, ev892: set Pos, ev893: set Pos, ev894: set Pos, ev895: set Pos, ev896: set Pos, ev897: set Pos, ev898: set Pos, ev899: set Pos, ev900: set Pos, ev901: set Pos, ev902: set Pos, ev903: set Pos, ev904: set Pos, ev905: set Pos, ev906: set Pos, ev907: set Pos, ev908: set Pos, ev909: set Pos, ev910: set Pos, ev911: set Pos, ev912: set Pos, ev913: set Pos, ev914: set Pos, ev915: set Pos, ev916: set Pos, ev917: set Pos, ev918: set Pos, ev919: set Pos, ev920: set Pos, ev921: set Pos, ev922: set Pos, ev923: set Pos, ev924: set Pos, ev925: set Pos, ev926: set Pos, ev927: set Pos, ev928: set Pos, ev929: set Pos, ev930: set Pos, ev931: set Pos, ev932: set Pos, ev933: set Pos, ev934: set Pos, ev935: set Pos, ev936: set Pos, ev937: set Pos, ev938: set Pos, ev939: set Pos, ev940: set Pos, ev941: set Pos, ev942: set Pos, ev943: set Pos, ev944: set Pos, ev945: set Pos, ev946: set Pos, ev947: set Pos, ev948: set Pos, ev949: set Pos, ev950: set Pos, ev951: set Pos, ev952: set Pos, ev953: set Pos, ev954: set Pos, ev955: set Pos, ev956: set Pos, ev957: set Pos, ev958: set Pos, ev959: set Pos, ev960: set Pos, ev961: set Pos, ev962: set Pos, ev963: set Pos, ev964: set Pos, ev965: set Pos, ev966: set Pos, ev967: set Pos, ev968: set Pos, ev969: set Pos, ev970: set Pos, ev971: set Pos, ev972: set Pos, ev973: set Pos, ev974: set Pos, ev975: set Pos, ev976: set Pos, ev977: set Pos, ev978: set Pos, ev979: set Pos, ev980: set Pos, ev981: set Pos, ev982: set Pos, ev983: set Pos, ev984: set Pos, ev985: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2, C3, L3, D3, C4, L4, D4 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (T0 + (T1 + T2)) }
fun un: set Label { ((T3 + T4) + (T5 + T6)) }
fun bin: set Label { (T7 + (T8 + T9)) }
fun nonempty: set Fiber { ((((E1 + (E2 + E3)) + (E4 + (E5 + E6))) + ((E7 + (E8 + E9)) + ((E10 + E11) + (E12 + E13)))) + (((E14 + (E15 + E16)) + ((E17 + E18) + (E19 + E20))) + ((E21 + (E22 + E23)) + ((E24 + E25) + (E27 + E29))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { ((U0->U1 + U1->U2) + (U2->U3 + U3->U4)) }
fun carrierNext: Carrier -> Carrier { ((((A0->A1 + A1->A2) + (A2->A3 + (A3->A4 + A4->R))) + ((R->C0 + C0->L0) + (L0->D0 + (D0->C1 + C1->L1)))) + (((L1->D1 + D1->C2) + (C2->L2 + (L2->D2 + D2->C3))) + ((C3->L3 + L3->D3) + (D3->C4 + (C4->L4 + L4->D4))))) }
fun child[a: Anchor]: set Port { a.(((A0->C0 + A1->C1) + (A2->C2 + (A3->C3 + A4->C4)))) }
fun left[a: Anchor]: set Port { a.(((A0->L0 + A1->L1) + (A2->L2 + (A3->L3 + A4->L4)))) }
fun right[a: Anchor]: set Port { a.(((A0->D0 + A1->D1) + (A2->D2 + (A3->D3 + A4->D4)))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
C3.src = A3
L3.src = A3
D3.src = A3
(some C3.target iff A3.lab in un and some A3.lab)
(some L3.target iff A3.lab in bin and some A3.lab)
(some D3.target iff A3.lab in bin and some A3.lab)
C4.src = A4
L4.src = A4
D4.src = A4
(some C4.target iff A4.lab in un and some A4.lab)
(some L4.target iff A4.lab in bin and some A4.lab)
(some D4.target iff A4.lab in bin and some A4.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
no A3.graph & (((A0 + A1) + (A2 + A3)))
no A4.graph & (((A0 + A1) + (A2 + (A3 + A4))))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
lone lab.T2
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un implies #(target.A2) > 1
some A2.lab implies some A1.lab
some A3.lab and A3.lab in un implies #(target.A3) > 1
some A3.lab implies some A2.lab
some A4.lab and A4.lab in un implies #(target.A4) > 1
some A4.lab implies some A3.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q0
E7.qo = Q0
E8.qi = Q0
E8.qo = Q0
E9.qi = Q0
E9.qo = Q0
E10.qi = Q0
E10.qo = Q0
E11.qi = Q0
E11.qo = Q0
E12.qi = Q0
E12.qo = Q0
E13.qi = Q0
E13.qo = Q0
E14.qi = Q0
E14.qo = Q0
E15.qi = Q0
E15.qo = Q0
E16.qi = Q0
E16.qo = Q0
E17.qi = Q0
E17.qo = Q0
E18.qi = Q0
E18.qo = Q0
E19.qi = Q0
E19.qo = Q0
E20.qi = Q0
E20.qo = Q0
E21.qi = Q0
E21.qo = Q0
E22.qi = Q0
E22.qo = Q0
E23.qi = Q0
E23.qo = Q0
E24.qi = Q0
E24.qo = Q0
E25.qi = Q0
E25.qo = Q0
E27.qi = Q0
E27.qo = Q0
E29.qi = Q0
E29.qo = Q0
all e: used | e.fiber in (E0) implies #e.cost = 0
all e: used | e.fiber in ((((E1 + E4) + (E6 + E7)) + ((E9 + E12) + (E13 + (E15 + E17))))) implies #e.cost = 2
all e: used | e.fiber in (((E2 + E3) + (E5 + E11))) implies #e.cost = 1
all e: used | e.fiber in ((((E8 + E10) + (E14 + E16)) + ((E18 + E19) + (E21 + E23)))) implies #e.cost = 3
all e: used | e.fiber in (((E20 + (E22 + E24)) + (E25 + (E27 + E29)))) implies #e.cost = 4
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q0)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 implies a.state = Q0
all a: active | a.lab = T3 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T4 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T5 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T6 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T8 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T9 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
}
fun range0: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop0: set Pos { (P2 + (P3 + P4)) }
fun next0: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift0_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun shift0_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P2 + P4->P3))) }
fun shift0_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift0_4: Pos -> Pos { ((P0->P4 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range0 | loop0 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range0 | loop0 in (range0 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range0 | some (loop0 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range0 | some (loop0 & (range0 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range0 | (i.shift0_1) in (range0 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range0 | (i.shift0_1).future0 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range0 | (i.shift0_1).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range0 | (i.shift0_2) in (range0 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range0 | (i.shift0_2).future0 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range0 | (i.shift0_2).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range0 | (i.shift0_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range0 | (i.shift0_3) in (range0 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range0 | some ((i.shift0_3).future0 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range0 | (i.shift0_3).future0 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range0 | (i.shift0_4) in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next0.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop1: set Pos { P4 }
fun next1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift1_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun shift1_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift1_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
fun shift1_4: Pos -> Pos { ((P0->P4 + P1->P4) + (P2->P4 + (P3->P4 + P4->P4))) }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range1 | loop1 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range1 | loop1 in (range1 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range1 | some (loop1 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range1 | some (loop1 & (range1 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range1 | (i.shift1_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range1 | (i.shift1_1) in (range1 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range1 | (i.shift1_1).future1 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range1 | (i.shift1_1).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range1 | (i.shift1_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range1 | (i.shift1_2) in (range1 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range1 | (i.shift1_2).future1 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range1 | (i.shift1_2).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range1 | (i.shift1_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range1 | (i.shift1_3) in (range1 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range1 | some ((i.shift1_3).future1 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range1 | (i.shift1_3).future1 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range1 | (i.shift1_4) in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next1.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fun range2: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop2: set Pos { ((P1 + P2) + (P3 + P4)) }
fun next2: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift2_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun shift2_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P1 + P4->P2))) }
fun shift2_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P1 + (P3->P2 + P4->P3))) }
fun shift2_4: Pos -> Pos { ((P0->P4 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range2 | (i.shift2_0) in (range2 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range2 | (i.shift2_0).future2 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range2 | (i.shift2_0).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range2 | loop2 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range2 | loop2 in (range2 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range2 | some (loop2 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range2 | some (loop2 & (range2 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range2 | (i.shift2_1) in (range2 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range2 | (i.shift2_1).future2 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range2 | (i.shift2_1).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range2 | (i.shift2_2) in (range2 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range2 | some ((i.shift2_2).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range2 | (i.shift2_2).future2 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range2 | (i.shift2_2).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range2 | (i.shift2_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range2 | (i.shift2_3) in (range2 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range2 | some ((i.shift2_3).future2 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range2 | (i.shift2_3).future2 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range2 | (i.shift2_4) in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range2 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next2.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range2 | some (i.future2 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range2 | i.future2 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range2 - left[a].ev) + right[a].ev)
}
fun range3: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop3: set Pos { P3 }
fun next3: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift3_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun shift3_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P3 + P3->P3)) }
fun shift3_3: Pos -> Pos { ((P0->P3 + P1->P3) + (P2->P3 + P3->P3)) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range3 | (i.shift3_0) in (range3 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range3 | (i.shift3_0).future3 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range3 | (i.shift3_0).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range3 | loop3 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range3 | loop3 in (range3 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range3 | some (loop3 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range3 | some (loop3 & (range3 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range3 | (i.shift3_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range3 | (i.shift3_1) in (range3 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range3 | (i.shift3_1).future3 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range3 | (i.shift3_1).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range3 | (i.shift3_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range3 | (i.shift3_2) in (range3 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range3 | some ((i.shift3_2).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range3 | (i.shift3_2).future3 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range3 | (i.shift3_2).future3 in (range3 - e.target.av)}
all e: used | e.fiber in ((E23 + E29)) implies e.ev = {i: range3 | (i.shift3_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range3 | (i.shift3_3) in (range3 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range3 | some ((i.shift3_3).future3 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range3 | (i.shift3_3).future3 in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range3 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next3.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range3 | some (i.future3 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range3 | i.future3 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range3 - left[a].ev) + right[a].ev)
}
fun range4: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop4: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun next4: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift4_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun shift4_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P0 + P4->P1))) }
fun shift4_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P0 + (P3->P1 + P4->P2))) }
fun shift4_4: Pos -> Pos { ((P0->P4 + P1->P0) + (P2->P1 + (P3->P2 + P4->P3))) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range4 | (i.shift4_0) in (range4 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range4 | (i.shift4_0).future4 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range4 | (i.shift4_0).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range4 | loop4 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range4 | loop4 in (range4 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range4 | some (loop4 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range4 | some (loop4 & (range4 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range4 | (i.shift4_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range4 | (i.shift4_1) in (range4 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range4 | (i.shift4_1).future4 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range4 | (i.shift4_1).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range4 | (i.shift4_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range4 | (i.shift4_2) in (range4 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range4 | some ((i.shift4_2).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range4 | (i.shift4_2).future4 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range4 | (i.shift4_2).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range4 | (i.shift4_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range4 | (i.shift4_3) in (range4 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range4 | some ((i.shift4_3).future4 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range4 | (i.shift4_3).future4 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range4 | (i.shift4_4) in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range4 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next4.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range4 | some (i.future4 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range4 | i.future4 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range4 - left[a].ev) + right[a].ev)
}
fun range5: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop5: set Pos { (P3 + P4) }
fun next5: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift5_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun shift5_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P3 + P4->P4))) }
fun shift5_3: Pos -> Pos { ((P0->P3 + P1->P4) + (P2->P3 + (P3->P4 + P4->P3))) }
fun shift5_4: Pos -> Pos { ((P0->P4 + P1->P3) + (P2->P4 + (P3->P3 + P4->P4))) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range5 | (i.shift5_0) in (range5 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range5 | (i.shift5_0).future5 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range5 | (i.shift5_0).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range5 | loop5 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range5 | loop5 in (range5 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range5 | some (loop5 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range5 | some (loop5 & (range5 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range5 | (i.shift5_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range5 | (i.shift5_1) in (range5 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range5 | (i.shift5_1).future5 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range5 | (i.shift5_1).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range5 | (i.shift5_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range5 | (i.shift5_2) in (range5 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range5 | some ((i.shift5_2).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range5 | (i.shift5_2).future5 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range5 | (i.shift5_2).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range5 | (i.shift5_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range5 | (i.shift5_3) in (range5 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range5 | some ((i.shift5_3).future5 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range5 | (i.shift5_3).future5 in (e.target.av)}
all e: used | e.fiber in (E29) implies e.ev = {i: range5 | (i.shift5_4) in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range5 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next5.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range5 | some (i.future5 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range5 | i.future5 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range5 - left[a].ev) + right[a].ev)
}
fun range6: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop6: set Pos { ((P0 + P1) + (P2 + P3)) }
fun next6: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun future6: Pos -> Pos { (*next6) & (range6->range6) }
fun shift6_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift6_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun shift6_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P0 + P3->P1)) }
fun shift6_3: Pos -> Pos { ((P0->P3 + P1->P0) + (P2->P1 + P3->P2)) }
pred semantics6[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range6
ev in used->range6
all e: used | e.fiber in ((E0 + (E1 + E29))) implies e.ev = {i: range6 | (i.shift6_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range6 | (i.shift6_0) in (range6 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range6 | (i.shift6_0).future6 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range6 | (i.shift6_0).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range6 | loop6 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range6 | loop6 in (range6 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range6 | some (loop6 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range6 | some (loop6 & (range6 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range6 | (i.shift6_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range6 | (i.shift6_1) in (range6 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range6 | (i.shift6_1).future6 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range6 | (i.shift6_1).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range6 | (i.shift6_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range6 | (i.shift6_2) in (range6 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range6 | some ((i.shift6_2).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range6 | (i.shift6_2).future6 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range6 | (i.shift6_2).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range6 | (i.shift6_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range6 | (i.shift6_3) in (range6 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range6 | some ((i.shift6_3).future6 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range6 | (i.shift6_3).future6 in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range6 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next6.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range6 | some (i.future6 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range6 | i.future6 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range6 - left[a].ev) + right[a].ev)
}
fun range7: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop7: set Pos { (P2 + P3) }
fun next7: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P2)) }
fun future7: Pos -> Pos { (*next7) & (range7->range7) }
fun shift7_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift7_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P2)) }
fun shift7_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P2 + P3->P3)) }
fun shift7_3: Pos -> Pos { ((P0->P3 + P1->P2) + (P2->P3 + P3->P2)) }
pred semantics7[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range7
ev in used->range7
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range7 | (i.shift7_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range7 | (i.shift7_0) in (range7 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range7 | (i.shift7_0).future7 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range7 | (i.shift7_0).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range7 | loop7 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range7 | loop7 in (range7 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range7 | some (loop7 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range7 | some (loop7 & (range7 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range7 | (i.shift7_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range7 | (i.shift7_1) in (range7 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range7 | (i.shift7_1).future7 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range7 | (i.shift7_1).future7 in (range7 - e.target.av)}
all e: used | e.fiber in ((E17 + E29)) implies e.ev = {i: range7 | (i.shift7_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range7 | (i.shift7_2) in (range7 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range7 | some ((i.shift7_2).future7 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range7 | some ((i.shift7_2).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range7 | (i.shift7_2).future7 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range7 | (i.shift7_2).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range7 | (i.shift7_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range7 | (i.shift7_3) in (range7 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range7 | some ((i.shift7_3).future7 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range7 | (i.shift7_3).future7 in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range7 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next7.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range7 | some (i.future7 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range7 | i.future7 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range7 - left[a].ev) + right[a].ev)
}
fun range8: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop8: set Pos { (P1 + (P2 + P3)) }
fun next8: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P1)) }
fun future8: Pos -> Pos { (*next8) & (range8->range8) }
fun shift8_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift8_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P1)) }
fun shift8_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P1 + P3->P2)) }
fun shift8_3: Pos -> Pos { ((P0->P3 + P1->P1) + (P2->P2 + P3->P3)) }
pred semantics8[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range8
ev in used->range8
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range8 | (i.shift8_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range8 | (i.shift8_0) in (range8 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range8 | (i.shift8_0).future8 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range8 | (i.shift8_0).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range8 | loop8 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range8 | loop8 in (range8 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range8 | some (loop8 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range8 | some (loop8 & (range8 - e.target.av))}
all e: used | e.fiber in ((E11 + E29)) implies e.ev = {i: range8 | (i.shift8_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range8 | (i.shift8_1) in (range8 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range8 | (i.shift8_1).future8 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range8 | (i.shift8_1).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range8 | (i.shift8_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range8 | (i.shift8_2) in (range8 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range8 | some ((i.shift8_2).future8 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range8 | some ((i.shift8_2).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range8 | (i.shift8_2).future8 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range8 | (i.shift8_2).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E23) implies e.ev = {i: range8 | (i.shift8_3) in (e.target.av)}
all e: used | e.fiber in (E24) implies e.ev = {i: range8 | (i.shift8_3) in (range8 - e.target.av)}
all e: used | e.fiber in (E25) implies e.ev = {i: range8 | some ((i.shift8_3).future8 & (e.target.av))}
all e: used | e.fiber in (E27) implies e.ev = {i: range8 | (i.shift8_3).future8 in (e.target.av)}
all a: active | a.lab = T3 implies a.av = (range8 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next8.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range8 | some (i.future8 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range8 | i.future8 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range8 - left[a].ev) + right[a].ev)
}
fun range9: set Pos { (P0 + (P1 + P2)) }
fun loop9: set Pos { P2 }
fun next9: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun future9: Pos -> Pos { (*next9) & (range9->range9) }
fun shift9_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift9_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun shift9_2: Pos -> Pos { (P0->P2 + (P1->P2 + P2->P2)) }
pred semantics9[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range9
ev in used->range9
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range9 | (i.shift9_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range9 | (i.shift9_0) in (range9 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range9 | (i.shift9_0).future9 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range9 | (i.shift9_0).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range9 | loop9 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range9 | loop9 in (range9 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range9 | some (loop9 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range9 | some (loop9 & (range9 - e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range9 | (i.shift9_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range9 | (i.shift9_1) in (range9 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range9 | (i.shift9_1).future9 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range9 | (i.shift9_1).future9 in (range9 - e.target.av)}
all e: used | e.fiber in ((E17 + (E23 + E29))) implies e.ev = {i: range9 | (i.shift9_2) in (e.target.av)}
all e: used | e.fiber in ((E18 + E24)) implies e.ev = {i: range9 | (i.shift9_2) in (range9 - e.target.av)}
all e: used | e.fiber in ((E19 + E25)) implies e.ev = {i: range9 | some ((i.shift9_2).future9 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range9 | some ((i.shift9_2).future9 & (range9 - e.target.av))}
all e: used | e.fiber in ((E21 + E27)) implies e.ev = {i: range9 | (i.shift9_2).future9 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range9 | (i.shift9_2).future9 in (range9 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range9 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next9.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range9 | some (i.future9 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range9 | i.future9 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range9 - left[a].ev) + right[a].ev)
}
fun range10: set Pos { (P0 + (P1 + P2)) }
fun loop10: set Pos { (P1 + P2) }
fun next10: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P1)) }
fun future10: Pos -> Pos { (*next10) & (range10->range10) }
fun shift10_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift10_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P1)) }
fun shift10_2: Pos -> Pos { (P0->P2 + (P1->P1 + P2->P2)) }
pred semantics10[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range10
ev in used->range10
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range10 | (i.shift10_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range10 | (i.shift10_0) in (range10 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range10 | (i.shift10_0).future10 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range10 | (i.shift10_0).future10 in (range10 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range10 | loop10 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range10 | loop10 in (range10 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range10 | some (loop10 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range10 | some (loop10 & (range10 - e.target.av))}
all e: used | e.fiber in ((E11 + E23)) implies e.ev = {i: range10 | (i.shift10_1) in (e.target.av)}
all e: used | e.fiber in ((E12 + E24)) implies e.ev = {i: range10 | (i.shift10_1) in (range10 - e.target.av)}
all e: used | e.fiber in ((E13 + E25)) implies e.ev = {i: range10 | some ((i.shift10_1).future10 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range10 | some ((i.shift10_1).future10 & (range10 - e.target.av))}
all e: used | e.fiber in ((E15 + E27)) implies e.ev = {i: range10 | (i.shift10_1).future10 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range10 | (i.shift10_1).future10 in (range10 - e.target.av)}
all e: used | e.fiber in ((E17 + E29)) implies e.ev = {i: range10 | (i.shift10_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range10 | (i.shift10_2) in (range10 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range10 | some ((i.shift10_2).future10 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range10 | some ((i.shift10_2).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range10 | (i.shift10_2).future10 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range10 | (i.shift10_2).future10 in (range10 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range10 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next10.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range10 | some (i.future10 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range10 | i.future10 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range10 - left[a].ev) + right[a].ev)
}
fun range11: set Pos { (P0 + (P1 + P2)) }
fun loop11: set Pos { (P0 + (P1 + P2)) }
fun next11: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P0)) }
fun future11: Pos -> Pos { (*next11) & (range11->range11) }
fun shift11_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift11_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P0)) }
fun shift11_2: Pos -> Pos { (P0->P2 + (P1->P0 + P2->P1)) }
pred semantics11[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range11
ev in used->range11
all e: used | e.fiber in ((E0 + (E1 + E23))) implies e.ev = {i: range11 | (i.shift11_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + E24)) implies e.ev = {i: range11 | (i.shift11_0) in (range11 - e.target.av)}
all e: used | e.fiber in ((E3 + E25)) implies e.ev = {i: range11 | some ((i.shift11_0).future11 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range11 | some ((i.shift11_0).future11 & (range11 - e.target.av))}
all e: used | e.fiber in ((E5 + E27)) implies e.ev = {i: range11 | (i.shift11_0).future11 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range11 | (i.shift11_0).future11 in (range11 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range11 | loop11 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range11 | loop11 in (range11 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range11 | some (loop11 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range11 | some (loop11 & (range11 - e.target.av))}
all e: used | e.fiber in ((E11 + E29)) implies e.ev = {i: range11 | (i.shift11_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range11 | (i.shift11_1) in (range11 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range11 | some ((i.shift11_1).future11 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range11 | some ((i.shift11_1).future11 & (range11 - e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range11 | (i.shift11_1).future11 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range11 | (i.shift11_1).future11 in (range11 - e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range11 | (i.shift11_2) in (e.target.av)}
all e: used | e.fiber in (E18) implies e.ev = {i: range11 | (i.shift11_2) in (range11 - e.target.av)}
all e: used | e.fiber in (E19) implies e.ev = {i: range11 | some ((i.shift11_2).future11 & (e.target.av))}
all e: used | e.fiber in (E20) implies e.ev = {i: range11 | some ((i.shift11_2).future11 & (range11 - e.target.av))}
all e: used | e.fiber in (E21) implies e.ev = {i: range11 | (i.shift11_2).future11 in (e.target.av)}
all e: used | e.fiber in (E22) implies e.ev = {i: range11 | (i.shift11_2).future11 in (range11 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range11 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next11.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range11 | some (i.future11 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range11 | i.future11 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range11 - left[a].ev) + right[a].ev)
}
fun range12: set Pos { (P0 + P1) }
fun loop12: set Pos { (P0 + P1) }
fun next12: Pos -> Pos { (P0->P1 + P1->P0) }
fun future12: Pos -> Pos { (*next12) & (range12->range12) }
fun shift12_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift12_1: Pos -> Pos { (P0->P1 + P1->P0) }
pred semantics12[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range12
ev in used->range12
all e: used | e.fiber in (((E0 + E1) + (E17 + E29))) implies e.ev = {i: range12 | (i.shift12_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + E18)) implies e.ev = {i: range12 | (i.shift12_0) in (range12 - e.target.av)}
all e: used | e.fiber in ((E3 + E19)) implies e.ev = {i: range12 | some ((i.shift12_0).future12 & (e.target.av))}
all e: used | e.fiber in ((E4 + E20)) implies e.ev = {i: range12 | some ((i.shift12_0).future12 & (range12 - e.target.av))}
all e: used | e.fiber in ((E5 + E21)) implies e.ev = {i: range12 | (i.shift12_0).future12 in (e.target.av)}
all e: used | e.fiber in ((E6 + E22)) implies e.ev = {i: range12 | (i.shift12_0).future12 in (range12 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range12 | loop12 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range12 | loop12 in (range12 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range12 | some (loop12 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range12 | some (loop12 & (range12 - e.target.av))}
all e: used | e.fiber in ((E11 + E23)) implies e.ev = {i: range12 | (i.shift12_1) in (e.target.av)}
all e: used | e.fiber in ((E12 + E24)) implies e.ev = {i: range12 | (i.shift12_1) in (range12 - e.target.av)}
all e: used | e.fiber in ((E13 + E25)) implies e.ev = {i: range12 | some ((i.shift12_1).future12 & (e.target.av))}
all e: used | e.fiber in (E14) implies e.ev = {i: range12 | some ((i.shift12_1).future12 & (range12 - e.target.av))}
all e: used | e.fiber in ((E15 + E27)) implies e.ev = {i: range12 | (i.shift12_1).future12 in (e.target.av)}
all e: used | e.fiber in (E16) implies e.ev = {i: range12 | (i.shift12_1).future12 in (range12 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range12 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next12.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range12 | some (i.future12 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range12 | i.future12 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range12 - left[a].ev) + right[a].ev)
}
fun range13: set Pos { (P0 + P1) }
fun loop13: set Pos { P1 }
fun next13: Pos -> Pos { (P0->P1 + P1->P1) }
fun future13: Pos -> Pos { (*next13) & (range13->range13) }
fun shift13_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift13_1: Pos -> Pos { (P0->P1 + P1->P1) }
pred semantics13[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range13
ev in used->range13
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range13 | (i.shift13_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range13 | (i.shift13_0) in (range13 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range13 | some ((i.shift13_0).future13 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range13 | some ((i.shift13_0).future13 & (range13 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range13 | (i.shift13_0).future13 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range13 | (i.shift13_0).future13 in (range13 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range13 | loop13 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range13 | loop13 in (range13 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range13 | some (loop13 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range13 | some (loop13 & (range13 - e.target.av))}
all e: used | e.fiber in (((E11 + E17) + (E23 + E29))) implies e.ev = {i: range13 | (i.shift13_1) in (e.target.av)}
all e: used | e.fiber in ((E12 + (E18 + E24))) implies e.ev = {i: range13 | (i.shift13_1) in (range13 - e.target.av)}
all e: used | e.fiber in ((E13 + (E19 + E25))) implies e.ev = {i: range13 | some ((i.shift13_1).future13 & (e.target.av))}
all e: used | e.fiber in ((E14 + E20)) implies e.ev = {i: range13 | some ((i.shift13_1).future13 & (range13 - e.target.av))}
all e: used | e.fiber in ((E15 + (E21 + E27))) implies e.ev = {i: range13 | (i.shift13_1).future13 in (e.target.av)}
all e: used | e.fiber in ((E16 + E22)) implies e.ev = {i: range13 | (i.shift13_1).future13 in (range13 - e.target.av)}
all a: active | a.lab = T3 implies a.av = (range13 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next13.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range13 | some (i.future13 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range13 | i.future13 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range13 - left[a].ev) + right[a].ev)
}
fun range14: set Pos { P0 }
fun loop14: set Pos { P0 }
fun next14: Pos -> Pos { P0->P0 }
fun future14: Pos -> Pos { (*next14) & (range14->range14) }
fun shift14_0: Pos -> Pos { P0->P0 }
pred semantics14[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range14
ev in used->range14
all e: used | e.fiber in (((E0 + (E1 + E11)) + (E17 + (E23 + E29)))) implies e.ev = {i: range14 | (i.shift14_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E12) + (E18 + E24))) implies e.ev = {i: range14 | (i.shift14_0) in (range14 - e.target.av)}
all e: used | e.fiber in (((E3 + E13) + (E19 + E25))) implies e.ev = {i: range14 | some ((i.shift14_0).future14 & (e.target.av))}
all e: used | e.fiber in ((E4 + (E14 + E20))) implies e.ev = {i: range14 | some ((i.shift14_0).future14 & (range14 - e.target.av))}
all e: used | e.fiber in (((E5 + E15) + (E21 + E27))) implies e.ev = {i: range14 | (i.shift14_0).future14 in (e.target.av)}
all e: used | e.fiber in ((E6 + (E16 + E22))) implies e.ev = {i: range14 | (i.shift14_0).future14 in (range14 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range14 | loop14 in (e.target.av)}
all e: used | e.fiber in (E8) implies e.ev = {i: range14 | loop14 in (range14 - e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range14 | some (loop14 & (e.target.av))}
all e: used | e.fiber in (E10) implies e.ev = {i: range14 | some (loop14 & (range14 - e.target.av))}
all a: active | a.lab = T3 implies a.av = (range14 - child[a].ev)
all a: active | a.lab = T4 implies a.av = (next14.(child[a].ev))
all a: active | a.lab = T5 implies a.av = ({i: range14 | some (i.future14 & child[a].ev)})
all a: active | a.lab = T6 implies a.av = ({i: range14 | i.future14 in child[a].ev})
all a: active | a.lab = T7 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T8 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T9 implies a.av = ((range14 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av0 = (P3)
all a: lab.T2 | a.av0 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev0)
semantics1[av1, ev1]
all a: lab.T0 | a.av1 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1 = ((P2 + P4))
all a: lab.T2 | a.av1 = (P1)
(R->P0 in ev1)
semantics2[av2, ev2]
all a: lab.T0 | a.av2 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av2 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av2 = (P4)
(R->P0 in ev2)
semantics2[av3, ev3]
all a: lab.T0 | a.av3 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av3 = (none)
all a: lab.T2 | a.av3 = ((P1 + (P2 + P4)))
(R->P0 in ev3)
semantics3[av4, ev4]
all a: lab.T0 | a.av4 = (P3)
all a: lab.T1 | a.av4 = (P3)
all a: lab.T2 | a.av4 = (P3)
(R->P0 in ev4)
semantics4[av5, ev5]
all a: lab.T0 | a.av5 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av5 = ((P1 + P4))
all a: lab.T2 | a.av5 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev5)
semantics3[av6, ev6]
all a: lab.T0 | a.av6 = ((P0 + P2))
all a: lab.T1 | a.av6 = (none)
all a: lab.T2 | a.av6 = ((P1 + P2))
(R->P0 in ev6)
semantics1[av7, ev7]
all a: lab.T0 | a.av7 = ((P1 + P4))
all a: lab.T1 | a.av7 = (P4)
all a: lab.T2 | a.av7 = ((P0 + (P3 + P4)))
(R->P0 in ev7)
semantics0[av8, ev8]
all a: lab.T0 | a.av8 = ((P2 + P4))
all a: lab.T1 | a.av8 = (none)
all a: lab.T2 | a.av8 = ((P0 + (P1 + P3)))
(R->P0 in ev8)
semantics4[av9, ev9]
all a: lab.T0 | a.av9 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av9 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av9 = ((P0 + (P1 + P4)))
(R->P0 in ev9)
semantics5[av10, ev10]
all a: lab.T0 | a.av10 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av10 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av10 = ((P1 + (P3 + P4)))
(R->P0 in ev10)
semantics1[av11, ev11]
all a: lab.T0 | a.av11 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av11 = (P3)
all a: lab.T2 | a.av11 = ((P0 + (P1 + P3)))
(R->P0 in ev11)
semantics3[av12, ev12]
all a: lab.T0 | a.av12 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av12 = ((P2 + P3))
all a: lab.T2 | a.av12 = ((P0 + P2))
(R->P0 in ev12)
semantics0[av13, ev13]
all a: lab.T0 | a.av13 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av13 = (none)
all a: lab.T2 | a.av13 = (P1)
(R->P0 in ev13)
semantics1[av14, ev14]
all a: lab.T0 | a.av14 = (P2)
all a: lab.T1 | a.av14 = (none)
all a: lab.T2 | a.av14 = ((P0 + (P2 + P4)))
(R->P0 in ev14)
semantics5[av15, ev15]
all a: lab.T0 | a.av15 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av15 = (P4)
all a: lab.T2 | a.av15 = ((P3 + P4))
(R->P0 in ev15)
semantics4[av16, ev16]
all a: lab.T0 | a.av16 = (P2)
all a: lab.T1 | a.av16 = (none)
all a: lab.T2 | a.av16 = ((P2 + P4))
(R->P0 in ev16)
semantics1[av17, ev17]
all a: lab.T0 | a.av17 = ((P1 + P2))
all a: lab.T1 | a.av17 = (none)
all a: lab.T2 | a.av17 = ((P2 + P4))
(R->P0 in ev17)
semantics0[av18, ev18]
all a: lab.T0 | a.av18 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av18 = ((P2 + P3))
all a: lab.T2 | a.av18 = ((P0 + (P1 + P2)))
(R->P0 in ev18)
semantics6[av19, ev19]
all a: lab.T0 | a.av19 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av19 = (P1)
all a: lab.T2 | a.av19 = ((P0 + (P1 + P2)))
(R->P0 in ev19)
semantics6[av20, ev20]
all a: lab.T0 | a.av20 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av20 = (P2)
all a: lab.T2 | a.av20 = ((P2 + P3))
(R->P0 in ev20)
semantics0[av21, ev21]
all a: lab.T0 | a.av21 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av21 = ((P1 + P2))
all a: lab.T2 | a.av21 = ((P2 + P3))
(R->P0 in ev21)
semantics1[av22, ev22]
all a: lab.T0 | a.av22 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av22 = (none)
all a: lab.T2 | a.av22 = ((P0 + (P1 + P4)))
(R->P0 in ev22)
semantics0[av23, ev23]
all a: lab.T0 | a.av23 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av23 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av23 = ((P1 + P2))
(R->P0 in ev23)
semantics0[av24, ev24]
all a: lab.T0 | a.av24 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av24 = ((P2 + P4))
all a: lab.T2 | a.av24 = (P0)
(R->P0 in ev24)
semantics4[av25, ev25]
all a: lab.T0 | a.av25 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av25 = ((P1 + P4))
all a: lab.T2 | a.av25 = ((P0 + (P1 + P2)))
(R->P0 in ev25)
semantics5[av26, ev26]
all a: lab.T0 | a.av26 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av26 = (none)
all a: lab.T2 | a.av26 = ((P1 + (P2 + P3)))
(R->P0 in ev26)
semantics7[av27, ev27]
all a: lab.T0 | a.av27 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av27 = ((P1 + P2))
all a: lab.T2 | a.av27 = ((P2 + P3))
(R->P0 in ev27)
semantics3[av28, ev28]
all a: lab.T0 | a.av28 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av28 = (P2)
all a: lab.T2 | a.av28 = ((P0 + P1))
(R->P0 in ev28)
semantics8[av29, ev29]
all a: lab.T0 | a.av29 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av29 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av29 = ((P2 + P3))
(R->P0 in ev29)
semantics6[av30, ev30]
all a: lab.T0 | a.av30 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av30 = (P3)
all a: lab.T2 | a.av30 = ((P0 + P2))
(R->P0 in ev30)
semantics9[av31, ev31]
all a: lab.T0 | a.av31 = ((P0 + P1))
all a: lab.T1 | a.av31 = (none)
all a: lab.T2 | a.av31 = (none)
(R->P0 in ev31)
semantics3[av32, ev32]
all a: lab.T0 | a.av32 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av32 = (none)
all a: lab.T2 | a.av32 = ((P1 + (P2 + P3)))
(R->P0 in ev32)
semantics3[av33, ev33]
all a: lab.T0 | a.av33 = ((P1 + P3))
all a: lab.T1 | a.av33 = (none)
all a: lab.T2 | a.av33 = (P2)
(R->P0 in ev33)
semantics5[av34, ev34]
all a: lab.T0 | a.av34 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av34 = ((P1 + P3))
all a: lab.T2 | a.av34 = ((P0 + (P1 + P4)))
(R->P0 in ev34)
semantics5[av35, ev35]
all a: lab.T0 | a.av35 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av35 = (P3)
all a: lab.T2 | a.av35 = ((P0 + (P3 + P4)))
(R->P0 in ev35)
semantics0[av36, ev36]
all a: lab.T0 | a.av36 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av36 = (none)
all a: lab.T2 | a.av36 = ((P0 + (P3 + P4)))
(R->P0 in ev36)
semantics1[av37, ev37]
all a: lab.T0 | a.av37 = (P4)
all a: lab.T1 | a.av37 = (none)
all a: lab.T2 | a.av37 = ((P3 + P4))
(R->P0 in ev37)
semantics2[av38, ev38]
all a: lab.T0 | a.av38 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av38 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av38 = ((P0 + P1))
(R->P0 in ev38)
semantics2[av39, ev39]
all a: lab.T0 | a.av39 = (none)
all a: lab.T1 | a.av39 = (none)
all a: lab.T2 | a.av39 = ((P0 + (P1 + P2)))
(R->P0 in ev39)
semantics0[av40, ev40]
all a: lab.T0 | a.av40 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av40 = (P4)
all a: lab.T2 | a.av40 = ((P1 + P2))
(R->P0 in ev40)
semantics5[av41, ev41]
all a: lab.T0 | a.av41 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av41 = ((P1 + P3))
all a: lab.T2 | a.av41 = ((P0 + (P1 + P2)))
(R->P0 in ev41)
semantics4[av42, ev42]
all a: lab.T0 | a.av42 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av42 = ((P0 + P3))
all a: lab.T2 | a.av42 = ((P1 + (P2 + P4)))
(R->P0 in ev42)
semantics4[av43, ev43]
all a: lab.T0 | a.av43 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av43 = (none)
all a: lab.T2 | a.av43 = ((P1 + (P2 + P3)))
(R->P0 in ev43)
semantics7[av44, ev44]
all a: lab.T0 | a.av44 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av44 = ((P1 + P3))
all a: lab.T2 | a.av44 = ((P0 + P3))
(R->P0 in ev44)
semantics2[av45, ev45]
all a: lab.T0 | a.av45 = ((P1 + P4))
all a: lab.T1 | a.av45 = (none)
all a: lab.T2 | a.av45 = ((P0 + (P3 + P4)))
(R->P0 in ev45)
semantics0[av46, ev46]
all a: lab.T0 | a.av46 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av46 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av46 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev46)
semantics1[av47, ev47]
all a: lab.T0 | a.av47 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av47 = ((P2 + P4))
all a: lab.T2 | a.av47 = (none)
(R->P0 in ev47)
semantics0[av48, ev48]
all a: lab.T0 | a.av48 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av48 = ((P3 + P4))
all a: lab.T2 | a.av48 = ((P2 + (P3 + P4)))
(R->P0 in ev48)
semantics5[av49, ev49]
all a: lab.T0 | a.av49 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av49 = (none)
all a: lab.T2 | a.av49 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev49)
semantics8[av50, ev50]
all a: lab.T0 | a.av50 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av50 = ((P1 + P3))
all a: lab.T2 | a.av50 = (P1)
(R->P0 in ev50)
semantics2[av51, ev51]
all a: lab.T0 | a.av51 = ((P1 + P3))
all a: lab.T1 | a.av51 = (none)
all a: lab.T2 | a.av51 = ((P0 + (P1 + P2)))
(R->P0 in ev51)
semantics5[av52, ev52]
all a: lab.T0 | a.av52 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av52 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av52 = ((P2 + P3))
(R->P0 in ev52)
semantics4[av53, ev53]
all a: lab.T0 | a.av53 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av53 = ((P3 + P4))
all a: lab.T2 | a.av53 = ((P2 + P4))
(R->P0 in ev53)
semantics0[av54, ev54]
all a: lab.T0 | a.av54 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av54 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av54 = ((P3 + P4))
(R->P0 in ev54)
semantics4[av55, ev55]
all a: lab.T0 | a.av55 = ((P0 + P3))
all a: lab.T1 | a.av55 = (none)
all a: lab.T2 | a.av55 = ((P0 + P1))
(R->P0 in ev55)
semantics7[av56, ev56]
all a: lab.T0 | a.av56 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av56 = (P3)
all a: lab.T2 | a.av56 = (none)
(R->P0 in ev56)
semantics2[av57, ev57]
all a: lab.T0 | a.av57 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av57 = (none)
all a: lab.T2 | a.av57 = ((P0 + (P1 + P4)))
(R->P0 in ev57)
semantics4[av58, ev58]
all a: lab.T0 | a.av58 = (P0)
all a: lab.T1 | a.av58 = (none)
all a: lab.T2 | a.av58 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev58)
semantics2[av59, ev59]
all a: lab.T0 | a.av59 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av59 = (none)
all a: lab.T2 | a.av59 = ((P3 + P4))
(R->P0 in ev59)
semantics1[av60, ev60]
all a: lab.T0 | a.av60 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av60 = (P3)
all a: lab.T2 | a.av60 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev60)
semantics3[av61, ev61]
all a: lab.T0 | a.av61 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av61 = (P1)
all a: lab.T2 | a.av61 = ((P0 + (P1 + P2)))
(R->P0 in ev61)
semantics1[av62, ev62]
all a: lab.T0 | a.av62 = ((P0 + P4))
all a: lab.T1 | a.av62 = (none)
all a: lab.T2 | a.av62 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev62)
semantics4[av63, ev63]
all a: lab.T0 | a.av63 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av63 = (P3)
all a: lab.T2 | a.av63 = (none)
(R->P0 in ev63)
semantics6[av64, ev64]
all a: lab.T0 | a.av64 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av64 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av64 = (P1)
(R->P0 in ev64)
semantics8[av65, ev65]
all a: lab.T0 | a.av65 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av65 = (P1)
all a: lab.T2 | a.av65 = ((P0 + (P2 + P3)))
(R->P0 in ev65)
semantics6[av66, ev66]
all a: lab.T0 | a.av66 = ((P2 + P3))
all a: lab.T1 | a.av66 = (none)
all a: lab.T2 | a.av66 = ((P0 + P2))
(R->P0 in ev66)
semantics6[av67, ev67]
all a: lab.T0 | a.av67 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av67 = ((P0 + P1))
all a: lab.T2 | a.av67 = ((P0 + P2))
(R->P0 in ev67)
semantics1[av68, ev68]
all a: lab.T0 | a.av68 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av68 = ((P2 + P4))
all a: lab.T2 | a.av68 = ((P1 + (P2 + P4)))
(R->P0 in ev68)
semantics1[av69, ev69]
all a: lab.T0 | a.av69 = ((P2 + P4))
all a: lab.T1 | a.av69 = (none)
all a: lab.T2 | a.av69 = ((P1 + P3))
(R->P0 in ev69)
semantics2[av70, ev70]
all a: lab.T0 | a.av70 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av70 = ((P3 + P4))
all a: lab.T2 | a.av70 = ((P2 + P3))
(R->P0 in ev70)
semantics3[av71, ev71]
all a: lab.T0 | a.av71 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av71 = ((P0 + P2))
all a: lab.T2 | a.av71 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev71)
semantics3[av72, ev72]
all a: lab.T0 | a.av72 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av72 = ((P1 + P3))
all a: lab.T2 | a.av72 = ((P0 + (P1 + P2)))
(R->P0 in ev72)
semantics4[av73, ev73]
all a: lab.T0 | a.av73 = (P4)
all a: lab.T1 | a.av73 = (none)
all a: lab.T2 | a.av73 = (P0)
(R->P0 in ev73)
semantics0[av74, ev74]
all a: lab.T0 | a.av74 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av74 = ((P0 + P1))
all a: lab.T2 | a.av74 = ((P0 + P2))
(R->P0 in ev74)
semantics0[av75, ev75]
all a: lab.T0 | a.av75 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av75 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av75 = ((P2 + P4))
(R->P0 in ev75)
semantics4[av76, ev76]
all a: lab.T0 | a.av76 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av76 = (P2)
all a: lab.T2 | a.av76 = (P4)
(R->P0 in ev76)
semantics5[av77, ev77]
all a: lab.T0 | a.av77 = ((P0 + P3))
all a: lab.T1 | a.av77 = (none)
all a: lab.T2 | a.av77 = ((P0 + P4))
(R->P0 in ev77)
semantics0[av78, ev78]
all a: lab.T0 | a.av78 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av78 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av78 = ((P0 + (P1 + P2)))
(R->P0 in ev78)
semantics6[av79, ev79]
all a: lab.T0 | a.av79 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av79 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av79 = ((P0 + (P1 + P3)))
(R->P0 in ev79)
semantics2[av80, ev80]
all a: lab.T0 | a.av80 = ((P0 + P1))
all a: lab.T1 | a.av80 = (none)
all a: lab.T2 | a.av80 = ((P3 + P4))
(R->P0 in ev80)
semantics3[av81, ev81]
all a: lab.T0 | a.av81 = (P3)
all a: lab.T1 | a.av81 = (none)
all a: lab.T2 | a.av81 = (P2)
(R->P0 in ev81)
semantics0[av82, ev82]
all a: lab.T0 | a.av82 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av82 = (P4)
all a: lab.T2 | a.av82 = (P1)
(R->P0 in ev82)
semantics5[av83, ev83]
all a: lab.T0 | a.av83 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av83 = ((P3 + P4))
all a: lab.T2 | a.av83 = ((P1 + P3))
(R->P0 in ev83)
semantics2[av84, ev84]
all a: lab.T0 | a.av84 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av84 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av84 = ((P0 + P2))
(R->P0 in ev84)
semantics0[av85, ev85]
all a: lab.T0 | a.av85 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av85 = (none)
all a: lab.T2 | a.av85 = ((P0 + P3))
(R->P0 in ev85)
semantics9[av86, ev86]
all a: lab.T0 | a.av86 = (P0)
all a: lab.T1 | a.av86 = (none)
all a: lab.T2 | a.av86 = ((P0 + P2))
(R->P0 in ev86)
semantics7[av87, ev87]
all a: lab.T0 | a.av87 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av87 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av87 = ((P0 + P3))
(R->P0 in ev87)
semantics9[av88, ev88]
all a: lab.T0 | a.av88 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av88 = ((P0 + P2))
all a: lab.T2 | a.av88 = (P1)
(R->P0 in ev88)
semantics0[av89, ev89]
all a: lab.T0 | a.av89 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av89 = (none)
all a: lab.T2 | a.av89 = ((P1 + P3))
(R->P0 in ev89)
semantics4[av90, ev90]
all a: lab.T0 | a.av90 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av90 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av90 = ((P0 + (P1 + P4)))
(R->P0 in ev90)
semantics4[av91, ev91]
all a: lab.T0 | a.av91 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av91 = ((P2 + P4))
all a: lab.T2 | a.av91 = ((P0 + (P2 + P4)))
(R->P0 in ev91)
semantics0[av92, ev92]
all a: lab.T0 | a.av92 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av92 = ((P2 + P4))
all a: lab.T2 | a.av92 = ((P2 + P3))
(R->P0 in ev92)
semantics0[av93, ev93]
all a: lab.T0 | a.av93 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av93 = (P4)
all a: lab.T2 | a.av93 = (none)
(R->P0 in ev93)
semantics0[av94, ev94]
all a: lab.T0 | a.av94 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av94 = ((P1 + P3))
all a: lab.T2 | a.av94 = ((P0 + P3))
(R->P0 in ev94)
semantics0[av95, ev95]
all a: lab.T0 | a.av95 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av95 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av95 = ((P1 + P4))
(R->P0 in ev95)
semantics0[av96, ev96]
all a: lab.T0 | a.av96 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av96 = (P3)
all a: lab.T2 | a.av96 = (P4)
(R->P0 in ev96)
semantics5[av97, ev97]
all a: lab.T0 | a.av97 = ((P1 + P4))
all a: lab.T1 | a.av97 = (none)
all a: lab.T2 | a.av97 = ((P2 + P3))
(R->P0 in ev97)
semantics3[av98, ev98]
all a: lab.T0 | a.av98 = ((P0 + P2))
all a: lab.T1 | a.av98 = (none)
all a: lab.T2 | a.av98 = (none)
(R->P0 in ev98)
semantics0[av99, ev99]
all a: lab.T0 | a.av99 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av99 = ((P1 + P2))
all a: lab.T2 | a.av99 = ((P0 + (P1 + P4)))
(R->P0 in ev99)
semantics2[av100, ev100]
all a: lab.T0 | a.av100 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av100 = (none)
all a: lab.T2 | a.av100 = (P0)
(R->P0 in ev100)
semantics1[av101, ev101]
all a: lab.T0 | a.av101 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av101 = ((P2 + P3))
all a: lab.T2 | a.av101 = (P4)
(R->P0 in ev101)
semantics8[av102, ev102]
all a: lab.T0 | a.av102 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av102 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av102 = (P1)
(R->P0 in ev102)
semantics1[av103, ev103]
all a: lab.T0 | a.av103 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av103 = (none)
all a: lab.T2 | a.av103 = ((P0 + (P1 + P4)))
(R->P0 in ev103)
semantics6[av104, ev104]
all a: lab.T0 | a.av104 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av104 = (none)
all a: lab.T2 | a.av104 = (P3)
(R->P0 in ev104)
semantics0[av105, ev105]
all a: lab.T0 | a.av105 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av105 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av105 = ((P1 + (P2 + P3)))
(R->P0 in ev105)
semantics0[av106, ev106]
all a: lab.T0 | a.av106 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av106 = (none)
all a: lab.T2 | a.av106 = ((P0 + (P2 + P4)))
(R->P0 in ev106)
semantics8[av107, ev107]
all a: lab.T0 | a.av107 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av107 = ((P1 + P3))
all a: lab.T2 | a.av107 = ((P0 + (P1 + P2)))
(R->P0 in ev107)
semantics10[av108, ev108]
all a: lab.T0 | a.av108 = (P2)
all a: lab.T1 | a.av108 = (none)
all a: lab.T2 | a.av108 = (none)
(R->P0 in ev108)
semantics5[av109, ev109]
all a: lab.T0 | a.av109 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av109 = (P3)
all a: lab.T2 | a.av109 = ((P0 + P4))
(R->P0 in ev109)
semantics5[av110, ev110]
all a: lab.T0 | a.av110 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av110 = ((P2 + P3))
all a: lab.T2 | a.av110 = ((P0 + P4))
(R->P0 in ev110)
semantics2[av111, ev111]
all a: lab.T0 | a.av111 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av111 = (none)
all a: lab.T2 | a.av111 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev111)
semantics11[av112, ev112]
all a: lab.T0 | a.av112 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av112 = (P2)
all a: lab.T2 | a.av112 = (P1)
(R->P0 in ev112)
semantics5[av113, ev113]
all a: lab.T0 | a.av113 = ((P3 + P4))
all a: lab.T1 | a.av113 = (none)
all a: lab.T2 | a.av113 = ((P0 + P3))
(R->P0 in ev113)
semantics5[av114, ev114]
all a: lab.T0 | a.av114 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av114 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av114 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev114)
semantics6[av115, ev115]
all a: lab.T0 | a.av115 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av115 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av115 = ((P0 + (P1 + P2)))
(R->P0 in ev115)
semantics2[av116, ev116]
all a: lab.T0 | a.av116 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av116 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av116 = ((P0 + (P1 + P2)))
(R->P0 in ev116)
semantics4[av117, ev117]
all a: lab.T0 | a.av117 = (P2)
all a: lab.T1 | a.av117 = (none)
all a: lab.T2 | a.av117 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev117)
semantics4[av118, ev118]
all a: lab.T0 | a.av118 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av118 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av118 = ((P0 + P3))
(R->P0 in ev118)
semantics5[av119, ev119]
all a: lab.T0 | a.av119 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av119 = ((P0 + P2))
all a: lab.T2 | a.av119 = ((P0 + (P2 + P3)))
(R->P0 in ev119)
semantics2[av120, ev120]
all a: lab.T0 | a.av120 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av120 = (none)
all a: lab.T2 | a.av120 = ((P0 + (P2 + P3)))
(R->P0 in ev120)
semantics1[av121, ev121]
all a: lab.T0 | a.av121 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av121 = ((P2 + P3))
all a: lab.T2 | a.av121 = ((P2 + (P3 + P4)))
(R->P0 in ev121)
semantics11[av122, ev122]
all a: lab.T0 | a.av122 = ((P0 + P2))
all a: lab.T1 | a.av122 = (none)
all a: lab.T2 | a.av122 = (P0)
(R->P0 in ev122)
semantics2[av123, ev123]
all a: lab.T0 | a.av123 = ((P3 + P4))
all a: lab.T1 | a.av123 = (none)
all a: lab.T2 | a.av123 = ((P0 + (P1 + P3)))
(R->P0 in ev123)
semantics3[av124, ev124]
all a: lab.T0 | a.av124 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av124 = (P2)
all a: lab.T2 | a.av124 = (none)
(R->P0 in ev124)
semantics2[av125, ev125]
all a: lab.T0 | a.av125 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av125 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av125 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev125)
semantics8[av126, ev126]
all a: lab.T0 | a.av126 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av126 = (P3)
all a: lab.T2 | a.av126 = ((P0 + P2))
(R->P0 in ev126)
semantics2[av127, ev127]
all a: lab.T0 | a.av127 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av127 = (none)
all a: lab.T2 | a.av127 = ((P2 + (P3 + P4)))
(R->P0 in ev127)
semantics1[av128, ev128]
all a: lab.T0 | a.av128 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av128 = (none)
all a: lab.T2 | a.av128 = (P1)
(R->P0 in ev128)
semantics0[av129, ev129]
all a: lab.T0 | a.av129 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av129 = ((P2 + P4))
all a: lab.T2 | a.av129 = (none)
(R->P0 in ev129)
semantics0[av130, ev130]
all a: lab.T0 | a.av130 = ((P0 + P4))
all a: lab.T1 | a.av130 = (none)
all a: lab.T2 | a.av130 = ((P0 + (P2 + P3)))
(R->P0 in ev130)
semantics3[av131, ev131]
all a: lab.T0 | a.av131 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av131 = (P3)
all a: lab.T2 | a.av131 = (P2)
(R->P0 in ev131)
semantics2[av132, ev132]
all a: lab.T0 | a.av132 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av132 = (none)
all a: lab.T2 | a.av132 = ((P1 + (P2 + P4)))
(R->P0 in ev132)
semantics0[av133, ev133]
all a: lab.T0 | a.av133 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av133 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av133 = ((P0 + (P3 + P4)))
(R->P0 in ev133)
semantics0[av134, ev134]
all a: lab.T0 | a.av134 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av134 = ((P3 + P4))
all a: lab.T2 | a.av134 = ((P0 + P1))
(R->P0 in ev134)
semantics1[av135, ev135]
all a: lab.T0 | a.av135 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av135 = (none)
all a: lab.T2 | a.av135 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev135)
semantics4[av136, ev136]
all a: lab.T0 | a.av136 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av136 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av136 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev136)
semantics3[av137, ev137]
all a: lab.T0 | a.av137 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av137 = ((P1 + P3))
all a: lab.T2 | a.av137 = ((P0 + (P1 + P2)))
(R->P0 in ev137)
semantics0[av138, ev138]
all a: lab.T0 | a.av138 = ((P0 + P2))
all a: lab.T1 | a.av138 = (none)
all a: lab.T2 | a.av138 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev138)
semantics5[av139, ev139]
all a: lab.T0 | a.av139 = ((P3 + P4))
all a: lab.T1 | a.av139 = ((P3 + P4))
all a: lab.T2 | a.av139 = (P3)
(R->P0 in ev139)
semantics4[av140, ev140]
all a: lab.T0 | a.av140 = (P2)
all a: lab.T1 | a.av140 = (none)
all a: lab.T2 | a.av140 = ((P1 + (P2 + P3)))
(R->P0 in ev140)
semantics2[av141, ev141]
all a: lab.T0 | a.av141 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av141 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av141 = ((P2 + (P3 + P4)))
(R->P0 in ev141)
semantics1[av142, ev142]
all a: lab.T0 | a.av142 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av142 = ((P3 + P4))
all a: lab.T2 | a.av142 = ((P2 + P3))
(R->P0 in ev142)
semantics2[av143, ev143]
all a: lab.T0 | a.av143 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av143 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av143 = ((P0 + (P1 + P3)))
(R->P0 in ev143)
semantics7[av144, ev144]
all a: lab.T0 | a.av144 = ((P2 + P3))
all a: lab.T1 | a.av144 = (P2)
all a: lab.T2 | a.av144 = ((P1 + P3))
(R->P0 in ev144)
semantics1[av145, ev145]
all a: lab.T0 | a.av145 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av145 = (none)
all a: lab.T2 | a.av145 = (P3)
(R->P0 in ev145)
semantics5[av146, ev146]
all a: lab.T0 | a.av146 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av146 = (none)
all a: lab.T2 | a.av146 = ((P1 + (P2 + P3)))
(R->P0 in ev146)
semantics1[av147, ev147]
all a: lab.T0 | a.av147 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av147 = (P4)
all a: lab.T2 | a.av147 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev147)
semantics3[av148, ev148]
all a: lab.T0 | a.av148 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av148 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av148 = ((P0 + (P1 + P2)))
(R->P0 in ev148)
semantics0[av149, ev149]
all a: lab.T0 | a.av149 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av149 = (none)
all a: lab.T2 | a.av149 = ((P3 + P4))
(R->P0 in ev149)
semantics3[av150, ev150]
all a: lab.T0 | a.av150 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av150 = (none)
all a: lab.T2 | a.av150 = ((P0 + (P1 + P3)))
(R->P0 in ev150)
semantics5[av151, ev151]
all a: lab.T0 | a.av151 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av151 = ((P3 + P4))
all a: lab.T2 | a.av151 = ((P1 + (P2 + P4)))
(R->P0 in ev151)
semantics5[av152, ev152]
all a: lab.T0 | a.av152 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av152 = (P3)
all a: lab.T2 | a.av152 = ((P0 + (P2 + P4)))
(R->P0 in ev152)
semantics1[av153, ev153]
all a: lab.T0 | a.av153 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av153 = (P3)
all a: lab.T2 | a.av153 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev153)
semantics5[av154, ev154]
all a: lab.T0 | a.av154 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av154 = ((P3 + P4))
all a: lab.T2 | a.av154 = ((P2 + P4))
(R->P0 in ev154)
semantics0[av155, ev155]
all a: lab.T0 | a.av155 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av155 = ((P2 + P3))
all a: lab.T2 | a.av155 = ((P0 + (P1 + P2)))
(R->P0 in ev155)
semantics1[av156, ev156]
all a: lab.T0 | a.av156 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av156 = (P4)
all a: lab.T2 | a.av156 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev156)
semantics8[av157, ev157]
all a: lab.T0 | a.av157 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av157 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av157 = ((P0 + P1))
(R->P0 in ev157)
semantics2[av158, ev158]
all a: lab.T0 | a.av158 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av158 = (none)
all a: lab.T2 | a.av158 = ((P1 + P2))
(R->P0 in ev158)
semantics6[av159, ev159]
all a: lab.T0 | a.av159 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av159 = ((P0 + P3))
all a: lab.T2 | a.av159 = (P0)
(R->P0 in ev159)
semantics2[av160, ev160]
all a: lab.T0 | a.av160 = (P1)
all a: lab.T1 | a.av160 = (none)
all a: lab.T2 | a.av160 = ((P0 + P2))
(R->P0 in ev160)
semantics2[av161, ev161]
all a: lab.T0 | a.av161 = (P0)
all a: lab.T1 | a.av161 = (none)
all a: lab.T2 | a.av161 = ((P2 + (P3 + P4)))
(R->P0 in ev161)
semantics3[av162, ev162]
all a: lab.T0 | a.av162 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av162 = ((P1 + P3))
all a: lab.T2 | a.av162 = ((P1 + (P2 + P3)))
(R->P0 in ev162)
semantics1[av163, ev163]
all a: lab.T0 | a.av163 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av163 = (P3)
all a: lab.T2 | a.av163 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev163)
semantics6[av164, ev164]
all a: lab.T0 | a.av164 = ((P0 + P3))
all a: lab.T1 | a.av164 = (none)
all a: lab.T2 | a.av164 = ((P0 + (P1 + P3)))
(R->P0 in ev164)
semantics4[av165, ev165]
all a: lab.T0 | a.av165 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av165 = ((P2 + P4))
all a: lab.T2 | a.av165 = ((P1 + P3))
(R->P0 in ev165)
semantics4[av166, ev166]
all a: lab.T0 | a.av166 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av166 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av166 = ((P2 + (P3 + P4)))
(R->P0 in ev166)
semantics5[av167, ev167]
all a: lab.T0 | a.av167 = (P4)
all a: lab.T1 | a.av167 = (none)
all a: lab.T2 | a.av167 = (P4)
(R->P0 in ev167)
semantics5[av168, ev168]
all a: lab.T0 | a.av168 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av168 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av168 = (P4)
(R->P0 in ev168)
semantics10[av169, ev169]
all a: lab.T0 | a.av169 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av169 = ((P0 + P2))
all a: lab.T2 | a.av169 = ((P1 + P2))
(R->P0 in ev169)
semantics0[av170, ev170]
all a: lab.T0 | a.av170 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av170 = ((P2 + P3))
all a: lab.T2 | a.av170 = ((P0 + (P2 + P4)))
(R->P0 in ev170)
semantics5[av171, ev171]
all a: lab.T0 | a.av171 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av171 = (P4)
all a: lab.T2 | a.av171 = (P0)
(R->P0 in ev171)
semantics8[av172, ev172]
all a: lab.T0 | a.av172 = ((P2 + P3))
all a: lab.T1 | a.av172 = (none)
all a: lab.T2 | a.av172 = ((P2 + P3))
(R->P0 in ev172)
semantics1[av173, ev173]
all a: lab.T0 | a.av173 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av173 = ((P2 + P3))
all a: lab.T2 | a.av173 = (P0)
(R->P0 in ev173)
semantics2[av174, ev174]
all a: lab.T0 | a.av174 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av174 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av174 = (P1)
(R->P0 in ev174)
semantics0[av175, ev175]
all a: lab.T0 | a.av175 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av175 = ((P1 + P2))
all a: lab.T2 | a.av175 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev175)
semantics0[av176, ev176]
all a: lab.T0 | a.av176 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av176 = ((P1 + P2))
all a: lab.T2 | a.av176 = ((P2 + (P3 + P4)))
(R->P0 in ev176)
semantics1[av177, ev177]
all a: lab.T0 | a.av177 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av177 = (P1)
all a: lab.T2 | a.av177 = ((P2 + P4))
(R->P0 in ev177)
semantics1[av178, ev178]
all a: lab.T0 | a.av178 = ((P3 + P4))
all a: lab.T1 | a.av178 = (P3)
all a: lab.T2 | a.av178 = ((P1 + P2))
(R->P0 in ev178)
semantics4[av179, ev179]
all a: lab.T0 | a.av179 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av179 = ((P0 + P1))
all a: lab.T2 | a.av179 = ((P0 + (P1 + P2)))
(R->P0 in ev179)
semantics1[av180, ev180]
all a: lab.T0 | a.av180 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av180 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av180 = (P3)
(R->P0 in ev180)
semantics1[av181, ev181]
all a: lab.T0 | a.av181 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av181 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av181 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev181)
semantics8[av182, ev182]
all a: lab.T0 | a.av182 = ((P1 + P3))
all a: lab.T1 | a.av182 = (none)
all a: lab.T2 | a.av182 = ((P1 + P3))
(R->P0 in ev182)
semantics9[av183, ev183]
all a: lab.T0 | a.av183 = (P2)
all a: lab.T1 | a.av183 = (P2)
all a: lab.T2 | a.av183 = (P1)
(R->P0 in ev183)
semantics0[av184, ev184]
all a: lab.T0 | a.av184 = ((P0 + P2))
all a: lab.T1 | a.av184 = (none)
all a: lab.T2 | a.av184 = ((P0 + P4))
(R->P0 in ev184)
semantics7[av185, ev185]
all a: lab.T0 | a.av185 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av185 = ((P2 + P3))
all a: lab.T2 | a.av185 = (P3)
(R->P0 in ev185)
semantics7[av186, ev186]
all a: lab.T0 | a.av186 = (P2)
all a: lab.T1 | a.av186 = (none)
all a: lab.T2 | a.av186 = (P3)
(R->P0 in ev186)
semantics3[av187, ev187]
all a: lab.T0 | a.av187 = (P0)
all a: lab.T1 | a.av187 = (none)
all a: lab.T2 | a.av187 = ((P1 + P2))
(R->P0 in ev187)
semantics4[av188, ev188]
all a: lab.T0 | a.av188 = ((P1 + P2))
all a: lab.T1 | a.av188 = (none)
all a: lab.T2 | a.av188 = ((P0 + (P2 + P4)))
(R->P0 in ev188)
semantics0[av189, ev189]
all a: lab.T0 | a.av189 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av189 = (P3)
all a: lab.T2 | a.av189 = ((P0 + (P1 + P2)))
(R->P0 in ev189)
semantics0[av190, ev190]
all a: lab.T0 | a.av190 = ((P2 + P4))
all a: lab.T1 | a.av190 = (none)
all a: lab.T2 | a.av190 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev190)
semantics4[av191, ev191]
all a: lab.T0 | a.av191 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av191 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av191 = ((P1 + P2))
(R->P0 in ev191)
semantics4[av192, ev192]
all a: lab.T0 | a.av192 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av192 = (P1)
all a: lab.T2 | a.av192 = ((P0 + P4))
(R->P0 in ev192)
semantics8[av193, ev193]
all a: lab.T0 | a.av193 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av193 = (P3)
all a: lab.T2 | a.av193 = ((P0 + (P1 + P3)))
(R->P0 in ev193)
semantics0[av194, ev194]
all a: lab.T0 | a.av194 = ((P1 + P4))
all a: lab.T1 | a.av194 = (none)
all a: lab.T2 | a.av194 = (P1)
(R->P0 in ev194)
semantics6[av195, ev195]
all a: lab.T0 | a.av195 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av195 = ((P0 + P1))
all a: lab.T2 | a.av195 = (P2)
(R->P0 in ev195)
semantics1[av196, ev196]
all a: lab.T0 | a.av196 = ((P0 + P2))
all a: lab.T1 | a.av196 = (none)
all a: lab.T2 | a.av196 = (P3)
(R->P0 in ev196)
semantics5[av197, ev197]
all a: lab.T0 | a.av197 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av197 = (P3)
all a: lab.T2 | a.av197 = ((P0 + P4))
(R->P0 in ev197)
semantics0[av198, ev198]
all a: lab.T0 | a.av198 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av198 = (none)
all a: lab.T2 | a.av198 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev198)
semantics1[av199, ev199]
all a: lab.T0 | a.av199 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av199 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av199 = ((P0 + P1))
(R->P0 in ev199)
semantics5[av200, ev200]
all a: lab.T0 | a.av200 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av200 = (P4)
all a: lab.T2 | a.av200 = ((P3 + P4))
(R->P0 in ev200)
semantics0[av201, ev201]
all a: lab.T0 | a.av201 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av201 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av201 = ((P3 + P4))
(R->P0 in ev201)
semantics2[av202, ev202]
all a: lab.T0 | a.av202 = (P4)
all a: lab.T1 | a.av202 = (none)
all a: lab.T2 | a.av202 = ((P0 + P2))
(R->P0 in ev202)
semantics0[av203, ev203]
all a: lab.T0 | a.av203 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av203 = ((P3 + P4))
all a: lab.T2 | a.av203 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev203)
semantics2[av204, ev204]
all a: lab.T0 | a.av204 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av204 = (none)
all a: lab.T2 | a.av204 = ((P0 + P3))
(R->P0 in ev204)
semantics0[av205, ev205]
all a: lab.T0 | a.av205 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av205 = ((P2 + P4))
all a: lab.T2 | a.av205 = ((P0 + (P3 + P4)))
(R->P0 in ev205)
semantics0[av206, ev206]
all a: lab.T0 | a.av206 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av206 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av206 = ((P1 + P2))
(R->P0 in ev206)
semantics1[av207, ev207]
all a: lab.T0 | a.av207 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av207 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av207 = ((P0 + (P1 + P4)))
(R->P0 in ev207)
semantics1[av208, ev208]
all a: lab.T0 | a.av208 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av208 = (P2)
all a: lab.T2 | a.av208 = ((P1 + P3))
(R->P0 in ev208)
semantics4[av209, ev209]
all a: lab.T0 | a.av209 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av209 = (none)
all a: lab.T2 | a.av209 = (P2)
(R->P0 in ev209)
semantics3[av210, ev210]
all a: lab.T0 | a.av210 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av210 = (P3)
all a: lab.T2 | a.av210 = ((P0 + P2))
(R->P0 in ev210)
semantics5[av211, ev211]
all a: lab.T0 | a.av211 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av211 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av211 = ((P3 + P4))
(R->P0 in ev211)
semantics1[av212, ev212]
all a: lab.T0 | a.av212 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av212 = (P4)
all a: lab.T2 | a.av212 = ((P1 + (P2 + P4)))
(R->P0 in ev212)
semantics2[av213, ev213]
all a: lab.T0 | a.av213 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av213 = (none)
all a: lab.T2 | a.av213 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev213)
semantics5[av214, ev214]
all a: lab.T0 | a.av214 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av214 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av214 = ((P2 + P3))
(R->P0 in ev214)
semantics12[av215, ev215]
all a: lab.T0 | a.av215 = ((P0 + P1))
all a: lab.T1 | a.av215 = (P1)
all a: lab.T2 | a.av215 = (P0)
(R->P0 in ev215)
semantics6[av216, ev216]
all a: lab.T0 | a.av216 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av216 = (none)
all a: lab.T2 | a.av216 = ((P1 + (P2 + P3)))
(R->P0 in ev216)
semantics2[av217, ev217]
all a: lab.T0 | a.av217 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av217 = (P4)
all a: lab.T2 | a.av217 = ((P1 + (P2 + P4)))
(R->P0 in ev217)
semantics7[av218, ev218]
all a: lab.T0 | a.av218 = ((P0 + P3))
all a: lab.T1 | a.av218 = (none)
all a: lab.T2 | a.av218 = ((P1 + P2))
(R->P0 in ev218)
semantics4[av219, ev219]
all a: lab.T0 | a.av219 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av219 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av219 = (P4)
(R->P0 in ev219)
semantics0[av220, ev220]
all a: lab.T0 | a.av220 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av220 = (none)
all a: lab.T2 | a.av220 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev220)
semantics0[av221, ev221]
all a: lab.T0 | a.av221 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av221 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av221 = ((P1 + (P2 + P4)))
(R->P0 in ev221)
semantics3[av222, ev222]
all a: lab.T0 | a.av222 = ((P1 + P3))
all a: lab.T1 | a.av222 = (P3)
all a: lab.T2 | a.av222 = ((P2 + P3))
(R->P0 in ev222)
semantics0[av223, ev223]
all a: lab.T0 | a.av223 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av223 = (none)
all a: lab.T2 | a.av223 = (P2)
(R->P0 in ev223)
semantics0[av224, ev224]
all a: lab.T0 | a.av224 = ((P0 + P1))
all a: lab.T1 | a.av224 = (none)
all a: lab.T2 | a.av224 = ((P0 + P2))
(R->P0 in ev224)
semantics5[av225, ev225]
all a: lab.T0 | a.av225 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av225 = (none)
all a: lab.T2 | a.av225 = (none)
(R->P0 in ev225)
semantics2[av226, ev226]
all a: lab.T0 | a.av226 = ((P2 + P4))
all a: lab.T1 | a.av226 = (none)
all a: lab.T2 | a.av226 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev226)
semantics2[av227, ev227]
all a: lab.T0 | a.av227 = (none)
all a: lab.T1 | a.av227 = (none)
all a: lab.T2 | a.av227 = ((P0 + (P2 + P3)))
(R->P0 in ev227)
semantics1[av228, ev228]
all a: lab.T0 | a.av228 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av228 = (none)
all a: lab.T2 | a.av228 = ((P1 + (P2 + P4)))
(R->P0 in ev228)
semantics0[av229, ev229]
all a: lab.T0 | a.av229 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av229 = ((P2 + P3))
all a: lab.T2 | a.av229 = ((P1 + (P2 + P4)))
(R->P0 in ev229)
semantics2[av230, ev230]
all a: lab.T0 | a.av230 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av230 = (none)
all a: lab.T2 | a.av230 = ((P1 + (P3 + P4)))
(R->P0 in ev230)
semantics0[av231, ev231]
all a: lab.T0 | a.av231 = ((P1 + P3))
all a: lab.T1 | a.av231 = (none)
all a: lab.T2 | a.av231 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev231)
semantics2[av232, ev232]
all a: lab.T0 | a.av232 = ((P2 + P3))
all a: lab.T1 | a.av232 = (none)
all a: lab.T2 | a.av232 = ((P0 + (P2 + P3)))
(R->P0 in ev232)
semantics5[av233, ev233]
all a: lab.T0 | a.av233 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av233 = ((P2 + P3))
all a: lab.T2 | a.av233 = ((P0 + (P2 + P4)))
(R->P0 in ev233)
semantics5[av234, ev234]
all a: lab.T0 | a.av234 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av234 = ((P3 + P4))
all a: lab.T2 | a.av234 = ((P0 + (P2 + P3)))
(R->P0 in ev234)
semantics2[av235, ev235]
all a: lab.T0 | a.av235 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av235 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av235 = ((P0 + P3))
(R->P0 in ev235)
semantics5[av236, ev236]
all a: lab.T0 | a.av236 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av236 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av236 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev236)
semantics1[av237, ev237]
all a: lab.T0 | a.av237 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av237 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av237 = ((P2 + (P3 + P4)))
(R->P0 in ev237)
semantics2[av238, ev238]
all a: lab.T0 | a.av238 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av238 = (none)
all a: lab.T2 | a.av238 = ((P0 + P2))
(R->P0 in ev238)
semantics3[av239, ev239]
all a: lab.T0 | a.av239 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av239 = (P3)
all a: lab.T2 | a.av239 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev239)
semantics4[av240, ev240]
all a: lab.T0 | a.av240 = (P4)
all a: lab.T1 | a.av240 = (none)
all a: lab.T2 | a.av240 = ((P0 + P1))
(R->P0 in ev240)
semantics1[av241, ev241]
all a: lab.T0 | a.av241 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av241 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av241 = ((P0 + (P1 + P3)))
(R->P0 in ev241)
semantics1[av242, ev242]
all a: lab.T0 | a.av242 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av242 = (none)
all a: lab.T2 | a.av242 = ((P0 + (P1 + P3)))
(R->P0 in ev242)
semantics6[av243, ev243]
all a: lab.T0 | a.av243 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av243 = ((P1 + P2))
all a: lab.T2 | a.av243 = ((P1 + P3))
(R->P0 in ev243)
semantics4[av244, ev244]
all a: lab.T0 | a.av244 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av244 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av244 = ((P0 + (P2 + P4)))
(R->P0 in ev244)
semantics7[av245, ev245]
all a: lab.T0 | a.av245 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av245 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av245 = ((P0 + P3))
(R->P0 in ev245)
semantics1[av246, ev246]
all a: lab.T0 | a.av246 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av246 = ((P1 + P2))
all a: lab.T2 | a.av246 = (P4)
(R->P0 in ev246)
semantics1[av247, ev247]
all a: lab.T0 | a.av247 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av247 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av247 = ((P3 + P4))
(R->P0 in ev247)
semantics2[av248, ev248]
all a: lab.T0 | a.av248 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av248 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av248 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev248)
semantics2[av249, ev249]
all a: lab.T0 | a.av249 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av249 = (none)
all a: lab.T2 | a.av249 = (P1)
(R->P0 in ev249)
semantics4[av250, ev250]
all a: lab.T0 | a.av250 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av250 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av250 = ((P1 + (P2 + P3)))
(R->P0 in ev250)
semantics1[av251, ev251]
all a: lab.T0 | a.av251 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av251 = (P4)
all a: lab.T2 | a.av251 = (P3)
(R->P0 in ev251)
semantics11[av252, ev252]
all a: lab.T0 | a.av252 = ((P0 + P1))
all a: lab.T1 | a.av252 = (none)
all a: lab.T2 | a.av252 = (P0)
(R->P0 in ev252)
semantics1[av253, ev253]
all a: lab.T0 | a.av253 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av253 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av253 = ((P0 + P3))
(R->P0 in ev253)
semantics1[av254, ev254]
all a: lab.T0 | a.av254 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av254 = (P4)
all a: lab.T2 | a.av254 = (P2)
(R->P0 in ev254)
semantics4[av255, ev255]
all a: lab.T0 | a.av255 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av255 = (none)
all a: lab.T2 | a.av255 = (P4)
(R->P0 in ev255)
semantics6[av256, ev256]
all a: lab.T0 | a.av256 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av256 = ((P1 + P2))
all a: lab.T2 | a.av256 = (P3)
(R->P0 in ev256)
semantics5[av257, ev257]
all a: lab.T0 | a.av257 = ((P1 + P2))
all a: lab.T1 | a.av257 = (none)
all a: lab.T2 | a.av257 = ((P2 + P4))
(R->P0 in ev257)
semantics10[av258, ev258]
all a: lab.T0 | a.av258 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av258 = (P0)
all a: lab.T2 | a.av258 = (P2)
(R->P0 in ev258)
semantics3[av259, ev259]
all a: lab.T0 | a.av259 = ((P0 + P1))
all a: lab.T1 | a.av259 = (none)
all a: lab.T2 | a.av259 = ((P1 + P2))
(R->P0 in ev259)
semantics2[av260, ev260]
all a: lab.T0 | a.av260 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av260 = ((P2 + P3))
all a: lab.T2 | a.av260 = (P3)
(R->P0 in ev260)
semantics7[av261, ev261]
all a: lab.T0 | a.av261 = ((P2 + P3))
all a: lab.T1 | a.av261 = (P3)
all a: lab.T2 | a.av261 = (P3)
(R->P0 in ev261)
semantics5[av262, ev262]
all a: lab.T0 | a.av262 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av262 = ((P2 + P4))
all a: lab.T2 | a.av262 = ((P0 + (P1 + P4)))
(R->P0 in ev262)
semantics5[av263, ev263]
all a: lab.T0 | a.av263 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av263 = (P3)
all a: lab.T2 | a.av263 = ((P1 + (P2 + P3)))
(R->P0 in ev263)
semantics0[av264, ev264]
all a: lab.T0 | a.av264 = (P4)
all a: lab.T1 | a.av264 = (none)
all a: lab.T2 | a.av264 = ((P1 + (P2 + P3)))
(R->P0 in ev264)
semantics4[av265, ev265]
all a: lab.T0 | a.av265 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av265 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av265 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev265)
semantics5[av266, ev266]
all a: lab.T0 | a.av266 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av266 = (P4)
all a: lab.T2 | a.av266 = ((P0 + (P2 + P4)))
(R->P0 in ev266)
semantics5[av267, ev267]
all a: lab.T0 | a.av267 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av267 = ((P2 + P3))
all a: lab.T2 | a.av267 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev267)
semantics1[av268, ev268]
all a: lab.T0 | a.av268 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av268 = ((P3 + P4))
all a: lab.T2 | a.av268 = ((P0 + (P1 + P4)))
(R->P0 in ev268)
semantics5[av269, ev269]
all a: lab.T0 | a.av269 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av269 = ((P0 + P3))
all a: lab.T2 | a.av269 = ((P1 + (P3 + P4)))
(R->P0 in ev269)
semantics1[av270, ev270]
all a: lab.T0 | a.av270 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av270 = (P3)
all a: lab.T2 | a.av270 = (P4)
(R->P0 in ev270)
semantics2[av271, ev271]
all a: lab.T0 | a.av271 = (P0)
all a: lab.T1 | a.av271 = (none)
all a: lab.T2 | a.av271 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev271)
semantics2[av272, ev272]
all a: lab.T0 | a.av272 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av272 = ((P0 + P2))
all a: lab.T2 | a.av272 = (P1)
(R->P0 in ev272)
semantics5[av273, ev273]
all a: lab.T0 | a.av273 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av273 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av273 = ((P0 + (P2 + P4)))
(R->P0 in ev273)
semantics1[av274, ev274]
all a: lab.T0 | a.av274 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av274 = (none)
all a: lab.T2 | a.av274 = ((P1 + P2))
(R->P0 in ev274)
semantics0[av275, ev275]
all a: lab.T0 | a.av275 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av275 = ((P3 + P4))
all a: lab.T2 | a.av275 = ((P0 + (P2 + P3)))
(R->P0 in ev275)
semantics5[av276, ev276]
all a: lab.T0 | a.av276 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av276 = ((P2 + P3))
all a: lab.T2 | a.av276 = ((P3 + P4))
(R->P0 in ev276)
semantics0[av277, ev277]
all a: lab.T0 | a.av277 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av277 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av277 = ((P1 + P3))
(R->P0 in ev277)
semantics0[av278, ev278]
all a: lab.T0 | a.av278 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av278 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av278 = ((P2 + P3))
(R->P0 in ev278)
semantics4[av279, ev279]
all a: lab.T0 | a.av279 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av279 = (none)
all a: lab.T2 | a.av279 = ((P1 + (P2 + P4)))
(R->P0 in ev279)
semantics5[av280, ev280]
all a: lab.T0 | a.av280 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av280 = (P4)
all a: lab.T2 | a.av280 = ((P0 + P4))
(R->P0 in ev280)
semantics8[av281, ev281]
all a: lab.T0 | a.av281 = ((P0 + P1))
all a: lab.T1 | a.av281 = (none)
all a: lab.T2 | a.av281 = ((P2 + P3))
(R->P0 in ev281)
semantics1[av282, ev282]
all a: lab.T0 | a.av282 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av282 = ((P3 + P4))
all a: lab.T2 | a.av282 = (P4)
(R->P0 in ev282)
semantics2[av283, ev283]
all a: lab.T0 | a.av283 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av283 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av283 = ((P0 + P1))
(R->P0 in ev283)
semantics2[av284, ev284]
all a: lab.T0 | a.av284 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av284 = (P1)
all a: lab.T2 | a.av284 = ((P0 + P2))
(R->P0 in ev284)
semantics6[av285, ev285]
all a: lab.T0 | a.av285 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av285 = (P0)
all a: lab.T2 | a.av285 = ((P1 + P2))
(R->P0 in ev285)
semantics9[av286, ev286]
all a: lab.T0 | a.av286 = ((P0 + P1))
all a: lab.T1 | a.av286 = (none)
all a: lab.T2 | a.av286 = ((P0 + (P1 + P2)))
(R->P0 in ev286)
semantics2[av287, ev287]
all a: lab.T0 | a.av287 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av287 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av287 = ((P2 + P4))
(R->P0 in ev287)
semantics3[av288, ev288]
all a: lab.T0 | a.av288 = ((P0 + P2))
all a: lab.T1 | a.av288 = (none)
all a: lab.T2 | a.av288 = ((P0 + (P1 + P2)))
(R->P0 in ev288)
semantics1[av289, ev289]
all a: lab.T0 | a.av289 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av289 = (P4)
all a: lab.T2 | a.av289 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev289)
semantics4[av290, ev290]
all a: lab.T0 | a.av290 = ((P0 + P4))
all a: lab.T1 | a.av290 = (none)
all a: lab.T2 | a.av290 = ((P1 + (P3 + P4)))
(R->P0 in ev290)
semantics4[av291, ev291]
all a: lab.T0 | a.av291 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av291 = (none)
all a: lab.T2 | a.av291 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev291)
semantics0[av292, ev292]
all a: lab.T0 | a.av292 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av292 = ((P1 + P3))
all a: lab.T2 | a.av292 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev292)
semantics3[av293, ev293]
all a: lab.T0 | a.av293 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av293 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av293 = (P2)
(R->P0 in ev293)
semantics2[av294, ev294]
all a: lab.T0 | a.av294 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av294 = ((P2 + P4))
all a: lab.T2 | a.av294 = ((P0 + P3))
(R->P0 in ev294)
semantics2[av295, ev295]
all a: lab.T0 | a.av295 = ((P1 + P4))
all a: lab.T1 | a.av295 = (none)
all a: lab.T2 | a.av295 = ((P0 + P3))
(R->P0 in ev295)
semantics2[av296, ev296]
all a: lab.T0 | a.av296 = ((P0 + P1))
all a: lab.T1 | a.av296 = (none)
all a: lab.T2 | a.av296 = ((P0 + P2))
(R->P0 in ev296)
semantics6[av297, ev297]
all a: lab.T0 | a.av297 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av297 = ((P0 + P3))
all a: lab.T2 | a.av297 = ((P0 + P3))
(R->P0 in ev297)
semantics4[av298, ev298]
all a: lab.T0 | a.av298 = ((P0 + P3))
all a: lab.T1 | a.av298 = (none)
all a: lab.T2 | a.av298 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev298)
semantics5[av299, ev299]
all a: lab.T0 | a.av299 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av299 = (none)
all a: lab.T2 | a.av299 = ((P1 + P4))
(R->P0 in ev299)
semantics0[av300, ev300]
all a: lab.T0 | a.av300 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av300 = (none)
all a: lab.T2 | a.av300 = ((P1 + (P2 + P4)))
(R->P0 in ev300)
semantics4[av301, ev301]
all a: lab.T0 | a.av301 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av301 = ((P1 + P4))
all a: lab.T2 | a.av301 = ((P0 + P4))
(R->P0 in ev301)
semantics0[av302, ev302]
all a: lab.T0 | a.av302 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av302 = (none)
all a: lab.T2 | a.av302 = ((P0 + (P1 + P3)))
(R->P0 in ev302)
semantics13[av303, ev303]
all a: lab.T0 | a.av303 = (P1)
all a: lab.T1 | a.av303 = (P1)
all a: lab.T2 | a.av303 = (none)
(R->P0 in ev303)
semantics2[av304, ev304]
all a: lab.T0 | a.av304 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av304 = (P2)
all a: lab.T2 | a.av304 = ((P1 + P4))
(R->P0 in ev304)
semantics0[av305, ev305]
all a: lab.T0 | a.av305 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av305 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av305 = ((P2 + P4))
(R->P0 in ev305)
semantics1[av306, ev306]
all a: lab.T0 | a.av306 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av306 = (P3)
all a: lab.T2 | a.av306 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev306)
semantics0[av307, ev307]
all a: lab.T0 | a.av307 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av307 = (none)
all a: lab.T2 | a.av307 = ((P0 + P4))
(R->P0 in ev307)
semantics0[av308, ev308]
all a: lab.T0 | a.av308 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av308 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av308 = ((P1 + (P3 + P4)))
(R->P0 in ev308)
semantics0[av309, ev309]
all a: lab.T0 | a.av309 = ((P0 + P1))
all a: lab.T1 | a.av309 = (none)
all a: lab.T2 | a.av309 = ((P3 + P4))
(R->P0 in ev309)
semantics2[av310, ev310]
all a: lab.T0 | a.av310 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av310 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av310 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev310)
semantics5[av311, ev311]
all a: lab.T0 | a.av311 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av311 = (none)
all a: lab.T2 | a.av311 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev311)
semantics8[av312, ev312]
all a: lab.T0 | a.av312 = (P2)
all a: lab.T1 | a.av312 = (none)
all a: lab.T2 | a.av312 = ((P0 + P2))
(R->P0 in ev312)
semantics0[av313, ev313]
all a: lab.T0 | a.av313 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av313 = (none)
all a: lab.T2 | a.av313 = ((P0 + (P1 + P3)))
(R->P0 in ev313)
semantics0[av314, ev314]
all a: lab.T0 | a.av314 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av314 = ((P2 + P4))
all a: lab.T2 | a.av314 = (none)
(R->P0 in ev314)
semantics0[av315, ev315]
all a: lab.T0 | a.av315 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av315 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av315 = ((P1 + P3))
(R->P0 in ev315)
semantics1[av316, ev316]
all a: lab.T0 | a.av316 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av316 = ((P3 + P4))
all a: lab.T2 | a.av316 = ((P0 + P4))
(R->P0 in ev316)
semantics0[av317, ev317]
all a: lab.T0 | a.av317 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av317 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av317 = ((P0 + P3))
(R->P0 in ev317)
semantics0[av318, ev318]
all a: lab.T0 | a.av318 = ((P0 + P3))
all a: lab.T1 | a.av318 = (none)
all a: lab.T2 | a.av318 = (P4)
(R->P0 in ev318)
semantics1[av319, ev319]
all a: lab.T0 | a.av319 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av319 = ((P0 + P2))
all a: lab.T2 | a.av319 = ((P1 + (P2 + P3)))
(R->P0 in ev319)
semantics1[av320, ev320]
all a: lab.T0 | a.av320 = ((P0 + P1))
all a: lab.T1 | a.av320 = (none)
all a: lab.T2 | a.av320 = ((P1 + P4))
(R->P0 in ev320)
semantics1[av321, ev321]
all a: lab.T0 | a.av321 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av321 = ((P1 + P2))
all a: lab.T2 | a.av321 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev321)
semantics2[av322, ev322]
all a: lab.T0 | a.av322 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av322 = (none)
all a: lab.T2 | a.av322 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev322)
semantics4[av323, ev323]
all a: lab.T0 | a.av323 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av323 = (none)
all a: lab.T2 | a.av323 = ((P0 + (P1 + P4)))
(R->P0 in ev323)
semantics1[av324, ev324]
all a: lab.T0 | a.av324 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av324 = (none)
all a: lab.T2 | a.av324 = (P1)
(R->P0 in ev324)
semantics5[av325, ev325]
all a: lab.T0 | a.av325 = ((P3 + P4))
all a: lab.T1 | a.av325 = (P3)
all a: lab.T2 | a.av325 = ((P0 + P4))
(R->P0 in ev325)
semantics2[av326, ev326]
all a: lab.T0 | a.av326 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av326 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av326 = ((P0 + (P1 + P2)))
(R->P0 in ev326)
semantics1[av327, ev327]
all a: lab.T0 | a.av327 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av327 = (P3)
all a: lab.T2 | a.av327 = ((P2 + P3))
(R->P0 in ev327)
semantics3[av328, ev328]
all a: lab.T0 | a.av328 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av328 = ((P1 + P2))
all a: lab.T2 | a.av328 = (none)
(R->P0 in ev328)
semantics1[av329, ev329]
all a: lab.T0 | a.av329 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av329 = (P3)
all a: lab.T2 | a.av329 = (none)
(R->P0 in ev329)
semantics4[av330, ev330]
all a: lab.T0 | a.av330 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av330 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av330 = ((P0 + P2))
(R->P0 in ev330)
semantics1[av331, ev331]
all a: lab.T0 | a.av331 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av331 = (none)
all a: lab.T2 | a.av331 = (P2)
(R->P0 in ev331)
semantics1[av332, ev332]
all a: lab.T0 | a.av332 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av332 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av332 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev332)
semantics1[av333, ev333]
all a: lab.T0 | a.av333 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av333 = ((P0 + P3))
all a: lab.T2 | a.av333 = ((P0 + (P1 + P2)))
(R->P0 in ev333)
semantics4[av334, ev334]
all a: lab.T0 | a.av334 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av334 = ((P0 + P2))
all a: lab.T2 | a.av334 = ((P0 + (P1 + P2)))
(R->P0 in ev334)
semantics8[av335, ev335]
all a: lab.T0 | a.av335 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av335 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av335 = ((P0 + (P1 + P3)))
(R->P0 in ev335)
semantics3[av336, ev336]
all a: lab.T0 | a.av336 = ((P0 + P3))
all a: lab.T1 | a.av336 = (P3)
all a: lab.T2 | a.av336 = ((P1 + (P2 + P3)))
(R->P0 in ev336)
semantics4[av337, ev337]
all a: lab.T0 | a.av337 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av337 = (none)
all a: lab.T2 | a.av337 = (((P0 + P2) + (P3 + P4)))
(R->P0 in ev337)
semantics2[av338, ev338]
all a: lab.T0 | a.av338 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av338 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av338 = ((P1 + (P2 + P4)))
(R->P0 in ev338)
semantics1[av339, ev339]
all a: lab.T0 | a.av339 = (P4)
all a: lab.T1 | a.av339 = (P4)
all a: lab.T2 | a.av339 = ((P0 + (P1 + P2)))
(R->P0 in ev339)
semantics2[av340, ev340]
all a: lab.T0 | a.av340 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av340 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av340 = ((P0 + P1))
(R->P0 in ev340)
semantics3[av341, ev341]
all a: lab.T0 | a.av341 = ((P0 + P2))
all a: lab.T1 | a.av341 = (none)
all a: lab.T2 | a.av341 = (P1)
(R->P0 in ev341)
semantics4[av342, ev342]
all a: lab.T0 | a.av342 = (P3)
all a: lab.T1 | a.av342 = (none)
all a: lab.T2 | a.av342 = ((P0 + (P2 + P4)))
(R->P0 in ev342)
semantics5[av343, ev343]
all a: lab.T0 | a.av343 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av343 = ((P1 + P4))
all a: lab.T2 | a.av343 = ((P0 + (P3 + P4)))
(R->P0 in ev343)
semantics8[av344, ev344]
all a: lab.T0 | a.av344 = ((P2 + P3))
all a: lab.T1 | a.av344 = (none)
all a: lab.T2 | a.av344 = ((P1 + P2))
(R->P0 in ev344)
semantics5[av345, ev345]
all a: lab.T0 | a.av345 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av345 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av345 = ((P0 + (P2 + P3)))
(R->P0 in ev345)
semantics5[av346, ev346]
all a: lab.T0 | a.av346 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av346 = ((P2 + P3))
all a: lab.T2 | a.av346 = (P3)
(R->P0 in ev346)
semantics7[av347, ev347]
all a: lab.T0 | a.av347 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av347 = (P3)
all a: lab.T2 | a.av347 = ((P1 + P3))
(R->P0 in ev347)
semantics3[av348, ev348]
all a: lab.T0 | a.av348 = ((P1 + P3))
all a: lab.T1 | a.av348 = (P3)
all a: lab.T2 | a.av348 = (P1)
(R->P0 in ev348)
semantics0[av349, ev349]
all a: lab.T0 | a.av349 = ((P0 + P3))
all a: lab.T1 | a.av349 = (none)
all a: lab.T2 | a.av349 = ((P3 + P4))
(R->P0 in ev349)
semantics1[av350, ev350]
all a: lab.T0 | a.av350 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av350 = ((P1 + P4))
all a: lab.T2 | a.av350 = ((P0 + (P1 + P2)))
(R->P0 in ev350)
semantics0[av351, ev351]
all a: lab.T0 | a.av351 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av351 = (none)
all a: lab.T2 | a.av351 = (P1)
(R->P0 in ev351)
semantics0[av352, ev352]
all a: lab.T0 | a.av352 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av352 = ((P2 + P4))
all a: lab.T2 | a.av352 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev352)
semantics0[av353, ev353]
all a: lab.T0 | a.av353 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av353 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av353 = ((P0 + (P1 + P2)))
(R->P0 in ev353)
semantics4[av354, ev354]
all a: lab.T0 | a.av354 = ((P0 + P1))
all a: lab.T1 | a.av354 = (none)
all a: lab.T2 | a.av354 = ((P0 + (P1 + P2)))
(R->P0 in ev354)
semantics1[av355, ev355]
all a: lab.T0 | a.av355 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av355 = (P1)
all a: lab.T2 | a.av355 = ((P0 + (P1 + P4)))
(R->P0 in ev355)
semantics8[av356, ev356]
all a: lab.T0 | a.av356 = (P2)
all a: lab.T1 | a.av356 = (none)
all a: lab.T2 | a.av356 = ((P0 + (P1 + P2)))
(R->P0 in ev356)
semantics6[av357, ev357]
all a: lab.T0 | a.av357 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av357 = ((P0 + P1))
all a: lab.T2 | a.av357 = (none)
(R->P0 in ev357)
semantics5[av358, ev358]
all a: lab.T0 | a.av358 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av358 = (none)
all a: lab.T2 | a.av358 = ((P1 + P4))
(R->P0 in ev358)
semantics5[av359, ev359]
all a: lab.T0 | a.av359 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av359 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av359 = ((P0 + (P2 + P4)))
(R->P0 in ev359)
semantics8[av360, ev360]
all a: lab.T0 | a.av360 = ((P0 + P3))
all a: lab.T1 | a.av360 = (none)
all a: lab.T2 | a.av360 = ((P2 + P3))
(R->P0 in ev360)
semantics2[av361, ev361]
all a: lab.T0 | a.av361 = ((P1 + P4))
all a: lab.T1 | a.av361 = (none)
all a: lab.T2 | a.av361 = ((P1 + (P2 + P3)))
(R->P0 in ev361)
semantics2[av362, ev362]
all a: lab.T0 | a.av362 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av362 = (P2)
all a: lab.T2 | a.av362 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev362)
semantics7[av363, ev363]
all a: lab.T0 | a.av363 = ((P0 + P3))
all a: lab.T1 | a.av363 = (none)
all a: lab.T2 | a.av363 = (P0)
(R->P0 in ev363)
semantics3[av364, ev364]
all a: lab.T0 | a.av364 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av364 = (P2)
all a: lab.T2 | a.av364 = ((P0 + (P2 + P3)))
(R->P0 in ev364)
semantics4[av365, ev365]
all a: lab.T0 | a.av365 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av365 = (none)
all a: lab.T2 | a.av365 = (none)
(R->P0 in ev365)
semantics1[av366, ev366]
all a: lab.T0 | a.av366 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av366 = (P2)
all a: lab.T2 | a.av366 = ((P0 + (P1 + P4)))
(R->P0 in ev366)
semantics2[av367, ev367]
all a: lab.T0 | a.av367 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av367 = ((P1 + P4))
all a: lab.T2 | a.av367 = (P0)
(R->P0 in ev367)
semantics2[av368, ev368]
all a: lab.T0 | a.av368 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av368 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av368 = ((P0 + P2))
(R->P0 in ev368)
semantics2[av369, ev369]
all a: lab.T0 | a.av369 = ((P0 + P3))
all a: lab.T1 | a.av369 = (none)
all a: lab.T2 | a.av369 = ((P0 + P4))
(R->P0 in ev369)
semantics2[av370, ev370]
all a: lab.T0 | a.av370 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av370 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av370 = ((P1 + P3))
(R->P0 in ev370)
semantics4[av371, ev371]
all a: lab.T0 | a.av371 = ((P0 + P2))
all a: lab.T1 | a.av371 = (none)
all a: lab.T2 | a.av371 = ((P1 + (P3 + P4)))
(R->P0 in ev371)
semantics0[av372, ev372]
all a: lab.T0 | a.av372 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av372 = ((P3 + P4))
all a: lab.T2 | a.av372 = ((P0 + (P1 + P4)))
(R->P0 in ev372)
semantics2[av373, ev373]
all a: lab.T0 | a.av373 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av373 = ((P2 + P4))
all a: lab.T2 | a.av373 = ((P3 + P4))
(R->P0 in ev373)
semantics0[av374, ev374]
all a: lab.T0 | a.av374 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av374 = ((P0 + P1))
all a: lab.T2 | a.av374 = ((P2 + P4))
(R->P0 in ev374)
semantics5[av375, ev375]
all a: lab.T0 | a.av375 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av375 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av375 = ((P1 + P3))
(R->P0 in ev375)
semantics3[av376, ev376]
all a: lab.T0 | a.av376 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av376 = (P3)
all a: lab.T2 | a.av376 = ((P0 + (P1 + P3)))
(R->P0 in ev376)
semantics3[av377, ev377]
all a: lab.T0 | a.av377 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av377 = (P1)
all a: lab.T2 | a.av377 = (P2)
(R->P0 in ev377)
semantics9[av378, ev378]
all a: lab.T0 | a.av378 = (P0)
all a: lab.T1 | a.av378 = (none)
all a: lab.T2 | a.av378 = ((P0 + P1))
(R->P0 in ev378)
semantics6[av379, ev379]
all a: lab.T0 | a.av379 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av379 = ((P1 + P3))
all a: lab.T2 | a.av379 = (P2)
(R->P0 in ev379)
semantics8[av380, ev380]
all a: lab.T0 | a.av380 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av380 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av380 = ((P0 + (P1 + P2)))
(R->P0 in ev380)
semantics4[av381, ev381]
all a: lab.T0 | a.av381 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av381 = ((P1 + P4))
all a: lab.T2 | a.av381 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev381)
semantics4[av382, ev382]
all a: lab.T0 | a.av382 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av382 = (none)
all a: lab.T2 | a.av382 = ((P3 + P4))
(R->P0 in ev382)
semantics4[av383, ev383]
all a: lab.T0 | a.av383 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av383 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av383 = (P0)
(R->P0 in ev383)
semantics1[av384, ev384]
all a: lab.T0 | a.av384 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av384 = ((P2 + P3))
all a: lab.T2 | a.av384 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev384)
semantics6[av385, ev385]
all a: lab.T0 | a.av385 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av385 = (none)
all a: lab.T2 | a.av385 = ((P2 + P3))
(R->P0 in ev385)
semantics8[av386, ev386]
all a: lab.T0 | a.av386 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av386 = (none)
all a: lab.T2 | a.av386 = ((P1 + P3))
(R->P0 in ev386)
semantics0[av387, ev387]
all a: lab.T0 | a.av387 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av387 = (none)
all a: lab.T2 | a.av387 = ((P0 + P2))
(R->P0 in ev387)
semantics0[av388, ev388]
all a: lab.T0 | a.av388 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av388 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av388 = ((P0 + (P1 + P3)))
(R->P0 in ev388)
semantics0[av389, ev389]
all a: lab.T0 | a.av389 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av389 = ((P2 + P4))
all a: lab.T2 | a.av389 = (P4)
(R->P0 in ev389)
semantics1[av390, ev390]
all a: lab.T0 | a.av390 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av390 = ((P1 + P2))
all a: lab.T2 | a.av390 = ((P1 + P3))
(R->P0 in ev390)
semantics4[av391, ev391]
all a: lab.T0 | a.av391 = (P2)
all a: lab.T1 | a.av391 = (none)
all a: lab.T2 | a.av391 = ((P2 + P3))
(R->P0 in ev391)
semantics1[av392, ev392]
all a: lab.T0 | a.av392 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av392 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av392 = ((P0 + (P1 + P2)))
(R->P0 in ev392)
semantics0[av393, ev393]
all a: lab.T0 | a.av393 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av393 = (none)
all a: lab.T2 | a.av393 = ((P0 + P4))
(R->P0 in ev393)
semantics9[av394, ev394]
all a: lab.T0 | a.av394 = ((P1 + P2))
all a: lab.T1 | a.av394 = (P2)
all a: lab.T2 | a.av394 = (P2)
(R->P0 in ev394)
semantics1[av395, ev395]
all a: lab.T0 | a.av395 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av395 = ((P1 + P4))
all a: lab.T2 | a.av395 = ((P1 + (P2 + P3)))
(R->P0 in ev395)
semantics1[av396, ev396]
all a: lab.T0 | a.av396 = ((P3 + P4))
all a: lab.T1 | a.av396 = ((P3 + P4))
all a: lab.T2 | a.av396 = ((P1 + (P2 + P3)))
(R->P0 in ev396)
semantics2[av397, ev397]
all a: lab.T0 | a.av397 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av397 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av397 = ((P0 + (P1 + P2)))
(R->P0 in ev397)
semantics0[av398, ev398]
all a: lab.T0 | a.av398 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av398 = (P4)
all a: lab.T2 | a.av398 = ((P2 + P4))
(R->P0 in ev398)
semantics5[av399, ev399]
all a: lab.T0 | a.av399 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av399 = (P4)
all a: lab.T2 | a.av399 = ((P2 + P4))
(R->P0 in ev399)
semantics2[av400, ev400]
all a: lab.T0 | a.av400 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av400 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av400 = ((P1 + (P2 + P3)))
(R->P0 in ev400)
semantics1[av401, ev401]
all a: lab.T0 | a.av401 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av401 = ((P2 + P3))
all a: lab.T2 | a.av401 = ((P0 + (P1 + P4)))
(R->P0 in ev401)
semantics1[av402, ev402]
all a: lab.T0 | a.av402 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av402 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av402 = (P1)
(R->P0 in ev402)
semantics3[av403, ev403]
all a: lab.T0 | a.av403 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av403 = (none)
all a: lab.T2 | a.av403 = (none)
(R->P0 in ev403)
semantics0[av404, ev404]
all a: lab.T0 | a.av404 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av404 = (none)
all a: lab.T2 | a.av404 = ((P2 + P4))
(R->P0 in ev404)
semantics6[av405, ev405]
all a: lab.T0 | a.av405 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av405 = ((P0 + P3))
all a: lab.T2 | a.av405 = ((P1 + (P2 + P3)))
(R->P0 in ev405)
semantics1[av406, ev406]
all a: lab.T0 | a.av406 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av406 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av406 = (P3)
(R->P0 in ev406)
semantics6[av407, ev407]
all a: lab.T0 | a.av407 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av407 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av407 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev407)
semantics0[av408, ev408]
all a: lab.T0 | a.av408 = ((P1 + P2))
all a: lab.T1 | a.av408 = (none)
all a: lab.T2 | a.av408 = (none)
(R->P0 in ev408)
semantics9[av409, ev409]
all a: lab.T0 | a.av409 = ((P1 + P2))
all a: lab.T1 | a.av409 = (P2)
all a: lab.T2 | a.av409 = (P1)
(R->P0 in ev409)
semantics8[av410, ev410]
all a: lab.T0 | a.av410 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av410 = ((P2 + P3))
all a: lab.T2 | a.av410 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev410)
semantics5[av411, ev411]
all a: lab.T0 | a.av411 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av411 = ((P0 + P3))
all a: lab.T2 | a.av411 = ((P1 + P2))
(R->P0 in ev411)
semantics7[av412, ev412]
all a: lab.T0 | a.av412 = ((P2 + P3))
all a: lab.T1 | a.av412 = (none)
all a: lab.T2 | a.av412 = ((P0 + P2))
(R->P0 in ev412)
semantics4[av413, ev413]
all a: lab.T0 | a.av413 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av413 = (P1)
all a: lab.T2 | a.av413 = ((P0 + (P1 + P2)))
(R->P0 in ev413)
semantics3[av414, ev414]
all a: lab.T0 | a.av414 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av414 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av414 = ((P1 + (P2 + P3)))
(R->P0 in ev414)
semantics5[av415, ev415]
all a: lab.T0 | a.av415 = (none)
all a: lab.T1 | a.av415 = (none)
all a: lab.T2 | a.av415 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev415)
semantics3[av416, ev416]
all a: lab.T0 | a.av416 = (P2)
all a: lab.T1 | a.av416 = (none)
all a: lab.T2 | a.av416 = ((P1 + P2))
(R->P0 in ev416)
semantics5[av417, ev417]
all a: lab.T0 | a.av417 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av417 = (none)
all a: lab.T2 | a.av417 = ((P0 + (P1 + P4)))
(R->P0 in ev417)
semantics1[av418, ev418]
all a: lab.T0 | a.av418 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av418 = (P3)
all a: lab.T2 | a.av418 = ((P0 + P1))
(R->P0 in ev418)
semantics0[av419, ev419]
all a: lab.T0 | a.av419 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av419 = ((P3 + P4))
all a: lab.T2 | a.av419 = (P3)
(R->P0 in ev419)
semantics5[av420, ev420]
all a: lab.T0 | a.av420 = ((P3 + P4))
all a: lab.T1 | a.av420 = (P3)
all a: lab.T2 | a.av420 = (P4)
(R->P0 in ev420)
semantics1[av421, ev421]
all a: lab.T0 | a.av421 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av421 = ((P2 + P3))
all a: lab.T2 | a.av421 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev421)
semantics5[av422, ev422]
all a: lab.T0 | a.av422 = ((P0 + P4))
all a: lab.T1 | a.av422 = (none)
all a: lab.T2 | a.av422 = ((P0 + (P1 + P3)))
(R->P0 in ev422)
semantics0[av423, ev423]
all a: lab.T0 | a.av423 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av423 = ((P3 + P4))
all a: lab.T2 | a.av423 = ((P3 + P4))
(R->P0 in ev423)
semantics4[av424, ev424]
all a: lab.T0 | a.av424 = ((P1 + P4))
all a: lab.T1 | a.av424 = (none)
all a: lab.T2 | a.av424 = (P4)
(R->P0 in ev424)
semantics4[av425, ev425]
all a: lab.T0 | a.av425 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av425 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av425 = ((P1 + P3))
(R->P0 in ev425)
semantics0[av426, ev426]
all a: lab.T0 | a.av426 = ((P2 + P4))
all a: lab.T1 | a.av426 = (none)
all a: lab.T2 | a.av426 = ((P1 + (P2 + P4)))
(R->P0 in ev426)
semantics8[av427, ev427]
all a: lab.T0 | a.av427 = ((P0 + P2))
all a: lab.T1 | a.av427 = (none)
all a: lab.T2 | a.av427 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev427)
semantics4[av428, ev428]
all a: lab.T0 | a.av428 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av428 = (none)
all a: lab.T2 | a.av428 = ((P0 + (P2 + P3)))
(R->P0 in ev428)
semantics11[av429, ev429]
all a: lab.T0 | a.av429 = (P0)
all a: lab.T1 | a.av429 = (none)
all a: lab.T2 | a.av429 = (P0)
(R->P0 in ev429)
semantics1[av430, ev430]
all a: lab.T0 | a.av430 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av430 = ((P2 + P4))
all a: lab.T2 | a.av430 = ((P1 + P4))
(R->P0 in ev430)
semantics5[av431, ev431]
all a: lab.T0 | a.av431 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av431 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av431 = ((P0 + (P3 + P4)))
(R->P0 in ev431)
semantics5[av432, ev432]
all a: lab.T0 | a.av432 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av432 = ((P2 + P4))
all a: lab.T2 | a.av432 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev432)
semantics0[av433, ev433]
all a: lab.T0 | a.av433 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av433 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av433 = ((P1 + P3))
(R->P0 in ev433)
semantics2[av434, ev434]
all a: lab.T0 | a.av434 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av434 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av434 = ((P1 + (P2 + P3)))
(R->P0 in ev434)
semantics0[av435, ev435]
all a: lab.T0 | a.av435 = ((P1 + P2))
all a: lab.T1 | a.av435 = (none)
all a: lab.T2 | a.av435 = ((P0 + P2))
(R->P0 in ev435)
semantics5[av436, ev436]
all a: lab.T0 | a.av436 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av436 = (none)
all a: lab.T2 | a.av436 = ((P1 + P4))
(R->P0 in ev436)
semantics0[av437, ev437]
all a: lab.T0 | a.av437 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av437 = (P4)
all a: lab.T2 | a.av437 = ((P0 + P1))
(R->P0 in ev437)
semantics1[av438, ev438]
all a: lab.T0 | a.av438 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av438 = ((P2 + P4))
all a: lab.T2 | a.av438 = ((P3 + P4))
(R->P0 in ev438)
semantics5[av439, ev439]
all a: lab.T0 | a.av439 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av439 = (P2)
all a: lab.T2 | a.av439 = ((P2 + P4))
(R->P0 in ev439)
semantics1[av440, ev440]
all a: lab.T0 | a.av440 = (P4)
all a: lab.T1 | a.av440 = (none)
all a: lab.T2 | a.av440 = ((P1 + P3))
(R->P0 in ev440)
semantics2[av441, ev441]
all a: lab.T0 | a.av441 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av441 = ((P2 + P3))
all a: lab.T2 | a.av441 = ((P1 + (P2 + P4)))
(R->P0 in ev441)
semantics3[av442, ev442]
all a: lab.T0 | a.av442 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av442 = (P3)
all a: lab.T2 | a.av442 = ((P0 + (P1 + P3)))
(R->P0 in ev442)
semantics5[av443, ev443]
all a: lab.T0 | a.av443 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av443 = ((P3 + P4))
all a: lab.T2 | a.av443 = ((P1 + P3))
(R->P0 in ev443)
semantics3[av444, ev444]
all a: lab.T0 | a.av444 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av444 = ((P2 + P3))
all a: lab.T2 | a.av444 = ((P0 + (P1 + P3)))
(R->P0 in ev444)
semantics3[av445, ev445]
all a: lab.T0 | a.av445 = ((P2 + P3))
all a: lab.T1 | a.av445 = ((P2 + P3))
all a: lab.T2 | a.av445 = ((P0 + (P1 + P3)))
(R->P0 in ev445)
semantics5[av446, ev446]
all a: lab.T0 | a.av446 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av446 = ((P1 + P4))
all a: lab.T2 | a.av446 = ((P0 + (P1 + P4)))
(R->P0 in ev446)
semantics6[av447, ev447]
all a: lab.T0 | a.av447 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av447 = (P0)
all a: lab.T2 | a.av447 = ((P1 + P3))
(R->P0 in ev447)
semantics4[av448, ev448]
all a: lab.T0 | a.av448 = ((P3 + P4))
all a: lab.T1 | a.av448 = (none)
all a: lab.T2 | a.av448 = ((P0 + (P1 + P2)))
(R->P0 in ev448)
semantics4[av449, ev449]
all a: lab.T0 | a.av449 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av449 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av449 = ((P1 + P4))
(R->P0 in ev449)
semantics3[av450, ev450]
all a: lab.T0 | a.av450 = ((P0 + P3))
all a: lab.T1 | a.av450 = (P3)
all a: lab.T2 | a.av450 = ((P0 + P2))
(R->P0 in ev450)
semantics8[av451, ev451]
all a: lab.T0 | a.av451 = (P0)
all a: lab.T1 | a.av451 = (none)
all a: lab.T2 | a.av451 = ((P0 + P2))
(R->P0 in ev451)
semantics3[av452, ev452]
all a: lab.T0 | a.av452 = (P2)
all a: lab.T1 | a.av452 = (none)
all a: lab.T2 | a.av452 = ((P0 + (P1 + P3)))
(R->P0 in ev452)
semantics4[av453, ev453]
all a: lab.T0 | a.av453 = (P0)
all a: lab.T1 | a.av453 = (none)
all a: lab.T2 | a.av453 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev453)
semantics0[av454, ev454]
all a: lab.T0 | a.av454 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av454 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av454 = ((P0 + (P3 + P4)))
(R->P0 in ev454)
semantics4[av455, ev455]
all a: lab.T0 | a.av455 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av455 = (none)
all a: lab.T2 | a.av455 = ((P0 + P3))
(R->P0 in ev455)
semantics5[av456, ev456]
all a: lab.T0 | a.av456 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av456 = (none)
all a: lab.T2 | a.av456 = ((P0 + (P1 + P3)))
(R->P0 in ev456)
semantics4[av457, ev457]
all a: lab.T0 | a.av457 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av457 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av457 = ((P1 + (P3 + P4)))
(R->P0 in ev457)
semantics14[av458, ev458]
all a: lab.T0 | a.av458 = (P0)
all a: lab.T1 | a.av458 = (none)
all a: lab.T2 | a.av458 = (P0)
(R->P0 in ev458)
semantics0[av459, ev459]
all a: lab.T0 | a.av459 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av459 = ((P1 + P3))
all a: lab.T2 | a.av459 = (P0)
(R->P0 in ev459)
semantics5[av460, ev460]
all a: lab.T0 | a.av460 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av460 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av460 = ((P0 + (P3 + P4)))
(R->P0 in ev460)
semantics0[av461, ev461]
all a: lab.T0 | a.av461 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av461 = ((P3 + P4))
all a: lab.T2 | a.av461 = ((P0 + (P1 + P2)))
(R->P0 in ev461)
semantics0[av462, ev462]
all a: lab.T0 | a.av462 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av462 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av462 = (P4)
(R->P0 in ev462)
semantics3[av463, ev463]
all a: lab.T0 | a.av463 = (P3)
all a: lab.T1 | a.av463 = (none)
all a: lab.T2 | a.av463 = (none)
(R->P0 in ev463)
semantics0[av464, ev464]
all a: lab.T0 | a.av464 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av464 = (none)
all a: lab.T2 | a.av464 = ((P1 + P2))
(R->P0 in ev464)
semantics5[av465, ev465]
all a: lab.T0 | a.av465 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av465 = (none)
all a: lab.T2 | a.av465 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev465)
semantics2[av466, ev466]
all a: lab.T0 | a.av466 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av466 = (none)
all a: lab.T2 | a.av466 = ((P1 + (P2 + P4)))
(R->P0 in ev466)
semantics2[av467, ev467]
all a: lab.T0 | a.av467 = ((P0 + P1))
all a: lab.T1 | a.av467 = (none)
all a: lab.T2 | a.av467 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev467)
semantics2[av468, ev468]
all a: lab.T0 | a.av468 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av468 = (none)
all a: lab.T2 | a.av468 = ((P0 + P3))
(R->P0 in ev468)
semantics2[av469, ev469]
all a: lab.T0 | a.av469 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av469 = ((P1 + P4))
all a: lab.T2 | a.av469 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev469)
semantics8[av470, ev470]
all a: lab.T0 | a.av470 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av470 = ((P1 + P3))
all a: lab.T2 | a.av470 = ((P1 + P2))
(R->P0 in ev470)
semantics2[av471, ev471]
all a: lab.T0 | a.av471 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av471 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av471 = ((P0 + P3))
(R->P0 in ev471)
semantics5[av472, ev472]
all a: lab.T0 | a.av472 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av472 = ((P0 + P2))
all a: lab.T2 | a.av472 = ((P1 + (P2 + P3)))
(R->P0 in ev472)
semantics0[av473, ev473]
all a: lab.T0 | a.av473 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av473 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av473 = ((P0 + (P1 + P2)))
(R->P0 in ev473)
semantics5[av474, ev474]
all a: lab.T0 | a.av474 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av474 = (P3)
all a: lab.T2 | a.av474 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev474)
semantics4[av475, ev475]
all a: lab.T0 | a.av475 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av475 = (none)
all a: lab.T2 | a.av475 = (P4)
(R->P0 in ev475)
semantics1[av476, ev476]
all a: lab.T0 | a.av476 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av476 = ((P0 + P1))
all a: lab.T2 | a.av476 = ((P2 + P3))
(R->P0 in ev476)
semantics4[av477, ev477]
all a: lab.T0 | a.av477 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av477 = (P2)
all a: lab.T2 | a.av477 = ((P0 + P2))
(R->P0 in ev477)
semantics1[av478, ev478]
all a: lab.T0 | a.av478 = ((P0 + P1))
all a: lab.T1 | a.av478 = (none)
all a: lab.T2 | a.av478 = (P4)
(R->P0 in ev478)
semantics8[av479, ev479]
all a: lab.T0 | a.av479 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av479 = (P3)
all a: lab.T2 | a.av479 = (P3)
(R->P0 in ev479)
semantics1[av480, ev480]
all a: lab.T0 | a.av480 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av480 = ((P2 + P3))
all a: lab.T2 | a.av480 = ((P0 + (P3 + P4)))
(R->P0 in ev480)
semantics1[av481, ev481]
all a: lab.T0 | a.av481 = ((P0 + P1))
all a: lab.T1 | a.av481 = (none)
all a: lab.T2 | a.av481 = ((P0 + (P2 + P4)))
(R->P0 in ev481)
semantics1[av482, ev482]
all a: lab.T0 | a.av482 = (P0)
all a: lab.T1 | a.av482 = (none)
all a: lab.T2 | a.av482 = ((P1 + P3))
(R->P0 in ev482)
semantics2[av483, ev483]
all a: lab.T0 | a.av483 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av483 = ((P0 + P2))
all a: lab.T2 | a.av483 = ((P0 + (P1 + P3)))
(R->P0 in ev483)
semantics1[av484, ev484]
all a: lab.T0 | a.av484 = ((P1 + P3))
all a: lab.T1 | a.av484 = (none)
all a: lab.T2 | a.av484 = (((P0 + P1) + (P2 + (P3 + P4))))
(R->P0 in ev484)
semantics6[av485, ev485]
all a: lab.T0 | a.av485 = (P1)
all a: lab.T1 | a.av485 = (none)
all a: lab.T2 | a.av485 = (P0)
(R->P0 in ev485)
semantics4[av486, ev486]
all a: lab.T0 | a.av486 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av486 = (none)
all a: lab.T2 | a.av486 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev486)
semantics2[av487, ev487]
all a: lab.T0 | a.av487 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av487 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av487 = ((P0 + (P1 + P3)))
not (R->P0 in ev487)
semantics5[av488, ev488]
all a: lab.T0 | a.av488 = ((P3 + P4))
all a: lab.T1 | a.av488 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av488 = ((P2 + (P3 + P4)))
not (R->P0 in ev488)
semantics0[av489, ev489]
all a: lab.T0 | a.av489 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av489 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av489 = ((P1 + P3))
not (R->P0 in ev489)
semantics0[av490, ev490]
all a: lab.T0 | a.av490 = (P2)
all a: lab.T1 | a.av490 = (P2)
all a: lab.T2 | a.av490 = ((P0 + (P1 + P2)))
not (R->P0 in ev490)
semantics4[av491, ev491]
all a: lab.T0 | a.av491 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av491 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av491 = ((P2 + P3))
not (R->P0 in ev491)
semantics6[av492, ev492]
all a: lab.T0 | a.av492 = ((P0 + P3))
all a: lab.T1 | a.av492 = ((P0 + P3))
all a: lab.T2 | a.av492 = (P3)
not (R->P0 in ev492)
semantics5[av493, ev493]
all a: lab.T0 | a.av493 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av493 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av493 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev493)
semantics5[av494, ev494]
all a: lab.T0 | a.av494 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av494 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av494 = ((P0 + P3))
not (R->P0 in ev494)
semantics2[av495, ev495]
all a: lab.T0 | a.av495 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av495 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av495 = ((P0 + (P1 + P2)))
not (R->P0 in ev495)
semantics10[av496, ev496]
all a: lab.T0 | a.av496 = ((P0 + P1))
all a: lab.T1 | a.av496 = ((P0 + P1))
all a: lab.T2 | a.av496 = (P1)
not (R->P0 in ev496)
semantics2[av497, ev497]
all a: lab.T0 | a.av497 = ((P1 + P2))
all a: lab.T1 | a.av497 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av497 = ((P1 + P4))
not (R->P0 in ev497)
semantics1[av498, ev498]
all a: lab.T0 | a.av498 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av498 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av498 = ((P1 + P2))
not (R->P0 in ev498)
semantics0[av499, ev499]
all a: lab.T0 | a.av499 = (P4)
all a: lab.T1 | a.av499 = ((P0 + P4))
all a: lab.T2 | a.av499 = ((P1 + (P3 + P4)))
not (R->P0 in ev499)
semantics2[av500, ev500]
all a: lab.T0 | a.av500 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av500 = ((P0 + P3))
all a: lab.T2 | a.av500 = ((P1 + (P3 + P4)))
not (R->P0 in ev500)
semantics5[av501, ev501]
all a: lab.T0 | a.av501 = (P4)
all a: lab.T1 | a.av501 = (P1)
all a: lab.T2 | a.av501 = (P0)
not (R->P0 in ev501)
semantics0[av502, ev502]
all a: lab.T0 | a.av502 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av502 = ((P1 + P4))
all a: lab.T2 | a.av502 = ((P2 + P3))
not (R->P0 in ev502)
semantics0[av503, ev503]
all a: lab.T0 | a.av503 = (none)
all a: lab.T1 | a.av503 = ((P1 + P3))
all a: lab.T2 | a.av503 = ((P0 + (P1 + P2)))
not (R->P0 in ev503)
semantics4[av504, ev504]
all a: lab.T0 | a.av504 = ((P0 + P4))
all a: lab.T1 | a.av504 = (P0)
all a: lab.T2 | a.av504 = ((P0 + (P1 + P4)))
not (R->P0 in ev504)
semantics1[av505, ev505]
all a: lab.T0 | a.av505 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av505 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av505 = ((P0 + P4))
not (R->P0 in ev505)
semantics4[av506, ev506]
all a: lab.T0 | a.av506 = (P0)
all a: lab.T1 | a.av506 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av506 = ((P0 + P2))
not (R->P0 in ev506)
semantics2[av507, ev507]
all a: lab.T0 | a.av507 = ((P0 + P2))
all a: lab.T1 | a.av507 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av507 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev507)
semantics4[av508, ev508]
all a: lab.T0 | a.av508 = ((P1 + P4))
all a: lab.T1 | a.av508 = (P3)
all a: lab.T2 | a.av508 = ((P0 + P3))
not (R->P0 in ev508)
semantics4[av509, ev509]
all a: lab.T0 | a.av509 = ((P3 + P4))
all a: lab.T1 | a.av509 = ((P1 + P2))
all a: lab.T2 | a.av509 = (P3)
not (R->P0 in ev509)
semantics0[av510, ev510]
all a: lab.T0 | a.av510 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av510 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av510 = ((P0 + (P1 + P3)))
not (R->P0 in ev510)
semantics4[av511, ev511]
all a: lab.T0 | a.av511 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av511 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av511 = ((P0 + (P1 + P3)))
not (R->P0 in ev511)
semantics4[av512, ev512]
all a: lab.T0 | a.av512 = ((P2 + P4))
all a: lab.T1 | a.av512 = (P1)
all a: lab.T2 | a.av512 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev512)
semantics1[av513, ev513]
all a: lab.T0 | a.av513 = ((P0 + P4))
all a: lab.T1 | a.av513 = (P1)
all a: lab.T2 | a.av513 = ((P0 + (P2 + P4)))
not (R->P0 in ev513)
semantics7[av514, ev514]
all a: lab.T0 | a.av514 = (P2)
all a: lab.T1 | a.av514 = (P1)
all a: lab.T2 | a.av514 = (P1)
not (R->P0 in ev514)
semantics1[av515, ev515]
all a: lab.T0 | a.av515 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av515 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av515 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev515)
semantics0[av516, ev516]
all a: lab.T0 | a.av516 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av516 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av516 = ((P1 + P3))
not (R->P0 in ev516)
semantics4[av517, ev517]
all a: lab.T0 | a.av517 = ((P1 + P4))
all a: lab.T1 | a.av517 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av517 = (P0)
not (R->P0 in ev517)
semantics2[av518, ev518]
all a: lab.T0 | a.av518 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av518 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av518 = ((P0 + (P1 + P2)))
not (R->P0 in ev518)
semantics5[av519, ev519]
all a: lab.T0 | a.av519 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av519 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av519 = ((P0 + P3))
not (R->P0 in ev519)
semantics4[av520, ev520]
all a: lab.T0 | a.av520 = (P3)
all a: lab.T1 | a.av520 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av520 = (P3)
not (R->P0 in ev520)
semantics1[av521, ev521]
all a: lab.T0 | a.av521 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av521 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av521 = ((P0 + P1))
not (R->P0 in ev521)
semantics10[av522, ev522]
all a: lab.T0 | a.av522 = (P1)
all a: lab.T1 | a.av522 = ((P1 + P2))
all a: lab.T2 | a.av522 = (P1)
not (R->P0 in ev522)
semantics2[av523, ev523]
all a: lab.T0 | a.av523 = (P2)
all a: lab.T1 | a.av523 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av523 = (none)
not (R->P0 in ev523)
semantics5[av524, ev524]
all a: lab.T0 | a.av524 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av524 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av524 = ((P0 + P3))
not (R->P0 in ev524)
semantics2[av525, ev525]
all a: lab.T0 | a.av525 = (P0)
all a: lab.T1 | a.av525 = (P2)
all a: lab.T2 | a.av525 = (P2)
not (R->P0 in ev525)
semantics7[av526, ev526]
all a: lab.T0 | a.av526 = ((P0 + P3))
all a: lab.T1 | a.av526 = ((P2 + P3))
all a: lab.T2 | a.av526 = (none)
not (R->P0 in ev526)
semantics4[av527, ev527]
all a: lab.T0 | a.av527 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av527 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av527 = (P3)
not (R->P0 in ev527)
semantics2[av528, ev528]
all a: lab.T0 | a.av528 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av528 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av528 = ((P0 + (P2 + P3)))
not (R->P0 in ev528)
semantics2[av529, ev529]
all a: lab.T0 | a.av529 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av529 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av529 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev529)
semantics5[av530, ev530]
all a: lab.T0 | a.av530 = ((P1 + P4))
all a: lab.T1 | a.av530 = (P3)
all a: lab.T2 | a.av530 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev530)
semantics2[av531, ev531]
all a: lab.T0 | a.av531 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av531 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av531 = ((P0 + (P1 + P3)))
not (R->P0 in ev531)
semantics0[av532, ev532]
all a: lab.T0 | a.av532 = ((P0 + P3))
all a: lab.T1 | a.av532 = ((P1 + P3))
all a: lab.T2 | a.av532 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev532)
semantics2[av533, ev533]
all a: lab.T0 | a.av533 = ((P1 + P2))
all a: lab.T1 | a.av533 = ((P2 + P3))
all a: lab.T2 | a.av533 = ((P0 + P2))
not (R->P0 in ev533)
semantics1[av534, ev534]
all a: lab.T0 | a.av534 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av534 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av534 = ((P0 + (P2 + P4)))
not (R->P0 in ev534)
semantics0[av535, ev535]
all a: lab.T0 | a.av535 = ((P2 + P3))
all a: lab.T1 | a.av535 = ((P0 + P1))
all a: lab.T2 | a.av535 = ((P1 + P3))
not (R->P0 in ev535)
semantics4[av536, ev536]
all a: lab.T0 | a.av536 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av536 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av536 = ((P0 + P1))
not (R->P0 in ev536)
semantics0[av537, ev537]
all a: lab.T0 | a.av537 = ((P1 + P4))
all a: lab.T1 | a.av537 = ((P1 + P2))
all a: lab.T2 | a.av537 = ((P0 + (P1 + P4)))
not (R->P0 in ev537)
semantics2[av538, ev538]
all a: lab.T0 | a.av538 = ((P2 + P4))
all a: lab.T1 | a.av538 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av538 = ((P1 + (P2 + P3)))
not (R->P0 in ev538)
semantics2[av539, ev539]
all a: lab.T0 | a.av539 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av539 = ((P2 + P3))
all a: lab.T2 | a.av539 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev539)
semantics5[av540, ev540]
all a: lab.T0 | a.av540 = ((P0 + P1))
all a: lab.T1 | a.av540 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av540 = ((P0 + (P1 + P3)))
not (R->P0 in ev540)
semantics4[av541, ev541]
all a: lab.T0 | a.av541 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av541 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av541 = (P0)
not (R->P0 in ev541)
semantics6[av542, ev542]
all a: lab.T0 | a.av542 = ((P1 + P2))
all a: lab.T1 | a.av542 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av542 = ((P0 + P1))
not (R->P0 in ev542)
semantics7[av543, ev543]
all a: lab.T0 | a.av543 = ((P0 + P1))
all a: lab.T1 | a.av543 = ((P2 + P3))
all a: lab.T2 | a.av543 = (P2)
not (R->P0 in ev543)
semantics3[av544, ev544]
all a: lab.T0 | a.av544 = (P1)
all a: lab.T1 | a.av544 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av544 = ((P1 + (P2 + P3)))
not (R->P0 in ev544)
semantics1[av545, ev545]
all a: lab.T0 | a.av545 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av545 = ((P0 + P2))
all a: lab.T2 | a.av545 = ((P2 + P4))
not (R->P0 in ev545)
semantics4[av546, ev546]
all a: lab.T0 | a.av546 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av546 = ((P0 + P2))
all a: lab.T2 | a.av546 = ((P0 + (P1 + P2)))
not (R->P0 in ev546)
semantics5[av547, ev547]
all a: lab.T0 | a.av547 = (P3)
all a: lab.T1 | a.av547 = ((P0 + P4))
all a: lab.T2 | a.av547 = (none)
not (R->P0 in ev547)
semantics1[av548, ev548]
all a: lab.T0 | a.av548 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av548 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av548 = ((P1 + P3))
not (R->P0 in ev548)
semantics4[av549, ev549]
all a: lab.T0 | a.av549 = ((P1 + P4))
all a: lab.T1 | a.av549 = ((P0 + P4))
all a: lab.T2 | a.av549 = ((P1 + (P2 + P3)))
not (R->P0 in ev549)
semantics0[av550, ev550]
all a: lab.T0 | a.av550 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av550 = ((P0 + P3))
all a: lab.T2 | a.av550 = ((P1 + P2))
not (R->P0 in ev550)
semantics2[av551, ev551]
all a: lab.T0 | a.av551 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av551 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av551 = ((P3 + P4))
not (R->P0 in ev551)
semantics1[av552, ev552]
all a: lab.T0 | a.av552 = ((P1 + P2))
all a: lab.T1 | a.av552 = ((P1 + P4))
all a: lab.T2 | a.av552 = ((P0 + (P3 + P4)))
not (R->P0 in ev552)
semantics8[av553, ev553]
all a: lab.T0 | a.av553 = ((P0 + P2))
all a: lab.T1 | a.av553 = ((P0 + P2))
all a: lab.T2 | a.av553 = (P3)
not (R->P0 in ev553)
semantics4[av554, ev554]
all a: lab.T0 | a.av554 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av554 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av554 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev554)
semantics4[av555, ev555]
all a: lab.T0 | a.av555 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av555 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av555 = ((P0 + (P1 + P4)))
not (R->P0 in ev555)
semantics0[av556, ev556]
all a: lab.T0 | a.av556 = ((P1 + P3))
all a: lab.T1 | a.av556 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av556 = ((P1 + (P3 + P4)))
not (R->P0 in ev556)
semantics1[av557, ev557]
all a: lab.T0 | a.av557 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av557 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av557 = ((P1 + P4))
not (R->P0 in ev557)
semantics5[av558, ev558]
all a: lab.T0 | a.av558 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av558 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av558 = ((P1 + P3))
not (R->P0 in ev558)
semantics0[av559, ev559]
all a: lab.T0 | a.av559 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av559 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av559 = ((P0 + P1))
not (R->P0 in ev559)
semantics6[av560, ev560]
all a: lab.T0 | a.av560 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av560 = ((P1 + P2))
all a: lab.T2 | a.av560 = (P0)
not (R->P0 in ev560)
semantics1[av561, ev561]
all a: lab.T0 | a.av561 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av561 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av561 = ((P0 + (P3 + P4)))
not (R->P0 in ev561)
semantics5[av562, ev562]
all a: lab.T0 | a.av562 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av562 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av562 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev562)
semantics4[av563, ev563]
all a: lab.T0 | a.av563 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av563 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av563 = (P3)
not (R->P0 in ev563)
semantics1[av564, ev564]
all a: lab.T0 | a.av564 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av564 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av564 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev564)
semantics1[av565, ev565]
all a: lab.T0 | a.av565 = ((P2 + P4))
all a: lab.T1 | a.av565 = ((P0 + P2))
all a: lab.T2 | a.av565 = ((P0 + (P2 + P4)))
not (R->P0 in ev565)
semantics4[av566, ev566]
all a: lab.T0 | a.av566 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av566 = ((P1 + P4))
all a: lab.T2 | a.av566 = ((P0 + P4))
not (R->P0 in ev566)
semantics2[av567, ev567]
all a: lab.T0 | a.av567 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av567 = ((P2 + P3))
all a: lab.T2 | a.av567 = ((P0 + P3))
not (R->P0 in ev567)
semantics0[av568, ev568]
all a: lab.T0 | a.av568 = (P2)
all a: lab.T1 | a.av568 = ((P2 + P4))
all a: lab.T2 | a.av568 = ((P0 + (P3 + P4)))
not (R->P0 in ev568)
semantics1[av569, ev569]
all a: lab.T0 | a.av569 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av569 = ((P3 + P4))
all a: lab.T2 | a.av569 = ((P1 + (P2 + P4)))
not (R->P0 in ev569)
semantics5[av570, ev570]
all a: lab.T0 | a.av570 = ((P1 + P2))
all a: lab.T1 | a.av570 = (P1)
all a: lab.T2 | a.av570 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev570)
semantics1[av571, ev571]
all a: lab.T0 | a.av571 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av571 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av571 = ((P1 + P4))
not (R->P0 in ev571)
semantics4[av572, ev572]
all a: lab.T0 | a.av572 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av572 = ((P2 + P4))
all a: lab.T2 | a.av572 = ((P0 + P2))
not (R->P0 in ev572)
semantics4[av573, ev573]
all a: lab.T0 | a.av573 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av573 = (P0)
all a: lab.T2 | a.av573 = ((P0 + (P3 + P4)))
not (R->P0 in ev573)
semantics4[av574, ev574]
all a: lab.T0 | a.av574 = (P3)
all a: lab.T1 | a.av574 = ((P0 + P3))
all a: lab.T2 | a.av574 = ((P1 + (P2 + P3)))
not (R->P0 in ev574)
semantics1[av575, ev575]
all a: lab.T0 | a.av575 = ((P1 + P4))
all a: lab.T1 | a.av575 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av575 = ((P3 + P4))
not (R->P0 in ev575)
semantics9[av576, ev576]
all a: lab.T0 | a.av576 = (P2)
all a: lab.T1 | a.av576 = ((P0 + P1))
all a: lab.T2 | a.av576 = (P1)
not (R->P0 in ev576)
semantics7[av577, ev577]
all a: lab.T0 | a.av577 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av577 = (P3)
all a: lab.T2 | a.av577 = ((P0 + (P2 + P3)))
not (R->P0 in ev577)
semantics4[av578, ev578]
all a: lab.T0 | a.av578 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av578 = ((P2 + P3))
all a: lab.T2 | a.av578 = ((P0 + (P3 + P4)))
not (R->P0 in ev578)
semantics4[av579, ev579]
all a: lab.T0 | a.av579 = (P4)
all a: lab.T1 | a.av579 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av579 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev579)
semantics0[av580, ev580]
all a: lab.T0 | a.av580 = ((P0 + P3))
all a: lab.T1 | a.av580 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av580 = ((P0 + (P2 + P4)))
not (R->P0 in ev580)
semantics3[av581, ev581]
all a: lab.T0 | a.av581 = ((P0 + P1))
all a: lab.T1 | a.av581 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av581 = ((P0 + (P1 + P2)))
not (R->P0 in ev581)
semantics4[av582, ev582]
all a: lab.T0 | a.av582 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av582 = (P3)
all a: lab.T2 | a.av582 = ((P1 + (P2 + P3)))
not (R->P0 in ev582)
semantics4[av583, ev583]
all a: lab.T0 | a.av583 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av583 = (P3)
all a: lab.T2 | a.av583 = ((P1 + P3))
not (R->P0 in ev583)
semantics1[av584, ev584]
all a: lab.T0 | a.av584 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av584 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av584 = ((P1 + P4))
not (R->P0 in ev584)
semantics0[av585, ev585]
all a: lab.T0 | a.av585 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av585 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av585 = (P4)
not (R->P0 in ev585)
semantics4[av586, ev586]
all a: lab.T0 | a.av586 = ((P3 + P4))
all a: lab.T1 | a.av586 = ((P1 + P3))
all a: lab.T2 | a.av586 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev586)
semantics1[av587, ev587]
all a: lab.T0 | a.av587 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av587 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av587 = ((P0 + (P2 + P3)))
not (R->P0 in ev587)
semantics6[av588, ev588]
all a: lab.T0 | a.av588 = (none)
all a: lab.T1 | a.av588 = (P2)
all a: lab.T2 | a.av588 = ((P0 + (P1 + P2)))
not (R->P0 in ev588)
semantics0[av589, ev589]
all a: lab.T0 | a.av589 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av589 = (P4)
all a: lab.T2 | a.av589 = (P1)
not (R->P0 in ev589)
semantics3[av590, ev590]
all a: lab.T0 | a.av590 = (P2)
all a: lab.T1 | a.av590 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av590 = ((P1 + (P2 + P3)))
not (R->P0 in ev590)
semantics0[av591, ev591]
all a: lab.T0 | a.av591 = (P2)
all a: lab.T1 | a.av591 = ((P2 + P3))
all a: lab.T2 | a.av591 = ((P0 + P4))
not (R->P0 in ev591)
semantics1[av592, ev592]
all a: lab.T0 | a.av592 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av592 = (P0)
all a: lab.T2 | a.av592 = ((P2 + P3))
not (R->P0 in ev592)
semantics5[av593, ev593]
all a: lab.T0 | a.av593 = ((P1 + P4))
all a: lab.T1 | a.av593 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av593 = (P2)
not (R->P0 in ev593)
semantics1[av594, ev594]
all a: lab.T0 | a.av594 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av594 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av594 = (P4)
not (R->P0 in ev594)
semantics4[av595, ev595]
all a: lab.T0 | a.av595 = ((P0 + P2))
all a: lab.T1 | a.av595 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av595 = ((P1 + (P2 + P4)))
not (R->P0 in ev595)
semantics2[av596, ev596]
all a: lab.T0 | a.av596 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av596 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av596 = ((P0 + P4))
not (R->P0 in ev596)
semantics1[av597, ev597]
all a: lab.T0 | a.av597 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av597 = ((P1 + P4))
all a: lab.T2 | a.av597 = ((P2 + P3))
not (R->P0 in ev597)
semantics0[av598, ev598]
all a: lab.T0 | a.av598 = (none)
all a: lab.T1 | a.av598 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av598 = ((P2 + (P3 + P4)))
not (R->P0 in ev598)
semantics5[av599, ev599]
all a: lab.T0 | a.av599 = ((P3 + P4))
all a: lab.T1 | a.av599 = (P1)
all a: lab.T2 | a.av599 = ((P2 + P3))
not (R->P0 in ev599)
semantics4[av600, ev600]
all a: lab.T0 | a.av600 = (P2)
all a: lab.T1 | a.av600 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av600 = ((P3 + P4))
not (R->P0 in ev600)
semantics2[av601, ev601]
all a: lab.T0 | a.av601 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av601 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av601 = ((P2 + P4))
not (R->P0 in ev601)
semantics4[av602, ev602]
all a: lab.T0 | a.av602 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av602 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av602 = ((P0 + P3))
not (R->P0 in ev602)
semantics1[av603, ev603]
all a: lab.T0 | a.av603 = (P1)
all a: lab.T1 | a.av603 = ((P0 + P4))
all a: lab.T2 | a.av603 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev603)
semantics4[av604, ev604]
all a: lab.T0 | a.av604 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av604 = ((P1 + P4))
all a: lab.T2 | a.av604 = (none)
not (R->P0 in ev604)
semantics6[av605, ev605]
all a: lab.T0 | a.av605 = (none)
all a: lab.T1 | a.av605 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av605 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev605)
semantics4[av606, ev606]
all a: lab.T0 | a.av606 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av606 = (P0)
all a: lab.T2 | a.av606 = ((P1 + P4))
not (R->P0 in ev606)
semantics2[av607, ev607]
all a: lab.T0 | a.av607 = ((P0 + P2))
all a: lab.T1 | a.av607 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av607 = ((P0 + (P3 + P4)))
not (R->P0 in ev607)
semantics1[av608, ev608]
all a: lab.T0 | a.av608 = (P1)
all a: lab.T1 | a.av608 = (P3)
all a: lab.T2 | a.av608 = ((P3 + P4))
not (R->P0 in ev608)
semantics0[av609, ev609]
all a: lab.T0 | a.av609 = ((P2 + P4))
all a: lab.T1 | a.av609 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av609 = ((P0 + P2))
not (R->P0 in ev609)
semantics7[av610, ev610]
all a: lab.T0 | a.av610 = ((P0 + P1))
all a: lab.T1 | a.av610 = (P2)
all a: lab.T2 | a.av610 = ((P1 + P2))
not (R->P0 in ev610)
semantics0[av611, ev611]
all a: lab.T0 | a.av611 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av611 = ((P0 + P4))
all a: lab.T2 | a.av611 = (P2)
not (R->P0 in ev611)
semantics4[av612, ev612]
all a: lab.T0 | a.av612 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av612 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av612 = ((P0 + (P1 + P2)))
not (R->P0 in ev612)
semantics4[av613, ev613]
all a: lab.T0 | a.av613 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av613 = ((P1 + P2))
all a: lab.T2 | a.av613 = (none)
not (R->P0 in ev613)
semantics5[av614, ev614]
all a: lab.T0 | a.av614 = (P3)
all a: lab.T1 | a.av614 = (P4)
all a: lab.T2 | a.av614 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev614)
semantics4[av615, ev615]
all a: lab.T0 | a.av615 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av615 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av615 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev615)
semantics0[av616, ev616]
all a: lab.T0 | a.av616 = (P1)
all a: lab.T1 | a.av616 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av616 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev616)
semantics5[av617, ev617]
all a: lab.T0 | a.av617 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av617 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av617 = ((P1 + P3))
not (R->P0 in ev617)
semantics1[av618, ev618]
all a: lab.T0 | a.av618 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av618 = (P1)
all a: lab.T2 | a.av618 = (P0)
not (R->P0 in ev618)
semantics4[av619, ev619]
all a: lab.T0 | a.av619 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av619 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av619 = ((P2 + (P3 + P4)))
not (R->P0 in ev619)
semantics5[av620, ev620]
all a: lab.T0 | a.av620 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av620 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av620 = ((P3 + P4))
not (R->P0 in ev620)
semantics5[av621, ev621]
all a: lab.T0 | a.av621 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av621 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av621 = ((P0 + P3))
not (R->P0 in ev621)
semantics1[av622, ev622]
all a: lab.T0 | a.av622 = ((P2 + P4))
all a: lab.T1 | a.av622 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av622 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev622)
semantics2[av623, ev623]
all a: lab.T0 | a.av623 = (P0)
all a: lab.T1 | a.av623 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av623 = ((P0 + (P2 + P4)))
not (R->P0 in ev623)
semantics0[av624, ev624]
all a: lab.T0 | a.av624 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av624 = ((P0 + P1))
all a: lab.T2 | a.av624 = ((P0 + (P3 + P4)))
not (R->P0 in ev624)
semantics4[av625, ev625]
all a: lab.T0 | a.av625 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av625 = ((P3 + P4))
all a: lab.T2 | a.av625 = ((P1 + (P2 + P3)))
not (R->P0 in ev625)
semantics0[av626, ev626]
all a: lab.T0 | a.av626 = ((P2 + P4))
all a: lab.T1 | a.av626 = ((P2 + P3))
all a: lab.T2 | a.av626 = ((P0 + (P1 + P4)))
not (R->P0 in ev626)
semantics5[av627, ev627]
all a: lab.T0 | a.av627 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av627 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av627 = ((P2 + P4))
not (R->P0 in ev627)
semantics2[av628, ev628]
all a: lab.T0 | a.av628 = ((P1 + P4))
all a: lab.T1 | a.av628 = ((P3 + P4))
all a: lab.T2 | a.av628 = ((P0 + P2))
not (R->P0 in ev628)
semantics1[av629, ev629]
all a: lab.T0 | a.av629 = ((P1 + P4))
all a: lab.T1 | a.av629 = (P0)
all a: lab.T2 | a.av629 = ((P0 + P4))
not (R->P0 in ev629)
semantics2[av630, ev630]
all a: lab.T0 | a.av630 = ((P1 + P3))
all a: lab.T1 | a.av630 = ((P3 + P4))
all a: lab.T2 | a.av630 = ((P2 + (P3 + P4)))
not (R->P0 in ev630)
semantics2[av631, ev631]
all a: lab.T0 | a.av631 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av631 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av631 = ((P1 + P2))
not (R->P0 in ev631)
semantics5[av632, ev632]
all a: lab.T0 | a.av632 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av632 = (P2)
all a: lab.T2 | a.av632 = ((P0 + (P2 + P3)))
not (R->P0 in ev632)
semantics5[av633, ev633]
all a: lab.T0 | a.av633 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av633 = (P0)
all a: lab.T2 | a.av633 = (P1)
not (R->P0 in ev633)
semantics4[av634, ev634]
all a: lab.T0 | a.av634 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av634 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av634 = ((P0 + P4))
not (R->P0 in ev634)
semantics5[av635, ev635]
all a: lab.T0 | a.av635 = ((P0 + P1))
all a: lab.T1 | a.av635 = ((P1 + P3))
all a: lab.T2 | a.av635 = (P2)
not (R->P0 in ev635)
semantics2[av636, ev636]
all a: lab.T0 | a.av636 = (P4)
all a: lab.T1 | a.av636 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av636 = ((P0 + (P2 + P4)))
not (R->P0 in ev636)
semantics4[av637, ev637]
all a: lab.T0 | a.av637 = ((P3 + P4))
all a: lab.T1 | a.av637 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av637 = ((P0 + (P2 + P3)))
not (R->P0 in ev637)
semantics2[av638, ev638]
all a: lab.T0 | a.av638 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av638 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av638 = ((P3 + P4))
not (R->P0 in ev638)
semantics4[av639, ev639]
all a: lab.T0 | a.av639 = (P2)
all a: lab.T1 | a.av639 = ((P0 + P4))
all a: lab.T2 | a.av639 = ((P0 + (P1 + P4)))
not (R->P0 in ev639)
semantics1[av640, ev640]
all a: lab.T0 | a.av640 = ((P1 + P3))
all a: lab.T1 | a.av640 = (P4)
all a: lab.T2 | a.av640 = ((P2 + P4))
not (R->P0 in ev640)
semantics0[av641, ev641]
all a: lab.T0 | a.av641 = ((P0 + P3))
all a: lab.T1 | a.av641 = ((P2 + P4))
all a: lab.T2 | a.av641 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev641)
semantics1[av642, ev642]
all a: lab.T0 | a.av642 = ((P2 + P4))
all a: lab.T1 | a.av642 = ((P2 + P3))
all a: lab.T2 | a.av642 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev642)
semantics5[av643, ev643]
all a: lab.T0 | a.av643 = (none)
all a: lab.T1 | a.av643 = ((P0 + P2))
all a: lab.T2 | a.av643 = ((P0 + (P1 + P4)))
not (R->P0 in ev643)
semantics1[av644, ev644]
all a: lab.T0 | a.av644 = ((P1 + P2))
all a: lab.T1 | a.av644 = ((P1 + P3))
all a: lab.T2 | a.av644 = ((P1 + P3))
not (R->P0 in ev644)
semantics3[av645, ev645]
all a: lab.T0 | a.av645 = ((P0 + P1))
all a: lab.T1 | a.av645 = (P3)
all a: lab.T2 | a.av645 = (P2)
not (R->P0 in ev645)
semantics0[av646, ev646]
all a: lab.T0 | a.av646 = ((P1 + P3))
all a: lab.T1 | a.av646 = (P1)
all a: lab.T2 | a.av646 = (P1)
not (R->P0 in ev646)
semantics2[av647, ev647]
all a: lab.T0 | a.av647 = ((P1 + P2))
all a: lab.T1 | a.av647 = ((P1 + P2))
all a: lab.T2 | a.av647 = ((P3 + P4))
not (R->P0 in ev647)
semantics2[av648, ev648]
all a: lab.T0 | a.av648 = ((P0 + P1))
all a: lab.T1 | a.av648 = ((P0 + P4))
all a: lab.T2 | a.av648 = ((P1 + P2))
not (R->P0 in ev648)
semantics0[av649, ev649]
all a: lab.T0 | a.av649 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av649 = ((P0 + P2))
all a: lab.T2 | a.av649 = (P4)
not (R->P0 in ev649)
semantics2[av650, ev650]
all a: lab.T0 | a.av650 = ((P0 + P2))
all a: lab.T1 | a.av650 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av650 = (none)
not (R->P0 in ev650)
semantics5[av651, ev651]
all a: lab.T0 | a.av651 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av651 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av651 = (P4)
not (R->P0 in ev651)
semantics2[av652, ev652]
all a: lab.T0 | a.av652 = ((P1 + P3))
all a: lab.T1 | a.av652 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av652 = ((P1 + (P2 + P4)))
not (R->P0 in ev652)
semantics5[av653, ev653]
all a: lab.T0 | a.av653 = ((P0 + P2))
all a: lab.T1 | a.av653 = ((P0 + P3))
all a: lab.T2 | a.av653 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev653)
semantics2[av654, ev654]
all a: lab.T0 | a.av654 = (P0)
all a: lab.T1 | a.av654 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av654 = (none)
not (R->P0 in ev654)
semantics5[av655, ev655]
all a: lab.T0 | a.av655 = ((P2 + P3))
all a: lab.T1 | a.av655 = (P3)
all a: lab.T2 | a.av655 = ((P0 + (P1 + P4)))
not (R->P0 in ev655)
semantics2[av656, ev656]
all a: lab.T0 | a.av656 = (P3)
all a: lab.T1 | a.av656 = ((P2 + P3))
all a: lab.T2 | a.av656 = ((P0 + P3))
not (R->P0 in ev656)
semantics5[av657, ev657]
all a: lab.T0 | a.av657 = ((P2 + P4))
all a: lab.T1 | a.av657 = ((P0 + P1))
all a: lab.T2 | a.av657 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev657)
semantics6[av658, ev658]
all a: lab.T0 | a.av658 = (P0)
all a: lab.T1 | a.av658 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av658 = ((P1 + P3))
not (R->P0 in ev658)
semantics7[av659, ev659]
all a: lab.T0 | a.av659 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av659 = ((P0 + P3))
all a: lab.T2 | a.av659 = ((P1 + P2))
not (R->P0 in ev659)
semantics2[av660, ev660]
all a: lab.T0 | a.av660 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av660 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av660 = (P3)
not (R->P0 in ev660)
semantics4[av661, ev661]
all a: lab.T0 | a.av661 = ((P2 + P4))
all a: lab.T1 | a.av661 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av661 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev661)
semantics4[av662, ev662]
all a: lab.T0 | a.av662 = (P2)
all a: lab.T1 | a.av662 = ((P2 + P4))
all a: lab.T2 | a.av662 = ((P0 + P1))
not (R->P0 in ev662)
semantics0[av663, ev663]
all a: lab.T0 | a.av663 = ((P1 + P4))
all a: lab.T1 | a.av663 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av663 = ((P0 + P4))
not (R->P0 in ev663)
semantics0[av664, ev664]
all a: lab.T0 | a.av664 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av664 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av664 = ((P0 + (P2 + P4)))
not (R->P0 in ev664)
semantics4[av665, ev665]
all a: lab.T0 | a.av665 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av665 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av665 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev665)
semantics2[av666, ev666]
all a: lab.T0 | a.av666 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av666 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av666 = ((P1 + (P2 + P4)))
not (R->P0 in ev666)
semantics0[av667, ev667]
all a: lab.T0 | a.av667 = ((P1 + P3))
all a: lab.T1 | a.av667 = (P0)
all a: lab.T2 | a.av667 = ((P0 + (P1 + P2)))
not (R->P0 in ev667)
semantics0[av668, ev668]
all a: lab.T0 | a.av668 = ((P0 + P2))
all a: lab.T1 | a.av668 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av668 = ((P0 + P2))
not (R->P0 in ev668)
semantics0[av669, ev669]
all a: lab.T0 | a.av669 = ((P3 + P4))
all a: lab.T1 | a.av669 = ((P3 + P4))
all a: lab.T2 | a.av669 = (P4)
not (R->P0 in ev669)
semantics1[av670, ev670]
all a: lab.T0 | a.av670 = (P3)
all a: lab.T1 | a.av670 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av670 = ((P0 + (P2 + P4)))
not (R->P0 in ev670)
semantics5[av671, ev671]
all a: lab.T0 | a.av671 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av671 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av671 = ((P0 + (P1 + P2)))
not (R->P0 in ev671)
semantics4[av672, ev672]
all a: lab.T0 | a.av672 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av672 = ((P3 + P4))
all a: lab.T2 | a.av672 = ((P1 + P3))
not (R->P0 in ev672)
semantics1[av673, ev673]
all a: lab.T0 | a.av673 = ((P1 + P3))
all a: lab.T1 | a.av673 = ((P0 + P4))
all a: lab.T2 | a.av673 = ((P0 + (P3 + P4)))
not (R->P0 in ev673)
semantics5[av674, ev674]
all a: lab.T0 | a.av674 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av674 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av674 = ((P0 + P3))
not (R->P0 in ev674)
semantics0[av675, ev675]
all a: lab.T0 | a.av675 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av675 = ((P0 + P2))
all a: lab.T2 | a.av675 = (P4)
not (R->P0 in ev675)
semantics0[av676, ev676]
all a: lab.T0 | a.av676 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av676 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av676 = ((P2 + P3))
not (R->P0 in ev676)
semantics13[av677, ev677]
all a: lab.T0 | a.av677 = (none)
all a: lab.T1 | a.av677 = (P1)
all a: lab.T2 | a.av677 = (P0)
not (R->P0 in ev677)
semantics2[av678, ev678]
all a: lab.T0 | a.av678 = ((P3 + P4))
all a: lab.T1 | a.av678 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av678 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev678)
semantics1[av679, ev679]
all a: lab.T0 | a.av679 = (P0)
all a: lab.T1 | a.av679 = (P4)
all a: lab.T2 | a.av679 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev679)
semantics2[av680, ev680]
all a: lab.T0 | a.av680 = ((P1 + P3))
all a: lab.T1 | a.av680 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av680 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev680)
semantics2[av681, ev681]
all a: lab.T0 | a.av681 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av681 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av681 = ((P1 + P3))
not (R->P0 in ev681)
semantics1[av682, ev682]
all a: lab.T0 | a.av682 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av682 = ((P3 + P4))
all a: lab.T2 | a.av682 = (P2)
not (R->P0 in ev682)
semantics1[av683, ev683]
all a: lab.T0 | a.av683 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av683 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av683 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev683)
semantics1[av684, ev684]
all a: lab.T0 | a.av684 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av684 = ((P2 + P3))
all a: lab.T2 | a.av684 = (none)
not (R->P0 in ev684)
semantics1[av685, ev685]
all a: lab.T0 | a.av685 = ((P1 + P3))
all a: lab.T1 | a.av685 = (P4)
all a: lab.T2 | a.av685 = (P3)
not (R->P0 in ev685)
semantics7[av686, ev686]
all a: lab.T0 | a.av686 = ((P1 + P3))
all a: lab.T1 | a.av686 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av686 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev686)
semantics1[av687, ev687]
all a: lab.T0 | a.av687 = ((P1 + P4))
all a: lab.T1 | a.av687 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av687 = ((P1 + (P2 + P3)))
not (R->P0 in ev687)
semantics5[av688, ev688]
all a: lab.T0 | a.av688 = ((P0 + P1))
all a: lab.T1 | a.av688 = ((P1 + P2))
all a: lab.T2 | a.av688 = ((P2 + P4))
not (R->P0 in ev688)
semantics4[av689, ev689]
all a: lab.T0 | a.av689 = ((P3 + P4))
all a: lab.T1 | a.av689 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av689 = ((P0 + (P1 + P2)))
not (R->P0 in ev689)
semantics4[av690, ev690]
all a: lab.T0 | a.av690 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av690 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av690 = (none)
not (R->P0 in ev690)
semantics0[av691, ev691]
all a: lab.T0 | a.av691 = ((P1 + P3))
all a: lab.T1 | a.av691 = ((P1 + P4))
all a: lab.T2 | a.av691 = ((P2 + (P3 + P4)))
not (R->P0 in ev691)
semantics2[av692, ev692]
all a: lab.T0 | a.av692 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av692 = ((P0 + P1))
all a: lab.T2 | a.av692 = (P1)
not (R->P0 in ev692)
semantics4[av693, ev693]
all a: lab.T0 | a.av693 = ((P0 + P1))
all a: lab.T1 | a.av693 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av693 = ((P0 + P2))
not (R->P0 in ev693)
semantics2[av694, ev694]
all a: lab.T0 | a.av694 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av694 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av694 = (P1)
not (R->P0 in ev694)
semantics0[av695, ev695]
all a: lab.T0 | a.av695 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av695 = ((P1 + P3))
all a: lab.T2 | a.av695 = ((P1 + (P3 + P4)))
not (R->P0 in ev695)
semantics4[av696, ev696]
all a: lab.T0 | a.av696 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av696 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av696 = ((P2 + P3))
not (R->P0 in ev696)
semantics2[av697, ev697]
all a: lab.T0 | a.av697 = ((P2 + P3))
all a: lab.T1 | a.av697 = (P3)
all a: lab.T2 | a.av697 = ((P0 + (P2 + P3)))
not (R->P0 in ev697)
semantics1[av698, ev698]
all a: lab.T0 | a.av698 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av698 = ((P2 + P4))
all a: lab.T2 | a.av698 = (P2)
not (R->P0 in ev698)
semantics8[av699, ev699]
all a: lab.T0 | a.av699 = (P0)
all a: lab.T1 | a.av699 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av699 = ((P1 + P3))
not (R->P0 in ev699)
semantics0[av700, ev700]
all a: lab.T0 | a.av700 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av700 = ((P0 + P4))
all a: lab.T2 | a.av700 = ((P3 + P4))
not (R->P0 in ev700)
semantics4[av701, ev701]
all a: lab.T0 | a.av701 = ((P0 + P4))
all a: lab.T1 | a.av701 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av701 = ((P3 + P4))
not (R->P0 in ev701)
semantics0[av702, ev702]
all a: lab.T0 | a.av702 = ((P2 + P3))
all a: lab.T1 | a.av702 = (P1)
all a: lab.T2 | a.av702 = ((P1 + (P3 + P4)))
not (R->P0 in ev702)
semantics0[av703, ev703]
all a: lab.T0 | a.av703 = ((P2 + P3))
all a: lab.T1 | a.av703 = ((P1 + P3))
all a: lab.T2 | a.av703 = ((P1 + P2))
not (R->P0 in ev703)
semantics1[av704, ev704]
all a: lab.T0 | a.av704 = (P1)
all a: lab.T1 | a.av704 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av704 = ((P1 + P4))
not (R->P0 in ev704)
semantics2[av705, ev705]
all a: lab.T0 | a.av705 = ((P2 + P4))
all a: lab.T1 | a.av705 = ((P0 + P3))
all a: lab.T2 | a.av705 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev705)
semantics0[av706, ev706]
all a: lab.T0 | a.av706 = ((P1 + P2))
all a: lab.T1 | a.av706 = (P3)
all a: lab.T2 | a.av706 = ((P0 + P4))
not (R->P0 in ev706)
semantics4[av707, ev707]
all a: lab.T0 | a.av707 = ((P0 + P3))
all a: lab.T1 | a.av707 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av707 = ((P1 + P4))
not (R->P0 in ev707)
semantics0[av708, ev708]
all a: lab.T0 | a.av708 = ((P0 + P4))
all a: lab.T1 | a.av708 = ((P0 + P3))
all a: lab.T2 | a.av708 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev708)
semantics5[av709, ev709]
all a: lab.T0 | a.av709 = ((P2 + P4))
all a: lab.T1 | a.av709 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av709 = ((P2 + P3))
not (R->P0 in ev709)
semantics0[av710, ev710]
all a: lab.T0 | a.av710 = ((P2 + P3))
all a: lab.T1 | a.av710 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av710 = (P1)
not (R->P0 in ev710)
semantics2[av711, ev711]
all a: lab.T0 | a.av711 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av711 = (P4)
all a: lab.T2 | a.av711 = ((P1 + (P3 + P4)))
not (R->P0 in ev711)
semantics2[av712, ev712]
all a: lab.T0 | a.av712 = ((P2 + P4))
all a: lab.T1 | a.av712 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av712 = (P3)
not (R->P0 in ev712)
semantics2[av713, ev713]
all a: lab.T0 | a.av713 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av713 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av713 = ((P0 + P4))
not (R->P0 in ev713)
semantics5[av714, ev714]
all a: lab.T0 | a.av714 = ((P2 + P3))
all a: lab.T1 | a.av714 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av714 = (P3)
not (R->P0 in ev714)
semantics4[av715, ev715]
all a: lab.T0 | a.av715 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av715 = ((P2 + P3))
all a: lab.T2 | a.av715 = ((P0 + P3))
not (R->P0 in ev715)
semantics2[av716, ev716]
all a: lab.T0 | a.av716 = (P4)
all a: lab.T1 | a.av716 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av716 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev716)
semantics4[av717, ev717]
all a: lab.T0 | a.av717 = ((P0 + P4))
all a: lab.T1 | a.av717 = (P1)
all a: lab.T2 | a.av717 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev717)
semantics5[av718, ev718]
all a: lab.T0 | a.av718 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av718 = (P1)
all a: lab.T2 | a.av718 = ((P1 + P4))
not (R->P0 in ev718)
semantics4[av719, ev719]
all a: lab.T0 | a.av719 = (P0)
all a: lab.T1 | a.av719 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av719 = ((P1 + P4))
not (R->P0 in ev719)
semantics5[av720, ev720]
all a: lab.T0 | a.av720 = (none)
all a: lab.T1 | a.av720 = ((P0 + P4))
all a: lab.T2 | a.av720 = (P1)
not (R->P0 in ev720)
semantics4[av721, ev721]
all a: lab.T0 | a.av721 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av721 = ((P1 + P3))
all a: lab.T2 | a.av721 = ((P2 + P3))
not (R->P0 in ev721)
semantics8[av722, ev722]
all a: lab.T0 | a.av722 = (P2)
all a: lab.T1 | a.av722 = (P1)
all a: lab.T2 | a.av722 = ((P1 + (P2 + P3)))
not (R->P0 in ev722)
semantics2[av723, ev723]
all a: lab.T0 | a.av723 = ((P0 + P4))
all a: lab.T1 | a.av723 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av723 = (P1)
not (R->P0 in ev723)
semantics2[av724, ev724]
all a: lab.T0 | a.av724 = (P1)
all a: lab.T1 | a.av724 = (P2)
all a: lab.T2 | a.av724 = (P0)
not (R->P0 in ev724)
semantics4[av725, ev725]
all a: lab.T0 | a.av725 = ((P2 + P4))
all a: lab.T1 | a.av725 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av725 = ((P0 + (P1 + P2)))
not (R->P0 in ev725)
semantics1[av726, ev726]
all a: lab.T0 | a.av726 = ((P0 + P4))
all a: lab.T1 | a.av726 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av726 = (none)
not (R->P0 in ev726)
semantics5[av727, ev727]
all a: lab.T0 | a.av727 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av727 = (P1)
all a: lab.T2 | a.av727 = ((P0 + (P1 + P4)))
not (R->P0 in ev727)
semantics1[av728, ev728]
all a: lab.T0 | a.av728 = ((P0 + P1))
all a: lab.T1 | a.av728 = ((P0 + P1))
all a: lab.T2 | a.av728 = ((P0 + P4))
not (R->P0 in ev728)
semantics2[av729, ev729]
all a: lab.T0 | a.av729 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av729 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av729 = (none)
not (R->P0 in ev729)
semantics4[av730, ev730]
all a: lab.T0 | a.av730 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av730 = ((P0 + P3))
all a: lab.T2 | a.av730 = ((P0 + (P1 + P2)))
not (R->P0 in ev730)
semantics1[av731, ev731]
all a: lab.T0 | a.av731 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av731 = ((P0 + P3))
all a: lab.T2 | a.av731 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev731)
semantics1[av732, ev732]
all a: lab.T0 | a.av732 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av732 = ((P0 + P2))
all a: lab.T2 | a.av732 = ((P1 + P4))
not (R->P0 in ev732)
semantics4[av733, ev733]
all a: lab.T0 | a.av733 = ((P1 + P2))
all a: lab.T1 | a.av733 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av733 = ((P2 + P3))
not (R->P0 in ev733)
semantics1[av734, ev734]
all a: lab.T0 | a.av734 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av734 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av734 = ((P0 + (P2 + P3)))
not (R->P0 in ev734)
semantics10[av735, ev735]
all a: lab.T0 | a.av735 = ((P0 + P1))
all a: lab.T1 | a.av735 = (P1)
all a: lab.T2 | a.av735 = (P2)
not (R->P0 in ev735)
semantics5[av736, ev736]
all a: lab.T0 | a.av736 = ((P1 + P2))
all a: lab.T1 | a.av736 = (P3)
all a: lab.T2 | a.av736 = ((P0 + P3))
not (R->P0 in ev736)
semantics2[av737, ev737]
all a: lab.T0 | a.av737 = (P2)
all a: lab.T1 | a.av737 = (P4)
all a: lab.T2 | a.av737 = ((P0 + (P1 + P4)))
not (R->P0 in ev737)
semantics1[av738, ev738]
all a: lab.T0 | a.av738 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av738 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av738 = ((P2 + (P3 + P4)))
not (R->P0 in ev738)
semantics4[av739, ev739]
all a: lab.T0 | a.av739 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av739 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av739 = ((P0 + (P1 + P4)))
not (R->P0 in ev739)
semantics2[av740, ev740]
all a: lab.T0 | a.av740 = (none)
all a: lab.T1 | a.av740 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av740 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev740)
semantics4[av741, ev741]
all a: lab.T0 | a.av741 = ((P3 + P4))
all a: lab.T1 | a.av741 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av741 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev741)
semantics2[av742, ev742]
all a: lab.T0 | a.av742 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av742 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av742 = ((P0 + P1))
not (R->P0 in ev742)
semantics7[av743, ev743]
all a: lab.T0 | a.av743 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av743 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av743 = ((P0 + P3))
not (R->P0 in ev743)
semantics4[av744, ev744]
all a: lab.T0 | a.av744 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av744 = (P4)
all a: lab.T2 | a.av744 = (P4)
not (R->P0 in ev744)
semantics1[av745, ev745]
all a: lab.T0 | a.av745 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av745 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av745 = (P0)
not (R->P0 in ev745)
semantics5[av746, ev746]
all a: lab.T0 | a.av746 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av746 = (P3)
all a: lab.T2 | a.av746 = ((P0 + (P2 + P3)))
not (R->P0 in ev746)
semantics2[av747, ev747]
all a: lab.T0 | a.av747 = ((P1 + P2))
all a: lab.T1 | a.av747 = ((P1 + P3))
all a: lab.T2 | a.av747 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev747)
semantics0[av748, ev748]
all a: lab.T0 | a.av748 = (P0)
all a: lab.T1 | a.av748 = ((P0 + P4))
all a: lab.T2 | a.av748 = ((P2 + (P3 + P4)))
not (R->P0 in ev748)
semantics4[av749, ev749]
all a: lab.T0 | a.av749 = ((P1 + P4))
all a: lab.T1 | a.av749 = ((P3 + P4))
all a: lab.T2 | a.av749 = (P4)
not (R->P0 in ev749)
semantics4[av750, ev750]
all a: lab.T0 | a.av750 = ((P1 + P4))
all a: lab.T1 | a.av750 = (P0)
all a: lab.T2 | a.av750 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev750)
semantics1[av751, ev751]
all a: lab.T0 | a.av751 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av751 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av751 = (P3)
not (R->P0 in ev751)
semantics0[av752, ev752]
all a: lab.T0 | a.av752 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av752 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av752 = ((P2 + P3))
not (R->P0 in ev752)
semantics3[av753, ev753]
all a: lab.T0 | a.av753 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av753 = (P1)
all a: lab.T2 | a.av753 = ((P0 + (P1 + P3)))
not (R->P0 in ev753)
semantics2[av754, ev754]
all a: lab.T0 | a.av754 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av754 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av754 = ((P1 + P3))
not (R->P0 in ev754)
semantics7[av755, ev755]
all a: lab.T0 | a.av755 = ((P1 + P2))
all a: lab.T1 | a.av755 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av755 = (P1)
not (R->P0 in ev755)
semantics1[av756, ev756]
all a: lab.T0 | a.av756 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av756 = ((P1 + P3))
all a: lab.T2 | a.av756 = ((P3 + P4))
not (R->P0 in ev756)
semantics1[av757, ev757]
all a: lab.T0 | a.av757 = ((P3 + P4))
all a: lab.T1 | a.av757 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av757 = ((P0 + (P1 + P4)))
not (R->P0 in ev757)
semantics0[av758, ev758]
all a: lab.T0 | a.av758 = ((P0 + P2))
all a: lab.T1 | a.av758 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av758 = ((P0 + P4))
not (R->P0 in ev758)
semantics5[av759, ev759]
all a: lab.T0 | a.av759 = ((P3 + P4))
all a: lab.T1 | a.av759 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av759 = ((P1 + P4))
not (R->P0 in ev759)
semantics1[av760, ev760]
all a: lab.T0 | a.av760 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av760 = ((P1 + P4))
all a: lab.T2 | a.av760 = ((P0 + (P3 + P4)))
not (R->P0 in ev760)
semantics1[av761, ev761]
all a: lab.T0 | a.av761 = ((P1 + P4))
all a: lab.T1 | a.av761 = ((P1 + P2))
all a: lab.T2 | a.av761 = ((P2 + P4))
not (R->P0 in ev761)
semantics0[av762, ev762]
all a: lab.T0 | a.av762 = (P1)
all a: lab.T1 | a.av762 = ((P2 + P3))
all a: lab.T2 | a.av762 = ((P1 + P4))
not (R->P0 in ev762)
semantics8[av763, ev763]
all a: lab.T0 | a.av763 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av763 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av763 = (P3)
not (R->P0 in ev763)
semantics2[av764, ev764]
all a: lab.T0 | a.av764 = ((P1 + P4))
all a: lab.T1 | a.av764 = (P0)
all a: lab.T2 | a.av764 = ((P1 + P3))
not (R->P0 in ev764)
semantics8[av765, ev765]
all a: lab.T0 | a.av765 = ((P1 + P3))
all a: lab.T1 | a.av765 = (P2)
all a: lab.T2 | a.av765 = (P3)
not (R->P0 in ev765)
semantics5[av766, ev766]
all a: lab.T0 | a.av766 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av766 = (P0)
all a: lab.T2 | a.av766 = (none)
not (R->P0 in ev766)
semantics7[av767, ev767]
all a: lab.T0 | a.av767 = (P0)
all a: lab.T1 | a.av767 = ((P1 + P2))
all a: lab.T2 | a.av767 = ((P1 + P2))
not (R->P0 in ev767)
semantics4[av768, ev768]
all a: lab.T0 | a.av768 = (none)
all a: lab.T1 | a.av768 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av768 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev768)
semantics0[av769, ev769]
all a: lab.T0 | a.av769 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av769 = (P4)
all a: lab.T2 | a.av769 = ((P0 + (P2 + P3)))
not (R->P0 in ev769)
semantics0[av770, ev770]
all a: lab.T0 | a.av770 = ((P1 + P3))
all a: lab.T1 | a.av770 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av770 = ((P1 + (P2 + P4)))
not (R->P0 in ev770)
semantics0[av771, ev771]
all a: lab.T0 | a.av771 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av771 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av771 = ((P0 + P1))
not (R->P0 in ev771)
semantics2[av772, ev772]
all a: lab.T0 | a.av772 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av772 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av772 = ((P0 + P1))
not (R->P0 in ev772)
semantics8[av773, ev773]
all a: lab.T0 | a.av773 = (P0)
all a: lab.T1 | a.av773 = ((P0 + P3))
all a: lab.T2 | a.av773 = ((P0 + P2))
not (R->P0 in ev773)
semantics2[av774, ev774]
all a: lab.T0 | a.av774 = ((P0 + P3))
all a: lab.T1 | a.av774 = (P0)
all a: lab.T2 | a.av774 = ((P0 + P4))
not (R->P0 in ev774)
semantics5[av775, ev775]
all a: lab.T0 | a.av775 = (P3)
all a: lab.T1 | a.av775 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av775 = (P0)
not (R->P0 in ev775)
semantics5[av776, ev776]
all a: lab.T0 | a.av776 = ((P1 + P4))
all a: lab.T1 | a.av776 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av776 = ((P0 + (P1 + P4)))
not (R->P0 in ev776)
semantics1[av777, ev777]
all a: lab.T0 | a.av777 = (P3)
all a: lab.T1 | a.av777 = (P2)
all a: lab.T2 | a.av777 = ((P0 + (P1 + P3)))
not (R->P0 in ev777)
semantics5[av778, ev778]
all a: lab.T0 | a.av778 = ((P1 + P2))
all a: lab.T1 | a.av778 = ((P0 + P1))
all a: lab.T2 | a.av778 = (P4)
not (R->P0 in ev778)
semantics3[av779, ev779]
all a: lab.T0 | a.av779 = ((P2 + P3))
all a: lab.T1 | a.av779 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av779 = ((P1 + (P2 + P3)))
not (R->P0 in ev779)
semantics0[av780, ev780]
all a: lab.T0 | a.av780 = ((P0 + P4))
all a: lab.T1 | a.av780 = ((P0 + P3))
all a: lab.T2 | a.av780 = ((P0 + P1))
not (R->P0 in ev780)
semantics1[av781, ev781]
all a: lab.T0 | a.av781 = ((P0 + P3))
all a: lab.T1 | a.av781 = ((P1 + P4))
all a: lab.T2 | a.av781 = ((P0 + (P1 + P3)))
not (R->P0 in ev781)
semantics4[av782, ev782]
all a: lab.T0 | a.av782 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av782 = ((P0 + P4))
all a: lab.T2 | a.av782 = ((P2 + P3))
not (R->P0 in ev782)
semantics4[av783, ev783]
all a: lab.T0 | a.av783 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av783 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av783 = ((P0 + P3))
not (R->P0 in ev783)
semantics5[av784, ev784]
all a: lab.T0 | a.av784 = (P4)
all a: lab.T1 | a.av784 = (P3)
all a: lab.T2 | a.av784 = ((P1 + (P2 + P4)))
not (R->P0 in ev784)
semantics5[av785, ev785]
all a: lab.T0 | a.av785 = ((P2 + P3))
all a: lab.T1 | a.av785 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av785 = ((P0 + (P3 + P4)))
not (R->P0 in ev785)
semantics1[av786, ev786]
all a: lab.T0 | a.av786 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av786 = ((P1 + P2))
all a: lab.T2 | a.av786 = ((P1 + (P2 + P4)))
not (R->P0 in ev786)
semantics5[av787, ev787]
all a: lab.T0 | a.av787 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av787 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av787 = ((P0 + (P2 + P3)))
not (R->P0 in ev787)
semantics1[av788, ev788]
all a: lab.T0 | a.av788 = ((P1 + P3))
all a: lab.T1 | a.av788 = ((P1 + P4))
all a: lab.T2 | a.av788 = ((P1 + P4))
not (R->P0 in ev788)
semantics5[av789, ev789]
all a: lab.T0 | a.av789 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av789 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av789 = ((P1 + P4))
not (R->P0 in ev789)
semantics5[av790, ev790]
all a: lab.T0 | a.av790 = ((P3 + P4))
all a: lab.T1 | a.av790 = ((P2 + P3))
all a: lab.T2 | a.av790 = ((P0 + (P3 + P4)))
not (R->P0 in ev790)
semantics8[av791, ev791]
all a: lab.T0 | a.av791 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av791 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av791 = ((P1 + (P2 + P3)))
not (R->P0 in ev791)
semantics0[av792, ev792]
all a: lab.T0 | a.av792 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av792 = ((P1 + P3))
all a: lab.T2 | a.av792 = ((P0 + (P1 + P2)))
not (R->P0 in ev792)
semantics0[av793, ev793]
all a: lab.T0 | a.av793 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av793 = ((P0 + P1))
all a: lab.T2 | a.av793 = ((P0 + P4))
not (R->P0 in ev793)
semantics1[av794, ev794]
all a: lab.T0 | a.av794 = (P0)
all a: lab.T1 | a.av794 = (P1)
all a: lab.T2 | a.av794 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev794)
semantics5[av795, ev795]
all a: lab.T0 | a.av795 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av795 = ((P1 + P4))
all a: lab.T2 | a.av795 = ((P2 + P3))
not (R->P0 in ev795)
semantics1[av796, ev796]
all a: lab.T0 | a.av796 = (P1)
all a: lab.T1 | a.av796 = ((P0 + P3))
all a: lab.T2 | a.av796 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev796)
semantics4[av797, ev797]
all a: lab.T0 | a.av797 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av797 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av797 = ((P2 + (P3 + P4)))
not (R->P0 in ev797)
semantics0[av798, ev798]
all a: lab.T0 | a.av798 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av798 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av798 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev798)
semantics1[av799, ev799]
all a: lab.T0 | a.av799 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av799 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av799 = (P2)
not (R->P0 in ev799)
semantics2[av800, ev800]
all a: lab.T0 | a.av800 = ((P0 + P3))
all a: lab.T1 | a.av800 = ((P2 + P3))
all a: lab.T2 | a.av800 = ((P1 + (P2 + P3)))
not (R->P0 in ev800)
semantics4[av801, ev801]
all a: lab.T0 | a.av801 = (none)
all a: lab.T1 | a.av801 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av801 = ((P2 + P4))
not (R->P0 in ev801)
semantics1[av802, ev802]
all a: lab.T0 | a.av802 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av802 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av802 = ((P1 + P3))
not (R->P0 in ev802)
semantics2[av803, ev803]
all a: lab.T0 | a.av803 = (P4)
all a: lab.T1 | a.av803 = (P0)
all a: lab.T2 | a.av803 = ((P1 + (P2 + P3)))
not (R->P0 in ev803)
semantics3[av804, ev804]
all a: lab.T0 | a.av804 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av804 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av804 = (P0)
not (R->P0 in ev804)
semantics1[av805, ev805]
all a: lab.T0 | a.av805 = ((P1 + P2))
all a: lab.T1 | a.av805 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av805 = ((P1 + P4))
not (R->P0 in ev805)
semantics2[av806, ev806]
all a: lab.T0 | a.av806 = (P2)
all a: lab.T1 | a.av806 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av806 = ((P2 + P4))
not (R->P0 in ev806)
semantics4[av807, ev807]
all a: lab.T0 | a.av807 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av807 = ((P3 + P4))
all a: lab.T2 | a.av807 = ((P1 + (P2 + P4)))
not (R->P0 in ev807)
semantics1[av808, ev808]
all a: lab.T0 | a.av808 = ((P1 + P3))
all a: lab.T1 | a.av808 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av808 = ((P2 + (P3 + P4)))
not (R->P0 in ev808)
semantics4[av809, ev809]
all a: lab.T0 | a.av809 = ((P0 + P3))
all a: lab.T1 | a.av809 = (P0)
all a: lab.T2 | a.av809 = ((P0 + (P2 + P3)))
not (R->P0 in ev809)
semantics1[av810, ev810]
all a: lab.T0 | a.av810 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av810 = ((P0 + P3))
all a: lab.T2 | a.av810 = ((P0 + P1))
not (R->P0 in ev810)
semantics3[av811, ev811]
all a: lab.T0 | a.av811 = ((P0 + P3))
all a: lab.T1 | a.av811 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av811 = (none)
not (R->P0 in ev811)
semantics4[av812, ev812]
all a: lab.T0 | a.av812 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av812 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av812 = ((P0 + (P1 + P4)))
not (R->P0 in ev812)
semantics1[av813, ev813]
all a: lab.T0 | a.av813 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av813 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av813 = ((P0 + P3))
not (R->P0 in ev813)
semantics0[av814, ev814]
all a: lab.T0 | a.av814 = ((P1 + P3))
all a: lab.T1 | a.av814 = ((P0 + P4))
all a: lab.T2 | a.av814 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev814)
semantics0[av815, ev815]
all a: lab.T0 | a.av815 = ((P1 + P2))
all a: lab.T1 | a.av815 = (P0)
all a: lab.T2 | a.av815 = ((P0 + (P1 + P3)))
not (R->P0 in ev815)
semantics1[av816, ev816]
all a: lab.T0 | a.av816 = (P2)
all a: lab.T1 | a.av816 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av816 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev816)
semantics4[av817, ev817]
all a: lab.T0 | a.av817 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av817 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av817 = ((P1 + P2))
not (R->P0 in ev817)
semantics2[av818, ev818]
all a: lab.T0 | a.av818 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av818 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av818 = ((P1 + P2))
not (R->P0 in ev818)
semantics5[av819, ev819]
all a: lab.T0 | a.av819 = ((P1 + P3))
all a: lab.T1 | a.av819 = (P1)
all a: lab.T2 | a.av819 = ((P1 + P4))
not (R->P0 in ev819)
semantics2[av820, ev820]
all a: lab.T0 | a.av820 = ((P0 + P2))
all a: lab.T1 | a.av820 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av820 = ((P0 + P2))
not (R->P0 in ev820)
semantics5[av821, ev821]
all a: lab.T0 | a.av821 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av821 = (P2)
all a: lab.T2 | a.av821 = ((P0 + (P1 + P2)))
not (R->P0 in ev821)
semantics0[av822, ev822]
all a: lab.T0 | a.av822 = (P1)
all a: lab.T1 | a.av822 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av822 = ((P1 + (P2 + P3)))
not (R->P0 in ev822)
semantics4[av823, ev823]
all a: lab.T0 | a.av823 = (P2)
all a: lab.T1 | a.av823 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av823 = ((P0 + (P2 + P3)))
not (R->P0 in ev823)
semantics7[av824, ev824]
all a: lab.T0 | a.av824 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av824 = (P3)
all a: lab.T2 | a.av824 = ((P0 + P1))
not (R->P0 in ev824)
semantics4[av825, ev825]
all a: lab.T0 | a.av825 = ((P1 + P4))
all a: lab.T1 | a.av825 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av825 = ((P0 + (P2 + P3)))
not (R->P0 in ev825)
semantics4[av826, ev826]
all a: lab.T0 | a.av826 = ((P1 + P3))
all a: lab.T1 | a.av826 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av826 = ((P1 + (P2 + P3)))
not (R->P0 in ev826)
semantics0[av827, ev827]
all a: lab.T0 | a.av827 = ((P2 + P3))
all a: lab.T1 | a.av827 = (P4)
all a: lab.T2 | a.av827 = ((P1 + P2))
not (R->P0 in ev827)
semantics5[av828, ev828]
all a: lab.T0 | a.av828 = ((P0 + P2))
all a: lab.T1 | a.av828 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av828 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev828)
semantics4[av829, ev829]
all a: lab.T0 | a.av829 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av829 = (P0)
all a: lab.T2 | a.av829 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev829)
semantics5[av830, ev830]
all a: lab.T0 | a.av830 = ((P0 + P4))
all a: lab.T1 | a.av830 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av830 = ((P0 + P3))
not (R->P0 in ev830)
semantics5[av831, ev831]
all a: lab.T0 | a.av831 = ((P0 + P4))
all a: lab.T1 | a.av831 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av831 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev831)
semantics4[av832, ev832]
all a: lab.T0 | a.av832 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av832 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av832 = ((P0 + P4))
not (R->P0 in ev832)
semantics4[av833, ev833]
all a: lab.T0 | a.av833 = (P0)
all a: lab.T1 | a.av833 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av833 = ((P0 + (P1 + P3)))
not (R->P0 in ev833)
semantics4[av834, ev834]
all a: lab.T0 | a.av834 = (P1)
all a: lab.T1 | a.av834 = ((P0 + P2))
all a: lab.T2 | a.av834 = ((P2 + P4))
not (R->P0 in ev834)
semantics2[av835, ev835]
all a: lab.T0 | a.av835 = ((P3 + P4))
all a: lab.T1 | a.av835 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av835 = ((P1 + (P2 + P4)))
not (R->P0 in ev835)
semantics4[av836, ev836]
all a: lab.T0 | a.av836 = ((P0 + P3))
all a: lab.T1 | a.av836 = ((P1 + P2))
all a: lab.T2 | a.av836 = ((P0 + (P1 + P3)))
not (R->P0 in ev836)
semantics1[av837, ev837]
all a: lab.T0 | a.av837 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av837 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av837 = ((P0 + P1))
not (R->P0 in ev837)
semantics5[av838, ev838]
all a: lab.T0 | a.av838 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av838 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av838 = ((P1 + (P2 + P3)))
not (R->P0 in ev838)
semantics4[av839, ev839]
all a: lab.T0 | a.av839 = (none)
all a: lab.T1 | a.av839 = (P1)
all a: lab.T2 | a.av839 = ((P1 + P4))
not (R->P0 in ev839)
semantics2[av840, ev840]
all a: lab.T0 | a.av840 = ((P1 + P3))
all a: lab.T1 | a.av840 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av840 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev840)
semantics4[av841, ev841]
all a: lab.T0 | a.av841 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av841 = (P0)
all a: lab.T2 | a.av841 = ((P1 + (P2 + P3)))
not (R->P0 in ev841)
semantics0[av842, ev842]
all a: lab.T0 | a.av842 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av842 = ((P1 + P2))
all a: lab.T2 | a.av842 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev842)
semantics4[av843, ev843]
all a: lab.T0 | a.av843 = (P0)
all a: lab.T1 | a.av843 = (P0)
all a: lab.T2 | a.av843 = ((P1 + (P2 + P3)))
not (R->P0 in ev843)
semantics0[av844, ev844]
all a: lab.T0 | a.av844 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av844 = ((P1 + P4))
all a: lab.T2 | a.av844 = ((P0 + P1))
not (R->P0 in ev844)
semantics4[av845, ev845]
all a: lab.T0 | a.av845 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av845 = ((P1 + (P3 + P4)))
all a: lab.T2 | a.av845 = (P0)
not (R->P0 in ev845)
semantics4[av846, ev846]
all a: lab.T0 | a.av846 = ((P3 + P4))
all a: lab.T1 | a.av846 = ((P2 + P3))
all a: lab.T2 | a.av846 = ((P0 + P1))
not (R->P0 in ev846)
semantics5[av847, ev847]
all a: lab.T0 | a.av847 = (P3)
all a: lab.T1 | a.av847 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av847 = ((P3 + P4))
not (R->P0 in ev847)
semantics5[av848, ev848]
all a: lab.T0 | a.av848 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av848 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av848 = (P3)
not (R->P0 in ev848)
semantics4[av849, ev849]
all a: lab.T0 | a.av849 = ((P1 + P4))
all a: lab.T1 | a.av849 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av849 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev849)
semantics8[av850, ev850]
all a: lab.T0 | a.av850 = ((P0 + P1))
all a: lab.T1 | a.av850 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av850 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev850)
semantics1[av851, ev851]
all a: lab.T0 | a.av851 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av851 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av851 = (P0)
not (R->P0 in ev851)
semantics7[av852, ev852]
all a: lab.T0 | a.av852 = (none)
all a: lab.T1 | a.av852 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av852 = ((P1 + P3))
not (R->P0 in ev852)
semantics2[av853, ev853]
all a: lab.T0 | a.av853 = ((P0 + P3))
all a: lab.T1 | a.av853 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av853 = ((P1 + (P2 + P3)))
not (R->P0 in ev853)
semantics2[av854, ev854]
all a: lab.T0 | a.av854 = ((P3 + P4))
all a: lab.T1 | a.av854 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av854 = ((P0 + (P1 + P4)))
not (R->P0 in ev854)
semantics1[av855, ev855]
all a: lab.T0 | a.av855 = ((P0 + P3))
all a: lab.T1 | a.av855 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av855 = ((P1 + (P2 + P3)))
not (R->P0 in ev855)
semantics5[av856, ev856]
all a: lab.T0 | a.av856 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av856 = ((P2 + P3))
all a: lab.T2 | a.av856 = ((P1 + (P2 + P4)))
not (R->P0 in ev856)
semantics0[av857, ev857]
all a: lab.T0 | a.av857 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av857 = ((P2 + P3))
all a: lab.T2 | a.av857 = ((P1 + P2))
not (R->P0 in ev857)
semantics0[av858, ev858]
all a: lab.T0 | a.av858 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av858 = (P4)
all a: lab.T2 | a.av858 = (P0)
not (R->P0 in ev858)
semantics1[av859, ev859]
all a: lab.T0 | a.av859 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av859 = (P2)
all a: lab.T2 | a.av859 = ((P1 + (P2 + P4)))
not (R->P0 in ev859)
semantics0[av860, ev860]
all a: lab.T0 | a.av860 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av860 = ((P0 + P3))
all a: lab.T2 | a.av860 = (P4)
not (R->P0 in ev860)
semantics0[av861, ev861]
all a: lab.T0 | a.av861 = ((P3 + P4))
all a: lab.T1 | a.av861 = ((P2 + P3))
all a: lab.T2 | a.av861 = ((P1 + P4))
not (R->P0 in ev861)
semantics0[av862, ev862]
all a: lab.T0 | a.av862 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av862 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av862 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev862)
semantics2[av863, ev863]
all a: lab.T0 | a.av863 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av863 = (P1)
all a: lab.T2 | a.av863 = ((P0 + (P2 + P3)))
not (R->P0 in ev863)
semantics4[av864, ev864]
all a: lab.T0 | a.av864 = ((P1 + P3))
all a: lab.T1 | a.av864 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av864 = ((P0 + P1))
not (R->P0 in ev864)
semantics2[av865, ev865]
all a: lab.T0 | a.av865 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av865 = (P1)
all a: lab.T2 | a.av865 = ((P2 + P3))
not (R->P0 in ev865)
semantics0[av866, ev866]
all a: lab.T0 | a.av866 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av866 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av866 = (P3)
not (R->P0 in ev866)
semantics2[av867, ev867]
all a: lab.T0 | a.av867 = ((P0 + P3))
all a: lab.T1 | a.av867 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av867 = ((P0 + (P2 + P3)))
not (R->P0 in ev867)
semantics5[av868, ev868]
all a: lab.T0 | a.av868 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av868 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av868 = ((P0 + P3))
not (R->P0 in ev868)
semantics4[av869, ev869]
all a: lab.T0 | a.av869 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av869 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av869 = ((P0 + (P1 + P3)))
not (R->P0 in ev869)
semantics4[av870, ev870]
all a: lab.T0 | a.av870 = ((P0 + P4))
all a: lab.T1 | a.av870 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av870 = ((P1 + (P2 + P3)))
not (R->P0 in ev870)
semantics1[av871, ev871]
all a: lab.T0 | a.av871 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av871 = (P0)
all a: lab.T2 | a.av871 = ((P0 + P3))
not (R->P0 in ev871)
semantics4[av872, ev872]
all a: lab.T0 | a.av872 = ((P1 + P4))
all a: lab.T1 | a.av872 = ((P2 + P3))
all a: lab.T2 | a.av872 = ((P0 + P4))
not (R->P0 in ev872)
semantics2[av873, ev873]
all a: lab.T0 | a.av873 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av873 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av873 = ((P0 + P3))
not (R->P0 in ev873)
semantics5[av874, ev874]
all a: lab.T0 | a.av874 = (P4)
all a: lab.T1 | a.av874 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av874 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev874)
semantics4[av875, ev875]
all a: lab.T0 | a.av875 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av875 = ((P0 + P2))
all a: lab.T2 | a.av875 = ((P1 + P4))
not (R->P0 in ev875)
semantics1[av876, ev876]
all a: lab.T0 | a.av876 = ((P1 + P4))
all a: lab.T1 | a.av876 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av876 = ((P0 + P4))
not (R->P0 in ev876)
semantics3[av877, ev877]
all a: lab.T0 | a.av877 = ((P1 + P3))
all a: lab.T1 | a.av877 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av877 = ((P1 + (P2 + P3)))
not (R->P0 in ev877)
semantics2[av878, ev878]
all a: lab.T0 | a.av878 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av878 = ((P1 + P2))
all a: lab.T2 | a.av878 = ((P0 + P3))
not (R->P0 in ev878)
semantics0[av879, ev879]
all a: lab.T0 | a.av879 = (P3)
all a: lab.T1 | a.av879 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av879 = ((P0 + P1))
not (R->P0 in ev879)
semantics8[av880, ev880]
all a: lab.T0 | a.av880 = ((P0 + P1))
all a: lab.T1 | a.av880 = (P1)
all a: lab.T2 | a.av880 = (none)
not (R->P0 in ev880)
semantics4[av881, ev881]
all a: lab.T0 | a.av881 = ((P2 + P4))
all a: lab.T1 | a.av881 = ((P0 + P3))
all a: lab.T2 | a.av881 = ((P1 + P4))
not (R->P0 in ev881)
semantics1[av882, ev882]
all a: lab.T0 | a.av882 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av882 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av882 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev882)
semantics1[av883, ev883]
all a: lab.T0 | a.av883 = ((P0 + P4))
all a: lab.T1 | a.av883 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av883 = ((P1 + (P2 + P3)))
not (R->P0 in ev883)
semantics1[av884, ev884]
all a: lab.T0 | a.av884 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av884 = (P0)
all a: lab.T2 | a.av884 = (P3)
not (R->P0 in ev884)
semantics4[av885, ev885]
all a: lab.T0 | a.av885 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av885 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av885 = ((P0 + P1))
not (R->P0 in ev885)
semantics0[av886, ev886]
all a: lab.T0 | a.av886 = (P4)
all a: lab.T1 | a.av886 = (P2)
all a: lab.T2 | a.av886 = (P1)
not (R->P0 in ev886)
semantics5[av887, ev887]
all a: lab.T0 | a.av887 = (P4)
all a: lab.T1 | a.av887 = ((P0 + P3))
all a: lab.T2 | a.av887 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev887)
semantics2[av888, ev888]
all a: lab.T0 | a.av888 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av888 = ((P1 + P2))
all a: lab.T2 | a.av888 = ((P0 + P2))
not (R->P0 in ev888)
semantics4[av889, ev889]
all a: lab.T0 | a.av889 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av889 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av889 = ((P1 + P2))
not (R->P0 in ev889)
semantics1[av890, ev890]
all a: lab.T0 | a.av890 = (P3)
all a: lab.T1 | a.av890 = ((P2 + P4))
all a: lab.T2 | a.av890 = ((P0 + (P1 + P3)))
not (R->P0 in ev890)
semantics1[av891, ev891]
all a: lab.T0 | a.av891 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av891 = ((P0 + P4))
all a: lab.T2 | a.av891 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev891)
semantics5[av892, ev892]
all a: lab.T0 | a.av892 = ((P0 + P4))
all a: lab.T1 | a.av892 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av892 = ((P0 + P1))
not (R->P0 in ev892)
semantics4[av893, ev893]
all a: lab.T0 | a.av893 = (P3)
all a: lab.T1 | a.av893 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av893 = ((P0 + P2))
not (R->P0 in ev893)
semantics0[av894, ev894]
all a: lab.T0 | a.av894 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av894 = ((P0 + (P2 + P4)))
all a: lab.T2 | a.av894 = ((P1 + (P2 + P3)))
not (R->P0 in ev894)
semantics4[av895, ev895]
all a: lab.T0 | a.av895 = (none)
all a: lab.T1 | a.av895 = (((P0 + P1) + (P2 + P3)))
all a: lab.T2 | a.av895 = ((P1 + (P3 + P4)))
not (R->P0 in ev895)
semantics0[av896, ev896]
all a: lab.T0 | a.av896 = (P2)
all a: lab.T1 | a.av896 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av896 = ((P0 + (P1 + P3)))
not (R->P0 in ev896)
semantics8[av897, ev897]
all a: lab.T0 | a.av897 = (P2)
all a: lab.T1 | a.av897 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av897 = (P0)
not (R->P0 in ev897)
semantics1[av898, ev898]
all a: lab.T0 | a.av898 = (P4)
all a: lab.T1 | a.av898 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av898 = ((P0 + (P2 + P3)))
not (R->P0 in ev898)
semantics7[av899, ev899]
all a: lab.T0 | a.av899 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av899 = (P0)
all a: lab.T2 | a.av899 = (P3)
not (R->P0 in ev899)
semantics1[av900, ev900]
all a: lab.T0 | a.av900 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av900 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av900 = ((P2 + P3))
not (R->P0 in ev900)
semantics4[av901, ev901]
all a: lab.T0 | a.av901 = (none)
all a: lab.T1 | a.av901 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av901 = ((P0 + (P3 + P4)))
not (R->P0 in ev901)
semantics2[av902, ev902]
all a: lab.T0 | a.av902 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av902 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av902 = ((P2 + P3))
not (R->P0 in ev902)
semantics2[av903, ev903]
all a: lab.T0 | a.av903 = ((P1 + P4))
all a: lab.T1 | a.av903 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av903 = ((P0 + (P2 + P4)))
not (R->P0 in ev903)
semantics2[av904, ev904]
all a: lab.T0 | a.av904 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av904 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av904 = ((P0 + (P1 + P2)))
not (R->P0 in ev904)
semantics4[av905, ev905]
all a: lab.T0 | a.av905 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av905 = ((P1 + P4))
all a: lab.T2 | a.av905 = (P0)
not (R->P0 in ev905)
semantics1[av906, ev906]
all a: lab.T0 | a.av906 = ((P0 + P3))
all a: lab.T1 | a.av906 = ((P1 + P4))
all a: lab.T2 | a.av906 = ((P0 + (P1 + P2)))
not (R->P0 in ev906)
semantics2[av907, ev907]
all a: lab.T0 | a.av907 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av907 = ((P0 + P4))
all a: lab.T2 | a.av907 = ((P1 + (P2 + P4)))
not (R->P0 in ev907)
semantics2[av908, ev908]
all a: lab.T0 | a.av908 = ((P2 + P4))
all a: lab.T1 | a.av908 = ((P0 + P2))
all a: lab.T2 | a.av908 = ((P0 + P2))
not (R->P0 in ev908)
semantics1[av909, ev909]
all a: lab.T0 | a.av909 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av909 = (P0)
all a: lab.T2 | a.av909 = ((P0 + (P1 + P2)))
not (R->P0 in ev909)
semantics0[av910, ev910]
all a: lab.T0 | a.av910 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av910 = ((P3 + P4))
all a: lab.T2 | a.av910 = (P0)
not (R->P0 in ev910)
semantics0[av911, ev911]
all a: lab.T0 | a.av911 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av911 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av911 = ((P3 + P4))
not (R->P0 in ev911)
semantics1[av912, ev912]
all a: lab.T0 | a.av912 = (P3)
all a: lab.T1 | a.av912 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av912 = ((P1 + (P3 + P4)))
not (R->P0 in ev912)
semantics4[av913, ev913]
all a: lab.T0 | a.av913 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av913 = (P3)
all a: lab.T2 | a.av913 = ((P0 + (P1 + P3)))
not (R->P0 in ev913)
semantics0[av914, ev914]
all a: lab.T0 | a.av914 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av914 = ((P0 + P2))
all a: lab.T2 | a.av914 = ((P2 + P4))
not (R->P0 in ev914)
semantics0[av915, ev915]
all a: lab.T0 | a.av915 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av915 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av915 = ((P2 + P4))
not (R->P0 in ev915)
semantics0[av916, ev916]
all a: lab.T0 | a.av916 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av916 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av916 = ((P0 + (P1 + P3)))
not (R->P0 in ev916)
semantics5[av917, ev917]
all a: lab.T0 | a.av917 = ((P1 + P4))
all a: lab.T1 | a.av917 = (P0)
all a: lab.T2 | a.av917 = ((P3 + P4))
not (R->P0 in ev917)
semantics0[av918, ev918]
all a: lab.T0 | a.av918 = ((P2 + P3))
all a: lab.T1 | a.av918 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av918 = ((P3 + P4))
not (R->P0 in ev918)
semantics4[av919, ev919]
all a: lab.T0 | a.av919 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av919 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av919 = ((P1 + P2))
not (R->P0 in ev919)
semantics1[av920, ev920]
all a: lab.T0 | a.av920 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av920 = ((P0 + P3))
all a: lab.T2 | a.av920 = ((P0 + (P2 + P3)))
not (R->P0 in ev920)
semantics3[av921, ev921]
all a: lab.T0 | a.av921 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av921 = (P2)
all a: lab.T2 | a.av921 = ((P1 + P3))
not (R->P0 in ev921)
semantics2[av922, ev922]
all a: lab.T0 | a.av922 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av922 = ((P2 + P3))
all a: lab.T2 | a.av922 = (P2)
not (R->P0 in ev922)
semantics4[av923, ev923]
all a: lab.T0 | a.av923 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av923 = ((P0 + P3))
all a: lab.T2 | a.av923 = ((P0 + (P1 + P4)))
not (R->P0 in ev923)
semantics8[av924, ev924]
all a: lab.T0 | a.av924 = ((P1 + P2))
all a: lab.T1 | a.av924 = ((P0 + P2))
all a: lab.T2 | a.av924 = ((P1 + P3))
not (R->P0 in ev924)
semantics8[av925, ev925]
all a: lab.T0 | a.av925 = (P2)
all a: lab.T1 | a.av925 = ((P2 + P3))
all a: lab.T2 | a.av925 = ((P0 + (P1 + P3)))
not (R->P0 in ev925)
semantics5[av926, ev926]
all a: lab.T0 | a.av926 = ((P1 + P2))
all a: lab.T1 | a.av926 = (P4)
all a: lab.T2 | a.av926 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev926)
semantics4[av927, ev927]
all a: lab.T0 | a.av927 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av927 = ((P2 + P3))
all a: lab.T2 | a.av927 = ((P0 + (P2 + P3)))
not (R->P0 in ev927)
semantics3[av928, ev928]
all a: lab.T0 | a.av928 = ((P0 + P2))
all a: lab.T1 | a.av928 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av928 = ((P0 + P3))
not (R->P0 in ev928)
semantics4[av929, ev929]
all a: lab.T0 | a.av929 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av929 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av929 = ((P1 + (P3 + P4)))
not (R->P0 in ev929)
semantics4[av930, ev930]
all a: lab.T0 | a.av930 = (P0)
all a: lab.T1 | a.av930 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av930 = ((P0 + (P3 + P4)))
not (R->P0 in ev930)
semantics2[av931, ev931]
all a: lab.T0 | a.av931 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av931 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av931 = (P3)
not (R->P0 in ev931)
semantics0[av932, ev932]
all a: lab.T0 | a.av932 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av932 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av932 = (P0)
not (R->P0 in ev932)
semantics0[av933, ev933]
all a: lab.T0 | a.av933 = ((P1 + P2))
all a: lab.T1 | a.av933 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av933 = ((P0 + (P2 + P4)))
not (R->P0 in ev933)
semantics5[av934, ev934]
all a: lab.T0 | a.av934 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av934 = ((P1 + P3))
all a: lab.T2 | a.av934 = ((P0 + (P2 + P3)))
not (R->P0 in ev934)
semantics2[av935, ev935]
all a: lab.T0 | a.av935 = (P4)
all a: lab.T1 | a.av935 = (((P1 + P2) + (P3 + P4)))
all a: lab.T2 | a.av935 = ((P1 + P3))
not (R->P0 in ev935)
semantics0[av936, ev936]
all a: lab.T0 | a.av936 = (P1)
all a: lab.T1 | a.av936 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av936 = ((P1 + (P2 + P3)))
not (R->P0 in ev936)
semantics0[av937, ev937]
all a: lab.T0 | a.av937 = (P0)
all a: lab.T1 | a.av937 = ((P0 + P1))
all a: lab.T2 | a.av937 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev937)
semantics1[av938, ev938]
all a: lab.T0 | a.av938 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av938 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av938 = (P4)
not (R->P0 in ev938)
semantics0[av939, ev939]
all a: lab.T0 | a.av939 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av939 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T2 | a.av939 = ((P1 + (P3 + P4)))
not (R->P0 in ev939)
semantics4[av940, ev940]
all a: lab.T0 | a.av940 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av940 = ((P2 + P3))
all a: lab.T2 | a.av940 = ((P0 + (P1 + P3)))
not (R->P0 in ev940)
semantics7[av941, ev941]
all a: lab.T0 | a.av941 = (none)
all a: lab.T1 | a.av941 = ((P1 + P3))
all a: lab.T2 | a.av941 = (P3)
not (R->P0 in ev941)
semantics0[av942, ev942]
all a: lab.T0 | a.av942 = ((P2 + P4))
all a: lab.T1 | a.av942 = (P2)
all a: lab.T2 | a.av942 = ((P0 + (P1 + P2)))
not (R->P0 in ev942)
semantics1[av943, ev943]
all a: lab.T0 | a.av943 = ((P0 + P4))
all a: lab.T1 | a.av943 = (P3)
all a: lab.T2 | a.av943 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev943)
semantics5[av944, ev944]
all a: lab.T0 | a.av944 = ((P1 + P4))
all a: lab.T1 | a.av944 = (((P0 + P1) + (P2 + P4)))
all a: lab.T2 | a.av944 = (P3)
not (R->P0 in ev944)
semantics4[av945, ev945]
all a: lab.T0 | a.av945 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av945 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av945 = ((P2 + P3))
not (R->P0 in ev945)
semantics5[av946, ev946]
all a: lab.T0 | a.av946 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av946 = ((P0 + P4))
all a: lab.T2 | a.av946 = ((P2 + P4))
not (R->P0 in ev946)
semantics0[av947, ev947]
all a: lab.T0 | a.av947 = ((P1 + P4))
all a: lab.T1 | a.av947 = ((P1 + P3))
all a: lab.T2 | a.av947 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev947)
semantics2[av948, ev948]
all a: lab.T0 | a.av948 = ((P0 + P2))
all a: lab.T1 | a.av948 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av948 = ((P3 + P4))
not (R->P0 in ev948)
semantics0[av949, ev949]
all a: lab.T0 | a.av949 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av949 = ((P1 + (P2 + P3)))
all a: lab.T2 | a.av949 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev949)
semantics7[av950, ev950]
all a: lab.T0 | a.av950 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av950 = ((P0 + P1))
all a: lab.T2 | a.av950 = ((P1 + P3))
not (R->P0 in ev950)
semantics4[av951, ev951]
all a: lab.T0 | a.av951 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av951 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av951 = ((P3 + P4))
not (R->P0 in ev951)
semantics4[av952, ev952]
all a: lab.T0 | a.av952 = ((P2 + P3))
all a: lab.T1 | a.av952 = ((P1 + P2))
all a: lab.T2 | a.av952 = ((P0 + (P1 + P3)))
not (R->P0 in ev952)
semantics2[av953, ev953]
all a: lab.T0 | a.av953 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av953 = (P2)
all a: lab.T2 | a.av953 = (P0)
not (R->P0 in ev953)
semantics5[av954, ev954]
all a: lab.T0 | a.av954 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av954 = ((P1 + (P2 + P4)))
all a: lab.T2 | a.av954 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev954)
semantics1[av955, ev955]
all a: lab.T0 | a.av955 = ((P0 + P4))
all a: lab.T1 | a.av955 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av955 = (P0)
not (R->P0 in ev955)
semantics0[av956, ev956]
all a: lab.T0 | a.av956 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av956 = ((P0 + (P1 + P2)))
all a: lab.T2 | a.av956 = ((P1 + (P3 + P4)))
not (R->P0 in ev956)
semantics7[av957, ev957]
all a: lab.T0 | a.av957 = (P2)
all a: lab.T1 | a.av957 = (P1)
all a: lab.T2 | a.av957 = ((P0 + P2))
not (R->P0 in ev957)
semantics5[av958, ev958]
all a: lab.T0 | a.av958 = ((P0 + P3))
all a: lab.T1 | a.av958 = (P2)
all a: lab.T2 | a.av958 = ((P1 + P2))
not (R->P0 in ev958)
semantics2[av959, ev959]
all a: lab.T0 | a.av959 = (none)
all a: lab.T1 | a.av959 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av959 = (P0)
not (R->P0 in ev959)
semantics0[av960, ev960]
all a: lab.T0 | a.av960 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av960 = ((P0 + P4))
all a: lab.T2 | a.av960 = ((P2 + P4))
not (R->P0 in ev960)
semantics1[av961, ev961]
all a: lab.T0 | a.av961 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av961 = ((P1 + P2))
all a: lab.T2 | a.av961 = ((P1 + (P2 + P4)))
not (R->P0 in ev961)
semantics5[av962, ev962]
all a: lab.T0 | a.av962 = ((P3 + P4))
all a: lab.T1 | a.av962 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av962 = ((P0 + P2))
not (R->P0 in ev962)
semantics4[av963, ev963]
all a: lab.T0 | a.av963 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av963 = ((P1 + P3))
all a: lab.T2 | a.av963 = ((P0 + (P3 + P4)))
not (R->P0 in ev963)
semantics5[av964, ev964]
all a: lab.T0 | a.av964 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av964 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av964 = (P4)
not (R->P0 in ev964)
semantics4[av965, ev965]
all a: lab.T0 | a.av965 = ((P1 + P4))
all a: lab.T1 | a.av965 = ((P0 + (P2 + P3)))
all a: lab.T2 | a.av965 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev965)
semantics4[av966, ev966]
all a: lab.T0 | a.av966 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av966 = ((P0 + P3))
all a: lab.T2 | a.av966 = ((P0 + (P3 + P4)))
not (R->P0 in ev966)
semantics0[av967, ev967]
all a: lab.T0 | a.av967 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av967 = (P3)
all a: lab.T2 | a.av967 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev967)
semantics4[av968, ev968]
all a: lab.T0 | a.av968 = (P3)
all a: lab.T1 | a.av968 = ((P0 + P1))
all a: lab.T2 | a.av968 = ((P0 + P3))
not (R->P0 in ev968)
semantics4[av969, ev969]
all a: lab.T0 | a.av969 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av969 = ((P0 + P3))
all a: lab.T2 | a.av969 = ((P0 + (P2 + P3)))
not (R->P0 in ev969)
semantics0[av970, ev970]
all a: lab.T0 | a.av970 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av970 = ((P0 + P2))
all a: lab.T2 | a.av970 = (P0)
not (R->P0 in ev970)
semantics5[av971, ev971]
all a: lab.T0 | a.av971 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av971 = ((P2 + P4))
all a: lab.T2 | a.av971 = ((P0 + (P1 + P3)))
not (R->P0 in ev971)
semantics3[av972, ev972]
all a: lab.T0 | a.av972 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av972 = ((P0 + (P1 + P3)))
all a: lab.T2 | a.av972 = ((P0 + (P2 + P3)))
not (R->P0 in ev972)
semantics2[av973, ev973]
all a: lab.T0 | a.av973 = ((P0 + P2))
all a: lab.T1 | a.av973 = (P3)
all a: lab.T2 | a.av973 = ((P1 + P3))
not (R->P0 in ev973)
semantics0[av974, ev974]
all a: lab.T0 | a.av974 = ((P0 + P2))
all a: lab.T1 | a.av974 = ((P2 + (P3 + P4)))
all a: lab.T2 | a.av974 = ((P1 + (P2 + P3)))
not (R->P0 in ev974)
semantics4[av975, ev975]
all a: lab.T0 | a.av975 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av975 = ((P0 + P4))
all a: lab.T2 | a.av975 = ((P3 + P4))
not (R->P0 in ev975)
semantics5[av976, ev976]
all a: lab.T0 | a.av976 = ((P0 + P3))
all a: lab.T1 | a.av976 = ((P0 + (P1 + P4)))
all a: lab.T2 | a.av976 = (P4)
not (R->P0 in ev976)
semantics0[av977, ev977]
all a: lab.T0 | a.av977 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av977 = (P1)
all a: lab.T2 | a.av977 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev977)
semantics4[av978, ev978]
all a: lab.T0 | a.av978 = ((P2 + P4))
all a: lab.T1 | a.av978 = ((P0 + P1))
all a: lab.T2 | a.av978 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev978)
semantics4[av979, ev979]
all a: lab.T0 | a.av979 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av979 = (((P0 + P2) + (P3 + P4)))
all a: lab.T2 | a.av979 = ((P2 + P4))
not (R->P0 in ev979)
semantics1[av980, ev980]
all a: lab.T0 | a.av980 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av980 = ((P2 + P3))
all a: lab.T2 | a.av980 = (P0)
not (R->P0 in ev980)
semantics8[av981, ev981]
all a: lab.T0 | a.av981 = ((P1 + P3))
all a: lab.T1 | a.av981 = ((P0 + P3))
all a: lab.T2 | a.av981 = (P2)
not (R->P0 in ev981)
semantics2[av982, ev982]
all a: lab.T0 | a.av982 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av982 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av982 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev982)
semantics1[av983, ev983]
all a: lab.T0 | a.av983 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av983 = ((P0 + (P3 + P4)))
all a: lab.T2 | a.av983 = (P3)
not (R->P0 in ev983)
semantics4[av984, ev984]
all a: lab.T0 | a.av984 = ((P1 + P4))
all a: lab.T1 | a.av984 = ((P0 + P2))
all a: lab.T2 | a.av984 = ((P0 + (P2 + P3)))
not (R->P0 in ev984)
semantics0[av985, ev985]
all a: lab.T0 | a.av985 = ((P0 + P2))
all a: lab.T1 | a.av985 = (((P0 + P1) + (P3 + P4)))
all a: lab.T2 | a.av985 = ((P2 + (P3 + P4)))
not (R->P0 in ev985)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 6 Int

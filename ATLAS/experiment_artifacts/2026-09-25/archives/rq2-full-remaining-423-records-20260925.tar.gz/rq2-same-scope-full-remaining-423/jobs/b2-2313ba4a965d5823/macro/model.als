abstract sig Unit {}
one sig U0, U1, U2 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8 extends Label {}
abstract sig Q {}
one sig Q0 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E9, E11, E12, E13, E15, E17 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos, av2: set Pos, av3: set Pos, av4: set Pos, av5: set Pos, av6: set Pos, av7: set Pos, av8: set Pos, av9: set Pos, av10: set Pos, av11: set Pos, av12: set Pos, av13: set Pos, av14: set Pos, av15: set Pos, av16: set Pos, av17: set Pos, av18: set Pos, av19: set Pos, av20: set Pos, av21: set Pos, av22: set Pos, av23: set Pos, av24: set Pos, av25: set Pos, av26: set Pos, av27: set Pos, av28: set Pos, av29: set Pos, av30: set Pos, av31: set Pos, av32: set Pos, av33: set Pos, av34: set Pos, av35: set Pos, av36: set Pos, av37: set Pos, av38: set Pos, av39: set Pos, av40: set Pos, av41: set Pos, av42: set Pos, av43: set Pos, av44: set Pos, av45: set Pos, av46: set Pos, av47: set Pos, av48: set Pos, av49: set Pos, av50: set Pos, av51: set Pos, av52: set Pos, av53: set Pos, av54: set Pos, av55: set Pos, av56: set Pos, av57: set Pos, av58: set Pos, av59: set Pos, av60: set Pos, av61: set Pos, av62: set Pos, av63: set Pos, av64: set Pos, av65: set Pos, av66: set Pos, av67: set Pos, av68: set Pos, av69: set Pos, av70: set Pos, av71: set Pos, av72: set Pos, av73: set Pos, av74: set Pos, av75: set Pos, av76: set Pos, av77: set Pos, av78: set Pos, av79: set Pos, av80: set Pos, av81: set Pos, av82: set Pos, av83: set Pos, av84: set Pos, av85: set Pos, av86: set Pos, av87: set Pos, av88: set Pos, av89: set Pos, av90: set Pos, av91: set Pos, av92: set Pos, av93: set Pos, av94: set Pos, av95: set Pos, av96: set Pos, av97: set Pos, av98: set Pos, av99: set Pos, av100: set Pos, av101: set Pos, av102: set Pos, av103: set Pos, av104: set Pos, av105: set Pos, av106: set Pos, av107: set Pos, av108: set Pos, av109: set Pos, av110: set Pos, av111: set Pos, av112: set Pos, av113: set Pos, av114: set Pos, av115: set Pos, av116: set Pos, av117: set Pos, av118: set Pos, av119: set Pos, av120: set Pos, av121: set Pos, av122: set Pos, av123: set Pos, av124: set Pos, av125: set Pos, av126: set Pos, av127: set Pos, av128: set Pos, av129: set Pos, av130: set Pos, av131: set Pos, av132: set Pos, av133: set Pos, av134: set Pos, av135: set Pos, av136: set Pos, av137: set Pos, av138: set Pos, av139: set Pos, av140: set Pos, av141: set Pos, av142: set Pos, av143: set Pos, av144: set Pos, av145: set Pos, av146: set Pos, av147: set Pos, av148: set Pos, av149: set Pos, av150: set Pos, av151: set Pos, av152: set Pos, av153: set Pos, av154: set Pos, av155: set Pos, av156: set Pos, av157: set Pos, av158: set Pos, av159: set Pos, av160: set Pos, av161: set Pos, av162: set Pos, av163: set Pos, av164: set Pos, av165: set Pos, av166: set Pos, av167: set Pos, av168: set Pos, av169: set Pos, av170: set Pos, av171: set Pos, av172: set Pos, av173: set Pos, av174: set Pos, av175: set Pos, av176: set Pos, av177: set Pos, av178: set Pos, av179: set Pos, av180: set Pos, av181: set Pos, av182: set Pos, av183: set Pos, av184: set Pos, av185: set Pos, av186: set Pos, av187: set Pos, av188: set Pos, av189: set Pos, av190: set Pos, av191: set Pos, av192: set Pos, av193: set Pos, av194: set Pos, av195: set Pos, av196: set Pos, av197: set Pos, av198: set Pos, av199: set Pos, av200: set Pos, av201: set Pos, av202: set Pos, av203: set Pos, av204: set Pos, av205: set Pos, av206: set Pos, av207: set Pos, av208: set Pos, av209: set Pos, av210: set Pos, av211: set Pos, av212: set Pos, av213: set Pos, av214: set Pos, av215: set Pos, av216: set Pos, av217: set Pos, av218: set Pos, av219: set Pos, av220: set Pos, av221: set Pos, av222: set Pos, av223: set Pos, av224: set Pos, av225: set Pos, av226: set Pos, av227: set Pos, av228: set Pos, av229: set Pos, av230: set Pos, av231: set Pos, av232: set Pos, av233: set Pos, av234: set Pos, av235: set Pos, av236: set Pos, av237: set Pos, av238: set Pos, av239: set Pos, av240: set Pos, av241: set Pos, av242: set Pos, av243: set Pos, av244: set Pos, av245: set Pos, av246: set Pos, av247: set Pos, av248: set Pos, av249: set Pos, av250: set Pos, av251: set Pos, av252: set Pos, av253: set Pos, av254: set Pos, av255: set Pos, av256: set Pos, av257: set Pos, av258: set Pos, av259: set Pos, av260: set Pos, av261: set Pos, av262: set Pos, av263: set Pos, av264: set Pos, av265: set Pos, av266: set Pos, av267: set Pos, av268: set Pos, av269: set Pos, av270: set Pos, av271: set Pos, av272: set Pos, av273: set Pos, av274: set Pos, av275: set Pos, av276: set Pos, av277: set Pos, av278: set Pos, av279: set Pos, av280: set Pos, av281: set Pos, av282: set Pos, av283: set Pos, av284: set Pos, av285: set Pos, av286: set Pos, av287: set Pos, av288: set Pos, av289: set Pos, av290: set Pos, av291: set Pos, av292: set Pos, av293: set Pos, av294: set Pos, av295: set Pos, av296: set Pos, av297: set Pos, av298: set Pos, av299: set Pos, av300: set Pos, av301: set Pos, av302: set Pos, av303: set Pos, av304: set Pos, av305: set Pos, av306: set Pos, av307: set Pos, av308: set Pos, av309: set Pos, av310: set Pos, av311: set Pos, av312: set Pos, av313: set Pos, av314: set Pos, av315: set Pos, av316: set Pos, av317: set Pos, av318: set Pos, av319: set Pos, av320: set Pos, av321: set Pos, av322: set Pos, av323: set Pos, av324: set Pos, av325: set Pos, av326: set Pos, av327: set Pos, av328: set Pos, av329: set Pos, av330: set Pos, av331: set Pos, av332: set Pos, av333: set Pos, av334: set Pos, av335: set Pos, av336: set Pos, av337: set Pos, av338: set Pos, av339: set Pos, av340: set Pos, av341: set Pos, av342: set Pos, av343: set Pos, av344: set Pos, av345: set Pos, av346: set Pos, av347: set Pos, av348: set Pos, av349: set Pos, av350: set Pos, av351: set Pos, av352: set Pos, av353: set Pos, av354: set Pos, av355: set Pos, av356: set Pos, av357: set Pos, av358: set Pos, av359: set Pos, av360: set Pos, av361: set Pos, av362: set Pos, av363: set Pos, av364: set Pos, av365: set Pos, av366: set Pos, av367: set Pos, av368: set Pos, av369: set Pos, av370: set Pos, av371: set Pos, av372: set Pos, av373: set Pos, av374: set Pos, av375: set Pos, av376: set Pos, av377: set Pos, av378: set Pos, av379: set Pos, av380: set Pos, av381: set Pos, av382: set Pos, av383: set Pos, av384: set Pos, av385: set Pos, av386: set Pos, av387: set Pos, av388: set Pos, av389: set Pos, av390: set Pos, av391: set Pos, av392: set Pos, av393: set Pos, av394: set Pos, av395: set Pos, av396: set Pos, av397: set Pos, av398: set Pos, av399: set Pos, av400: set Pos, av401: set Pos, av402: set Pos, av403: set Pos, av404: set Pos, av405: set Pos, av406: set Pos, av407: set Pos, av408: set Pos, av409: set Pos, av410: set Pos, av411: set Pos, av412: set Pos, av413: set Pos, av414: set Pos, av415: set Pos, av416: set Pos, av417: set Pos, av418: set Pos, av419: set Pos, av420: set Pos, av421: set Pos, av422: set Pos, av423: set Pos, av424: set Pos, av425: set Pos, av426: set Pos, av427: set Pos, av428: set Pos, av429: set Pos, av430: set Pos, av431: set Pos, av432: set Pos, av433: set Pos, av434: set Pos, av435: set Pos, av436: set Pos, av437: set Pos, av438: set Pos, av439: set Pos, av440: set Pos, av441: set Pos, av442: set Pos, av443: set Pos, av444: set Pos, av445: set Pos, av446: set Pos, av447: set Pos, av448: set Pos, av449: set Pos, av450: set Pos, av451: set Pos, av452: set Pos, av453: set Pos, av454: set Pos, av455: set Pos, av456: set Pos, av457: set Pos, av458: set Pos, av459: set Pos, av460: set Pos, av461: set Pos, av462: set Pos, av463: set Pos, av464: set Pos, av465: set Pos, av466: set Pos, av467: set Pos, av468: set Pos, av469: set Pos, av470: set Pos, av471: set Pos, av472: set Pos, av473: set Pos, av474: set Pos, av475: set Pos, av476: set Pos, av477: set Pos, av478: set Pos, av479: set Pos, av480: set Pos, av481: set Pos, av482: set Pos, av483: set Pos, av484: set Pos, av485: set Pos, av486: set Pos, av487: set Pos, av488: set Pos, av489: set Pos, av490: set Pos, av491: set Pos, av492: set Pos, av493: set Pos, av494: set Pos, av495: set Pos, av496: set Pos, av497: set Pos, av498: set Pos, av499: set Pos, av500: set Pos, av501: set Pos, av502: set Pos, av503: set Pos, av504: set Pos, av505: set Pos, av506: set Pos, av507: set Pos, av508: set Pos, av509: set Pos, av510: set Pos, av511: set Pos, av512: set Pos, av513: set Pos, av514: set Pos, av515: set Pos, av516: set Pos, av517: set Pos, av518: set Pos, av519: set Pos, av520: set Pos, av521: set Pos, av522: set Pos, av523: set Pos, av524: set Pos, av525: set Pos, av526: set Pos, av527: set Pos, av528: set Pos, av529: set Pos, av530: set Pos, av531: set Pos, av532: set Pos, av533: set Pos, av534: set Pos, av535: set Pos, av536: set Pos, av537: set Pos, av538: set Pos, av539: set Pos, av540: set Pos, av541: set Pos, av542: set Pos, av543: set Pos, av544: set Pos, av545: set Pos, av546: set Pos, av547: set Pos, av548: set Pos, av549: set Pos, av550: set Pos, av551: set Pos, av552: set Pos, av553: set Pos, av554: set Pos, av555: set Pos, av556: set Pos, av557: set Pos, av558: set Pos, av559: set Pos, av560: set Pos, av561: set Pos, av562: set Pos, av563: set Pos, av564: set Pos, av565: set Pos, av566: set Pos, av567: set Pos, av568: set Pos, av569: set Pos, av570: set Pos, av571: set Pos, av572: set Pos, av573: set Pos, av574: set Pos, av575: set Pos, av576: set Pos, av577: set Pos, av578: set Pos, av579: set Pos, av580: set Pos, av581: set Pos, av582: set Pos, av583: set Pos, av584: set Pos, av585: set Pos, av586: set Pos, av587: set Pos, av588: set Pos, av589: set Pos, av590: set Pos, av591: set Pos, av592: set Pos, av593: set Pos, av594: set Pos, av595: set Pos, av596: set Pos, av597: set Pos, av598: set Pos, av599: set Pos, av600: set Pos, av601: set Pos, av602: set Pos, av603: set Pos, av604: set Pos, av605: set Pos, av606: set Pos, av607: set Pos, av608: set Pos, av609: set Pos, av610: set Pos, av611: set Pos, av612: set Pos, av613: set Pos, av614: set Pos, av615: set Pos, av616: set Pos, av617: set Pos, av618: set Pos, av619: set Pos, av620: set Pos, av621: set Pos, av622: set Pos, av623: set Pos, av624: set Pos, av625: set Pos, av626: set Pos, av627: set Pos, av628: set Pos, av629: set Pos, av630: set Pos, av631: set Pos, av632: set Pos, av633: set Pos, av634: set Pos, av635: set Pos, av636: set Pos, av637: set Pos, av638: set Pos, av639: set Pos, av640: set Pos, av641: set Pos, av642: set Pos, av643: set Pos, av644: set Pos, av645: set Pos, av646: set Pos, av647: set Pos, av648: set Pos, av649: set Pos, av650: set Pos, av651: set Pos, av652: set Pos, av653: set Pos, av654: set Pos, av655: set Pos, av656: set Pos, av657: set Pos, av658: set Pos, av659: set Pos, av660: set Pos, av661: set Pos, av662: set Pos, av663: set Pos, av664: set Pos, av665: set Pos, av666: set Pos, av667: set Pos, av668: set Pos, av669: set Pos, av670: set Pos, av671: set Pos, av672: set Pos, av673: set Pos, av674: set Pos, av675: set Pos, av676: set Pos, av677: set Pos, av678: set Pos, av679: set Pos, av680: set Pos, av681: set Pos, av682: set Pos, av683: set Pos, av684: set Pos, av685: set Pos, av686: set Pos, av687: set Pos, av688: set Pos, av689: set Pos, av690: set Pos, av691: set Pos, av692: set Pos, av693: set Pos, av694: set Pos, av695: set Pos, av696: set Pos, av697: set Pos, av698: set Pos, av699: set Pos, av700: set Pos, av701: set Pos, av702: set Pos, av703: set Pos, av704: set Pos, av705: set Pos, av706: set Pos, av707: set Pos, av708: set Pos, av709: set Pos, av710: set Pos, av711: set Pos, av712: set Pos, av713: set Pos, av714: set Pos, av715: set Pos, av716: set Pos, av717: set Pos, av718: set Pos, av719: set Pos, av720: set Pos, av721: set Pos, av722: set Pos, av723: set Pos, av724: set Pos, av725: set Pos, av726: set Pos, av727: set Pos, av728: set Pos, av729: set Pos, av730: set Pos, av731: set Pos, av732: set Pos, av733: set Pos, av734: set Pos, av735: set Pos, av736: set Pos, av737: set Pos, av738: set Pos, av739: set Pos, av740: set Pos, av741: set Pos, av742: set Pos, av743: set Pos, av744: set Pos, av745: set Pos, av746: set Pos, av747: set Pos, av748: set Pos, av749: set Pos, av750: set Pos, av751: set Pos, av752: set Pos, av753: set Pos, av754: set Pos, av755: set Pos, av756: set Pos, av757: set Pos, av758: set Pos, av759: set Pos, av760: set Pos, av761: set Pos, av762: set Pos, av763: set Pos, av764: set Pos, av765: set Pos, av766: set Pos, av767: set Pos, av768: set Pos, av769: set Pos, av770: set Pos, av771: set Pos, av772: set Pos, av773: set Pos, av774: set Pos, av775: set Pos, av776: set Pos, av777: set Pos, av778: set Pos, av779: set Pos, av780: set Pos, av781: set Pos, av782: set Pos, av783: set Pos, av784: set Pos, av785: set Pos, av786: set Pos, av787: set Pos, av788: set Pos, av789: set Pos, av790: set Pos, av791: set Pos, av792: set Pos, av793: set Pos, av794: set Pos, av795: set Pos, av796: set Pos, av797: set Pos, av798: set Pos, av799: set Pos, av800: set Pos, av801: set Pos, av802: set Pos, av803: set Pos, av804: set Pos, av805: set Pos, av806: set Pos, av807: set Pos, av808: set Pos, av809: set Pos, av810: set Pos, av811: set Pos, av812: set Pos, av813: set Pos, av814: set Pos, av815: set Pos, av816: set Pos, av817: set Pos, av818: set Pos, av819: set Pos, av820: set Pos, av821: set Pos, av822: set Pos, av823: set Pos, av824: set Pos, av825: set Pos, av826: set Pos, av827: set Pos, av828: set Pos, av829: set Pos, av830: set Pos, av831: set Pos, av832: set Pos, av833: set Pos, av834: set Pos, av835: set Pos, av836: set Pos, av837: set Pos, av838: set Pos, av839: set Pos, av840: set Pos, av841: set Pos, av842: set Pos, av843: set Pos, av844: set Pos, av845: set Pos, av846: set Pos, av847: set Pos, av848: set Pos, av849: set Pos, av850: set Pos, av851: set Pos, av852: set Pos, av853: set Pos, av854: set Pos, av855: set Pos, av856: set Pos, av857: set Pos, av858: set Pos, av859: set Pos, av860: set Pos, av861: set Pos, av862: set Pos, av863: set Pos, av864: set Pos, av865: set Pos, av866: set Pos, av867: set Pos, av868: set Pos, av869: set Pos, av870: set Pos, av871: set Pos, av872: set Pos, av873: set Pos, av874: set Pos, av875: set Pos, av876: set Pos, av877: set Pos, av878: set Pos, av879: set Pos, av880: set Pos, av881: set Pos, av882: set Pos, av883: set Pos, av884: set Pos, av885: set Pos, av886: set Pos, av887: set Pos, av888: set Pos, av889: set Pos, av890: set Pos, av891: set Pos, av892: set Pos, av893: set Pos, av894: set Pos, av895: set Pos, av896: set Pos, av897: set Pos, av898: set Pos, av899: set Pos, av900: set Pos, av901: set Pos, av902: set Pos, av903: set Pos, av904: set Pos, av905: set Pos, av906: set Pos, av907: set Pos, av908: set Pos, av909: set Pos, av910: set Pos, av911: set Pos, av912: set Pos, av913: set Pos, av914: set Pos, av915: set Pos, av916: set Pos, av917: set Pos, av918: set Pos, av919: set Pos, av920: set Pos, av921: set Pos, av922: set Pos, av923: set Pos, av924: set Pos, av925: set Pos, av926: set Pos, av927: set Pos, av928: set Pos, av929: set Pos, av930: set Pos, av931: set Pos, av932: set Pos, av933: set Pos, av934: set Pos, av935: set Pos, av936: set Pos, av937: set Pos, av938: set Pos, av939: set Pos, av940: set Pos, av941: set Pos, av942: set Pos, av943: set Pos, av944: set Pos, av945: set Pos, av946: set Pos, av947: set Pos, av948: set Pos, av949: set Pos, av950: set Pos, av951: set Pos, av952: set Pos, av953: set Pos, av954: set Pos, av955: set Pos, av956: set Pos, av957: set Pos, av958: set Pos, av959: set Pos, av960: set Pos, av961: set Pos, av962: set Pos, av963: set Pos, av964: set Pos, av965: set Pos, av966: set Pos, av967: set Pos, av968: set Pos, av969: set Pos, av970: set Pos, av971: set Pos, av972: set Pos, av973: set Pos, av974: set Pos, av975: set Pos, av976: set Pos, av977: set Pos, av978: set Pos, av979: set Pos, av980: set Pos, av981: set Pos, av982: set Pos, av983: set Pos, av984: set Pos, av985: set Pos, av986: set Pos, av987: set Pos, av988: set Pos, av989: set Pos, av990: set Pos, av991: set Pos, av992: set Pos, av993: set Pos, av994: set Pos, av995: set Pos, av996: set Pos, av997: set Pos, av998: set Pos, av999: set Pos, av1000: set Pos, av1001: set Pos, av1002: set Pos, av1003: set Pos, av1004: set Pos, av1005: set Pos, av1006: set Pos, av1007: set Pos, av1008: set Pos, av1009: set Pos, av1010: set Pos, av1011: set Pos, av1012: set Pos, av1013: set Pos, av1014: set Pos, av1015: set Pos, av1016: set Pos, av1017: set Pos, av1018: set Pos, av1019: set Pos, av1020: set Pos, av1021: set Pos, av1022: set Pos, av1023: set Pos, av1024: set Pos, av1025: set Pos, av1026: set Pos, av1027: set Pos, av1028: set Pos, av1029: set Pos, av1030: set Pos, av1031: set Pos, av1032: set Pos, av1033: set Pos, av1034: set Pos, av1035: set Pos, av1036: set Pos, av1037: set Pos, av1038: set Pos, av1039: set Pos, av1040: set Pos, av1041: set Pos, av1042: set Pos, av1043: set Pos, av1044: set Pos, av1045: set Pos, av1046: set Pos, av1047: set Pos, av1048: set Pos, av1049: set Pos, av1050: set Pos, av1051: set Pos, av1052: set Pos, av1053: set Pos, av1054: set Pos, av1055: set Pos, av1056: set Pos, av1057: set Pos, av1058: set Pos, av1059: set Pos, av1060: set Pos, av1061: set Pos, av1062: set Pos, av1063: set Pos, av1064: set Pos, av1065: set Pos, av1066: set Pos, av1067: set Pos, av1068: set Pos, av1069: set Pos, av1070: set Pos, av1071: set Pos, av1072: set Pos, av1073: set Pos, av1074: set Pos, av1075: set Pos, av1076: set Pos, av1077: set Pos, av1078: set Pos, av1079: set Pos, av1080: set Pos, av1081: set Pos, av1082: set Pos, av1083: set Pos, av1084: set Pos, av1085: set Pos, av1086: set Pos, av1087: set Pos, av1088: set Pos, av1089: set Pos, av1090: set Pos, av1091: set Pos, av1092: set Pos, av1093: set Pos, av1094: set Pos, av1095: set Pos, av1096: set Pos, av1097: set Pos, av1098: set Pos, av1099: set Pos, av1100: set Pos, av1101: set Pos, av1102: set Pos, av1103: set Pos, av1104: set Pos, av1105: set Pos, av1106: set Pos, av1107: set Pos, av1108: set Pos, av1109: set Pos, av1110: set Pos, av1111: set Pos, av1112: set Pos, av1113: set Pos, av1114: set Pos, av1115: set Pos, av1116: set Pos, av1117: set Pos, av1118: set Pos, av1119: set Pos, av1120: set Pos, av1121: set Pos, av1122: set Pos, av1123: set Pos, av1124: set Pos, av1125: set Pos, av1126: set Pos, av1127: set Pos, av1128: set Pos, av1129: set Pos, av1130: set Pos, av1131: set Pos, av1132: set Pos, av1133: set Pos, av1134: set Pos, av1135: set Pos, av1136: set Pos, av1137: set Pos, av1138: set Pos, av1139: set Pos, av1140: set Pos, av1141: set Pos, av1142: set Pos, av1143: set Pos, av1144: set Pos, av1145: set Pos, av1146: set Pos, av1147: set Pos, av1148: set Pos, av1149: set Pos, av1150: set Pos, av1151: set Pos, av1152: set Pos, av1153: set Pos, av1154: set Pos, av1155: set Pos, av1156: set Pos, av1157: set Pos, av1158: set Pos, av1159: set Pos, av1160: set Pos, av1161: set Pos, av1162: set Pos, av1163: set Pos, av1164: set Pos, av1165: set Pos, av1166: set Pos, av1167: set Pos, av1168: set Pos, av1169: set Pos, av1170: set Pos, av1171: set Pos, av1172: set Pos, av1173: set Pos, av1174: set Pos, av1175: set Pos, av1176: set Pos, av1177: set Pos, av1178: set Pos, av1179: set Pos, av1180: set Pos, av1181: set Pos, av1182: set Pos, av1183: set Pos, av1184: set Pos, av1185: set Pos, av1186: set Pos, av1187: set Pos, av1188: set Pos, av1189: set Pos, av1190: set Pos, av1191: set Pos, av1192: set Pos, av1193: set Pos, av1194: set Pos, av1195: set Pos, av1196: set Pos, av1197: set Pos, av1198: set Pos, av1199: set Pos, av1200: set Pos, av1201: set Pos, av1202: set Pos, av1203: set Pos, av1204: set Pos, av1205: set Pos, av1206: set Pos, av1207: set Pos, av1208: set Pos, av1209: set Pos, av1210: set Pos, av1211: set Pos, av1212: set Pos, av1213: set Pos, av1214: set Pos, av1215: set Pos, av1216: set Pos, av1217: set Pos, av1218: set Pos, av1219: set Pos, av1220: set Pos, av1221: set Pos, av1222: set Pos, av1223: set Pos, av1224: set Pos, av1225: set Pos, av1226: set Pos, av1227: set Pos, av1228: set Pos, av1229: set Pos, av1230: set Pos, av1231: set Pos, av1232: set Pos, av1233: set Pos, av1234: set Pos, av1235: set Pos, av1236: set Pos, av1237: set Pos, av1238: set Pos, av1239: set Pos, av1240: set Pos, av1241: set Pos, av1242: set Pos, av1243: set Pos, av1244: set Pos, av1245: set Pos, av1246: set Pos, av1247: set Pos, av1248: set Pos, av1249: set Pos, av1250: set Pos, av1251: set Pos, av1252: set Pos, av1253: set Pos, av1254: set Pos, av1255: set Pos, av1256: set Pos, av1257: set Pos, av1258: set Pos, av1259: set Pos, av1260: set Pos, av1261: set Pos, av1262: set Pos, av1263: set Pos, av1264: set Pos, av1265: set Pos, av1266: set Pos, av1267: set Pos, av1268: set Pos, av1269: set Pos, av1270: set Pos, av1271: set Pos, av1272: set Pos, av1273: set Pos, av1274: set Pos, av1275: set Pos, av1276: set Pos, av1277: set Pos }
one sig A0, A1, A2 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos, ev2: set Pos, ev3: set Pos, ev4: set Pos, ev5: set Pos, ev6: set Pos, ev7: set Pos, ev8: set Pos, ev9: set Pos, ev10: set Pos, ev11: set Pos, ev12: set Pos, ev13: set Pos, ev14: set Pos, ev15: set Pos, ev16: set Pos, ev17: set Pos, ev18: set Pos, ev19: set Pos, ev20: set Pos, ev21: set Pos, ev22: set Pos, ev23: set Pos, ev24: set Pos, ev25: set Pos, ev26: set Pos, ev27: set Pos, ev28: set Pos, ev29: set Pos, ev30: set Pos, ev31: set Pos, ev32: set Pos, ev33: set Pos, ev34: set Pos, ev35: set Pos, ev36: set Pos, ev37: set Pos, ev38: set Pos, ev39: set Pos, ev40: set Pos, ev41: set Pos, ev42: set Pos, ev43: set Pos, ev44: set Pos, ev45: set Pos, ev46: set Pos, ev47: set Pos, ev48: set Pos, ev49: set Pos, ev50: set Pos, ev51: set Pos, ev52: set Pos, ev53: set Pos, ev54: set Pos, ev55: set Pos, ev56: set Pos, ev57: set Pos, ev58: set Pos, ev59: set Pos, ev60: set Pos, ev61: set Pos, ev62: set Pos, ev63: set Pos, ev64: set Pos, ev65: set Pos, ev66: set Pos, ev67: set Pos, ev68: set Pos, ev69: set Pos, ev70: set Pos, ev71: set Pos, ev72: set Pos, ev73: set Pos, ev74: set Pos, ev75: set Pos, ev76: set Pos, ev77: set Pos, ev78: set Pos, ev79: set Pos, ev80: set Pos, ev81: set Pos, ev82: set Pos, ev83: set Pos, ev84: set Pos, ev85: set Pos, ev86: set Pos, ev87: set Pos, ev88: set Pos, ev89: set Pos, ev90: set Pos, ev91: set Pos, ev92: set Pos, ev93: set Pos, ev94: set Pos, ev95: set Pos, ev96: set Pos, ev97: set Pos, ev98: set Pos, ev99: set Pos, ev100: set Pos, ev101: set Pos, ev102: set Pos, ev103: set Pos, ev104: set Pos, ev105: set Pos, ev106: set Pos, ev107: set Pos, ev108: set Pos, ev109: set Pos, ev110: set Pos, ev111: set Pos, ev112: set Pos, ev113: set Pos, ev114: set Pos, ev115: set Pos, ev116: set Pos, ev117: set Pos, ev118: set Pos, ev119: set Pos, ev120: set Pos, ev121: set Pos, ev122: set Pos, ev123: set Pos, ev124: set Pos, ev125: set Pos, ev126: set Pos, ev127: set Pos, ev128: set Pos, ev129: set Pos, ev130: set Pos, ev131: set Pos, ev132: set Pos, ev133: set Pos, ev134: set Pos, ev135: set Pos, ev136: set Pos, ev137: set Pos, ev138: set Pos, ev139: set Pos, ev140: set Pos, ev141: set Pos, ev142: set Pos, ev143: set Pos, ev144: set Pos, ev145: set Pos, ev146: set Pos, ev147: set Pos, ev148: set Pos, ev149: set Pos, ev150: set Pos, ev151: set Pos, ev152: set Pos, ev153: set Pos, ev154: set Pos, ev155: set Pos, ev156: set Pos, ev157: set Pos, ev158: set Pos, ev159: set Pos, ev160: set Pos, ev161: set Pos, ev162: set Pos, ev163: set Pos, ev164: set Pos, ev165: set Pos, ev166: set Pos, ev167: set Pos, ev168: set Pos, ev169: set Pos, ev170: set Pos, ev171: set Pos, ev172: set Pos, ev173: set Pos, ev174: set Pos, ev175: set Pos, ev176: set Pos, ev177: set Pos, ev178: set Pos, ev179: set Pos, ev180: set Pos, ev181: set Pos, ev182: set Pos, ev183: set Pos, ev184: set Pos, ev185: set Pos, ev186: set Pos, ev187: set Pos, ev188: set Pos, ev189: set Pos, ev190: set Pos, ev191: set Pos, ev192: set Pos, ev193: set Pos, ev194: set Pos, ev195: set Pos, ev196: set Pos, ev197: set Pos, ev198: set Pos, ev199: set Pos, ev200: set Pos, ev201: set Pos, ev202: set Pos, ev203: set Pos, ev204: set Pos, ev205: set Pos, ev206: set Pos, ev207: set Pos, ev208: set Pos, ev209: set Pos, ev210: set Pos, ev211: set Pos, ev212: set Pos, ev213: set Pos, ev214: set Pos, ev215: set Pos, ev216: set Pos, ev217: set Pos, ev218: set Pos, ev219: set Pos, ev220: set Pos, ev221: set Pos, ev222: set Pos, ev223: set Pos, ev224: set Pos, ev225: set Pos, ev226: set Pos, ev227: set Pos, ev228: set Pos, ev229: set Pos, ev230: set Pos, ev231: set Pos, ev232: set Pos, ev233: set Pos, ev234: set Pos, ev235: set Pos, ev236: set Pos, ev237: set Pos, ev238: set Pos, ev239: set Pos, ev240: set Pos, ev241: set Pos, ev242: set Pos, ev243: set Pos, ev244: set Pos, ev245: set Pos, ev246: set Pos, ev247: set Pos, ev248: set Pos, ev249: set Pos, ev250: set Pos, ev251: set Pos, ev252: set Pos, ev253: set Pos, ev254: set Pos, ev255: set Pos, ev256: set Pos, ev257: set Pos, ev258: set Pos, ev259: set Pos, ev260: set Pos, ev261: set Pos, ev262: set Pos, ev263: set Pos, ev264: set Pos, ev265: set Pos, ev266: set Pos, ev267: set Pos, ev268: set Pos, ev269: set Pos, ev270: set Pos, ev271: set Pos, ev272: set Pos, ev273: set Pos, ev274: set Pos, ev275: set Pos, ev276: set Pos, ev277: set Pos, ev278: set Pos, ev279: set Pos, ev280: set Pos, ev281: set Pos, ev282: set Pos, ev283: set Pos, ev284: set Pos, ev285: set Pos, ev286: set Pos, ev287: set Pos, ev288: set Pos, ev289: set Pos, ev290: set Pos, ev291: set Pos, ev292: set Pos, ev293: set Pos, ev294: set Pos, ev295: set Pos, ev296: set Pos, ev297: set Pos, ev298: set Pos, ev299: set Pos, ev300: set Pos, ev301: set Pos, ev302: set Pos, ev303: set Pos, ev304: set Pos, ev305: set Pos, ev306: set Pos, ev307: set Pos, ev308: set Pos, ev309: set Pos, ev310: set Pos, ev311: set Pos, ev312: set Pos, ev313: set Pos, ev314: set Pos, ev315: set Pos, ev316: set Pos, ev317: set Pos, ev318: set Pos, ev319: set Pos, ev320: set Pos, ev321: set Pos, ev322: set Pos, ev323: set Pos, ev324: set Pos, ev325: set Pos, ev326: set Pos, ev327: set Pos, ev328: set Pos, ev329: set Pos, ev330: set Pos, ev331: set Pos, ev332: set Pos, ev333: set Pos, ev334: set Pos, ev335: set Pos, ev336: set Pos, ev337: set Pos, ev338: set Pos, ev339: set Pos, ev340: set Pos, ev341: set Pos, ev342: set Pos, ev343: set Pos, ev344: set Pos, ev345: set Pos, ev346: set Pos, ev347: set Pos, ev348: set Pos, ev349: set Pos, ev350: set Pos, ev351: set Pos, ev352: set Pos, ev353: set Pos, ev354: set Pos, ev355: set Pos, ev356: set Pos, ev357: set Pos, ev358: set Pos, ev359: set Pos, ev360: set Pos, ev361: set Pos, ev362: set Pos, ev363: set Pos, ev364: set Pos, ev365: set Pos, ev366: set Pos, ev367: set Pos, ev368: set Pos, ev369: set Pos, ev370: set Pos, ev371: set Pos, ev372: set Pos, ev373: set Pos, ev374: set Pos, ev375: set Pos, ev376: set Pos, ev377: set Pos, ev378: set Pos, ev379: set Pos, ev380: set Pos, ev381: set Pos, ev382: set Pos, ev383: set Pos, ev384: set Pos, ev385: set Pos, ev386: set Pos, ev387: set Pos, ev388: set Pos, ev389: set Pos, ev390: set Pos, ev391: set Pos, ev392: set Pos, ev393: set Pos, ev394: set Pos, ev395: set Pos, ev396: set Pos, ev397: set Pos, ev398: set Pos, ev399: set Pos, ev400: set Pos, ev401: set Pos, ev402: set Pos, ev403: set Pos, ev404: set Pos, ev405: set Pos, ev406: set Pos, ev407: set Pos, ev408: set Pos, ev409: set Pos, ev410: set Pos, ev411: set Pos, ev412: set Pos, ev413: set Pos, ev414: set Pos, ev415: set Pos, ev416: set Pos, ev417: set Pos, ev418: set Pos, ev419: set Pos, ev420: set Pos, ev421: set Pos, ev422: set Pos, ev423: set Pos, ev424: set Pos, ev425: set Pos, ev426: set Pos, ev427: set Pos, ev428: set Pos, ev429: set Pos, ev430: set Pos, ev431: set Pos, ev432: set Pos, ev433: set Pos, ev434: set Pos, ev435: set Pos, ev436: set Pos, ev437: set Pos, ev438: set Pos, ev439: set Pos, ev440: set Pos, ev441: set Pos, ev442: set Pos, ev443: set Pos, ev444: set Pos, ev445: set Pos, ev446: set Pos, ev447: set Pos, ev448: set Pos, ev449: set Pos, ev450: set Pos, ev451: set Pos, ev452: set Pos, ev453: set Pos, ev454: set Pos, ev455: set Pos, ev456: set Pos, ev457: set Pos, ev458: set Pos, ev459: set Pos, ev460: set Pos, ev461: set Pos, ev462: set Pos, ev463: set Pos, ev464: set Pos, ev465: set Pos, ev466: set Pos, ev467: set Pos, ev468: set Pos, ev469: set Pos, ev470: set Pos, ev471: set Pos, ev472: set Pos, ev473: set Pos, ev474: set Pos, ev475: set Pos, ev476: set Pos, ev477: set Pos, ev478: set Pos, ev479: set Pos, ev480: set Pos, ev481: set Pos, ev482: set Pos, ev483: set Pos, ev484: set Pos, ev485: set Pos, ev486: set Pos, ev487: set Pos, ev488: set Pos, ev489: set Pos, ev490: set Pos, ev491: set Pos, ev492: set Pos, ev493: set Pos, ev494: set Pos, ev495: set Pos, ev496: set Pos, ev497: set Pos, ev498: set Pos, ev499: set Pos, ev500: set Pos, ev501: set Pos, ev502: set Pos, ev503: set Pos, ev504: set Pos, ev505: set Pos, ev506: set Pos, ev507: set Pos, ev508: set Pos, ev509: set Pos, ev510: set Pos, ev511: set Pos, ev512: set Pos, ev513: set Pos, ev514: set Pos, ev515: set Pos, ev516: set Pos, ev517: set Pos, ev518: set Pos, ev519: set Pos, ev520: set Pos, ev521: set Pos, ev522: set Pos, ev523: set Pos, ev524: set Pos, ev525: set Pos, ev526: set Pos, ev527: set Pos, ev528: set Pos, ev529: set Pos, ev530: set Pos, ev531: set Pos, ev532: set Pos, ev533: set Pos, ev534: set Pos, ev535: set Pos, ev536: set Pos, ev537: set Pos, ev538: set Pos, ev539: set Pos, ev540: set Pos, ev541: set Pos, ev542: set Pos, ev543: set Pos, ev544: set Pos, ev545: set Pos, ev546: set Pos, ev547: set Pos, ev548: set Pos, ev549: set Pos, ev550: set Pos, ev551: set Pos, ev552: set Pos, ev553: set Pos, ev554: set Pos, ev555: set Pos, ev556: set Pos, ev557: set Pos, ev558: set Pos, ev559: set Pos, ev560: set Pos, ev561: set Pos, ev562: set Pos, ev563: set Pos, ev564: set Pos, ev565: set Pos, ev566: set Pos, ev567: set Pos, ev568: set Pos, ev569: set Pos, ev570: set Pos, ev571: set Pos, ev572: set Pos, ev573: set Pos, ev574: set Pos, ev575: set Pos, ev576: set Pos, ev577: set Pos, ev578: set Pos, ev579: set Pos, ev580: set Pos, ev581: set Pos, ev582: set Pos, ev583: set Pos, ev584: set Pos, ev585: set Pos, ev586: set Pos, ev587: set Pos, ev588: set Pos, ev589: set Pos, ev590: set Pos, ev591: set Pos, ev592: set Pos, ev593: set Pos, ev594: set Pos, ev595: set Pos, ev596: set Pos, ev597: set Pos, ev598: set Pos, ev599: set Pos, ev600: set Pos, ev601: set Pos, ev602: set Pos, ev603: set Pos, ev604: set Pos, ev605: set Pos, ev606: set Pos, ev607: set Pos, ev608: set Pos, ev609: set Pos, ev610: set Pos, ev611: set Pos, ev612: set Pos, ev613: set Pos, ev614: set Pos, ev615: set Pos, ev616: set Pos, ev617: set Pos, ev618: set Pos, ev619: set Pos, ev620: set Pos, ev621: set Pos, ev622: set Pos, ev623: set Pos, ev624: set Pos, ev625: set Pos, ev626: set Pos, ev627: set Pos, ev628: set Pos, ev629: set Pos, ev630: set Pos, ev631: set Pos, ev632: set Pos, ev633: set Pos, ev634: set Pos, ev635: set Pos, ev636: set Pos, ev637: set Pos, ev638: set Pos, ev639: set Pos, ev640: set Pos, ev641: set Pos, ev642: set Pos, ev643: set Pos, ev644: set Pos, ev645: set Pos, ev646: set Pos, ev647: set Pos, ev648: set Pos, ev649: set Pos, ev650: set Pos, ev651: set Pos, ev652: set Pos, ev653: set Pos, ev654: set Pos, ev655: set Pos, ev656: set Pos, ev657: set Pos, ev658: set Pos, ev659: set Pos, ev660: set Pos, ev661: set Pos, ev662: set Pos, ev663: set Pos, ev664: set Pos, ev665: set Pos, ev666: set Pos, ev667: set Pos, ev668: set Pos, ev669: set Pos, ev670: set Pos, ev671: set Pos, ev672: set Pos, ev673: set Pos, ev674: set Pos, ev675: set Pos, ev676: set Pos, ev677: set Pos, ev678: set Pos, ev679: set Pos, ev680: set Pos, ev681: set Pos, ev682: set Pos, ev683: set Pos, ev684: set Pos, ev685: set Pos, ev686: set Pos, ev687: set Pos, ev688: set Pos, ev689: set Pos, ev690: set Pos, ev691: set Pos, ev692: set Pos, ev693: set Pos, ev694: set Pos, ev695: set Pos, ev696: set Pos, ev697: set Pos, ev698: set Pos, ev699: set Pos, ev700: set Pos, ev701: set Pos, ev702: set Pos, ev703: set Pos, ev704: set Pos, ev705: set Pos, ev706: set Pos, ev707: set Pos, ev708: set Pos, ev709: set Pos, ev710: set Pos, ev711: set Pos, ev712: set Pos, ev713: set Pos, ev714: set Pos, ev715: set Pos, ev716: set Pos, ev717: set Pos, ev718: set Pos, ev719: set Pos, ev720: set Pos, ev721: set Pos, ev722: set Pos, ev723: set Pos, ev724: set Pos, ev725: set Pos, ev726: set Pos, ev727: set Pos, ev728: set Pos, ev729: set Pos, ev730: set Pos, ev731: set Pos, ev732: set Pos, ev733: set Pos, ev734: set Pos, ev735: set Pos, ev736: set Pos, ev737: set Pos, ev738: set Pos, ev739: set Pos, ev740: set Pos, ev741: set Pos, ev742: set Pos, ev743: set Pos, ev744: set Pos, ev745: set Pos, ev746: set Pos, ev747: set Pos, ev748: set Pos, ev749: set Pos, ev750: set Pos, ev751: set Pos, ev752: set Pos, ev753: set Pos, ev754: set Pos, ev755: set Pos, ev756: set Pos, ev757: set Pos, ev758: set Pos, ev759: set Pos, ev760: set Pos, ev761: set Pos, ev762: set Pos, ev763: set Pos, ev764: set Pos, ev765: set Pos, ev766: set Pos, ev767: set Pos, ev768: set Pos, ev769: set Pos, ev770: set Pos, ev771: set Pos, ev772: set Pos, ev773: set Pos, ev774: set Pos, ev775: set Pos, ev776: set Pos, ev777: set Pos, ev778: set Pos, ev779: set Pos, ev780: set Pos, ev781: set Pos, ev782: set Pos, ev783: set Pos, ev784: set Pos, ev785: set Pos, ev786: set Pos, ev787: set Pos, ev788: set Pos, ev789: set Pos, ev790: set Pos, ev791: set Pos, ev792: set Pos, ev793: set Pos, ev794: set Pos, ev795: set Pos, ev796: set Pos, ev797: set Pos, ev798: set Pos, ev799: set Pos, ev800: set Pos, ev801: set Pos, ev802: set Pos, ev803: set Pos, ev804: set Pos, ev805: set Pos, ev806: set Pos, ev807: set Pos, ev808: set Pos, ev809: set Pos, ev810: set Pos, ev811: set Pos, ev812: set Pos, ev813: set Pos, ev814: set Pos, ev815: set Pos, ev816: set Pos, ev817: set Pos, ev818: set Pos, ev819: set Pos, ev820: set Pos, ev821: set Pos, ev822: set Pos, ev823: set Pos, ev824: set Pos, ev825: set Pos, ev826: set Pos, ev827: set Pos, ev828: set Pos, ev829: set Pos, ev830: set Pos, ev831: set Pos, ev832: set Pos, ev833: set Pos, ev834: set Pos, ev835: set Pos, ev836: set Pos, ev837: set Pos, ev838: set Pos, ev839: set Pos, ev840: set Pos, ev841: set Pos, ev842: set Pos, ev843: set Pos, ev844: set Pos, ev845: set Pos, ev846: set Pos, ev847: set Pos, ev848: set Pos, ev849: set Pos, ev850: set Pos, ev851: set Pos, ev852: set Pos, ev853: set Pos, ev854: set Pos, ev855: set Pos, ev856: set Pos, ev857: set Pos, ev858: set Pos, ev859: set Pos, ev860: set Pos, ev861: set Pos, ev862: set Pos, ev863: set Pos, ev864: set Pos, ev865: set Pos, ev866: set Pos, ev867: set Pos, ev868: set Pos, ev869: set Pos, ev870: set Pos, ev871: set Pos, ev872: set Pos, ev873: set Pos, ev874: set Pos, ev875: set Pos, ev876: set Pos, ev877: set Pos, ev878: set Pos, ev879: set Pos, ev880: set Pos, ev881: set Pos, ev882: set Pos, ev883: set Pos, ev884: set Pos, ev885: set Pos, ev886: set Pos, ev887: set Pos, ev888: set Pos, ev889: set Pos, ev890: set Pos, ev891: set Pos, ev892: set Pos, ev893: set Pos, ev894: set Pos, ev895: set Pos, ev896: set Pos, ev897: set Pos, ev898: set Pos, ev899: set Pos, ev900: set Pos, ev901: set Pos, ev902: set Pos, ev903: set Pos, ev904: set Pos, ev905: set Pos, ev906: set Pos, ev907: set Pos, ev908: set Pos, ev909: set Pos, ev910: set Pos, ev911: set Pos, ev912: set Pos, ev913: set Pos, ev914: set Pos, ev915: set Pos, ev916: set Pos, ev917: set Pos, ev918: set Pos, ev919: set Pos, ev920: set Pos, ev921: set Pos, ev922: set Pos, ev923: set Pos, ev924: set Pos, ev925: set Pos, ev926: set Pos, ev927: set Pos, ev928: set Pos, ev929: set Pos, ev930: set Pos, ev931: set Pos, ev932: set Pos, ev933: set Pos, ev934: set Pos, ev935: set Pos, ev936: set Pos, ev937: set Pos, ev938: set Pos, ev939: set Pos, ev940: set Pos, ev941: set Pos, ev942: set Pos, ev943: set Pos, ev944: set Pos, ev945: set Pos, ev946: set Pos, ev947: set Pos, ev948: set Pos, ev949: set Pos, ev950: set Pos, ev951: set Pos, ev952: set Pos, ev953: set Pos, ev954: set Pos, ev955: set Pos, ev956: set Pos, ev957: set Pos, ev958: set Pos, ev959: set Pos, ev960: set Pos, ev961: set Pos, ev962: set Pos, ev963: set Pos, ev964: set Pos, ev965: set Pos, ev966: set Pos, ev967: set Pos, ev968: set Pos, ev969: set Pos, ev970: set Pos, ev971: set Pos, ev972: set Pos, ev973: set Pos, ev974: set Pos, ev975: set Pos, ev976: set Pos, ev977: set Pos, ev978: set Pos, ev979: set Pos, ev980: set Pos, ev981: set Pos, ev982: set Pos, ev983: set Pos, ev984: set Pos, ev985: set Pos, ev986: set Pos, ev987: set Pos, ev988: set Pos, ev989: set Pos, ev990: set Pos, ev991: set Pos, ev992: set Pos, ev993: set Pos, ev994: set Pos, ev995: set Pos, ev996: set Pos, ev997: set Pos, ev998: set Pos, ev999: set Pos, ev1000: set Pos, ev1001: set Pos, ev1002: set Pos, ev1003: set Pos, ev1004: set Pos, ev1005: set Pos, ev1006: set Pos, ev1007: set Pos, ev1008: set Pos, ev1009: set Pos, ev1010: set Pos, ev1011: set Pos, ev1012: set Pos, ev1013: set Pos, ev1014: set Pos, ev1015: set Pos, ev1016: set Pos, ev1017: set Pos, ev1018: set Pos, ev1019: set Pos, ev1020: set Pos, ev1021: set Pos, ev1022: set Pos, ev1023: set Pos, ev1024: set Pos, ev1025: set Pos, ev1026: set Pos, ev1027: set Pos, ev1028: set Pos, ev1029: set Pos, ev1030: set Pos, ev1031: set Pos, ev1032: set Pos, ev1033: set Pos, ev1034: set Pos, ev1035: set Pos, ev1036: set Pos, ev1037: set Pos, ev1038: set Pos, ev1039: set Pos, ev1040: set Pos, ev1041: set Pos, ev1042: set Pos, ev1043: set Pos, ev1044: set Pos, ev1045: set Pos, ev1046: set Pos, ev1047: set Pos, ev1048: set Pos, ev1049: set Pos, ev1050: set Pos, ev1051: set Pos, ev1052: set Pos, ev1053: set Pos, ev1054: set Pos, ev1055: set Pos, ev1056: set Pos, ev1057: set Pos, ev1058: set Pos, ev1059: set Pos, ev1060: set Pos, ev1061: set Pos, ev1062: set Pos, ev1063: set Pos, ev1064: set Pos, ev1065: set Pos, ev1066: set Pos, ev1067: set Pos, ev1068: set Pos, ev1069: set Pos, ev1070: set Pos, ev1071: set Pos, ev1072: set Pos, ev1073: set Pos, ev1074: set Pos, ev1075: set Pos, ev1076: set Pos, ev1077: set Pos, ev1078: set Pos, ev1079: set Pos, ev1080: set Pos, ev1081: set Pos, ev1082: set Pos, ev1083: set Pos, ev1084: set Pos, ev1085: set Pos, ev1086: set Pos, ev1087: set Pos, ev1088: set Pos, ev1089: set Pos, ev1090: set Pos, ev1091: set Pos, ev1092: set Pos, ev1093: set Pos, ev1094: set Pos, ev1095: set Pos, ev1096: set Pos, ev1097: set Pos, ev1098: set Pos, ev1099: set Pos, ev1100: set Pos, ev1101: set Pos, ev1102: set Pos, ev1103: set Pos, ev1104: set Pos, ev1105: set Pos, ev1106: set Pos, ev1107: set Pos, ev1108: set Pos, ev1109: set Pos, ev1110: set Pos, ev1111: set Pos, ev1112: set Pos, ev1113: set Pos, ev1114: set Pos, ev1115: set Pos, ev1116: set Pos, ev1117: set Pos, ev1118: set Pos, ev1119: set Pos, ev1120: set Pos, ev1121: set Pos, ev1122: set Pos, ev1123: set Pos, ev1124: set Pos, ev1125: set Pos, ev1126: set Pos, ev1127: set Pos, ev1128: set Pos, ev1129: set Pos, ev1130: set Pos, ev1131: set Pos, ev1132: set Pos, ev1133: set Pos, ev1134: set Pos, ev1135: set Pos, ev1136: set Pos, ev1137: set Pos, ev1138: set Pos, ev1139: set Pos, ev1140: set Pos, ev1141: set Pos, ev1142: set Pos, ev1143: set Pos, ev1144: set Pos, ev1145: set Pos, ev1146: set Pos, ev1147: set Pos, ev1148: set Pos, ev1149: set Pos, ev1150: set Pos, ev1151: set Pos, ev1152: set Pos, ev1153: set Pos, ev1154: set Pos, ev1155: set Pos, ev1156: set Pos, ev1157: set Pos, ev1158: set Pos, ev1159: set Pos, ev1160: set Pos, ev1161: set Pos, ev1162: set Pos, ev1163: set Pos, ev1164: set Pos, ev1165: set Pos, ev1166: set Pos, ev1167: set Pos, ev1168: set Pos, ev1169: set Pos, ev1170: set Pos, ev1171: set Pos, ev1172: set Pos, ev1173: set Pos, ev1174: set Pos, ev1175: set Pos, ev1176: set Pos, ev1177: set Pos, ev1178: set Pos, ev1179: set Pos, ev1180: set Pos, ev1181: set Pos, ev1182: set Pos, ev1183: set Pos, ev1184: set Pos, ev1185: set Pos, ev1186: set Pos, ev1187: set Pos, ev1188: set Pos, ev1189: set Pos, ev1190: set Pos, ev1191: set Pos, ev1192: set Pos, ev1193: set Pos, ev1194: set Pos, ev1195: set Pos, ev1196: set Pos, ev1197: set Pos, ev1198: set Pos, ev1199: set Pos, ev1200: set Pos, ev1201: set Pos, ev1202: set Pos, ev1203: set Pos, ev1204: set Pos, ev1205: set Pos, ev1206: set Pos, ev1207: set Pos, ev1208: set Pos, ev1209: set Pos, ev1210: set Pos, ev1211: set Pos, ev1212: set Pos, ev1213: set Pos, ev1214: set Pos, ev1215: set Pos, ev1216: set Pos, ev1217: set Pos, ev1218: set Pos, ev1219: set Pos, ev1220: set Pos, ev1221: set Pos, ev1222: set Pos, ev1223: set Pos, ev1224: set Pos, ev1225: set Pos, ev1226: set Pos, ev1227: set Pos, ev1228: set Pos, ev1229: set Pos, ev1230: set Pos, ev1231: set Pos, ev1232: set Pos, ev1233: set Pos, ev1234: set Pos, ev1235: set Pos, ev1236: set Pos, ev1237: set Pos, ev1238: set Pos, ev1239: set Pos, ev1240: set Pos, ev1241: set Pos, ev1242: set Pos, ev1243: set Pos, ev1244: set Pos, ev1245: set Pos, ev1246: set Pos, ev1247: set Pos, ev1248: set Pos, ev1249: set Pos, ev1250: set Pos, ev1251: set Pos, ev1252: set Pos, ev1253: set Pos, ev1254: set Pos, ev1255: set Pos, ev1256: set Pos, ev1257: set Pos, ev1258: set Pos, ev1259: set Pos, ev1260: set Pos, ev1261: set Pos, ev1262: set Pos, ev1263: set Pos, ev1264: set Pos, ev1265: set Pos, ev1266: set Pos, ev1267: set Pos, ev1268: set Pos, ev1269: set Pos, ev1270: set Pos, ev1271: set Pos, ev1272: set Pos, ev1273: set Pos, ev1274: set Pos, ev1275: set Pos, ev1276: set Pos, ev1277: set Pos }
one sig R, C0, L0, D0, C1, L1, D1, C2, L2, D2 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { (T0 + T1) }
fun un: set Label { ((T2 + T3) + (T4 + T5)) }
fun bin: set Label { (T6 + (T7 + T8)) }
fun nonempty: set Fiber { (((E1 + (E2 + E3)) + (E4 + (E5 + E6))) + ((E7 + (E9 + E11)) + ((E12 + E13) + (E15 + E17)))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { (U0->U1 + U1->U2) }
fun carrierNext: Carrier -> Carrier { (((A0->A1 + (A1->A2 + A2->R)) + (R->C0 + (C0->L0 + L0->D0))) + ((D0->C1 + (C1->L1 + L1->D1)) + (D1->C2 + (C2->L2 + L2->D2)))) }
fun child[a: Anchor]: set Port { a.((A0->C0 + (A1->C1 + A2->C2))) }
fun left[a: Anchor]: set Port { a.((A0->L0 + (A1->L1 + A2->L2))) }
fun right[a: Anchor]: set Port { a.((A0->D0 + (A1->D1 + A2->D2))) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
C2.src = A2
L2.src = A2
D2.src = A2
(some C2.target iff A2.lab in un and some A2.lab)
(some L2.target iff A2.lab in bin and some A2.lab)
(some D2.target iff A2.lab in bin and some A2.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
no A2.graph & ((A0 + (A1 + A2)))
#(lab.bin) <= 2
lone lab.T0
lone lab.T1
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
some A2.lab and A2.lab in un implies #(target.A2) > 1
some A2.lab implies some A1.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q0
E2.qi = Q0
E2.qo = Q0
E3.qi = Q0
E3.qo = Q0
E4.qi = Q0
E4.qo = Q0
E5.qi = Q0
E5.qo = Q0
E6.qi = Q0
E6.qo = Q0
E7.qi = Q0
E7.qo = Q0
E9.qi = Q0
E9.qo = Q0
E11.qi = Q0
E11.qo = Q0
E12.qi = Q0
E12.qo = Q0
E13.qi = Q0
E13.qo = Q0
E15.qi = Q0
E15.qo = Q0
E17.qi = Q0
E17.qo = Q0
all e: used | e.fiber in (E0) implies #e.cost = 0
all e: used | e.fiber in ((((E1 + E4) + (E6 + E7)) + ((E9 + E12) + (E13 + (E15 + E17))))) implies #e.cost = 2
all e: used | e.fiber in (((E2 + E3) + (E5 + E11))) implies #e.cost = 1
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in (Q0)
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 implies a.state = Q0
all a: active | a.lab = T2 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T3 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T4 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T5 and child[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
all a: active | a.lab = T8 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q0
}
fun range0: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop0: set Pos { P4 }
fun next0: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift0_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P4))) }
fun shift0_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P4 + P4->P4))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range0 | loop0 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range0 | some (loop0 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range0 | (i.shift0_1) in (range0 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range0 | (i.shift0_1).future0 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next0.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { P0 }
fun loop1: set Pos { P0 }
fun next1: Pos -> Pos { P0->P0 }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { P0->P0 }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in (((E0 + E1) + (E11 + E17))) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + E12)) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in ((E3 + E13)) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in ((E5 + E15)) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range1 | loop1 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range1 | some (loop1 & (e.target.av))}
all a: active | a.lab = T2 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next1.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fun range2: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop2: set Pos { P3 }
fun next2: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun future2: Pos -> Pos { (*next2) & (range2->range2) }
fun shift2_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift2_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P3)) }
fun shift2_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P3 + P3->P3)) }
pred semantics2[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range2
ev in used->range2
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range2 | (i.shift2_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range2 | (i.shift2_0) in (range2 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range2 | some ((i.shift2_0).future2 & (range2 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range2 | (i.shift2_0).future2 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range2 | (i.shift2_0).future2 in (range2 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range2 | loop2 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range2 | some (loop2 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range2 | (i.shift2_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range2 | (i.shift2_1) in (range2 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range2 | some ((i.shift2_1).future2 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range2 | (i.shift2_1).future2 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range2 | (i.shift2_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range2 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next2.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range2 | some (i.future2 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range2 | i.future2 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range2 - left[a].ev) + right[a].ev)
}
fun range3: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop3: set Pos { (P2 + (P3 + P4)) }
fun next3: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun future3: Pos -> Pos { (*next3) & (range3->range3) }
fun shift3_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift3_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P2))) }
fun shift3_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P2 + P4->P3))) }
pred semantics3[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range3
ev in used->range3
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range3 | (i.shift3_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range3 | (i.shift3_0) in (range3 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range3 | some ((i.shift3_0).future3 & (range3 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range3 | (i.shift3_0).future3 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range3 | (i.shift3_0).future3 in (range3 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range3 | loop3 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range3 | some (loop3 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range3 | (i.shift3_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range3 | (i.shift3_1) in (range3 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range3 | some ((i.shift3_1).future3 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range3 | (i.shift3_1).future3 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range3 | (i.shift3_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range3 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next3.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range3 | some (i.future3 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range3 | i.future3 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range3 - left[a].ev) + right[a].ev)
}
fun range4: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop4: set Pos { (P3 + P4) }
fun next4: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun future4: Pos -> Pos { (*next4) & (range4->range4) }
fun shift4_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift4_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P3))) }
fun shift4_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P3 + P4->P4))) }
pred semantics4[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range4
ev in used->range4
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range4 | (i.shift4_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range4 | (i.shift4_0) in (range4 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range4 | some ((i.shift4_0).future4 & (range4 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range4 | (i.shift4_0).future4 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range4 | (i.shift4_0).future4 in (range4 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range4 | loop4 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range4 | some (loop4 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range4 | (i.shift4_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range4 | (i.shift4_1) in (range4 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range4 | some ((i.shift4_1).future4 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range4 | (i.shift4_1).future4 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range4 | (i.shift4_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range4 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next4.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range4 | some (i.future4 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range4 | i.future4 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range4 - left[a].ev) + right[a].ev)
}
fun range5: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop5: set Pos { ((P0 + P1) + (P2 + P3)) }
fun next5: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun future5: Pos -> Pos { (*next5) & (range5->range5) }
fun shift5_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift5_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P0)) }
fun shift5_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P0 + P3->P1)) }
pred semantics5[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range5
ev in used->range5
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range5 | (i.shift5_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range5 | (i.shift5_0) in (range5 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range5 | some ((i.shift5_0).future5 & (range5 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range5 | (i.shift5_0).future5 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range5 | (i.shift5_0).future5 in (range5 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range5 | loop5 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range5 | some (loop5 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range5 | (i.shift5_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range5 | (i.shift5_1) in (range5 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range5 | some ((i.shift5_1).future5 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range5 | (i.shift5_1).future5 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range5 | (i.shift5_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range5 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next5.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range5 | some (i.future5 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range5 | i.future5 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range5 - left[a].ev) + right[a].ev)
}
fun range6: set Pos { (P0 + P1) }
fun loop6: set Pos { (P0 + P1) }
fun next6: Pos -> Pos { (P0->P1 + P1->P0) }
fun future6: Pos -> Pos { (*next6) & (range6->range6) }
fun shift6_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift6_1: Pos -> Pos { (P0->P1 + P1->P0) }
pred semantics6[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range6
ev in used->range6
all e: used | e.fiber in ((E0 + (E1 + E17))) implies e.ev = {i: range6 | (i.shift6_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range6 | (i.shift6_0) in (range6 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range6 | some ((i.shift6_0).future6 & (range6 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range6 | (i.shift6_0).future6 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range6 | (i.shift6_0).future6 in (range6 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range6 | loop6 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range6 | some (loop6 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range6 | (i.shift6_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range6 | (i.shift6_1) in (range6 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range6 | some ((i.shift6_1).future6 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range6 | (i.shift6_1).future6 in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range6 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next6.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range6 | some (i.future6 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range6 | i.future6 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range6 - left[a].ev) + right[a].ev)
}
fun range7: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop7: set Pos { ((P1 + P2) + (P3 + P4)) }
fun next7: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun future7: Pos -> Pos { (*next7) & (range7->range7) }
fun shift7_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift7_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P1))) }
fun shift7_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P1 + P4->P2))) }
pred semantics7[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range7
ev in used->range7
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range7 | (i.shift7_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range7 | (i.shift7_0) in (range7 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range7 | some ((i.shift7_0).future7 & (range7 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range7 | (i.shift7_0).future7 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range7 | (i.shift7_0).future7 in (range7 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range7 | loop7 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range7 | some (loop7 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range7 | (i.shift7_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range7 | (i.shift7_1) in (range7 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range7 | some ((i.shift7_1).future7 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range7 | (i.shift7_1).future7 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range7 | (i.shift7_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range7 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next7.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range7 | some (i.future7 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range7 | i.future7 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range7 - left[a].ev) + right[a].ev)
}
fun range8: set Pos { (P0 + P1) }
fun loop8: set Pos { P1 }
fun next8: Pos -> Pos { (P0->P1 + P1->P1) }
fun future8: Pos -> Pos { (*next8) & (range8->range8) }
fun shift8_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift8_1: Pos -> Pos { (P0->P1 + P1->P1) }
pred semantics8[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range8
ev in used->range8
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range8 | (i.shift8_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range8 | (i.shift8_0) in (range8 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range8 | some ((i.shift8_0).future8 & (range8 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range8 | (i.shift8_0).future8 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range8 | (i.shift8_0).future8 in (range8 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range8 | loop8 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range8 | some (loop8 & (e.target.av))}
all e: used | e.fiber in ((E11 + E17)) implies e.ev = {i: range8 | (i.shift8_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range8 | (i.shift8_1) in (range8 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range8 | some ((i.shift8_1).future8 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range8 | (i.shift8_1).future8 in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range8 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next8.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range8 | some (i.future8 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range8 | i.future8 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range8 - left[a].ev) + right[a].ev)
}
fun range9: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun loop9: set Pos { ((P0 + P1) + (P2 + (P3 + P4))) }
fun next9: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun future9: Pos -> Pos { (*next9) & (range9->range9) }
fun shift9_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + (P3->P3 + P4->P4))) }
fun shift9_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + (P3->P4 + P4->P0))) }
fun shift9_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P4 + (P3->P0 + P4->P1))) }
pred semantics9[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range9
ev in used->range9
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range9 | (i.shift9_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range9 | (i.shift9_0) in (range9 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range9 | some ((i.shift9_0).future9 & (range9 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range9 | (i.shift9_0).future9 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range9 | (i.shift9_0).future9 in (range9 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range9 | loop9 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range9 | some (loop9 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range9 | (i.shift9_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range9 | (i.shift9_1) in (range9 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range9 | some ((i.shift9_1).future9 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range9 | (i.shift9_1).future9 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range9 | (i.shift9_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range9 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next9.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range9 | some (i.future9 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range9 | i.future9 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range9 - left[a].ev) + right[a].ev)
}
fun range10: set Pos { (P0 + (P1 + P2)) }
fun loop10: set Pos { P2 }
fun next10: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun future10: Pos -> Pos { (*next10) & (range10->range10) }
fun shift10_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift10_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P2)) }
fun shift10_2: Pos -> Pos { (P0->P2 + (P1->P2 + P2->P2)) }
pred semantics10[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range10
ev in used->range10
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range10 | (i.shift10_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range10 | (i.shift10_0) in (range10 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range10 | some ((i.shift10_0).future10 & (range10 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range10 | (i.shift10_0).future10 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range10 | (i.shift10_0).future10 in (range10 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range10 | loop10 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range10 | some (loop10 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range10 | (i.shift10_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range10 | (i.shift10_1) in (range10 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range10 | some ((i.shift10_1).future10 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range10 | (i.shift10_1).future10 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range10 | (i.shift10_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range10 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next10.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range10 | some (i.future10 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range10 | i.future10 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range10 - left[a].ev) + right[a].ev)
}
fun range11: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop11: set Pos { (P2 + P3) }
fun next11: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P2)) }
fun future11: Pos -> Pos { (*next11) & (range11->range11) }
fun shift11_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift11_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P2)) }
fun shift11_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P2 + P3->P3)) }
pred semantics11[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range11
ev in used->range11
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range11 | (i.shift11_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range11 | (i.shift11_0) in (range11 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range11 | some ((i.shift11_0).future11 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range11 | some ((i.shift11_0).future11 & (range11 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range11 | (i.shift11_0).future11 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range11 | (i.shift11_0).future11 in (range11 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range11 | loop11 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range11 | some (loop11 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range11 | (i.shift11_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range11 | (i.shift11_1) in (range11 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range11 | some ((i.shift11_1).future11 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range11 | (i.shift11_1).future11 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range11 | (i.shift11_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range11 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next11.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range11 | some (i.future11 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range11 | i.future11 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range11 - left[a].ev) + right[a].ev)
}
fun range12: set Pos { (P0 + (P1 + P2)) }
fun loop12: set Pos { (P1 + P2) }
fun next12: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P1)) }
fun future12: Pos -> Pos { (*next12) & (range12->range12) }
fun shift12_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift12_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P1)) }
fun shift12_2: Pos -> Pos { (P0->P2 + (P1->P1 + P2->P2)) }
pred semantics12[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range12
ev in used->range12
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range12 | (i.shift12_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range12 | (i.shift12_0) in (range12 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range12 | some ((i.shift12_0).future12 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range12 | some ((i.shift12_0).future12 & (range12 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range12 | (i.shift12_0).future12 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range12 | (i.shift12_0).future12 in (range12 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range12 | loop12 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range12 | some (loop12 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range12 | (i.shift12_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range12 | (i.shift12_1) in (range12 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range12 | some ((i.shift12_1).future12 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range12 | (i.shift12_1).future12 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range12 | (i.shift12_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range12 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next12.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range12 | some (i.future12 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range12 | i.future12 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range12 - left[a].ev) + right[a].ev)
}
fun range13: set Pos { (P0 + (P1 + P2)) }
fun loop13: set Pos { (P0 + (P1 + P2)) }
fun next13: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P0)) }
fun future13: Pos -> Pos { (*next13) & (range13->range13) }
fun shift13_0: Pos -> Pos { (P0->P0 + (P1->P1 + P2->P2)) }
fun shift13_1: Pos -> Pos { (P0->P1 + (P1->P2 + P2->P0)) }
fun shift13_2: Pos -> Pos { (P0->P2 + (P1->P0 + P2->P1)) }
pred semantics13[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range13
ev in used->range13
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range13 | (i.shift13_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range13 | (i.shift13_0) in (range13 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range13 | some ((i.shift13_0).future13 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range13 | some ((i.shift13_0).future13 & (range13 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range13 | (i.shift13_0).future13 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range13 | (i.shift13_0).future13 in (range13 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range13 | loop13 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range13 | some (loop13 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range13 | (i.shift13_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range13 | (i.shift13_1) in (range13 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range13 | some ((i.shift13_1).future13 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range13 | (i.shift13_1).future13 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range13 | (i.shift13_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range13 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next13.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range13 | some (i.future13 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range13 | i.future13 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range13 - left[a].ev) + right[a].ev)
}
fun range14: set Pos { ((P0 + P1) + (P2 + P3)) }
fun loop14: set Pos { (P1 + (P2 + P3)) }
fun next14: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P1)) }
fun future14: Pos -> Pos { (*next14) & (range14->range14) }
fun shift14_0: Pos -> Pos { ((P0->P0 + P1->P1) + (P2->P2 + P3->P3)) }
fun shift14_1: Pos -> Pos { ((P0->P1 + P1->P2) + (P2->P3 + P3->P1)) }
fun shift14_2: Pos -> Pos { ((P0->P2 + P1->P3) + (P2->P1 + P3->P2)) }
pred semantics14[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range14
ev in used->range14
all e: used | e.fiber in ((E0 + E1)) implies e.ev = {i: range14 | (i.shift14_0) in (e.target.av)}
all e: used | e.fiber in (E2) implies e.ev = {i: range14 | (i.shift14_0) in (range14 - e.target.av)}
all e: used | e.fiber in (E3) implies e.ev = {i: range14 | some ((i.shift14_0).future14 & (e.target.av))}
all e: used | e.fiber in (E4) implies e.ev = {i: range14 | some ((i.shift14_0).future14 & (range14 - e.target.av))}
all e: used | e.fiber in (E5) implies e.ev = {i: range14 | (i.shift14_0).future14 in (e.target.av)}
all e: used | e.fiber in (E6) implies e.ev = {i: range14 | (i.shift14_0).future14 in (range14 - e.target.av)}
all e: used | e.fiber in (E7) implies e.ev = {i: range14 | loop14 in (e.target.av)}
all e: used | e.fiber in (E9) implies e.ev = {i: range14 | some (loop14 & (e.target.av))}
all e: used | e.fiber in (E11) implies e.ev = {i: range14 | (i.shift14_1) in (e.target.av)}
all e: used | e.fiber in (E12) implies e.ev = {i: range14 | (i.shift14_1) in (range14 - e.target.av)}
all e: used | e.fiber in (E13) implies e.ev = {i: range14 | some ((i.shift14_1).future14 & (e.target.av))}
all e: used | e.fiber in (E15) implies e.ev = {i: range14 | (i.shift14_1).future14 in (e.target.av)}
all e: used | e.fiber in (E17) implies e.ev = {i: range14 | (i.shift14_2) in (e.target.av)}
all a: active | a.lab = T2 implies a.av = (range14 - child[a].ev)
all a: active | a.lab = T3 implies a.av = (next14.(child[a].ev))
all a: active | a.lab = T4 implies a.av = ({i: range14 | some (i.future14 & child[a].ev)})
all a: active | a.lab = T5 implies a.av = ({i: range14 | i.future14 in child[a].ev})
all a: active | a.lab = T6 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T7 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T8 implies a.av = ((range14 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av0 = ((P0 + P3))
(R->P0 in ev0)
semantics1[av1, ev1]
all a: lab.T0 | a.av1 = (P0)
all a: lab.T1 | a.av1 = (P0)
(R->P0 in ev1)
semantics0[av2, ev2]
all a: lab.T0 | a.av2 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av2 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev2)
semantics2[av3, ev3]
all a: lab.T0 | a.av3 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av3 = ((P0 + (P1 + P2)))
(R->P0 in ev3)
semantics2[av4, ev4]
all a: lab.T0 | a.av4 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av4 = ((P0 + (P1 + P3)))
(R->P0 in ev4)
semantics0[av5, ev5]
all a: lab.T0 | a.av5 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av5 = ((P0 + (P1 + P3)))
(R->P0 in ev5)
semantics3[av6, ev6]
all a: lab.T0 | a.av6 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av6 = ((P0 + (P1 + P3)))
(R->P0 in ev6)
semantics4[av7, ev7]
all a: lab.T0 | a.av7 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av7 = ((P0 + (P1 + P4)))
(R->P0 in ev7)
semantics3[av8, ev8]
all a: lab.T0 | a.av8 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av8 = ((P1 + P3))
(R->P0 in ev8)
semantics5[av9, ev9]
all a: lab.T0 | a.av9 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av9 = ((P0 + (P1 + P2)))
(R->P0 in ev9)
semantics6[av10, ev10]
all a: lab.T0 | a.av10 = ((P0 + P1))
all a: lab.T1 | a.av10 = (P1)
(R->P0 in ev10)
semantics7[av11, ev11]
all a: lab.T0 | a.av11 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av11 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev11)
semantics2[av12, ev12]
all a: lab.T0 | a.av12 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av12 = ((P0 + P3))
(R->P0 in ev12)
semantics8[av13, ev13]
all a: lab.T0 | a.av13 = ((P0 + P1))
all a: lab.T1 | a.av13 = (P1)
(R->P0 in ev13)
semantics9[av14, ev14]
all a: lab.T0 | a.av14 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av14 = ((P0 + (P1 + P2)))
(R->P0 in ev14)
semantics7[av15, ev15]
all a: lab.T0 | a.av15 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av15 = ((P1 + (P3 + P4)))
(R->P0 in ev15)
semantics9[av16, ev16]
all a: lab.T0 | a.av16 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av16 = (((P0 + P1) + (P2 + P3)))
(R->P0 in ev16)
semantics9[av17, ev17]
all a: lab.T0 | a.av17 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av17 = ((P1 + (P2 + P3)))
(R->P0 in ev17)
semantics10[av18, ev18]
all a: lab.T0 | a.av18 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av18 = ((P0 + P2))
(R->P0 in ev18)
semantics11[av19, ev19]
all a: lab.T0 | a.av19 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av19 = (P3)
(R->P0 in ev19)
semantics0[av20, ev20]
all a: lab.T0 | a.av20 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av20 = (((P0 + P1) + (P2 + P4)))
(R->P0 in ev20)
semantics9[av21, ev21]
all a: lab.T0 | a.av21 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av21 = (((P1 + P2) + (P3 + P4)))
(R->P0 in ev21)
semantics12[av22, ev22]
all a: lab.T0 | a.av22 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av22 = ((P0 + P1))
(R->P0 in ev22)
semantics0[av23, ev23]
all a: lab.T0 | a.av23 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av23 = ((P0 + P4))
(R->P0 in ev23)
semantics4[av24, ev24]
all a: lab.T0 | a.av24 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av24 = ((P2 + P3))
(R->P0 in ev24)
semantics5[av25, ev25]
all a: lab.T0 | a.av25 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av25 = ((P0 + P3))
(R->P0 in ev25)
semantics3[av26, ev26]
all a: lab.T0 | a.av26 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av26 = (P4)
(R->P0 in ev26)
semantics7[av27, ev27]
all a: lab.T0 | a.av27 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av27 = ((P0 + P2))
(R->P0 in ev27)
semantics9[av28, ev28]
all a: lab.T0 | a.av28 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av28 = ((P0 + P2))
(R->P0 in ev28)
semantics13[av29, ev29]
all a: lab.T0 | a.av29 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av29 = (P2)
(R->P0 in ev29)
semantics9[av30, ev30]
all a: lab.T0 | a.av30 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av30 = ((P1 + (P3 + P4)))
(R->P0 in ev30)
semantics10[av31, ev31]
all a: lab.T0 | a.av31 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av31 = (P2)
(R->P0 in ev31)
semantics9[av32, ev32]
all a: lab.T0 | a.av32 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av32 = (((P0 + P1) + (P3 + P4)))
(R->P0 in ev32)
semantics10[av33, ev33]
all a: lab.T0 | a.av33 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av33 = ((P0 + P1))
(R->P0 in ev33)
semantics5[av34, ev34]
all a: lab.T0 | a.av34 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av34 = ((P1 + (P2 + P3)))
(R->P0 in ev34)
semantics7[av35, ev35]
all a: lab.T0 | a.av35 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av35 = ((P1 + P4))
(R->P0 in ev35)
semantics12[av36, ev36]
all a: lab.T0 | a.av36 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av36 = (P2)
(R->P0 in ev36)
semantics0[av37, ev37]
all a: lab.T0 | a.av37 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av37 = (P4)
(R->P0 in ev37)
semantics2[av38, ev38]
all a: lab.T0 | a.av38 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av38 = ((P1 + P2))
(R->P0 in ev38)
semantics4[av39, ev39]
all a: lab.T0 | a.av39 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av39 = (P4)
(R->P0 in ev39)
semantics6[av40, ev40]
all a: lab.T0 | a.av40 = ((P0 + P1))
all a: lab.T1 | a.av40 = (P0)
(R->P0 in ev40)
semantics1[av41, ev41]
all a: lab.T0 | a.av41 = (P0)
all a: lab.T1 | a.av41 = (none)
(R->P0 in ev41)
semantics4[av42, ev42]
all a: lab.T0 | a.av42 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av42 = ((P1 + P4))
(R->P0 in ev42)
semantics0[av43, ev43]
all a: lab.T0 | a.av43 = (((P0 + P1) + (P2 + (P3 + P4))))
all a: lab.T1 | a.av43 = ((P2 + P3))
(R->P0 in ev43)
semantics13[av44, ev44]
all a: lab.T0 | a.av44 = ((P0 + P1))
all a: lab.T1 | a.av44 = ((P0 + (P1 + P2)))
not (R->P0 in ev44)
semantics10[av45, ev45]
all a: lab.T0 | a.av45 = (P2)
all a: lab.T1 | a.av45 = (none)
not (R->P0 in ev45)
semantics7[av46, ev46]
all a: lab.T0 | a.av46 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av46 = ((P0 + (P2 + P3)))
not (R->P0 in ev46)
semantics7[av47, ev47]
all a: lab.T0 | a.av47 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av47 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev47)
semantics2[av48, ev48]
all a: lab.T0 | a.av48 = (P0)
all a: lab.T1 | a.av48 = ((P1 + P3))
not (R->P0 in ev48)
semantics3[av49, ev49]
all a: lab.T0 | a.av49 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av49 = ((P1 + P4))
not (R->P0 in ev49)
semantics9[av50, ev50]
all a: lab.T0 | a.av50 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av50 = (P3)
not (R->P0 in ev50)
semantics9[av51, ev51]
all a: lab.T0 | a.av51 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av51 = ((P0 + (P3 + P4)))
not (R->P0 in ev51)
semantics2[av52, ev52]
all a: lab.T0 | a.av52 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av52 = ((P0 + P3))
not (R->P0 in ev52)
semantics7[av53, ev53]
all a: lab.T0 | a.av53 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av53 = (P4)
not (R->P0 in ev53)
semantics10[av54, ev54]
all a: lab.T0 | a.av54 = (none)
all a: lab.T1 | a.av54 = (P1)
not (R->P0 in ev54)
semantics9[av55, ev55]
all a: lab.T0 | a.av55 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av55 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev55)
semantics9[av56, ev56]
all a: lab.T0 | a.av56 = (P3)
all a: lab.T1 | a.av56 = (P2)
not (R->P0 in ev56)
semantics7[av57, ev57]
all a: lab.T0 | a.av57 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av57 = ((P1 + (P3 + P4)))
not (R->P0 in ev57)
semantics0[av58, ev58]
all a: lab.T0 | a.av58 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av58 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev58)
semantics9[av59, ev59]
all a: lab.T0 | a.av59 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av59 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev59)
semantics0[av60, ev60]
all a: lab.T0 | a.av60 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av60 = ((P0 + P3))
not (R->P0 in ev60)
semantics2[av61, ev61]
all a: lab.T0 | a.av61 = ((P0 + P2))
all a: lab.T1 | a.av61 = ((P1 + (P2 + P3)))
not (R->P0 in ev61)
semantics10[av62, ev62]
all a: lab.T0 | a.av62 = (P0)
all a: lab.T1 | a.av62 = (P1)
not (R->P0 in ev62)
semantics3[av63, ev63]
all a: lab.T0 | a.av63 = ((P2 + P4))
all a: lab.T1 | a.av63 = ((P0 + P1))
not (R->P0 in ev63)
semantics7[av64, ev64]
all a: lab.T0 | a.av64 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av64 = ((P0 + (P1 + P4)))
not (R->P0 in ev64)
semantics10[av65, ev65]
all a: lab.T0 | a.av65 = (P2)
all a: lab.T1 | a.av65 = ((P1 + P2))
not (R->P0 in ev65)
semantics3[av66, ev66]
all a: lab.T0 | a.av66 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av66 = ((P0 + (P2 + P4)))
not (R->P0 in ev66)
semantics0[av67, ev67]
all a: lab.T0 | a.av67 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av67 = (P1)
not (R->P0 in ev67)
semantics7[av68, ev68]
all a: lab.T0 | a.av68 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av68 = (P3)
not (R->P0 in ev68)
semantics3[av69, ev69]
all a: lab.T0 | a.av69 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av69 = ((P2 + P3))
not (R->P0 in ev69)
semantics14[av70, ev70]
all a: lab.T0 | a.av70 = ((P0 + P1))
all a: lab.T1 | a.av70 = (P1)
not (R->P0 in ev70)
semantics4[av71, ev71]
all a: lab.T0 | a.av71 = (P2)
all a: lab.T1 | a.av71 = ((P2 + P4))
not (R->P0 in ev71)
semantics5[av72, ev72]
all a: lab.T0 | a.av72 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av72 = ((P1 + P3))
not (R->P0 in ev72)
semantics3[av73, ev73]
all a: lab.T0 | a.av73 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av73 = ((P0 + (P1 + P2)))
not (R->P0 in ev73)
semantics3[av74, ev74]
all a: lab.T0 | a.av74 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av74 = ((P0 + P1))
not (R->P0 in ev74)
semantics3[av75, ev75]
all a: lab.T0 | a.av75 = ((P2 + P3))
all a: lab.T1 | a.av75 = ((P0 + (P1 + P3)))
not (R->P0 in ev75)
semantics3[av76, ev76]
all a: lab.T0 | a.av76 = ((P2 + P4))
all a: lab.T1 | a.av76 = ((P0 + (P1 + P4)))
not (R->P0 in ev76)
semantics7[av77, ev77]
all a: lab.T0 | a.av77 = ((P0 + P2))
all a: lab.T1 | a.av77 = ((P0 + (P2 + P4)))
not (R->P0 in ev77)
semantics0[av78, ev78]
all a: lab.T0 | a.av78 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av78 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev78)
semantics3[av79, ev79]
all a: lab.T0 | a.av79 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av79 = ((P1 + (P2 + P4)))
not (R->P0 in ev79)
semantics9[av80, ev80]
all a: lab.T0 | a.av80 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av80 = ((P0 + (P1 + P4)))
not (R->P0 in ev80)
semantics3[av81, ev81]
all a: lab.T0 | a.av81 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av81 = ((P1 + P2))
not (R->P0 in ev81)
semantics3[av82, ev82]
all a: lab.T0 | a.av82 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av82 = (none)
not (R->P0 in ev82)
semantics9[av83, ev83]
all a: lab.T0 | a.av83 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av83 = ((P0 + (P1 + P3)))
not (R->P0 in ev83)
semantics0[av84, ev84]
all a: lab.T0 | a.av84 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av84 = (P2)
not (R->P0 in ev84)
semantics9[av85, ev85]
all a: lab.T0 | a.av85 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av85 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev85)
semantics2[av86, ev86]
all a: lab.T0 | a.av86 = (P3)
all a: lab.T1 | a.av86 = (P0)
not (R->P0 in ev86)
semantics7[av87, ev87]
all a: lab.T0 | a.av87 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av87 = (P4)
not (R->P0 in ev87)
semantics3[av88, ev88]
all a: lab.T0 | a.av88 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av88 = ((P2 + (P3 + P4)))
not (R->P0 in ev88)
semantics0[av89, ev89]
all a: lab.T0 | a.av89 = ((P0 + P1))
all a: lab.T1 | a.av89 = ((P2 + P3))
not (R->P0 in ev89)
semantics3[av90, ev90]
all a: lab.T0 | a.av90 = ((P0 + P2))
all a: lab.T1 | a.av90 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev90)
semantics0[av91, ev91]
all a: lab.T0 | a.av91 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av91 = ((P0 + P3))
not (R->P0 in ev91)
semantics7[av92, ev92]
all a: lab.T0 | a.av92 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av92 = (P1)
not (R->P0 in ev92)
semantics0[av93, ev93]
all a: lab.T0 | a.av93 = ((P0 + P4))
all a: lab.T1 | a.av93 = ((P2 + P3))
not (R->P0 in ev93)
semantics7[av94, ev94]
all a: lab.T0 | a.av94 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av94 = ((P0 + P3))
not (R->P0 in ev94)
semantics4[av95, ev95]
all a: lab.T0 | a.av95 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av95 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev95)
semantics3[av96, ev96]
all a: lab.T0 | a.av96 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av96 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev96)
semantics9[av97, ev97]
all a: lab.T0 | a.av97 = ((P1 + P2))
all a: lab.T1 | a.av97 = ((P0 + P3))
not (R->P0 in ev97)
semantics0[av98, ev98]
all a: lab.T0 | a.av98 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av98 = ((P1 + P2))
not (R->P0 in ev98)
semantics7[av99, ev99]
all a: lab.T0 | a.av99 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av99 = ((P1 + (P2 + P3)))
not (R->P0 in ev99)
semantics4[av100, ev100]
all a: lab.T0 | a.av100 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av100 = ((P0 + P4))
not (R->P0 in ev100)
semantics7[av101, ev101]
all a: lab.T0 | a.av101 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av101 = ((P1 + (P2 + P4)))
not (R->P0 in ev101)
semantics9[av102, ev102]
all a: lab.T0 | a.av102 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av102 = ((P1 + P3))
not (R->P0 in ev102)
semantics11[av103, ev103]
all a: lab.T0 | a.av103 = ((P1 + P3))
all a: lab.T1 | a.av103 = ((P0 + (P1 + P2)))
not (R->P0 in ev103)
semantics9[av104, ev104]
all a: lab.T0 | a.av104 = (none)
all a: lab.T1 | a.av104 = (P1)
not (R->P0 in ev104)
semantics5[av105, ev105]
all a: lab.T0 | a.av105 = ((P0 + P3))
all a: lab.T1 | a.av105 = (P3)
not (R->P0 in ev105)
semantics3[av106, ev106]
all a: lab.T0 | a.av106 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av106 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev106)
semantics9[av107, ev107]
all a: lab.T0 | a.av107 = ((P0 + P1))
all a: lab.T1 | a.av107 = ((P0 + P3))
not (R->P0 in ev107)
semantics4[av108, ev108]
all a: lab.T0 | a.av108 = ((P2 + P3))
all a: lab.T1 | a.av108 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev108)
semantics9[av109, ev109]
all a: lab.T0 | a.av109 = ((P0 + P2))
all a: lab.T1 | a.av109 = ((P0 + P2))
not (R->P0 in ev109)
semantics9[av110, ev110]
all a: lab.T0 | a.av110 = ((P0 + P1))
all a: lab.T1 | a.av110 = (none)
not (R->P0 in ev110)
semantics7[av111, ev111]
all a: lab.T0 | a.av111 = ((P1 + P3))
all a: lab.T1 | a.av111 = ((P1 + (P2 + P4)))
not (R->P0 in ev111)
semantics9[av112, ev112]
all a: lab.T0 | a.av112 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av112 = ((P2 + (P3 + P4)))
not (R->P0 in ev112)
semantics9[av113, ev113]
all a: lab.T0 | a.av113 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av113 = (P1)
not (R->P0 in ev113)
semantics9[av114, ev114]
all a: lab.T0 | a.av114 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av114 = ((P1 + P4))
not (R->P0 in ev114)
semantics7[av115, ev115]
all a: lab.T0 | a.av115 = ((P3 + P4))
all a: lab.T1 | a.av115 = ((P0 + (P1 + P3)))
not (R->P0 in ev115)
semantics3[av116, ev116]
all a: lab.T0 | a.av116 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av116 = ((P1 + (P2 + P3)))
not (R->P0 in ev116)
semantics0[av117, ev117]
all a: lab.T0 | a.av117 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av117 = ((P2 + (P3 + P4)))
not (R->P0 in ev117)
semantics7[av118, ev118]
all a: lab.T0 | a.av118 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av118 = (none)
not (R->P0 in ev118)
semantics2[av119, ev119]
all a: lab.T0 | a.av119 = ((P0 + P2))
all a: lab.T1 | a.av119 = (P3)
not (R->P0 in ev119)
semantics2[av120, ev120]
all a: lab.T0 | a.av120 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av120 = ((P0 + (P1 + P2)))
not (R->P0 in ev120)
semantics3[av121, ev121]
all a: lab.T0 | a.av121 = ((P1 + P2))
all a: lab.T1 | a.av121 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev121)
semantics9[av122, ev122]
all a: lab.T0 | a.av122 = ((P1 + P4))
all a: lab.T1 | a.av122 = ((P0 + P3))
not (R->P0 in ev122)
semantics4[av123, ev123]
all a: lab.T0 | a.av123 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av123 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev123)
semantics0[av124, ev124]
all a: lab.T0 | a.av124 = (P3)
all a: lab.T1 | a.av124 = ((P0 + (P2 + P3)))
not (R->P0 in ev124)
semantics3[av125, ev125]
all a: lab.T0 | a.av125 = ((P3 + P4))
all a: lab.T1 | a.av125 = ((P0 + (P1 + P3)))
not (R->P0 in ev125)
semantics7[av126, ev126]
all a: lab.T0 | a.av126 = (P4)
all a: lab.T1 | a.av126 = ((P2 + P4))
not (R->P0 in ev126)
semantics0[av127, ev127]
all a: lab.T0 | a.av127 = ((P2 + P4))
all a: lab.T1 | a.av127 = ((P0 + P3))
not (R->P0 in ev127)
semantics2[av128, ev128]
all a: lab.T0 | a.av128 = (P3)
all a: lab.T1 | a.av128 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev128)
semantics7[av129, ev129]
all a: lab.T0 | a.av129 = ((P0 + P1))
all a: lab.T1 | a.av129 = (P4)
not (R->P0 in ev129)
semantics0[av130, ev130]
all a: lab.T0 | a.av130 = ((P1 + P4))
all a: lab.T1 | a.av130 = ((P0 + (P2 + P4)))
not (R->P0 in ev130)
semantics0[av131, ev131]
all a: lab.T0 | a.av131 = (P0)
all a: lab.T1 | a.av131 = ((P0 + (P2 + P4)))
not (R->P0 in ev131)
semantics14[av132, ev132]
all a: lab.T0 | a.av132 = ((P0 + P2))
all a: lab.T1 | a.av132 = ((P0 + P3))
not (R->P0 in ev132)
semantics5[av133, ev133]
all a: lab.T0 | a.av133 = (P3)
all a: lab.T1 | a.av133 = ((P1 + P3))
not (R->P0 in ev133)
semantics9[av134, ev134]
all a: lab.T0 | a.av134 = ((P0 + P1))
all a: lab.T1 | a.av134 = ((P1 + P2))
not (R->P0 in ev134)
semantics7[av135, ev135]
all a: lab.T0 | a.av135 = (none)
all a: lab.T1 | a.av135 = ((P0 + (P1 + P2)))
not (R->P0 in ev135)
semantics9[av136, ev136]
all a: lab.T0 | a.av136 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av136 = ((P3 + P4))
not (R->P0 in ev136)
semantics3[av137, ev137]
all a: lab.T0 | a.av137 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av137 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev137)
semantics7[av138, ev138]
all a: lab.T0 | a.av138 = (P2)
all a: lab.T1 | a.av138 = (P4)
not (R->P0 in ev138)
semantics0[av139, ev139]
all a: lab.T0 | a.av139 = ((P0 + P4))
all a: lab.T1 | a.av139 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev139)
semantics0[av140, ev140]
all a: lab.T0 | a.av140 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av140 = (P1)
not (R->P0 in ev140)
semantics0[av141, ev141]
all a: lab.T0 | a.av141 = ((P2 + P3))
all a: lab.T1 | a.av141 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev141)
semantics3[av142, ev142]
all a: lab.T0 | a.av142 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av142 = ((P0 + (P1 + P3)))
not (R->P0 in ev142)
semantics0[av143, ev143]
all a: lab.T0 | a.av143 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av143 = ((P1 + (P2 + P4)))
not (R->P0 in ev143)
semantics0[av144, ev144]
all a: lab.T0 | a.av144 = ((P1 + P4))
all a: lab.T1 | a.av144 = ((P1 + (P3 + P4)))
not (R->P0 in ev144)
semantics7[av145, ev145]
all a: lab.T0 | a.av145 = ((P0 + P1))
all a: lab.T1 | a.av145 = ((P1 + (P2 + P3)))
not (R->P0 in ev145)
semantics14[av146, ev146]
all a: lab.T0 | a.av146 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av146 = (P2)
not (R->P0 in ev146)
semantics2[av147, ev147]
all a: lab.T0 | a.av147 = ((P0 + P3))
all a: lab.T1 | a.av147 = ((P0 + (P1 + P3)))
not (R->P0 in ev147)
semantics7[av148, ev148]
all a: lab.T0 | a.av148 = (P0)
all a: lab.T1 | a.av148 = ((P0 + P2))
not (R->P0 in ev148)
semantics4[av149, ev149]
all a: lab.T0 | a.av149 = (P4)
all a: lab.T1 | a.av149 = (P0)
not (R->P0 in ev149)
semantics0[av150, ev150]
all a: lab.T0 | a.av150 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av150 = ((P1 + P3))
not (R->P0 in ev150)
semantics12[av151, ev151]
all a: lab.T0 | a.av151 = ((P1 + P2))
all a: lab.T1 | a.av151 = (P2)
not (R->P0 in ev151)
semantics5[av152, ev152]
all a: lab.T0 | a.av152 = ((P0 + P2))
all a: lab.T1 | a.av152 = ((P0 + P1))
not (R->P0 in ev152)
semantics5[av153, ev153]
all a: lab.T0 | a.av153 = ((P0 + P1))
all a: lab.T1 | a.av153 = ((P0 + (P1 + P2)))
not (R->P0 in ev153)
semantics2[av154, ev154]
all a: lab.T0 | a.av154 = (P2)
all a: lab.T1 | a.av154 = ((P1 + P3))
not (R->P0 in ev154)
semantics2[av155, ev155]
all a: lab.T0 | a.av155 = ((P0 + P3))
all a: lab.T1 | a.av155 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev155)
semantics2[av156, ev156]
all a: lab.T0 | a.av156 = ((P1 + P2))
all a: lab.T1 | a.av156 = ((P0 + P3))
not (R->P0 in ev156)
semantics7[av157, ev157]
all a: lab.T0 | a.av157 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av157 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev157)
semantics2[av158, ev158]
all a: lab.T0 | a.av158 = ((P0 + P2))
all a: lab.T1 | a.av158 = ((P0 + P3))
not (R->P0 in ev158)
semantics7[av159, ev159]
all a: lab.T0 | a.av159 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av159 = ((P0 + (P1 + P2)))
not (R->P0 in ev159)
semantics0[av160, ev160]
all a: lab.T0 | a.av160 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av160 = ((P0 + (P1 + P3)))
not (R->P0 in ev160)
semantics3[av161, ev161]
all a: lab.T0 | a.av161 = (none)
all a: lab.T1 | a.av161 = ((P0 + (P3 + P4)))
not (R->P0 in ev161)
semantics13[av162, ev162]
all a: lab.T0 | a.av162 = (P0)
all a: lab.T1 | a.av162 = ((P1 + P2))
not (R->P0 in ev162)
semantics3[av163, ev163]
all a: lab.T0 | a.av163 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av163 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev163)
semantics7[av164, ev164]
all a: lab.T0 | a.av164 = (none)
all a: lab.T1 | a.av164 = ((P0 + P3))
not (R->P0 in ev164)
semantics10[av165, ev165]
all a: lab.T0 | a.av165 = ((P0 + P2))
all a: lab.T1 | a.av165 = ((P0 + (P1 + P2)))
not (R->P0 in ev165)
semantics4[av166, ev166]
all a: lab.T0 | a.av166 = ((P1 + P2))
all a: lab.T1 | a.av166 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev166)
semantics11[av167, ev167]
all a: lab.T0 | a.av167 = (P3)
all a: lab.T1 | a.av167 = ((P1 + P3))
not (R->P0 in ev167)
semantics7[av168, ev168]
all a: lab.T0 | a.av168 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av168 = ((P1 + P4))
not (R->P0 in ev168)
semantics9[av169, ev169]
all a: lab.T0 | a.av169 = ((P1 + P4))
all a: lab.T1 | a.av169 = ((P0 + (P2 + P3)))
not (R->P0 in ev169)
semantics9[av170, ev170]
all a: lab.T0 | a.av170 = ((P0 + P2))
all a: lab.T1 | a.av170 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev170)
semantics3[av171, ev171]
all a: lab.T0 | a.av171 = ((P1 + P3))
all a: lab.T1 | a.av171 = (P0)
not (R->P0 in ev171)
semantics4[av172, ev172]
all a: lab.T0 | a.av172 = (P4)
all a: lab.T1 | a.av172 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev172)
semantics7[av173, ev173]
all a: lab.T0 | a.av173 = ((P1 + P4))
all a: lab.T1 | a.av173 = ((P1 + P4))
not (R->P0 in ev173)
semantics14[av174, ev174]
all a: lab.T0 | a.av174 = (P2)
all a: lab.T1 | a.av174 = ((P0 + (P1 + P2)))
not (R->P0 in ev174)
semantics0[av175, ev175]
all a: lab.T0 | a.av175 = ((P2 + P3))
all a: lab.T1 | a.av175 = ((P0 + P3))
not (R->P0 in ev175)
semantics0[av176, ev176]
all a: lab.T0 | a.av176 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av176 = ((P2 + P4))
not (R->P0 in ev176)
semantics9[av177, ev177]
all a: lab.T0 | a.av177 = (P3)
all a: lab.T1 | a.av177 = ((P1 + P2))
not (R->P0 in ev177)
semantics0[av178, ev178]
all a: lab.T0 | a.av178 = (P4)
all a: lab.T1 | a.av178 = ((P0 + (P2 + P3)))
not (R->P0 in ev178)
semantics3[av179, ev179]
all a: lab.T0 | a.av179 = (P1)
all a: lab.T1 | a.av179 = ((P1 + (P2 + P3)))
not (R->P0 in ev179)
semantics0[av180, ev180]
all a: lab.T0 | a.av180 = ((P0 + P3))
all a: lab.T1 | a.av180 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev180)
semantics0[av181, ev181]
all a: lab.T0 | a.av181 = ((P2 + P3))
all a: lab.T1 | a.av181 = ((P2 + P4))
not (R->P0 in ev181)
semantics0[av182, ev182]
all a: lab.T0 | a.av182 = ((P3 + P4))
all a: lab.T1 | a.av182 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev182)
semantics14[av183, ev183]
all a: lab.T0 | a.av183 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av183 = ((P0 + P2))
not (R->P0 in ev183)
semantics12[av184, ev184]
all a: lab.T0 | a.av184 = ((P0 + P2))
all a: lab.T1 | a.av184 = ((P0 + P1))
not (R->P0 in ev184)
semantics2[av185, ev185]
all a: lab.T0 | a.av185 = (P3)
all a: lab.T1 | a.av185 = ((P0 + P2))
not (R->P0 in ev185)
semantics5[av186, ev186]
all a: lab.T0 | a.av186 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av186 = ((P0 + (P2 + P3)))
not (R->P0 in ev186)
semantics4[av187, ev187]
all a: lab.T0 | a.av187 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av187 = ((P0 + P2))
not (R->P0 in ev187)
semantics0[av188, ev188]
all a: lab.T0 | a.av188 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av188 = ((P1 + P3))
not (R->P0 in ev188)
semantics14[av189, ev189]
all a: lab.T0 | a.av189 = ((P1 + P3))
all a: lab.T1 | a.av189 = ((P0 + (P1 + P2)))
not (R->P0 in ev189)
semantics9[av190, ev190]
all a: lab.T0 | a.av190 = ((P2 + P4))
all a: lab.T1 | a.av190 = ((P1 + P3))
not (R->P0 in ev190)
semantics2[av191, ev191]
all a: lab.T0 | a.av191 = (P2)
all a: lab.T1 | a.av191 = ((P1 + P2))
not (R->P0 in ev191)
semantics4[av192, ev192]
all a: lab.T0 | a.av192 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av192 = ((P0 + (P1 + P4)))
not (R->P0 in ev192)
semantics3[av193, ev193]
all a: lab.T0 | a.av193 = ((P1 + P2))
all a: lab.T1 | a.av193 = ((P0 + P3))
not (R->P0 in ev193)
semantics4[av194, ev194]
all a: lab.T0 | a.av194 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av194 = ((P2 + P4))
not (R->P0 in ev194)
semantics9[av195, ev195]
all a: lab.T0 | a.av195 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av195 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev195)
semantics9[av196, ev196]
all a: lab.T0 | a.av196 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av196 = ((P0 + P2))
not (R->P0 in ev196)
semantics14[av197, ev197]
all a: lab.T0 | a.av197 = (P2)
all a: lab.T1 | a.av197 = ((P1 + (P2 + P3)))
not (R->P0 in ev197)
semantics9[av198, ev198]
all a: lab.T0 | a.av198 = ((P1 + P2))
all a: lab.T1 | a.av198 = ((P0 + (P2 + P3)))
not (R->P0 in ev198)
semantics0[av199, ev199]
all a: lab.T0 | a.av199 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av199 = ((P2 + P4))
not (R->P0 in ev199)
semantics4[av200, ev200]
all a: lab.T0 | a.av200 = ((P2 + P3))
all a: lab.T1 | a.av200 = ((P1 + P3))
not (R->P0 in ev200)
semantics7[av201, ev201]
all a: lab.T0 | a.av201 = (P1)
all a: lab.T1 | a.av201 = ((P0 + P2))
not (R->P0 in ev201)
semantics6[av202, ev202]
all a: lab.T0 | a.av202 = (P1)
all a: lab.T1 | a.av202 = (none)
not (R->P0 in ev202)
semantics9[av203, ev203]
all a: lab.T0 | a.av203 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av203 = ((P1 + P4))
not (R->P0 in ev203)
semantics0[av204, ev204]
all a: lab.T0 | a.av204 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av204 = (P4)
not (R->P0 in ev204)
semantics0[av205, ev205]
all a: lab.T0 | a.av205 = ((P0 + P2))
all a: lab.T1 | a.av205 = (P4)
not (R->P0 in ev205)
semantics9[av206, ev206]
all a: lab.T0 | a.av206 = ((P0 + P1))
all a: lab.T1 | a.av206 = ((P0 + P4))
not (R->P0 in ev206)
semantics3[av207, ev207]
all a: lab.T0 | a.av207 = ((P3 + P4))
all a: lab.T1 | a.av207 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev207)
semantics3[av208, ev208]
all a: lab.T0 | a.av208 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av208 = ((P0 + P1))
not (R->P0 in ev208)
semantics9[av209, ev209]
all a: lab.T0 | a.av209 = ((P1 + P2))
all a: lab.T1 | a.av209 = ((P1 + (P2 + P4)))
not (R->P0 in ev209)
semantics4[av210, ev210]
all a: lab.T0 | a.av210 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av210 = ((P2 + (P3 + P4)))
not (R->P0 in ev210)
semantics14[av211, ev211]
all a: lab.T0 | a.av211 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av211 = ((P0 + (P1 + P3)))
not (R->P0 in ev211)
semantics7[av212, ev212]
all a: lab.T0 | a.av212 = ((P0 + P1))
all a: lab.T1 | a.av212 = ((P1 + (P3 + P4)))
not (R->P0 in ev212)
semantics7[av213, ev213]
all a: lab.T0 | a.av213 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av213 = ((P3 + P4))
not (R->P0 in ev213)
semantics0[av214, ev214]
all a: lab.T0 | a.av214 = ((P0 + P3))
all a: lab.T1 | a.av214 = ((P0 + P1))
not (R->P0 in ev214)
semantics5[av215, ev215]
all a: lab.T0 | a.av215 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av215 = (P1)
not (R->P0 in ev215)
semantics4[av216, ev216]
all a: lab.T0 | a.av216 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av216 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev216)
semantics7[av217, ev217]
all a: lab.T0 | a.av217 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av217 = ((P0 + (P2 + P4)))
not (R->P0 in ev217)
semantics9[av218, ev218]
all a: lab.T0 | a.av218 = ((P0 + P2))
all a: lab.T1 | a.av218 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev218)
semantics4[av219, ev219]
all a: lab.T0 | a.av219 = (none)
all a: lab.T1 | a.av219 = ((P0 + (P2 + P3)))
not (R->P0 in ev219)
semantics4[av220, ev220]
all a: lab.T0 | a.av220 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av220 = (P2)
not (R->P0 in ev220)
semantics9[av221, ev221]
all a: lab.T0 | a.av221 = ((P1 + P2))
all a: lab.T1 | a.av221 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev221)
semantics14[av222, ev222]
all a: lab.T0 | a.av222 = ((P0 + P1))
all a: lab.T1 | a.av222 = ((P2 + P3))
not (R->P0 in ev222)
semantics3[av223, ev223]
all a: lab.T0 | a.av223 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av223 = ((P3 + P4))
not (R->P0 in ev223)
semantics3[av224, ev224]
all a: lab.T0 | a.av224 = ((P0 + P1))
all a: lab.T1 | a.av224 = ((P1 + P3))
not (R->P0 in ev224)
semantics6[av225, ev225]
all a: lab.T0 | a.av225 = (none)
all a: lab.T1 | a.av225 = (P1)
not (R->P0 in ev225)
semantics7[av226, ev226]
all a: lab.T0 | a.av226 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av226 = ((P0 + (P3 + P4)))
not (R->P0 in ev226)
semantics9[av227, ev227]
all a: lab.T0 | a.av227 = ((P0 + P2))
all a: lab.T1 | a.av227 = ((P0 + (P1 + P2)))
not (R->P0 in ev227)
semantics2[av228, ev228]
all a: lab.T0 | a.av228 = ((P0 + P3))
all a: lab.T1 | a.av228 = ((P0 + (P2 + P3)))
not (R->P0 in ev228)
semantics9[av229, ev229]
all a: lab.T0 | a.av229 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av229 = ((P1 + (P2 + P3)))
not (R->P0 in ev229)
semantics2[av230, ev230]
all a: lab.T0 | a.av230 = ((P1 + P3))
all a: lab.T1 | a.av230 = ((P0 + P1))
not (R->P0 in ev230)
semantics9[av231, ev231]
all a: lab.T0 | a.av231 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av231 = ((P2 + (P3 + P4)))
not (R->P0 in ev231)
semantics7[av232, ev232]
all a: lab.T0 | a.av232 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av232 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev232)
semantics3[av233, ev233]
all a: lab.T0 | a.av233 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av233 = ((P0 + P2))
not (R->P0 in ev233)
semantics9[av234, ev234]
all a: lab.T0 | a.av234 = (none)
all a: lab.T1 | a.av234 = ((P1 + (P3 + P4)))
not (R->P0 in ev234)
semantics14[av235, ev235]
all a: lab.T0 | a.av235 = ((P2 + P3))
all a: lab.T1 | a.av235 = ((P0 + (P1 + P3)))
not (R->P0 in ev235)
semantics4[av236, ev236]
all a: lab.T0 | a.av236 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av236 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev236)
semantics9[av237, ev237]
all a: lab.T0 | a.av237 = ((P1 + P4))
all a: lab.T1 | a.av237 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev237)
semantics10[av238, ev238]
all a: lab.T0 | a.av238 = (none)
all a: lab.T1 | a.av238 = ((P0 + P1))
not (R->P0 in ev238)
semantics9[av239, ev239]
all a: lab.T0 | a.av239 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av239 = ((P0 + P3))
not (R->P0 in ev239)
semantics7[av240, ev240]
all a: lab.T0 | a.av240 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av240 = ((P0 + (P2 + P3)))
not (R->P0 in ev240)
semantics8[av241, ev241]
all a: lab.T0 | a.av241 = (P0)
all a: lab.T1 | a.av241 = (P0)
not (R->P0 in ev241)
semantics7[av242, ev242]
all a: lab.T0 | a.av242 = ((P0 + P3))
all a: lab.T1 | a.av242 = (P0)
not (R->P0 in ev242)
semantics9[av243, ev243]
all a: lab.T0 | a.av243 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av243 = ((P0 + (P2 + P3)))
not (R->P0 in ev243)
semantics0[av244, ev244]
all a: lab.T0 | a.av244 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av244 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev244)
semantics7[av245, ev245]
all a: lab.T0 | a.av245 = ((P0 + P3))
all a: lab.T1 | a.av245 = ((P0 + (P2 + P3)))
not (R->P0 in ev245)
semantics2[av246, ev246]
all a: lab.T0 | a.av246 = ((P1 + P3))
all a: lab.T1 | a.av246 = ((P0 + P2))
not (R->P0 in ev246)
semantics13[av247, ev247]
all a: lab.T0 | a.av247 = (P1)
all a: lab.T1 | a.av247 = (P2)
not (R->P0 in ev247)
semantics14[av248, ev248]
all a: lab.T0 | a.av248 = (P1)
all a: lab.T1 | a.av248 = (P0)
not (R->P0 in ev248)
semantics5[av249, ev249]
all a: lab.T0 | a.av249 = (P0)
all a: lab.T1 | a.av249 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev249)
semantics14[av250, ev250]
all a: lab.T0 | a.av250 = ((P0 + P2))
all a: lab.T1 | a.av250 = ((P2 + P3))
not (R->P0 in ev250)
semantics9[av251, ev251]
all a: lab.T0 | a.av251 = ((P1 + P2))
all a: lab.T1 | a.av251 = (P0)
not (R->P0 in ev251)
semantics7[av252, ev252]
all a: lab.T0 | a.av252 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av252 = ((P0 + P1))
not (R->P0 in ev252)
semantics9[av253, ev253]
all a: lab.T0 | a.av253 = (P0)
all a: lab.T1 | a.av253 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev253)
semantics10[av254, ev254]
all a: lab.T0 | a.av254 = ((P0 + P2))
all a: lab.T1 | a.av254 = (P0)
not (R->P0 in ev254)
semantics0[av255, ev255]
all a: lab.T0 | a.av255 = ((P0 + P3))
all a: lab.T1 | a.av255 = ((P2 + P4))
not (R->P0 in ev255)
semantics0[av256, ev256]
all a: lab.T0 | a.av256 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av256 = ((P1 + P3))
not (R->P0 in ev256)
semantics9[av257, ev257]
all a: lab.T0 | a.av257 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av257 = ((P0 + (P1 + P4)))
not (R->P0 in ev257)
semantics2[av258, ev258]
all a: lab.T0 | a.av258 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av258 = ((P2 + P3))
not (R->P0 in ev258)
semantics9[av259, ev259]
all a: lab.T0 | a.av259 = ((P1 + P2))
all a: lab.T1 | a.av259 = ((P1 + P4))
not (R->P0 in ev259)
semantics9[av260, ev260]
all a: lab.T0 | a.av260 = ((P2 + P4))
all a: lab.T1 | a.av260 = ((P0 + P3))
not (R->P0 in ev260)
semantics9[av261, ev261]
all a: lab.T0 | a.av261 = (P0)
all a: lab.T1 | a.av261 = ((P0 + (P2 + P3)))
not (R->P0 in ev261)
semantics7[av262, ev262]
all a: lab.T0 | a.av262 = ((P0 + P1))
all a: lab.T1 | a.av262 = ((P0 + P3))
not (R->P0 in ev262)
semantics7[av263, ev263]
all a: lab.T0 | a.av263 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av263 = ((P0 + (P2 + P3)))
not (R->P0 in ev263)
semantics4[av264, ev264]
all a: lab.T0 | a.av264 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av264 = (P1)
not (R->P0 in ev264)
semantics0[av265, ev265]
all a: lab.T0 | a.av265 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av265 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev265)
semantics9[av266, ev266]
all a: lab.T0 | a.av266 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av266 = ((P2 + P3))
not (R->P0 in ev266)
semantics4[av267, ev267]
all a: lab.T0 | a.av267 = (none)
all a: lab.T1 | a.av267 = (P4)
not (R->P0 in ev267)
semantics0[av268, ev268]
all a: lab.T0 | a.av268 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av268 = ((P0 + P4))
not (R->P0 in ev268)
semantics5[av269, ev269]
all a: lab.T0 | a.av269 = ((P1 + P3))
all a: lab.T1 | a.av269 = ((P0 + P3))
not (R->P0 in ev269)
semantics7[av270, ev270]
all a: lab.T0 | a.av270 = ((P0 + P2))
all a: lab.T1 | a.av270 = ((P1 + P3))
not (R->P0 in ev270)
semantics0[av271, ev271]
all a: lab.T0 | a.av271 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av271 = ((P1 + P4))
not (R->P0 in ev271)
semantics9[av272, ev272]
all a: lab.T0 | a.av272 = (P4)
all a: lab.T1 | a.av272 = (P2)
not (R->P0 in ev272)
semantics14[av273, ev273]
all a: lab.T0 | a.av273 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av273 = ((P0 + P2))
not (R->P0 in ev273)
semantics2[av274, ev274]
all a: lab.T0 | a.av274 = ((P0 + P3))
all a: lab.T1 | a.av274 = (none)
not (R->P0 in ev274)
semantics4[av275, ev275]
all a: lab.T0 | a.av275 = ((P1 + P3))
all a: lab.T1 | a.av275 = ((P2 + P3))
not (R->P0 in ev275)
semantics7[av276, ev276]
all a: lab.T0 | a.av276 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av276 = (P3)
not (R->P0 in ev276)
semantics9[av277, ev277]
all a: lab.T0 | a.av277 = (P2)
all a: lab.T1 | a.av277 = ((P1 + P3))
not (R->P0 in ev277)
semantics2[av278, ev278]
all a: lab.T0 | a.av278 = (P3)
all a: lab.T1 | a.av278 = ((P1 + P2))
not (R->P0 in ev278)
semantics14[av279, ev279]
all a: lab.T0 | a.av279 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av279 = ((P2 + P3))
not (R->P0 in ev279)
semantics14[av280, ev280]
all a: lab.T0 | a.av280 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av280 = (P3)
not (R->P0 in ev280)
semantics3[av281, ev281]
all a: lab.T0 | a.av281 = ((P1 + P2))
all a: lab.T1 | a.av281 = ((P1 + (P3 + P4)))
not (R->P0 in ev281)
semantics4[av282, ev282]
all a: lab.T0 | a.av282 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av282 = ((P1 + P3))
not (R->P0 in ev282)
semantics3[av283, ev283]
all a: lab.T0 | a.av283 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av283 = ((P1 + (P2 + P3)))
not (R->P0 in ev283)
semantics2[av284, ev284]
all a: lab.T0 | a.av284 = ((P1 + P3))
all a: lab.T1 | a.av284 = (P0)
not (R->P0 in ev284)
semantics3[av285, ev285]
all a: lab.T0 | a.av285 = ((P0 + P3))
all a: lab.T1 | a.av285 = ((P1 + P2))
not (R->P0 in ev285)
semantics0[av286, ev286]
all a: lab.T0 | a.av286 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av286 = ((P0 + (P2 + P4)))
not (R->P0 in ev286)
semantics4[av287, ev287]
all a: lab.T0 | a.av287 = ((P0 + P4))
all a: lab.T1 | a.av287 = ((P2 + P4))
not (R->P0 in ev287)
semantics0[av288, ev288]
all a: lab.T0 | a.av288 = ((P0 + P4))
all a: lab.T1 | a.av288 = ((P2 + P4))
not (R->P0 in ev288)
semantics9[av289, ev289]
all a: lab.T0 | a.av289 = ((P0 + P4))
all a: lab.T1 | a.av289 = ((P2 + P4))
not (R->P0 in ev289)
semantics0[av290, ev290]
all a: lab.T0 | a.av290 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av290 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev290)
semantics7[av291, ev291]
all a: lab.T0 | a.av291 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av291 = ((P3 + P4))
not (R->P0 in ev291)
semantics4[av292, ev292]
all a: lab.T0 | a.av292 = (P3)
all a: lab.T1 | a.av292 = ((P0 + (P1 + P4)))
not (R->P0 in ev292)
semantics10[av293, ev293]
all a: lab.T0 | a.av293 = ((P0 + P1))
all a: lab.T1 | a.av293 = ((P0 + P2))
not (R->P0 in ev293)
semantics7[av294, ev294]
all a: lab.T0 | a.av294 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av294 = ((P1 + (P2 + P4)))
not (R->P0 in ev294)
semantics0[av295, ev295]
all a: lab.T0 | a.av295 = ((P1 + P3))
all a: lab.T1 | a.av295 = (P3)
not (R->P0 in ev295)
semantics9[av296, ev296]
all a: lab.T0 | a.av296 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av296 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev296)
semantics11[av297, ev297]
all a: lab.T0 | a.av297 = ((P1 + P2))
all a: lab.T1 | a.av297 = (P2)
not (R->P0 in ev297)
semantics9[av298, ev298]
all a: lab.T0 | a.av298 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av298 = ((P0 + (P1 + P2)))
not (R->P0 in ev298)
semantics4[av299, ev299]
all a: lab.T0 | a.av299 = ((P1 + P3))
all a: lab.T1 | a.av299 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev299)
semantics9[av300, ev300]
all a: lab.T0 | a.av300 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av300 = (P0)
not (R->P0 in ev300)
semantics4[av301, ev301]
all a: lab.T0 | a.av301 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av301 = (P4)
not (R->P0 in ev301)
semantics4[av302, ev302]
all a: lab.T0 | a.av302 = (P4)
all a: lab.T1 | a.av302 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev302)
semantics9[av303, ev303]
all a: lab.T0 | a.av303 = ((P0 + P1))
all a: lab.T1 | a.av303 = (P0)
not (R->P0 in ev303)
semantics3[av304, ev304]
all a: lab.T0 | a.av304 = ((P0 + P1))
all a: lab.T1 | a.av304 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev304)
semantics2[av305, ev305]
all a: lab.T0 | a.av305 = ((P0 + P3))
all a: lab.T1 | a.av305 = ((P0 + P1))
not (R->P0 in ev305)
semantics7[av306, ev306]
all a: lab.T0 | a.av306 = ((P3 + P4))
all a: lab.T1 | a.av306 = ((P1 + P3))
not (R->P0 in ev306)
semantics9[av307, ev307]
all a: lab.T0 | a.av307 = ((P2 + P4))
all a: lab.T1 | a.av307 = ((P0 + P4))
not (R->P0 in ev307)
semantics10[av308, ev308]
all a: lab.T0 | a.av308 = (P1)
all a: lab.T1 | a.av308 = (P0)
not (R->P0 in ev308)
semantics4[av309, ev309]
all a: lab.T0 | a.av309 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av309 = ((P0 + (P2 + P4)))
not (R->P0 in ev309)
semantics0[av310, ev310]
all a: lab.T0 | a.av310 = (P4)
all a: lab.T1 | a.av310 = ((P2 + P3))
not (R->P0 in ev310)
semantics4[av311, ev311]
all a: lab.T0 | a.av311 = ((P1 + P3))
all a: lab.T1 | a.av311 = ((P1 + (P2 + P3)))
not (R->P0 in ev311)
semantics0[av312, ev312]
all a: lab.T0 | a.av312 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av312 = ((P1 + P2))
not (R->P0 in ev312)
semantics2[av313, ev313]
all a: lab.T0 | a.av313 = ((P0 + P1))
all a: lab.T1 | a.av313 = ((P1 + P2))
not (R->P0 in ev313)
semantics0[av314, ev314]
all a: lab.T0 | a.av314 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av314 = (P3)
not (R->P0 in ev314)
semantics9[av315, ev315]
all a: lab.T0 | a.av315 = (P2)
all a: lab.T1 | a.av315 = ((P2 + P4))
not (R->P0 in ev315)
semantics0[av316, ev316]
all a: lab.T0 | a.av316 = (P4)
all a: lab.T1 | a.av316 = ((P1 + P2))
not (R->P0 in ev316)
semantics5[av317, ev317]
all a: lab.T0 | a.av317 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av317 = (P3)
not (R->P0 in ev317)
semantics7[av318, ev318]
all a: lab.T0 | a.av318 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av318 = ((P2 + (P3 + P4)))
not (R->P0 in ev318)
semantics9[av319, ev319]
all a: lab.T0 | a.av319 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av319 = ((P2 + P3))
not (R->P0 in ev319)
semantics9[av320, ev320]
all a: lab.T0 | a.av320 = (P2)
all a: lab.T1 | a.av320 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev320)
semantics7[av321, ev321]
all a: lab.T0 | a.av321 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av321 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev321)
semantics9[av322, ev322]
all a: lab.T0 | a.av322 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av322 = ((P1 + (P3 + P4)))
not (R->P0 in ev322)
semantics9[av323, ev323]
all a: lab.T0 | a.av323 = (P1)
all a: lab.T1 | a.av323 = (none)
not (R->P0 in ev323)
semantics7[av324, ev324]
all a: lab.T0 | a.av324 = (P3)
all a: lab.T1 | a.av324 = ((P2 + P4))
not (R->P0 in ev324)
semantics0[av325, ev325]
all a: lab.T0 | a.av325 = (P4)
all a: lab.T1 | a.av325 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev325)
semantics2[av326, ev326]
all a: lab.T0 | a.av326 = (P2)
all a: lab.T1 | a.av326 = ((P1 + (P2 + P3)))
not (R->P0 in ev326)
semantics7[av327, ev327]
all a: lab.T0 | a.av327 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av327 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev327)
semantics10[av328, ev328]
all a: lab.T0 | a.av328 = (P1)
all a: lab.T1 | a.av328 = ((P0 + P2))
not (R->P0 in ev328)
semantics7[av329, ev329]
all a: lab.T0 | a.av329 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av329 = ((P0 + P3))
not (R->P0 in ev329)
semantics0[av330, ev330]
all a: lab.T0 | a.av330 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av330 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev330)
semantics11[av331, ev331]
all a: lab.T0 | a.av331 = (P3)
all a: lab.T1 | a.av331 = (P1)
not (R->P0 in ev331)
semantics7[av332, ev332]
all a: lab.T0 | a.av332 = (none)
all a: lab.T1 | a.av332 = ((P1 + (P3 + P4)))
not (R->P0 in ev332)
semantics9[av333, ev333]
all a: lab.T0 | a.av333 = (P0)
all a: lab.T1 | a.av333 = (none)
not (R->P0 in ev333)
semantics9[av334, ev334]
all a: lab.T0 | a.av334 = ((P0 + P4))
all a: lab.T1 | a.av334 = ((P1 + P3))
not (R->P0 in ev334)
semantics9[av335, ev335]
all a: lab.T0 | a.av335 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av335 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev335)
semantics4[av336, ev336]
all a: lab.T0 | a.av336 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av336 = ((P2 + P4))
not (R->P0 in ev336)
semantics2[av337, ev337]
all a: lab.T0 | a.av337 = (none)
all a: lab.T1 | a.av337 = ((P1 + P2))
not (R->P0 in ev337)
semantics7[av338, ev338]
all a: lab.T0 | a.av338 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av338 = ((P1 + P4))
not (R->P0 in ev338)
semantics9[av339, ev339]
all a: lab.T0 | a.av339 = (P0)
all a: lab.T1 | a.av339 = (P2)
not (R->P0 in ev339)
semantics2[av340, ev340]
all a: lab.T0 | a.av340 = ((P1 + P3))
all a: lab.T1 | a.av340 = ((P0 + (P1 + P3)))
not (R->P0 in ev340)
semantics4[av341, ev341]
all a: lab.T0 | a.av341 = ((P0 + P1))
all a: lab.T1 | a.av341 = ((P2 + P3))
not (R->P0 in ev341)
semantics2[av342, ev342]
all a: lab.T0 | a.av342 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av342 = (P1)
not (R->P0 in ev342)
semantics9[av343, ev343]
all a: lab.T0 | a.av343 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av343 = ((P1 + P2))
not (R->P0 in ev343)
semantics7[av344, ev344]
all a: lab.T0 | a.av344 = (P4)
all a: lab.T1 | a.av344 = ((P0 + (P1 + P3)))
not (R->P0 in ev344)
semantics5[av345, ev345]
all a: lab.T0 | a.av345 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av345 = ((P2 + P3))
not (R->P0 in ev345)
semantics2[av346, ev346]
all a: lab.T0 | a.av346 = (none)
all a: lab.T1 | a.av346 = ((P0 + (P1 + P3)))
not (R->P0 in ev346)
semantics3[av347, ev347]
all a: lab.T0 | a.av347 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av347 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev347)
semantics4[av348, ev348]
all a: lab.T0 | a.av348 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av348 = ((P0 + (P3 + P4)))
not (R->P0 in ev348)
semantics9[av349, ev349]
all a: lab.T0 | a.av349 = ((P0 + P1))
all a: lab.T1 | a.av349 = ((P0 + P2))
not (R->P0 in ev349)
semantics9[av350, ev350]
all a: lab.T0 | a.av350 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av350 = (P1)
not (R->P0 in ev350)
semantics7[av351, ev351]
all a: lab.T0 | a.av351 = ((P0 + P2))
all a: lab.T1 | a.av351 = ((P0 + P2))
not (R->P0 in ev351)
semantics4[av352, ev352]
all a: lab.T0 | a.av352 = ((P1 + P4))
all a: lab.T1 | a.av352 = ((P1 + (P2 + P3)))
not (R->P0 in ev352)
semantics7[av353, ev353]
all a: lab.T0 | a.av353 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av353 = (P4)
not (R->P0 in ev353)
semantics0[av354, ev354]
all a: lab.T0 | a.av354 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av354 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev354)
semantics3[av355, ev355]
all a: lab.T0 | a.av355 = (P2)
all a: lab.T1 | a.av355 = ((P2 + (P3 + P4)))
not (R->P0 in ev355)
semantics14[av356, ev356]
all a: lab.T0 | a.av356 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av356 = ((P2 + P3))
not (R->P0 in ev356)
semantics0[av357, ev357]
all a: lab.T0 | a.av357 = ((P3 + P4))
all a: lab.T1 | a.av357 = ((P1 + P3))
not (R->P0 in ev357)
semantics14[av358, ev358]
all a: lab.T0 | a.av358 = (P0)
all a: lab.T1 | a.av358 = ((P1 + P3))
not (R->P0 in ev358)
semantics0[av359, ev359]
all a: lab.T0 | a.av359 = (P4)
all a: lab.T1 | a.av359 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev359)
semantics5[av360, ev360]
all a: lab.T0 | a.av360 = ((P1 + P3))
all a: lab.T1 | a.av360 = ((P0 + (P1 + P3)))
not (R->P0 in ev360)
semantics11[av361, ev361]
all a: lab.T0 | a.av361 = ((P0 + P2))
all a: lab.T1 | a.av361 = ((P0 + P1))
not (R->P0 in ev361)
semantics0[av362, ev362]
all a: lab.T0 | a.av362 = (P4)
all a: lab.T1 | a.av362 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev362)
semantics4[av363, ev363]
all a: lab.T0 | a.av363 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av363 = ((P0 + P2))
not (R->P0 in ev363)
semantics4[av364, ev364]
all a: lab.T0 | a.av364 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av364 = (P4)
not (R->P0 in ev364)
semantics9[av365, ev365]
all a: lab.T0 | a.av365 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av365 = ((P1 + (P2 + P4)))
not (R->P0 in ev365)
semantics7[av366, ev366]
all a: lab.T0 | a.av366 = ((P2 + P3))
all a: lab.T1 | a.av366 = ((P0 + (P1 + P3)))
not (R->P0 in ev366)
semantics0[av367, ev367]
all a: lab.T0 | a.av367 = ((P3 + P4))
all a: lab.T1 | a.av367 = ((P0 + (P1 + P3)))
not (R->P0 in ev367)
semantics3[av368, ev368]
all a: lab.T0 | a.av368 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av368 = ((P0 + (P1 + P4)))
not (R->P0 in ev368)
semantics9[av369, ev369]
all a: lab.T0 | a.av369 = (P2)
all a: lab.T1 | a.av369 = ((P0 + (P2 + P4)))
not (R->P0 in ev369)
semantics5[av370, ev370]
all a: lab.T0 | a.av370 = (P0)
all a: lab.T1 | a.av370 = ((P1 + P3))
not (R->P0 in ev370)
semantics3[av371, ev371]
all a: lab.T0 | a.av371 = ((P0 + P2))
all a: lab.T1 | a.av371 = ((P0 + P1))
not (R->P0 in ev371)
semantics2[av372, ev372]
all a: lab.T0 | a.av372 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av372 = (P0)
not (R->P0 in ev372)
semantics9[av373, ev373]
all a: lab.T0 | a.av373 = ((P0 + P3))
all a: lab.T1 | a.av373 = (none)
not (R->P0 in ev373)
semantics3[av374, ev374]
all a: lab.T0 | a.av374 = ((P1 + P4))
all a: lab.T1 | a.av374 = (P4)
not (R->P0 in ev374)
semantics0[av375, ev375]
all a: lab.T0 | a.av375 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av375 = ((P1 + P4))
not (R->P0 in ev375)
semantics9[av376, ev376]
all a: lab.T0 | a.av376 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av376 = (P3)
not (R->P0 in ev376)
semantics11[av377, ev377]
all a: lab.T0 | a.av377 = ((P1 + P2))
all a: lab.T1 | a.av377 = (P1)
not (R->P0 in ev377)
semantics8[av378, ev378]
all a: lab.T0 | a.av378 = (none)
all a: lab.T1 | a.av378 = (P1)
not (R->P0 in ev378)
semantics4[av379, ev379]
all a: lab.T0 | a.av379 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av379 = ((P0 + (P2 + P3)))
not (R->P0 in ev379)
semantics9[av380, ev380]
all a: lab.T0 | a.av380 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av380 = ((P2 + P3))
not (R->P0 in ev380)
semantics9[av381, ev381]
all a: lab.T0 | a.av381 = ((P1 + P4))
all a: lab.T1 | a.av381 = ((P1 + P2))
not (R->P0 in ev381)
semantics7[av382, ev382]
all a: lab.T0 | a.av382 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av382 = ((P0 + (P1 + P2)))
not (R->P0 in ev382)
semantics0[av383, ev383]
all a: lab.T0 | a.av383 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av383 = (P3)
not (R->P0 in ev383)
semantics3[av384, ev384]
all a: lab.T0 | a.av384 = ((P0 + P1))
all a: lab.T1 | a.av384 = ((P1 + P4))
not (R->P0 in ev384)
semantics0[av385, ev385]
all a: lab.T0 | a.av385 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av385 = ((P0 + P1))
not (R->P0 in ev385)
semantics7[av386, ev386]
all a: lab.T0 | a.av386 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av386 = ((P0 + P3))
not (R->P0 in ev386)
semantics4[av387, ev387]
all a: lab.T0 | a.av387 = (P2)
all a: lab.T1 | a.av387 = ((P1 + P4))
not (R->P0 in ev387)
semantics4[av388, ev388]
all a: lab.T0 | a.av388 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av388 = ((P0 + P1))
not (R->P0 in ev388)
semantics4[av389, ev389]
all a: lab.T0 | a.av389 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av389 = ((P2 + P3))
not (R->P0 in ev389)
semantics6[av390, ev390]
all a: lab.T0 | a.av390 = (P1)
all a: lab.T1 | a.av390 = (P0)
not (R->P0 in ev390)
semantics7[av391, ev391]
all a: lab.T0 | a.av391 = ((P1 + P2))
all a: lab.T1 | a.av391 = ((P1 + (P2 + P4)))
not (R->P0 in ev391)
semantics7[av392, ev392]
all a: lab.T0 | a.av392 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av392 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev392)
semantics7[av393, ev393]
all a: lab.T0 | a.av393 = (P3)
all a: lab.T1 | a.av393 = ((P0 + (P2 + P3)))
not (R->P0 in ev393)
semantics3[av394, ev394]
all a: lab.T0 | a.av394 = (P4)
all a: lab.T1 | a.av394 = ((P0 + (P1 + P2)))
not (R->P0 in ev394)
semantics9[av395, ev395]
all a: lab.T0 | a.av395 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av395 = ((P0 + (P2 + P3)))
not (R->P0 in ev395)
semantics0[av396, ev396]
all a: lab.T0 | a.av396 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av396 = ((P0 + (P2 + P4)))
not (R->P0 in ev396)
semantics9[av397, ev397]
all a: lab.T0 | a.av397 = (none)
all a: lab.T1 | a.av397 = ((P0 + P4))
not (R->P0 in ev397)
semantics9[av398, ev398]
all a: lab.T0 | a.av398 = ((P2 + P3))
all a: lab.T1 | a.av398 = ((P0 + (P2 + P3)))
not (R->P0 in ev398)
semantics11[av399, ev399]
all a: lab.T0 | a.av399 = ((P0 + P3))
all a: lab.T1 | a.av399 = (P1)
not (R->P0 in ev399)
semantics0[av400, ev400]
all a: lab.T0 | a.av400 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av400 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev400)
semantics2[av401, ev401]
all a: lab.T0 | a.av401 = (P3)
all a: lab.T1 | a.av401 = (P2)
not (R->P0 in ev401)
semantics7[av402, ev402]
all a: lab.T0 | a.av402 = (P4)
all a: lab.T1 | a.av402 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev402)
semantics3[av403, ev403]
all a: lab.T0 | a.av403 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av403 = ((P0 + (P1 + P4)))
not (R->P0 in ev403)
semantics2[av404, ev404]
all a: lab.T0 | a.av404 = ((P0 + P2))
all a: lab.T1 | a.av404 = (P0)
not (R->P0 in ev404)
semantics0[av405, ev405]
all a: lab.T0 | a.av405 = ((P0 + P3))
all a: lab.T1 | a.av405 = ((P0 + P2))
not (R->P0 in ev405)
semantics4[av406, ev406]
all a: lab.T0 | a.av406 = ((P0 + P3))
all a: lab.T1 | a.av406 = ((P1 + P2))
not (R->P0 in ev406)
semantics9[av407, ev407]
all a: lab.T0 | a.av407 = ((P1 + P3))
all a: lab.T1 | a.av407 = ((P2 + P3))
not (R->P0 in ev407)
semantics14[av408, ev408]
all a: lab.T0 | a.av408 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av408 = (P1)
not (R->P0 in ev408)
semantics9[av409, ev409]
all a: lab.T0 | a.av409 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av409 = ((P0 + P1))
not (R->P0 in ev409)
semantics3[av410, ev410]
all a: lab.T0 | a.av410 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av410 = ((P0 + P4))
not (R->P0 in ev410)
semantics0[av411, ev411]
all a: lab.T0 | a.av411 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av411 = ((P1 + P2))
not (R->P0 in ev411)
semantics10[av412, ev412]
all a: lab.T0 | a.av412 = ((P0 + P2))
all a: lab.T1 | a.av412 = (P1)
not (R->P0 in ev412)
semantics12[av413, ev413]
all a: lab.T0 | a.av413 = ((P0 + P1))
all a: lab.T1 | a.av413 = ((P1 + P2))
not (R->P0 in ev413)
semantics5[av414, ev414]
all a: lab.T0 | a.av414 = (P1)
all a: lab.T1 | a.av414 = ((P0 + (P2 + P3)))
not (R->P0 in ev414)
semantics4[av415, ev415]
all a: lab.T0 | a.av415 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av415 = (P3)
not (R->P0 in ev415)
semantics7[av416, ev416]
all a: lab.T0 | a.av416 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av416 = ((P1 + P4))
not (R->P0 in ev416)
semantics7[av417, ev417]
all a: lab.T0 | a.av417 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av417 = ((P1 + P3))
not (R->P0 in ev417)
semantics2[av418, ev418]
all a: lab.T0 | a.av418 = (P2)
all a: lab.T1 | a.av418 = ((P2 + P3))
not (R->P0 in ev418)
semantics9[av419, ev419]
all a: lab.T0 | a.av419 = ((P1 + P2))
all a: lab.T1 | a.av419 = ((P0 + (P1 + P2)))
not (R->P0 in ev419)
semantics14[av420, ev420]
all a: lab.T0 | a.av420 = ((P0 + P1))
all a: lab.T1 | a.av420 = ((P0 + (P2 + P3)))
not (R->P0 in ev420)
semantics10[av421, ev421]
all a: lab.T0 | a.av421 = (P0)
all a: lab.T1 | a.av421 = ((P0 + P2))
not (R->P0 in ev421)
semantics4[av422, ev422]
all a: lab.T0 | a.av422 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av422 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev422)
semantics3[av423, ev423]
all a: lab.T0 | a.av423 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av423 = ((P0 + (P1 + P3)))
not (R->P0 in ev423)
semantics5[av424, ev424]
all a: lab.T0 | a.av424 = (P0)
all a: lab.T1 | a.av424 = ((P1 + P2))
not (R->P0 in ev424)
semantics0[av425, ev425]
all a: lab.T0 | a.av425 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av425 = ((P0 + (P1 + P2)))
not (R->P0 in ev425)
semantics9[av426, ev426]
all a: lab.T0 | a.av426 = ((P0 + P1))
all a: lab.T1 | a.av426 = ((P0 + (P2 + P3)))
not (R->P0 in ev426)
semantics4[av427, ev427]
all a: lab.T0 | a.av427 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av427 = ((P0 + (P2 + P3)))
not (R->P0 in ev427)
semantics7[av428, ev428]
all a: lab.T0 | a.av428 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av428 = ((P1 + (P2 + P4)))
not (R->P0 in ev428)
semantics13[av429, ev429]
all a: lab.T0 | a.av429 = (P0)
all a: lab.T1 | a.av429 = ((P0 + (P1 + P2)))
not (R->P0 in ev429)
semantics9[av430, ev430]
all a: lab.T0 | a.av430 = ((P0 + P3))
all a: lab.T1 | a.av430 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev430)
semantics2[av431, ev431]
all a: lab.T0 | a.av431 = ((P1 + P3))
all a: lab.T1 | a.av431 = (P1)
not (R->P0 in ev431)
semantics2[av432, ev432]
all a: lab.T0 | a.av432 = ((P0 + P3))
all a: lab.T1 | a.av432 = ((P1 + P3))
not (R->P0 in ev432)
semantics7[av433, ev433]
all a: lab.T0 | a.av433 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av433 = ((P2 + P3))
not (R->P0 in ev433)
semantics3[av434, ev434]
all a: lab.T0 | a.av434 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av434 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev434)
semantics3[av435, ev435]
all a: lab.T0 | a.av435 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av435 = ((P0 + P3))
not (R->P0 in ev435)
semantics7[av436, ev436]
all a: lab.T0 | a.av436 = ((P0 + P2))
all a: lab.T1 | a.av436 = ((P0 + (P1 + P4)))
not (R->P0 in ev436)
semantics0[av437, ev437]
all a: lab.T0 | a.av437 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av437 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev437)
semantics3[av438, ev438]
all a: lab.T0 | a.av438 = ((P0 + P3))
all a: lab.T1 | a.av438 = ((P1 + (P2 + P3)))
not (R->P0 in ev438)
semantics9[av439, ev439]
all a: lab.T0 | a.av439 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av439 = (P4)
not (R->P0 in ev439)
semantics5[av440, ev440]
all a: lab.T0 | a.av440 = ((P1 + P2))
all a: lab.T1 | a.av440 = ((P1 + P2))
not (R->P0 in ev440)
semantics9[av441, ev441]
all a: lab.T0 | a.av441 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av441 = (P0)
not (R->P0 in ev441)
semantics3[av442, ev442]
all a: lab.T0 | a.av442 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av442 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev442)
semantics3[av443, ev443]
all a: lab.T0 | a.av443 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av443 = ((P2 + P4))
not (R->P0 in ev443)
semantics2[av444, ev444]
all a: lab.T0 | a.av444 = ((P0 + P2))
all a: lab.T1 | a.av444 = ((P1 + P2))
not (R->P0 in ev444)
semantics4[av445, ev445]
all a: lab.T0 | a.av445 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av445 = (P0)
not (R->P0 in ev445)
semantics7[av446, ev446]
all a: lab.T0 | a.av446 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av446 = ((P1 + P3))
not (R->P0 in ev446)
semantics13[av447, ev447]
all a: lab.T0 | a.av447 = (P2)
all a: lab.T1 | a.av447 = (P1)
not (R->P0 in ev447)
semantics0[av448, ev448]
all a: lab.T0 | a.av448 = ((P3 + P4))
all a: lab.T1 | a.av448 = ((P0 + P4))
not (R->P0 in ev448)
semantics3[av449, ev449]
all a: lab.T0 | a.av449 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av449 = ((P0 + P1))
not (R->P0 in ev449)
semantics4[av450, ev450]
all a: lab.T0 | a.av450 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av450 = ((P1 + P4))
not (R->P0 in ev450)
semantics7[av451, ev451]
all a: lab.T0 | a.av451 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av451 = ((P1 + (P3 + P4)))
not (R->P0 in ev451)
semantics9[av452, ev452]
all a: lab.T0 | a.av452 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av452 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev452)
semantics9[av453, ev453]
all a: lab.T0 | a.av453 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av453 = (P2)
not (R->P0 in ev453)
semantics9[av454, ev454]
all a: lab.T0 | a.av454 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av454 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev454)
semantics3[av455, ev455]
all a: lab.T0 | a.av455 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av455 = ((P1 + P4))
not (R->P0 in ev455)
semantics9[av456, ev456]
all a: lab.T0 | a.av456 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av456 = ((P1 + P4))
not (R->P0 in ev456)
semantics4[av457, ev457]
all a: lab.T0 | a.av457 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av457 = (P4)
not (R->P0 in ev457)
semantics9[av458, ev458]
all a: lab.T0 | a.av458 = (P0)
all a: lab.T1 | a.av458 = (P4)
not (R->P0 in ev458)
semantics4[av459, ev459]
all a: lab.T0 | a.av459 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av459 = ((P0 + (P2 + P3)))
not (R->P0 in ev459)
semantics4[av460, ev460]
all a: lab.T0 | a.av460 = (P1)
all a: lab.T1 | a.av460 = ((P0 + (P2 + P3)))
not (R->P0 in ev460)
semantics4[av461, ev461]
all a: lab.T0 | a.av461 = ((P1 + P3))
all a: lab.T1 | a.av461 = ((P0 + (P1 + P4)))
not (R->P0 in ev461)
semantics9[av462, ev462]
all a: lab.T0 | a.av462 = ((P1 + P2))
all a: lab.T1 | a.av462 = ((P2 + P3))
not (R->P0 in ev462)
semantics9[av463, ev463]
all a: lab.T0 | a.av463 = ((P1 + P3))
all a: lab.T1 | a.av463 = (P3)
not (R->P0 in ev463)
semantics9[av464, ev464]
all a: lab.T0 | a.av464 = ((P0 + P1))
all a: lab.T1 | a.av464 = (P2)
not (R->P0 in ev464)
semantics7[av465, ev465]
all a: lab.T0 | a.av465 = ((P2 + P3))
all a: lab.T1 | a.av465 = ((P1 + (P2 + P4)))
not (R->P0 in ev465)
semantics5[av466, ev466]
all a: lab.T0 | a.av466 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av466 = ((P1 + (P2 + P3)))
not (R->P0 in ev466)
semantics9[av467, ev467]
all a: lab.T0 | a.av467 = (P2)
all a: lab.T1 | a.av467 = ((P0 + P3))
not (R->P0 in ev467)
semantics2[av468, ev468]
all a: lab.T0 | a.av468 = ((P0 + P3))
all a: lab.T1 | a.av468 = ((P2 + P3))
not (R->P0 in ev468)
semantics5[av469, ev469]
all a: lab.T0 | a.av469 = ((P2 + P3))
all a: lab.T1 | a.av469 = (P3)
not (R->P0 in ev469)
semantics9[av470, ev470]
all a: lab.T0 | a.av470 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av470 = ((P1 + (P2 + P3)))
not (R->P0 in ev470)
semantics14[av471, ev471]
all a: lab.T0 | a.av471 = ((P0 + P3))
all a: lab.T1 | a.av471 = ((P1 + P3))
not (R->P0 in ev471)
semantics7[av472, ev472]
all a: lab.T0 | a.av472 = ((P0 + P3))
all a: lab.T1 | a.av472 = ((P2 + P4))
not (R->P0 in ev472)
semantics9[av473, ev473]
all a: lab.T0 | a.av473 = (P2)
all a: lab.T1 | a.av473 = (P3)
not (R->P0 in ev473)
semantics10[av474, ev474]
all a: lab.T0 | a.av474 = ((P0 + P2))
all a: lab.T1 | a.av474 = ((P1 + P2))
not (R->P0 in ev474)
semantics10[av475, ev475]
all a: lab.T0 | a.av475 = ((P0 + P1))
all a: lab.T1 | a.av475 = ((P1 + P2))
not (R->P0 in ev475)
semantics12[av476, ev476]
all a: lab.T0 | a.av476 = ((P0 + P2))
all a: lab.T1 | a.av476 = (P0)
not (R->P0 in ev476)
semantics4[av477, ev477]
all a: lab.T0 | a.av477 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av477 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev477)
semantics9[av478, ev478]
all a: lab.T0 | a.av478 = ((P0 + P2))
all a: lab.T1 | a.av478 = ((P1 + P2))
not (R->P0 in ev478)
semantics11[av479, ev479]
all a: lab.T0 | a.av479 = ((P0 + P2))
all a: lab.T1 | a.av479 = ((P0 + P3))
not (R->P0 in ev479)
semantics0[av480, ev480]
all a: lab.T0 | a.av480 = ((P0 + P3))
all a: lab.T1 | a.av480 = ((P1 + (P2 + P3)))
not (R->P0 in ev480)
semantics7[av481, ev481]
all a: lab.T0 | a.av481 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av481 = (P2)
not (R->P0 in ev481)
semantics0[av482, ev482]
all a: lab.T0 | a.av482 = ((P2 + P4))
all a: lab.T1 | a.av482 = (P3)
not (R->P0 in ev482)
semantics0[av483, ev483]
all a: lab.T0 | a.av483 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av483 = ((P0 + P4))
not (R->P0 in ev483)
semantics3[av484, ev484]
all a: lab.T0 | a.av484 = ((P2 + P4))
all a: lab.T1 | a.av484 = ((P0 + P4))
not (R->P0 in ev484)
semantics2[av485, ev485]
all a: lab.T0 | a.av485 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av485 = (P2)
not (R->P0 in ev485)
semantics7[av486, ev486]
all a: lab.T0 | a.av486 = (P1)
all a: lab.T1 | a.av486 = ((P0 + (P1 + P2)))
not (R->P0 in ev486)
semantics2[av487, ev487]
all a: lab.T0 | a.av487 = (P2)
all a: lab.T1 | a.av487 = ((P0 + (P1 + P3)))
not (R->P0 in ev487)
semantics7[av488, ev488]
all a: lab.T0 | a.av488 = (P4)
all a: lab.T1 | a.av488 = ((P0 + P2))
not (R->P0 in ev488)
semantics7[av489, ev489]
all a: lab.T0 | a.av489 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av489 = ((P0 + (P1 + P2)))
not (R->P0 in ev489)
semantics3[av490, ev490]
all a: lab.T0 | a.av490 = ((P1 + P3))
all a: lab.T1 | a.av490 = (P2)
not (R->P0 in ev490)
semantics3[av491, ev491]
all a: lab.T0 | a.av491 = ((P3 + P4))
all a: lab.T1 | a.av491 = (none)
not (R->P0 in ev491)
semantics0[av492, ev492]
all a: lab.T0 | a.av492 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av492 = ((P0 + P4))
not (R->P0 in ev492)
semantics9[av493, ev493]
all a: lab.T0 | a.av493 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av493 = (P0)
not (R->P0 in ev493)
semantics0[av494, ev494]
all a: lab.T0 | a.av494 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av494 = (P3)
not (R->P0 in ev494)
semantics4[av495, ev495]
all a: lab.T0 | a.av495 = ((P0 + P4))
all a: lab.T1 | a.av495 = ((P0 + (P1 + P2)))
not (R->P0 in ev495)
semantics7[av496, ev496]
all a: lab.T0 | a.av496 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av496 = ((P0 + (P2 + P4)))
not (R->P0 in ev496)
semantics9[av497, ev497]
all a: lab.T0 | a.av497 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av497 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev497)
semantics3[av498, ev498]
all a: lab.T0 | a.av498 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av498 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev498)
semantics2[av499, ev499]
all a: lab.T0 | a.av499 = (none)
all a: lab.T1 | a.av499 = (P2)
not (R->P0 in ev499)
semantics2[av500, ev500]
all a: lab.T0 | a.av500 = (P2)
all a: lab.T1 | a.av500 = ((P0 + P1))
not (R->P0 in ev500)
semantics4[av501, ev501]
all a: lab.T0 | a.av501 = ((P1 + P3))
all a: lab.T1 | a.av501 = ((P3 + P4))
not (R->P0 in ev501)
semantics7[av502, ev502]
all a: lab.T0 | a.av502 = ((P0 + P4))
all a: lab.T1 | a.av502 = ((P1 + (P2 + P4)))
not (R->P0 in ev502)
semantics0[av503, ev503]
all a: lab.T0 | a.av503 = (P2)
all a: lab.T1 | a.av503 = ((P1 + (P2 + P4)))
not (R->P0 in ev503)
semantics0[av504, ev504]
all a: lab.T0 | a.av504 = ((P0 + P2))
all a: lab.T1 | a.av504 = (P3)
not (R->P0 in ev504)
semantics3[av505, ev505]
all a: lab.T0 | a.av505 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av505 = ((P2 + P3))
not (R->P0 in ev505)
semantics9[av506, ev506]
all a: lab.T0 | a.av506 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av506 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev506)
semantics7[av507, ev507]
all a: lab.T0 | a.av507 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av507 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev507)
semantics7[av508, ev508]
all a: lab.T0 | a.av508 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av508 = (P3)
not (R->P0 in ev508)
semantics3[av509, ev509]
all a: lab.T0 | a.av509 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av509 = ((P0 + (P3 + P4)))
not (R->P0 in ev509)
semantics3[av510, ev510]
all a: lab.T0 | a.av510 = ((P2 + P4))
all a: lab.T1 | a.av510 = ((P1 + (P3 + P4)))
not (R->P0 in ev510)
semantics4[av511, ev511]
all a: lab.T0 | a.av511 = ((P2 + P3))
all a: lab.T1 | a.av511 = ((P1 + (P2 + P4)))
not (R->P0 in ev511)
semantics10[av512, ev512]
all a: lab.T0 | a.av512 = (none)
all a: lab.T1 | a.av512 = ((P0 + P2))
not (R->P0 in ev512)
semantics12[av513, ev513]
all a: lab.T0 | a.av513 = ((P1 + P2))
all a: lab.T1 | a.av513 = ((P0 + P1))
not (R->P0 in ev513)
semantics9[av514, ev514]
all a: lab.T0 | a.av514 = (P3)
all a: lab.T1 | a.av514 = ((P1 + P3))
not (R->P0 in ev514)
semantics5[av515, ev515]
all a: lab.T0 | a.av515 = ((P0 + P1))
all a: lab.T1 | a.av515 = ((P0 + P1))
not (R->P0 in ev515)
semantics9[av516, ev516]
all a: lab.T0 | a.av516 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av516 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev516)
semantics9[av517, ev517]
all a: lab.T0 | a.av517 = ((P0 + P1))
all a: lab.T1 | a.av517 = ((P0 + (P1 + P4)))
not (R->P0 in ev517)
semantics3[av518, ev518]
all a: lab.T0 | a.av518 = ((P3 + P4))
all a: lab.T1 | a.av518 = ((P2 + P4))
not (R->P0 in ev518)
semantics8[av519, ev519]
all a: lab.T0 | a.av519 = (P1)
all a: lab.T1 | a.av519 = (P1)
not (R->P0 in ev519)
semantics7[av520, ev520]
all a: lab.T0 | a.av520 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av520 = ((P0 + P2))
not (R->P0 in ev520)
semantics0[av521, ev521]
all a: lab.T0 | a.av521 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av521 = ((P1 + P4))
not (R->P0 in ev521)
semantics0[av522, ev522]
all a: lab.T0 | a.av522 = ((P0 + P4))
all a: lab.T1 | a.av522 = ((P0 + P4))
not (R->P0 in ev522)
semantics10[av523, ev523]
all a: lab.T0 | a.av523 = ((P1 + P2))
all a: lab.T1 | a.av523 = (P1)
not (R->P0 in ev523)
semantics7[av524, ev524]
all a: lab.T0 | a.av524 = ((P0 + P3))
all a: lab.T1 | a.av524 = ((P1 + P4))
not (R->P0 in ev524)
semantics7[av525, ev525]
all a: lab.T0 | a.av525 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av525 = (none)
not (R->P0 in ev525)
semantics3[av526, ev526]
all a: lab.T0 | a.av526 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av526 = (P1)
not (R->P0 in ev526)
semantics9[av527, ev527]
all a: lab.T0 | a.av527 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av527 = ((P0 + P1))
not (R->P0 in ev527)
semantics11[av528, ev528]
all a: lab.T0 | a.av528 = ((P2 + P3))
all a: lab.T1 | a.av528 = (P2)
not (R->P0 in ev528)
semantics7[av529, ev529]
all a: lab.T0 | a.av529 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av529 = ((P0 + P2))
not (R->P0 in ev529)
semantics4[av530, ev530]
all a: lab.T0 | a.av530 = (P1)
all a: lab.T1 | a.av530 = ((P1 + P4))
not (R->P0 in ev530)
semantics0[av531, ev531]
all a: lab.T0 | a.av531 = ((P1 + P2))
all a: lab.T1 | a.av531 = ((P2 + P3))
not (R->P0 in ev531)
semantics4[av532, ev532]
all a: lab.T0 | a.av532 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av532 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev532)
semantics3[av533, ev533]
all a: lab.T0 | a.av533 = ((P1 + P3))
all a: lab.T1 | a.av533 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev533)
semantics9[av534, ev534]
all a: lab.T0 | a.av534 = ((P3 + P4))
all a: lab.T1 | a.av534 = ((P2 + P4))
not (R->P0 in ev534)
semantics3[av535, ev535]
all a: lab.T0 | a.av535 = (P2)
all a: lab.T1 | a.av535 = ((P1 + (P2 + P3)))
not (R->P0 in ev535)
semantics3[av536, ev536]
all a: lab.T0 | a.av536 = ((P0 + P4))
all a: lab.T1 | a.av536 = ((P0 + (P2 + P4)))
not (R->P0 in ev536)
semantics11[av537, ev537]
all a: lab.T0 | a.av537 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av537 = ((P0 + (P1 + P2)))
not (R->P0 in ev537)
semantics2[av538, ev538]
all a: lab.T0 | a.av538 = (P2)
all a: lab.T1 | a.av538 = ((P0 + (P1 + P2)))
not (R->P0 in ev538)
semantics7[av539, ev539]
all a: lab.T0 | a.av539 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av539 = ((P0 + (P1 + P2)))
not (R->P0 in ev539)
semantics7[av540, ev540]
all a: lab.T0 | a.av540 = ((P0 + P3))
all a: lab.T1 | a.av540 = (P3)
not (R->P0 in ev540)
semantics4[av541, ev541]
all a: lab.T0 | a.av541 = (P3)
all a: lab.T1 | a.av541 = ((P0 + (P2 + P3)))
not (R->P0 in ev541)
semantics0[av542, ev542]
all a: lab.T0 | a.av542 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av542 = (P4)
not (R->P0 in ev542)
semantics0[av543, ev543]
all a: lab.T0 | a.av543 = ((P0 + P4))
all a: lab.T1 | a.av543 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev543)
semantics3[av544, ev544]
all a: lab.T0 | a.av544 = ((P0 + P3))
all a: lab.T1 | a.av544 = ((P0 + P1))
not (R->P0 in ev544)
semantics7[av545, ev545]
all a: lab.T0 | a.av545 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av545 = ((P3 + P4))
not (R->P0 in ev545)
semantics4[av546, ev546]
all a: lab.T0 | a.av546 = ((P1 + P2))
all a: lab.T1 | a.av546 = ((P1 + P3))
not (R->P0 in ev546)
semantics12[av547, ev547]
all a: lab.T0 | a.av547 = (P2)
all a: lab.T1 | a.av547 = (P2)
not (R->P0 in ev547)
semantics2[av548, ev548]
all a: lab.T0 | a.av548 = ((P0 + P3))
all a: lab.T1 | a.av548 = ((P1 + (P2 + P3)))
not (R->P0 in ev548)
semantics7[av549, ev549]
all a: lab.T0 | a.av549 = ((P2 + P3))
all a: lab.T1 | a.av549 = ((P3 + P4))
not (R->P0 in ev549)
semantics9[av550, ev550]
all a: lab.T0 | a.av550 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av550 = (P1)
not (R->P0 in ev550)
semantics9[av551, ev551]
all a: lab.T0 | a.av551 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av551 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev551)
semantics0[av552, ev552]
all a: lab.T0 | a.av552 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av552 = ((P1 + P3))
not (R->P0 in ev552)
semantics9[av553, ev553]
all a: lab.T0 | a.av553 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av553 = ((P0 + P4))
not (R->P0 in ev553)
semantics4[av554, ev554]
all a: lab.T0 | a.av554 = ((P1 + P4))
all a: lab.T1 | a.av554 = ((P3 + P4))
not (R->P0 in ev554)
semantics3[av555, ev555]
all a: lab.T0 | a.av555 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av555 = ((P0 + (P1 + P2)))
not (R->P0 in ev555)
semantics7[av556, ev556]
all a: lab.T0 | a.av556 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av556 = ((P0 + (P3 + P4)))
not (R->P0 in ev556)
semantics0[av557, ev557]
all a: lab.T0 | a.av557 = ((P0 + P3))
all a: lab.T1 | a.av557 = ((P1 + (P2 + P4)))
not (R->P0 in ev557)
semantics9[av558, ev558]
all a: lab.T0 | a.av558 = ((P1 + P4))
all a: lab.T1 | a.av558 = (P2)
not (R->P0 in ev558)
semantics0[av559, ev559]
all a: lab.T0 | a.av559 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av559 = (P3)
not (R->P0 in ev559)
semantics0[av560, ev560]
all a: lab.T0 | a.av560 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av560 = (P0)
not (R->P0 in ev560)
semantics3[av561, ev561]
all a: lab.T0 | a.av561 = (P2)
all a: lab.T1 | a.av561 = ((P0 + (P2 + P4)))
not (R->P0 in ev561)
semantics7[av562, ev562]
all a: lab.T0 | a.av562 = ((P2 + P4))
all a: lab.T1 | a.av562 = ((P1 + (P2 + P3)))
not (R->P0 in ev562)
semantics2[av563, ev563]
all a: lab.T0 | a.av563 = (P3)
all a: lab.T1 | a.av563 = (none)
not (R->P0 in ev563)
semantics12[av564, ev564]
all a: lab.T0 | a.av564 = ((P0 + P1))
all a: lab.T1 | a.av564 = ((P0 + (P1 + P2)))
not (R->P0 in ev564)
semantics9[av565, ev565]
all a: lab.T0 | a.av565 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av565 = ((P1 + P2))
not (R->P0 in ev565)
semantics0[av566, ev566]
all a: lab.T0 | a.av566 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av566 = (P0)
not (R->P0 in ev566)
semantics1[av567, ev567]
all a: lab.T0 | a.av567 = (none)
all a: lab.T1 | a.av567 = (P0)
not (R->P0 in ev567)
semantics7[av568, ev568]
all a: lab.T0 | a.av568 = (P1)
all a: lab.T1 | a.av568 = ((P1 + (P2 + P4)))
not (R->P0 in ev568)
semantics5[av569, ev569]
all a: lab.T0 | a.av569 = (none)
all a: lab.T1 | a.av569 = ((P2 + P3))
not (R->P0 in ev569)
semantics3[av570, ev570]
all a: lab.T0 | a.av570 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av570 = ((P0 + (P1 + P2)))
not (R->P0 in ev570)
semantics2[av571, ev571]
all a: lab.T0 | a.av571 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av571 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev571)
semantics7[av572, ev572]
all a: lab.T0 | a.av572 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av572 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev572)
semantics3[av573, ev573]
all a: lab.T0 | a.av573 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av573 = ((P3 + P4))
not (R->P0 in ev573)
semantics7[av574, ev574]
all a: lab.T0 | a.av574 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av574 = ((P0 + P3))
not (R->P0 in ev574)
semantics4[av575, ev575]
all a: lab.T0 | a.av575 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av575 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev575)
semantics3[av576, ev576]
all a: lab.T0 | a.av576 = ((P1 + P4))
all a: lab.T1 | a.av576 = ((P0 + (P3 + P4)))
not (R->P0 in ev576)
semantics3[av577, ev577]
all a: lab.T0 | a.av577 = ((P1 + P3))
all a: lab.T1 | a.av577 = ((P0 + P3))
not (R->P0 in ev577)
semantics7[av578, ev578]
all a: lab.T0 | a.av578 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av578 = ((P1 + (P2 + P3)))
not (R->P0 in ev578)
semantics4[av579, ev579]
all a: lab.T0 | a.av579 = (P2)
all a: lab.T1 | a.av579 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev579)
semantics3[av580, ev580]
all a: lab.T0 | a.av580 = ((P1 + P3))
all a: lab.T1 | a.av580 = ((P0 + (P1 + P3)))
not (R->P0 in ev580)
semantics9[av581, ev581]
all a: lab.T0 | a.av581 = ((P1 + P2))
all a: lab.T1 | a.av581 = (P3)
not (R->P0 in ev581)
semantics3[av582, ev582]
all a: lab.T0 | a.av582 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av582 = ((P0 + P3))
not (R->P0 in ev582)
semantics7[av583, ev583]
all a: lab.T0 | a.av583 = ((P0 + P1))
all a: lab.T1 | a.av583 = (P3)
not (R->P0 in ev583)
semantics0[av584, ev584]
all a: lab.T0 | a.av584 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av584 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev584)
semantics3[av585, ev585]
all a: lab.T0 | a.av585 = ((P0 + P4))
all a: lab.T1 | a.av585 = ((P0 + P1))
not (R->P0 in ev585)
semantics7[av586, ev586]
all a: lab.T0 | a.av586 = ((P2 + P4))
all a: lab.T1 | a.av586 = ((P1 + P4))
not (R->P0 in ev586)
semantics3[av587, ev587]
all a: lab.T0 | a.av587 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av587 = ((P2 + (P3 + P4)))
not (R->P0 in ev587)
semantics5[av588, ev588]
all a: lab.T0 | a.av588 = ((P2 + P3))
all a: lab.T1 | a.av588 = ((P0 + P3))
not (R->P0 in ev588)
semantics9[av589, ev589]
all a: lab.T0 | a.av589 = (P3)
all a: lab.T1 | a.av589 = ((P0 + (P1 + P4)))
not (R->P0 in ev589)
semantics0[av590, ev590]
all a: lab.T0 | a.av590 = ((P0 + P1))
all a: lab.T1 | a.av590 = ((P0 + (P2 + P4)))
not (R->P0 in ev590)
semantics11[av591, ev591]
all a: lab.T0 | a.av591 = (P1)
all a: lab.T1 | a.av591 = (P3)
not (R->P0 in ev591)
semantics4[av592, ev592]
all a: lab.T0 | a.av592 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av592 = ((P2 + P4))
not (R->P0 in ev592)
semantics9[av593, ev593]
all a: lab.T0 | a.av593 = ((P2 + P4))
all a: lab.T1 | a.av593 = ((P0 + (P3 + P4)))
not (R->P0 in ev593)
semantics9[av594, ev594]
all a: lab.T0 | a.av594 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av594 = ((P0 + P3))
not (R->P0 in ev594)
semantics0[av595, ev595]
all a: lab.T0 | a.av595 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av595 = ((P0 + (P2 + P3)))
not (R->P0 in ev595)
semantics4[av596, ev596]
all a: lab.T0 | a.av596 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av596 = ((P0 + P4))
not (R->P0 in ev596)
semantics0[av597, ev597]
all a: lab.T0 | a.av597 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av597 = ((P0 + (P2 + P3)))
not (R->P0 in ev597)
semantics4[av598, ev598]
all a: lab.T0 | a.av598 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av598 = ((P1 + (P2 + P3)))
not (R->P0 in ev598)
semantics4[av599, ev599]
all a: lab.T0 | a.av599 = ((P0 + P1))
all a: lab.T1 | a.av599 = ((P1 + P4))
not (R->P0 in ev599)
semantics0[av600, ev600]
all a: lab.T0 | a.av600 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av600 = ((P0 + (P1 + P3)))
not (R->P0 in ev600)
semantics4[av601, ev601]
all a: lab.T0 | a.av601 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av601 = ((P0 + (P1 + P4)))
not (R->P0 in ev601)
semantics3[av602, ev602]
all a: lab.T0 | a.av602 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av602 = ((P2 + (P3 + P4)))
not (R->P0 in ev602)
semantics5[av603, ev603]
all a: lab.T0 | a.av603 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av603 = ((P1 + P2))
not (R->P0 in ev603)
semantics3[av604, ev604]
all a: lab.T0 | a.av604 = ((P0 + P2))
all a: lab.T1 | a.av604 = ((P2 + (P3 + P4)))
not (R->P0 in ev604)
semantics0[av605, ev605]
all a: lab.T0 | a.av605 = ((P0 + P3))
all a: lab.T1 | a.av605 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev605)
semantics9[av606, ev606]
all a: lab.T0 | a.av606 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av606 = ((P1 + P4))
not (R->P0 in ev606)
semantics3[av607, ev607]
all a: lab.T0 | a.av607 = ((P1 + P4))
all a: lab.T1 | a.av607 = ((P1 + P2))
not (R->P0 in ev607)
semantics9[av608, ev608]
all a: lab.T0 | a.av608 = (P3)
all a: lab.T1 | a.av608 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev608)
semantics2[av609, ev609]
all a: lab.T0 | a.av609 = (P2)
all a: lab.T1 | a.av609 = ((P0 + (P2 + P3)))
not (R->P0 in ev609)
semantics3[av610, ev610]
all a: lab.T0 | a.av610 = ((P0 + P3))
all a: lab.T1 | a.av610 = ((P0 + (P2 + P4)))
not (R->P0 in ev610)
semantics0[av611, ev611]
all a: lab.T0 | a.av611 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av611 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev611)
semantics9[av612, ev612]
all a: lab.T0 | a.av612 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av612 = ((P0 + P1))
not (R->P0 in ev612)
semantics7[av613, ev613]
all a: lab.T0 | a.av613 = ((P0 + P3))
all a: lab.T1 | a.av613 = ((P0 + (P1 + P4)))
not (R->P0 in ev613)
semantics11[av614, ev614]
all a: lab.T0 | a.av614 = ((P1 + P2))
all a: lab.T1 | a.av614 = ((P2 + P3))
not (R->P0 in ev614)
semantics4[av615, ev615]
all a: lab.T0 | a.av615 = ((P1 + P4))
all a: lab.T1 | a.av615 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev615)
semantics7[av616, ev616]
all a: lab.T0 | a.av616 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av616 = ((P3 + P4))
not (R->P0 in ev616)
semantics4[av617, ev617]
all a: lab.T0 | a.av617 = ((P1 + P3))
all a: lab.T1 | a.av617 = ((P0 + (P3 + P4)))
not (R->P0 in ev617)
semantics9[av618, ev618]
all a: lab.T0 | a.av618 = ((P0 + P4))
all a: lab.T1 | a.av618 = ((P0 + P2))
not (R->P0 in ev618)
semantics4[av619, ev619]
all a: lab.T0 | a.av619 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av619 = ((P1 + (P2 + P3)))
not (R->P0 in ev619)
semantics0[av620, ev620]
all a: lab.T0 | a.av620 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av620 = ((P0 + P4))
not (R->P0 in ev620)
semantics3[av621, ev621]
all a: lab.T0 | a.av621 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av621 = (P2)
not (R->P0 in ev621)
semantics7[av622, ev622]
all a: lab.T0 | a.av622 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av622 = ((P2 + P4))
not (R->P0 in ev622)
semantics3[av623, ev623]
all a: lab.T0 | a.av623 = ((P0 + P4))
all a: lab.T1 | a.av623 = ((P0 + P4))
not (R->P0 in ev623)
semantics3[av624, ev624]
all a: lab.T0 | a.av624 = ((P0 + P4))
all a: lab.T1 | a.av624 = (P1)
not (R->P0 in ev624)
semantics2[av625, ev625]
all a: lab.T0 | a.av625 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av625 = (P3)
not (R->P0 in ev625)
semantics7[av626, ev626]
all a: lab.T0 | a.av626 = ((P0 + P1))
all a: lab.T1 | a.av626 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev626)
semantics3[av627, ev627]
all a: lab.T0 | a.av627 = (P1)
all a: lab.T1 | a.av627 = ((P1 + P4))
not (R->P0 in ev627)
semantics9[av628, ev628]
all a: lab.T0 | a.av628 = (P4)
all a: lab.T1 | a.av628 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev628)
semantics3[av629, ev629]
all a: lab.T0 | a.av629 = (P1)
all a: lab.T1 | a.av629 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev629)
semantics5[av630, ev630]
all a: lab.T0 | a.av630 = (P1)
all a: lab.T1 | a.av630 = ((P2 + P3))
not (R->P0 in ev630)
semantics2[av631, ev631]
all a: lab.T0 | a.av631 = (P3)
all a: lab.T1 | a.av631 = ((P0 + (P2 + P3)))
not (R->P0 in ev631)
semantics14[av632, ev632]
all a: lab.T0 | a.av632 = (P3)
all a: lab.T1 | a.av632 = ((P0 + (P1 + P3)))
not (R->P0 in ev632)
semantics8[av633, ev633]
all a: lab.T0 | a.av633 = (none)
all a: lab.T1 | a.av633 = (P0)
not (R->P0 in ev633)
semantics3[av634, ev634]
all a: lab.T0 | a.av634 = (P0)
all a: lab.T1 | a.av634 = ((P0 + (P3 + P4)))
not (R->P0 in ev634)
semantics7[av635, ev635]
all a: lab.T0 | a.av635 = ((P3 + P4))
all a: lab.T1 | a.av635 = (P1)
not (R->P0 in ev635)
semantics2[av636, ev636]
all a: lab.T0 | a.av636 = (P1)
all a: lab.T1 | a.av636 = ((P0 + (P1 + P3)))
not (R->P0 in ev636)
semantics3[av637, ev637]
all a: lab.T0 | a.av637 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av637 = ((P1 + (P3 + P4)))
not (R->P0 in ev637)
semantics10[av638, ev638]
all a: lab.T0 | a.av638 = (P0)
all a: lab.T1 | a.av638 = (P2)
not (R->P0 in ev638)
semantics9[av639, ev639]
all a: lab.T0 | a.av639 = ((P1 + P3))
all a: lab.T1 | a.av639 = ((P2 + (P3 + P4)))
not (R->P0 in ev639)
semantics3[av640, ev640]
all a: lab.T0 | a.av640 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av640 = ((P0 + P4))
not (R->P0 in ev640)
semantics4[av641, ev641]
all a: lab.T0 | a.av641 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av641 = ((P0 + P1))
not (R->P0 in ev641)
semantics3[av642, ev642]
all a: lab.T0 | a.av642 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av642 = ((P1 + P4))
not (R->P0 in ev642)
semantics14[av643, ev643]
all a: lab.T0 | a.av643 = ((P1 + P2))
all a: lab.T1 | a.av643 = ((P0 + (P1 + P2)))
not (R->P0 in ev643)
semantics3[av644, ev644]
all a: lab.T0 | a.av644 = (P0)
all a: lab.T1 | a.av644 = ((P0 + P4))
not (R->P0 in ev644)
semantics4[av645, ev645]
all a: lab.T0 | a.av645 = ((P2 + P3))
all a: lab.T1 | a.av645 = ((P0 + (P2 + P3)))
not (R->P0 in ev645)
semantics14[av646, ev646]
all a: lab.T0 | a.av646 = ((P0 + P1))
all a: lab.T1 | a.av646 = ((P0 + (P1 + P2)))
not (R->P0 in ev646)
semantics5[av647, ev647]
all a: lab.T0 | a.av647 = ((P0 + P2))
all a: lab.T1 | a.av647 = ((P2 + P3))
not (R->P0 in ev647)
semantics4[av648, ev648]
all a: lab.T0 | a.av648 = ((P3 + P4))
all a: lab.T1 | a.av648 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev648)
semantics4[av649, ev649]
all a: lab.T0 | a.av649 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av649 = ((P2 + (P3 + P4)))
not (R->P0 in ev649)
semantics3[av650, ev650]
all a: lab.T0 | a.av650 = ((P2 + P4))
all a: lab.T1 | a.av650 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev650)
semantics5[av651, ev651]
all a: lab.T0 | a.av651 = ((P0 + P1))
all a: lab.T1 | a.av651 = ((P0 + P2))
not (R->P0 in ev651)
semantics7[av652, ev652]
all a: lab.T0 | a.av652 = ((P0 + P3))
all a: lab.T1 | a.av652 = ((P0 + (P1 + P2)))
not (R->P0 in ev652)
semantics0[av653, ev653]
all a: lab.T0 | a.av653 = ((P0 + P2))
all a: lab.T1 | a.av653 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev653)
semantics4[av654, ev654]
all a: lab.T0 | a.av654 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av654 = ((P0 + (P2 + P3)))
not (R->P0 in ev654)
semantics14[av655, ev655]
all a: lab.T0 | a.av655 = (P3)
all a: lab.T1 | a.av655 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev655)
semantics2[av656, ev656]
all a: lab.T0 | a.av656 = (none)
all a: lab.T1 | a.av656 = ((P0 + P2))
not (R->P0 in ev656)
semantics2[av657, ev657]
all a: lab.T0 | a.av657 = ((P0 + P2))
all a: lab.T1 | a.av657 = ((P1 + P3))
not (R->P0 in ev657)
semantics4[av658, ev658]
all a: lab.T0 | a.av658 = ((P2 + P3))
all a: lab.T1 | a.av658 = (P0)
not (R->P0 in ev658)
semantics0[av659, ev659]
all a: lab.T0 | a.av659 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av659 = ((P0 + P4))
not (R->P0 in ev659)
semantics9[av660, ev660]
all a: lab.T0 | a.av660 = ((P0 + P1))
all a: lab.T1 | a.av660 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev660)
semantics9[av661, ev661]
all a: lab.T0 | a.av661 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av661 = ((P1 + (P3 + P4)))
not (R->P0 in ev661)
semantics4[av662, ev662]
all a: lab.T0 | a.av662 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av662 = ((P1 + P4))
not (R->P0 in ev662)
semantics0[av663, ev663]
all a: lab.T0 | a.av663 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av663 = ((P3 + P4))
not (R->P0 in ev663)
semantics7[av664, ev664]
all a: lab.T0 | a.av664 = ((P0 + P3))
all a: lab.T1 | a.av664 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev664)
semantics0[av665, ev665]
all a: lab.T0 | a.av665 = (P4)
all a: lab.T1 | a.av665 = ((P0 + (P3 + P4)))
not (R->P0 in ev665)
semantics9[av666, ev666]
all a: lab.T0 | a.av666 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av666 = ((P1 + P4))
not (R->P0 in ev666)
semantics9[av667, ev667]
all a: lab.T0 | a.av667 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av667 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev667)
semantics4[av668, ev668]
all a: lab.T0 | a.av668 = (P2)
all a: lab.T1 | a.av668 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev668)
semantics3[av669, ev669]
all a: lab.T0 | a.av669 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av669 = ((P0 + (P1 + P2)))
not (R->P0 in ev669)
semantics2[av670, ev670]
all a: lab.T0 | a.av670 = ((P0 + P1))
all a: lab.T1 | a.av670 = (P2)
not (R->P0 in ev670)
semantics2[av671, ev671]
all a: lab.T0 | a.av671 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av671 = ((P0 + P3))
not (R->P0 in ev671)
semantics0[av672, ev672]
all a: lab.T0 | a.av672 = ((P3 + P4))
all a: lab.T1 | a.av672 = ((P1 + P4))
not (R->P0 in ev672)
semantics9[av673, ev673]
all a: lab.T0 | a.av673 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av673 = ((P0 + (P3 + P4)))
not (R->P0 in ev673)
semantics12[av674, ev674]
all a: lab.T0 | a.av674 = (none)
all a: lab.T1 | a.av674 = ((P0 + P1))
not (R->P0 in ev674)
semantics5[av675, ev675]
all a: lab.T0 | a.av675 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av675 = ((P0 + P3))
not (R->P0 in ev675)
semantics9[av676, ev676]
all a: lab.T0 | a.av676 = ((P2 + P3))
all a: lab.T1 | a.av676 = ((P3 + P4))
not (R->P0 in ev676)
semantics0[av677, ev677]
all a: lab.T0 | a.av677 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av677 = ((P1 + (P2 + P3)))
not (R->P0 in ev677)
semantics4[av678, ev678]
all a: lab.T0 | a.av678 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av678 = ((P1 + (P3 + P4)))
not (R->P0 in ev678)
semantics10[av679, ev679]
all a: lab.T0 | a.av679 = (P1)
all a: lab.T1 | a.av679 = ((P1 + P2))
not (R->P0 in ev679)
semantics10[av680, ev680]
all a: lab.T0 | a.av680 = ((P0 + P1))
all a: lab.T1 | a.av680 = (P0)
not (R->P0 in ev680)
semantics9[av681, ev681]
all a: lab.T0 | a.av681 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av681 = ((P1 + (P3 + P4)))
not (R->P0 in ev681)
semantics2[av682, ev682]
all a: lab.T0 | a.av682 = (P3)
all a: lab.T1 | a.av682 = ((P1 + P3))
not (R->P0 in ev682)
semantics9[av683, ev683]
all a: lab.T0 | a.av683 = (P4)
all a: lab.T1 | a.av683 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev683)
semantics13[av684, ev684]
all a: lab.T0 | a.av684 = ((P1 + P2))
all a: lab.T1 | a.av684 = ((P0 + (P1 + P2)))
not (R->P0 in ev684)
semantics2[av685, ev685]
all a: lab.T0 | a.av685 = ((P2 + P3))
all a: lab.T1 | a.av685 = (P3)
not (R->P0 in ev685)
semantics0[av686, ev686]
all a: lab.T0 | a.av686 = (P3)
all a: lab.T1 | a.av686 = (P2)
not (R->P0 in ev686)
semantics5[av687, ev687]
all a: lab.T0 | a.av687 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av687 = ((P1 + (P2 + P3)))
not (R->P0 in ev687)
semantics3[av688, ev688]
all a: lab.T0 | a.av688 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av688 = ((P1 + P4))
not (R->P0 in ev688)
semantics5[av689, ev689]
all a: lab.T0 | a.av689 = ((P0 + P3))
all a: lab.T1 | a.av689 = (P0)
not (R->P0 in ev689)
semantics14[av690, ev690]
all a: lab.T0 | a.av690 = ((P0 + P3))
all a: lab.T1 | a.av690 = (P3)
not (R->P0 in ev690)
semantics9[av691, ev691]
all a: lab.T0 | a.av691 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av691 = (P4)
not (R->P0 in ev691)
semantics13[av692, ev692]
all a: lab.T0 | a.av692 = ((P0 + P2))
all a: lab.T1 | a.av692 = ((P0 + (P1 + P2)))
not (R->P0 in ev692)
semantics9[av693, ev693]
all a: lab.T0 | a.av693 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av693 = ((P0 + P3))
not (R->P0 in ev693)
semantics9[av694, ev694]
all a: lab.T0 | a.av694 = ((P1 + P4))
all a: lab.T1 | a.av694 = ((P2 + P3))
not (R->P0 in ev694)
semantics7[av695, ev695]
all a: lab.T0 | a.av695 = ((P2 + P4))
all a: lab.T1 | a.av695 = (P4)
not (R->P0 in ev695)
semantics0[av696, ev696]
all a: lab.T0 | a.av696 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av696 = ((P1 + P2))
not (R->P0 in ev696)
semantics0[av697, ev697]
all a: lab.T0 | a.av697 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av697 = ((P2 + P3))
not (R->P0 in ev697)
semantics4[av698, ev698]
all a: lab.T0 | a.av698 = ((P1 + P3))
all a: lab.T1 | a.av698 = ((P1 + (P3 + P4)))
not (R->P0 in ev698)
semantics3[av699, ev699]
all a: lab.T0 | a.av699 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av699 = ((P2 + P3))
not (R->P0 in ev699)
semantics0[av700, ev700]
all a: lab.T0 | a.av700 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av700 = ((P1 + P4))
not (R->P0 in ev700)
semantics4[av701, ev701]
all a: lab.T0 | a.av701 = (P4)
all a: lab.T1 | a.av701 = ((P0 + (P1 + P3)))
not (R->P0 in ev701)
semantics7[av702, ev702]
all a: lab.T0 | a.av702 = ((P0 + P3))
all a: lab.T1 | a.av702 = ((P1 + (P3 + P4)))
not (R->P0 in ev702)
semantics7[av703, ev703]
all a: lab.T0 | a.av703 = ((P3 + P4))
all a: lab.T1 | a.av703 = ((P1 + (P2 + P3)))
not (R->P0 in ev703)
semantics0[av704, ev704]
all a: lab.T0 | a.av704 = (P0)
all a: lab.T1 | a.av704 = ((P0 + (P2 + P3)))
not (R->P0 in ev704)
semantics3[av705, ev705]
all a: lab.T0 | a.av705 = ((P0 + P3))
all a: lab.T1 | a.av705 = ((P3 + P4))
not (R->P0 in ev705)
semantics4[av706, ev706]
all a: lab.T0 | a.av706 = ((P0 + P4))
all a: lab.T1 | a.av706 = ((P2 + (P3 + P4)))
not (R->P0 in ev706)
semantics0[av707, ev707]
all a: lab.T0 | a.av707 = ((P0 + P4))
all a: lab.T1 | a.av707 = ((P0 + (P2 + P4)))
not (R->P0 in ev707)
semantics5[av708, ev708]
all a: lab.T0 | a.av708 = ((P1 + P3))
all a: lab.T1 | a.av708 = ((P0 + (P1 + P2)))
not (R->P0 in ev708)
semantics7[av709, ev709]
all a: lab.T0 | a.av709 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av709 = ((P1 + (P3 + P4)))
not (R->P0 in ev709)
semantics0[av710, ev710]
all a: lab.T0 | a.av710 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av710 = ((P0 + (P2 + P4)))
not (R->P0 in ev710)
semantics7[av711, ev711]
all a: lab.T0 | a.av711 = (P3)
all a: lab.T1 | a.av711 = ((P2 + (P3 + P4)))
not (R->P0 in ev711)
semantics3[av712, ev712]
all a: lab.T0 | a.av712 = ((P3 + P4))
all a: lab.T1 | a.av712 = ((P0 + (P1 + P2)))
not (R->P0 in ev712)
semantics3[av713, ev713]
all a: lab.T0 | a.av713 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av713 = ((P0 + P4))
not (R->P0 in ev713)
semantics3[av714, ev714]
all a: lab.T0 | a.av714 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av714 = (P1)
not (R->P0 in ev714)
semantics2[av715, ev715]
all a: lab.T0 | a.av715 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av715 = (P2)
not (R->P0 in ev715)
semantics9[av716, ev716]
all a: lab.T0 | a.av716 = ((P0 + P4))
all a: lab.T1 | a.av716 = ((P1 + (P3 + P4)))
not (R->P0 in ev716)
semantics0[av717, ev717]
all a: lab.T0 | a.av717 = ((P1 + P3))
all a: lab.T1 | a.av717 = ((P0 + P2))
not (R->P0 in ev717)
semantics5[av718, ev718]
all a: lab.T0 | a.av718 = ((P0 + P3))
all a: lab.T1 | a.av718 = ((P0 + P2))
not (R->P0 in ev718)
semantics9[av719, ev719]
all a: lab.T0 | a.av719 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av719 = (P3)
not (R->P0 in ev719)
semantics9[av720, ev720]
all a: lab.T0 | a.av720 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av720 = ((P0 + P2))
not (R->P0 in ev720)
semantics7[av721, ev721]
all a: lab.T0 | a.av721 = (P3)
all a: lab.T1 | a.av721 = ((P0 + P3))
not (R->P0 in ev721)
semantics3[av722, ev722]
all a: lab.T0 | a.av722 = ((P0 + P1))
all a: lab.T1 | a.av722 = ((P0 + P2))
not (R->P0 in ev722)
semantics14[av723, ev723]
all a: lab.T0 | a.av723 = ((P0 + P1))
all a: lab.T1 | a.av723 = ((P1 + P3))
not (R->P0 in ev723)
semantics3[av724, ev724]
all a: lab.T0 | a.av724 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av724 = (P0)
not (R->P0 in ev724)
semantics5[av725, ev725]
all a: lab.T0 | a.av725 = (P0)
all a: lab.T1 | a.av725 = (P1)
not (R->P0 in ev725)
semantics2[av726, ev726]
all a: lab.T0 | a.av726 = ((P1 + P3))
all a: lab.T1 | a.av726 = ((P1 + (P2 + P3)))
not (R->P0 in ev726)
semantics10[av727, ev727]
all a: lab.T0 | a.av727 = (P1)
all a: lab.T1 | a.av727 = (P1)
not (R->P0 in ev727)
semantics4[av728, ev728]
all a: lab.T0 | a.av728 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av728 = ((P1 + (P2 + P3)))
not (R->P0 in ev728)
semantics7[av729, ev729]
all a: lab.T0 | a.av729 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av729 = ((P3 + P4))
not (R->P0 in ev729)
semantics11[av730, ev730]
all a: lab.T0 | a.av730 = (P0)
all a: lab.T1 | a.av730 = ((P0 + P3))
not (R->P0 in ev730)
semantics9[av731, ev731]
all a: lab.T0 | a.av731 = (none)
all a: lab.T1 | a.av731 = (P0)
not (R->P0 in ev731)
semantics3[av732, ev732]
all a: lab.T0 | a.av732 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av732 = ((P0 + (P2 + P3)))
not (R->P0 in ev732)
semantics2[av733, ev733]
all a: lab.T0 | a.av733 = ((P2 + P3))
all a: lab.T1 | a.av733 = ((P0 + (P1 + P2)))
not (R->P0 in ev733)
semantics9[av734, ev734]
all a: lab.T0 | a.av734 = ((P0 + P2))
all a: lab.T1 | a.av734 = ((P2 + P4))
not (R->P0 in ev734)
semantics7[av735, ev735]
all a: lab.T0 | a.av735 = ((P1 + P4))
all a: lab.T1 | a.av735 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev735)
semantics10[av736, ev736]
all a: lab.T0 | a.av736 = (P1)
all a: lab.T1 | a.av736 = ((P0 + (P1 + P2)))
not (R->P0 in ev736)
semantics9[av737, ev737]
all a: lab.T0 | a.av737 = (P1)
all a: lab.T1 | a.av737 = (P0)
not (R->P0 in ev737)
semantics4[av738, ev738]
all a: lab.T0 | a.av738 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av738 = ((P0 + (P2 + P3)))
not (R->P0 in ev738)
semantics0[av739, ev739]
all a: lab.T0 | a.av739 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av739 = ((P0 + (P1 + P4)))
not (R->P0 in ev739)
semantics11[av740, ev740]
all a: lab.T0 | a.av740 = ((P1 + P2))
all a: lab.T1 | a.av740 = ((P1 + P3))
not (R->P0 in ev740)
semantics3[av741, ev741]
all a: lab.T0 | a.av741 = ((P1 + P2))
all a: lab.T1 | a.av741 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev741)
semantics9[av742, ev742]
all a: lab.T0 | a.av742 = ((P0 + P1))
all a: lab.T1 | a.av742 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev742)
semantics5[av743, ev743]
all a: lab.T0 | a.av743 = (P0)
all a: lab.T1 | a.av743 = (P3)
not (R->P0 in ev743)
semantics14[av744, ev744]
all a: lab.T0 | a.av744 = ((P0 + P3))
all a: lab.T1 | a.av744 = (P0)
not (R->P0 in ev744)
semantics3[av745, ev745]
all a: lab.T0 | a.av745 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av745 = ((P1 + (P3 + P4)))
not (R->P0 in ev745)
semantics2[av746, ev746]
all a: lab.T0 | a.av746 = (P1)
all a: lab.T1 | a.av746 = ((P0 + P2))
not (R->P0 in ev746)
semantics0[av747, ev747]
all a: lab.T0 | a.av747 = (none)
all a: lab.T1 | a.av747 = ((P0 + (P1 + P3)))
not (R->P0 in ev747)
semantics4[av748, ev748]
all a: lab.T0 | a.av748 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av748 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev748)
semantics0[av749, ev749]
all a: lab.T0 | a.av749 = ((P0 + P1))
all a: lab.T1 | a.av749 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev749)
semantics9[av750, ev750]
all a: lab.T0 | a.av750 = (P1)
all a: lab.T1 | a.av750 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev750)
semantics14[av751, ev751]
all a: lab.T0 | a.av751 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av751 = ((P0 + P1))
not (R->P0 in ev751)
semantics9[av752, ev752]
all a: lab.T0 | a.av752 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av752 = ((P1 + P3))
not (R->P0 in ev752)
semantics0[av753, ev753]
all a: lab.T0 | a.av753 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av753 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev753)
semantics9[av754, ev754]
all a: lab.T0 | a.av754 = (P4)
all a: lab.T1 | a.av754 = ((P0 + (P2 + P4)))
not (R->P0 in ev754)
semantics2[av755, ev755]
all a: lab.T0 | a.av755 = (P0)
all a: lab.T1 | a.av755 = ((P0 + (P1 + P2)))
not (R->P0 in ev755)
semantics3[av756, ev756]
all a: lab.T0 | a.av756 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av756 = ((P1 + P3))
not (R->P0 in ev756)
semantics14[av757, ev757]
all a: lab.T0 | a.av757 = ((P0 + P1))
all a: lab.T1 | a.av757 = ((P0 + P2))
not (R->P0 in ev757)
semantics0[av758, ev758]
all a: lab.T0 | a.av758 = (P1)
all a: lab.T1 | a.av758 = ((P0 + (P2 + P3)))
not (R->P0 in ev758)
semantics0[av759, ev759]
all a: lab.T0 | a.av759 = (P1)
all a: lab.T1 | a.av759 = ((P0 + (P1 + P4)))
not (R->P0 in ev759)
semantics7[av760, ev760]
all a: lab.T0 | a.av760 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av760 = ((P3 + P4))
not (R->P0 in ev760)
semantics14[av761, ev761]
all a: lab.T0 | a.av761 = (P0)
all a: lab.T1 | a.av761 = (P2)
not (R->P0 in ev761)
semantics7[av762, ev762]
all a: lab.T0 | a.av762 = (P1)
all a: lab.T1 | a.av762 = ((P2 + P4))
not (R->P0 in ev762)
semantics9[av763, ev763]
all a: lab.T0 | a.av763 = ((P1 + P3))
all a: lab.T1 | a.av763 = ((P2 + P4))
not (R->P0 in ev763)
semantics4[av764, ev764]
all a: lab.T0 | a.av764 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av764 = ((P1 + P4))
not (R->P0 in ev764)
semantics2[av765, ev765]
all a: lab.T0 | a.av765 = (P2)
all a: lab.T1 | a.av765 = (none)
not (R->P0 in ev765)
semantics3[av766, ev766]
all a: lab.T0 | a.av766 = ((P1 + P3))
all a: lab.T1 | a.av766 = ((P0 + P2))
not (R->P0 in ev766)
semantics8[av767, ev767]
all a: lab.T0 | a.av767 = (P1)
all a: lab.T1 | a.av767 = (none)
not (R->P0 in ev767)
semantics7[av768, ev768]
all a: lab.T0 | a.av768 = ((P0 + P2))
all a: lab.T1 | a.av768 = (P1)
not (R->P0 in ev768)
semantics5[av769, ev769]
all a: lab.T0 | a.av769 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av769 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev769)
semantics0[av770, ev770]
all a: lab.T0 | a.av770 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av770 = ((P1 + P2))
not (R->P0 in ev770)
semantics0[av771, ev771]
all a: lab.T0 | a.av771 = (P0)
all a: lab.T1 | a.av771 = ((P0 + P4))
not (R->P0 in ev771)
semantics3[av772, ev772]
all a: lab.T0 | a.av772 = ((P0 + P3))
all a: lab.T1 | a.av772 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev772)
semantics0[av773, ev773]
all a: lab.T0 | a.av773 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av773 = ((P1 + (P2 + P3)))
not (R->P0 in ev773)
semantics7[av774, ev774]
all a: lab.T0 | a.av774 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av774 = ((P0 + (P2 + P3)))
not (R->P0 in ev774)
semantics0[av775, ev775]
all a: lab.T0 | a.av775 = ((P0 + P1))
all a: lab.T1 | a.av775 = ((P1 + P4))
not (R->P0 in ev775)
semantics5[av776, ev776]
all a: lab.T0 | a.av776 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av776 = (P0)
not (R->P0 in ev776)
semantics5[av777, ev777]
all a: lab.T0 | a.av777 = ((P0 + P1))
all a: lab.T1 | a.av777 = (P1)
not (R->P0 in ev777)
semantics9[av778, ev778]
all a: lab.T0 | a.av778 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av778 = (P2)
not (R->P0 in ev778)
semantics5[av779, ev779]
all a: lab.T0 | a.av779 = (P3)
all a: lab.T1 | a.av779 = ((P0 + P3))
not (R->P0 in ev779)
semantics7[av780, ev780]
all a: lab.T0 | a.av780 = ((P0 + P2))
all a: lab.T1 | a.av780 = ((P1 + (P2 + P4)))
not (R->P0 in ev780)
semantics0[av781, ev781]
all a: lab.T0 | a.av781 = (P4)
all a: lab.T1 | a.av781 = ((P0 + P2))
not (R->P0 in ev781)
semantics0[av782, ev782]
all a: lab.T0 | a.av782 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av782 = (P3)
not (R->P0 in ev782)
semantics0[av783, ev783]
all a: lab.T0 | a.av783 = ((P2 + P4))
all a: lab.T1 | a.av783 = ((P0 + (P2 + P4)))
not (R->P0 in ev783)
semantics7[av784, ev784]
all a: lab.T0 | a.av784 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av784 = ((P1 + (P3 + P4)))
not (R->P0 in ev784)
semantics7[av785, ev785]
all a: lab.T0 | a.av785 = ((P1 + P3))
all a: lab.T1 | a.av785 = ((P1 + (P3 + P4)))
not (R->P0 in ev785)
semantics7[av786, ev786]
all a: lab.T0 | a.av786 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av786 = ((P0 + P4))
not (R->P0 in ev786)
semantics9[av787, ev787]
all a: lab.T0 | a.av787 = ((P0 + P2))
all a: lab.T1 | a.av787 = (P1)
not (R->P0 in ev787)
semantics10[av788, ev788]
all a: lab.T0 | a.av788 = (P1)
all a: lab.T1 | a.av788 = (none)
not (R->P0 in ev788)
semantics4[av789, ev789]
all a: lab.T0 | a.av789 = ((P0 + P1))
all a: lab.T1 | a.av789 = ((P0 + (P2 + P3)))
not (R->P0 in ev789)
semantics9[av790, ev790]
all a: lab.T0 | a.av790 = ((P0 + P4))
all a: lab.T1 | a.av790 = ((P3 + P4))
not (R->P0 in ev790)
semantics5[av791, ev791]
all a: lab.T0 | a.av791 = (P3)
all a: lab.T1 | a.av791 = (P2)
not (R->P0 in ev791)
semantics9[av792, ev792]
all a: lab.T0 | a.av792 = ((P2 + P4))
all a: lab.T1 | a.av792 = ((P2 + P4))
not (R->P0 in ev792)
semantics9[av793, ev793]
all a: lab.T0 | a.av793 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av793 = ((P1 + P3))
not (R->P0 in ev793)
semantics11[av794, ev794]
all a: lab.T0 | a.av794 = ((P1 + P2))
all a: lab.T1 | a.av794 = ((P0 + (P1 + P3)))
not (R->P0 in ev794)
semantics7[av795, ev795]
all a: lab.T0 | a.av795 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av795 = ((P0 + (P1 + P3)))
not (R->P0 in ev795)
semantics7[av796, ev796]
all a: lab.T0 | a.av796 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av796 = ((P2 + P4))
not (R->P0 in ev796)
semantics13[av797, ev797]
all a: lab.T0 | a.av797 = (P1)
all a: lab.T1 | a.av797 = (P0)
not (R->P0 in ev797)
semantics3[av798, ev798]
all a: lab.T0 | a.av798 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av798 = ((P1 + P2))
not (R->P0 in ev798)
semantics14[av799, ev799]
all a: lab.T0 | a.av799 = (none)
all a: lab.T1 | a.av799 = ((P0 + P1))
not (R->P0 in ev799)
semantics7[av800, ev800]
all a: lab.T0 | a.av800 = ((P2 + P3))
all a: lab.T1 | a.av800 = ((P0 + P1))
not (R->P0 in ev800)
semantics2[av801, ev801]
all a: lab.T0 | a.av801 = ((P2 + P3))
all a: lab.T1 | a.av801 = (P2)
not (R->P0 in ev801)
semantics9[av802, ev802]
all a: lab.T0 | a.av802 = (P2)
all a: lab.T1 | a.av802 = ((P0 + P2))
not (R->P0 in ev802)
semantics12[av803, ev803]
all a: lab.T0 | a.av803 = (P2)
all a: lab.T1 | a.av803 = ((P0 + P2))
not (R->P0 in ev803)
semantics5[av804, ev804]
all a: lab.T0 | a.av804 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av804 = ((P0 + P1))
not (R->P0 in ev804)
semantics2[av805, ev805]
all a: lab.T0 | a.av805 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av805 = (P1)
not (R->P0 in ev805)
semantics9[av806, ev806]
all a: lab.T0 | a.av806 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av806 = ((P2 + P4))
not (R->P0 in ev806)
semantics3[av807, ev807]
all a: lab.T0 | a.av807 = (P4)
all a: lab.T1 | a.av807 = ((P1 + P2))
not (R->P0 in ev807)
semantics9[av808, ev808]
all a: lab.T0 | a.av808 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av808 = ((P0 + P1))
not (R->P0 in ev808)
semantics3[av809, ev809]
all a: lab.T0 | a.av809 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av809 = ((P0 + (P1 + P4)))
not (R->P0 in ev809)
semantics7[av810, ev810]
all a: lab.T0 | a.av810 = ((P0 + P4))
all a: lab.T1 | a.av810 = ((P0 + P2))
not (R->P0 in ev810)
semantics3[av811, ev811]
all a: lab.T0 | a.av811 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av811 = ((P0 + (P1 + P2)))
not (R->P0 in ev811)
semantics9[av812, ev812]
all a: lab.T0 | a.av812 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av812 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev812)
semantics2[av813, ev813]
all a: lab.T0 | a.av813 = (P0)
all a: lab.T1 | a.av813 = (P2)
not (R->P0 in ev813)
semantics3[av814, ev814]
all a: lab.T0 | a.av814 = ((P0 + P2))
all a: lab.T1 | a.av814 = ((P1 + P2))
not (R->P0 in ev814)
semantics11[av815, ev815]
all a: lab.T0 | a.av815 = (P3)
all a: lab.T1 | a.av815 = ((P0 + P2))
not (R->P0 in ev815)
semantics9[av816, ev816]
all a: lab.T0 | a.av816 = (P1)
all a: lab.T1 | a.av816 = ((P0 + (P2 + P3)))
not (R->P0 in ev816)
semantics9[av817, ev817]
all a: lab.T0 | a.av817 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av817 = ((P3 + P4))
not (R->P0 in ev817)
semantics2[av818, ev818]
all a: lab.T0 | a.av818 = ((P0 + P3))
all a: lab.T1 | a.av818 = (P2)
not (R->P0 in ev818)
semantics2[av819, ev819]
all a: lab.T0 | a.av819 = ((P0 + P2))
all a: lab.T1 | a.av819 = ((P0 + P1))
not (R->P0 in ev819)
semantics11[av820, ev820]
all a: lab.T0 | a.av820 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av820 = ((P0 + (P1 + P2)))
not (R->P0 in ev820)
semantics0[av821, ev821]
all a: lab.T0 | a.av821 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av821 = ((P1 + (P2 + P3)))
not (R->P0 in ev821)
semantics11[av822, ev822]
all a: lab.T0 | a.av822 = (P2)
all a: lab.T1 | a.av822 = ((P2 + P3))
not (R->P0 in ev822)
semantics3[av823, ev823]
all a: lab.T0 | a.av823 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av823 = ((P0 + P3))
not (R->P0 in ev823)
semantics3[av824, ev824]
all a: lab.T0 | a.av824 = ((P0 + P3))
all a: lab.T1 | a.av824 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev824)
semantics4[av825, ev825]
all a: lab.T0 | a.av825 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av825 = ((P0 + P2))
not (R->P0 in ev825)
semantics0[av826, ev826]
all a: lab.T0 | a.av826 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av826 = ((P0 + P2))
not (R->P0 in ev826)
semantics0[av827, ev827]
all a: lab.T0 | a.av827 = ((P1 + P2))
all a: lab.T1 | a.av827 = ((P0 + (P1 + P4)))
not (R->P0 in ev827)
semantics0[av828, ev828]
all a: lab.T0 | a.av828 = ((P0 + P1))
all a: lab.T1 | a.av828 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev828)
semantics4[av829, ev829]
all a: lab.T0 | a.av829 = ((P0 + P4))
all a: lab.T1 | a.av829 = (P3)
not (R->P0 in ev829)
semantics9[av830, ev830]
all a: lab.T0 | a.av830 = (P1)
all a: lab.T1 | a.av830 = ((P2 + P3))
not (R->P0 in ev830)
semantics14[av831, ev831]
all a: lab.T0 | a.av831 = ((P2 + P3))
all a: lab.T1 | a.av831 = (P1)
not (R->P0 in ev831)
semantics13[av832, ev832]
all a: lab.T0 | a.av832 = (P1)
all a: lab.T1 | a.av832 = (none)
not (R->P0 in ev832)
semantics0[av833, ev833]
all a: lab.T0 | a.av833 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av833 = ((P2 + P3))
not (R->P0 in ev833)
semantics9[av834, ev834]
all a: lab.T0 | a.av834 = (P4)
all a: lab.T1 | a.av834 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev834)
semantics7[av835, ev835]
all a: lab.T0 | a.av835 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av835 = (P0)
not (R->P0 in ev835)
semantics9[av836, ev836]
all a: lab.T0 | a.av836 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av836 = ((P1 + (P2 + P3)))
not (R->P0 in ev836)
semantics7[av837, ev837]
all a: lab.T0 | a.av837 = ((P1 + P4))
all a: lab.T1 | a.av837 = ((P2 + (P3 + P4)))
not (R->P0 in ev837)
semantics3[av838, ev838]
all a: lab.T0 | a.av838 = ((P2 + P4))
all a: lab.T1 | a.av838 = ((P0 + (P1 + P3)))
not (R->P0 in ev838)
semantics5[av839, ev839]
all a: lab.T0 | a.av839 = ((P1 + P2))
all a: lab.T1 | a.av839 = ((P0 + P1))
not (R->P0 in ev839)
semantics9[av840, ev840]
all a: lab.T0 | a.av840 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av840 = ((P1 + P4))
not (R->P0 in ev840)
semantics2[av841, ev841]
all a: lab.T0 | a.av841 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av841 = ((P0 + P2))
not (R->P0 in ev841)
semantics3[av842, ev842]
all a: lab.T0 | a.av842 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av842 = (none)
not (R->P0 in ev842)
semantics3[av843, ev843]
all a: lab.T0 | a.av843 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av843 = (P1)
not (R->P0 in ev843)
semantics3[av844, ev844]
all a: lab.T0 | a.av844 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av844 = ((P0 + (P3 + P4)))
not (R->P0 in ev844)
semantics9[av845, ev845]
all a: lab.T0 | a.av845 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av845 = (none)
not (R->P0 in ev845)
semantics8[av846, ev846]
all a: lab.T0 | a.av846 = (P0)
all a: lab.T1 | a.av846 = (none)
not (R->P0 in ev846)
semantics9[av847, ev847]
all a: lab.T0 | a.av847 = (P0)
all a: lab.T1 | a.av847 = ((P0 + P1))
not (R->P0 in ev847)
semantics9[av848, ev848]
all a: lab.T0 | a.av848 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av848 = ((P0 + (P1 + P4)))
not (R->P0 in ev848)
semantics3[av849, ev849]
all a: lab.T0 | a.av849 = (P0)
all a: lab.T1 | a.av849 = ((P0 + (P1 + P3)))
not (R->P0 in ev849)
semantics14[av850, ev850]
all a: lab.T0 | a.av850 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av850 = ((P0 + P2))
not (R->P0 in ev850)
semantics3[av851, ev851]
all a: lab.T0 | a.av851 = ((P1 + P4))
all a: lab.T1 | a.av851 = ((P3 + P4))
not (R->P0 in ev851)
semantics9[av852, ev852]
all a: lab.T0 | a.av852 = ((P2 + P4))
all a: lab.T1 | a.av852 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev852)
semantics3[av853, ev853]
all a: lab.T0 | a.av853 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av853 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev853)
semantics14[av854, ev854]
all a: lab.T0 | a.av854 = ((P0 + P1))
all a: lab.T1 | a.av854 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev854)
semantics10[av855, ev855]
all a: lab.T0 | a.av855 = ((P0 + P1))
all a: lab.T1 | a.av855 = (P2)
not (R->P0 in ev855)
semantics12[av856, ev856]
all a: lab.T0 | a.av856 = ((P0 + P1))
all a: lab.T1 | a.av856 = (P1)
not (R->P0 in ev856)
semantics4[av857, ev857]
all a: lab.T0 | a.av857 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av857 = ((P0 + (P1 + P4)))
not (R->P0 in ev857)
semantics0[av858, ev858]
all a: lab.T0 | a.av858 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av858 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev858)
semantics3[av859, ev859]
all a: lab.T0 | a.av859 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av859 = ((P1 + (P2 + P3)))
not (R->P0 in ev859)
semantics0[av860, ev860]
all a: lab.T0 | a.av860 = (P3)
all a: lab.T1 | a.av860 = ((P1 + (P2 + P3)))
not (R->P0 in ev860)
semantics11[av861, ev861]
all a: lab.T0 | a.av861 = (P3)
all a: lab.T1 | a.av861 = ((P1 + (P2 + P3)))
not (R->P0 in ev861)
semantics9[av862, ev862]
all a: lab.T0 | a.av862 = ((P0 + P4))
all a: lab.T1 | a.av862 = ((P1 + (P2 + P3)))
not (R->P0 in ev862)
semantics9[av863, ev863]
all a: lab.T0 | a.av863 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av863 = ((P0 + (P1 + P2)))
not (R->P0 in ev863)
semantics13[av864, ev864]
all a: lab.T0 | a.av864 = ((P1 + P2))
all a: lab.T1 | a.av864 = (P1)
not (R->P0 in ev864)
semantics4[av865, ev865]
all a: lab.T0 | a.av865 = (P2)
all a: lab.T1 | a.av865 = ((P0 + P3))
not (R->P0 in ev865)
semantics0[av866, ev866]
all a: lab.T0 | a.av866 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av866 = ((P0 + (P3 + P4)))
not (R->P0 in ev866)
semantics9[av867, ev867]
all a: lab.T0 | a.av867 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av867 = ((P1 + (P2 + P3)))
not (R->P0 in ev867)
semantics14[av868, ev868]
all a: lab.T0 | a.av868 = (P0)
all a: lab.T1 | a.av868 = ((P0 + P1))
not (R->P0 in ev868)
semantics3[av869, ev869]
all a: lab.T0 | a.av869 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av869 = ((P0 + (P3 + P4)))
not (R->P0 in ev869)
semantics3[av870, ev870]
all a: lab.T0 | a.av870 = ((P1 + P3))
all a: lab.T1 | a.av870 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev870)
semantics0[av871, ev871]
all a: lab.T0 | a.av871 = (P1)
all a: lab.T1 | a.av871 = ((P2 + P4))
not (R->P0 in ev871)
semantics14[av872, ev872]
all a: lab.T0 | a.av872 = ((P2 + P3))
all a: lab.T1 | a.av872 = (P2)
not (R->P0 in ev872)
semantics9[av873, ev873]
all a: lab.T0 | a.av873 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av873 = ((P0 + (P1 + P3)))
not (R->P0 in ev873)
semantics1[av874, ev874]
all a: lab.T0 | a.av874 = (none)
all a: lab.T1 | a.av874 = (none)
not (R->P0 in ev874)
semantics3[av875, ev875]
all a: lab.T0 | a.av875 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av875 = ((P0 + P2))
not (R->P0 in ev875)
semantics11[av876, ev876]
all a: lab.T0 | a.av876 = (P2)
all a: lab.T1 | a.av876 = ((P1 + P2))
not (R->P0 in ev876)
semantics7[av877, ev877]
all a: lab.T0 | a.av877 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av877 = ((P2 + (P3 + P4)))
not (R->P0 in ev877)
semantics3[av878, ev878]
all a: lab.T0 | a.av878 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av878 = ((P0 + (P1 + P3)))
not (R->P0 in ev878)
semantics9[av879, ev879]
all a: lab.T0 | a.av879 = (P0)
all a: lab.T1 | a.av879 = ((P0 + (P1 + P2)))
not (R->P0 in ev879)
semantics9[av880, ev880]
all a: lab.T0 | a.av880 = ((P0 + P2))
all a: lab.T1 | a.av880 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev880)
semantics4[av881, ev881]
all a: lab.T0 | a.av881 = (P4)
all a: lab.T1 | a.av881 = ((P2 + P4))
not (R->P0 in ev881)
semantics0[av882, ev882]
all a: lab.T0 | a.av882 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av882 = (P0)
not (R->P0 in ev882)
semantics0[av883, ev883]
all a: lab.T0 | a.av883 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av883 = (P4)
not (R->P0 in ev883)
semantics7[av884, ev884]
all a: lab.T0 | a.av884 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av884 = ((P0 + (P2 + P4)))
not (R->P0 in ev884)
semantics4[av885, ev885]
all a: lab.T0 | a.av885 = ((P1 + P4))
all a: lab.T1 | a.av885 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev885)
semantics9[av886, ev886]
all a: lab.T0 | a.av886 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av886 = ((P1 + (P2 + P3)))
not (R->P0 in ev886)
semantics11[av887, ev887]
all a: lab.T0 | a.av887 = ((P2 + P3))
all a: lab.T1 | a.av887 = ((P0 + (P1 + P3)))
not (R->P0 in ev887)
semantics2[av888, ev888]
all a: lab.T0 | a.av888 = ((P1 + P3))
all a: lab.T1 | a.av888 = ((P1 + P2))
not (R->P0 in ev888)
semantics9[av889, ev889]
all a: lab.T0 | a.av889 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av889 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev889)
semantics5[av890, ev890]
all a: lab.T0 | a.av890 = ((P1 + P2))
all a: lab.T1 | a.av890 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev890)
semantics9[av891, ev891]
all a: lab.T0 | a.av891 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av891 = (P2)
not (R->P0 in ev891)
semantics3[av892, ev892]
all a: lab.T0 | a.av892 = (P2)
all a: lab.T1 | a.av892 = ((P0 + (P1 + P2)))
not (R->P0 in ev892)
semantics13[av893, ev893]
all a: lab.T0 | a.av893 = ((P0 + P2))
all a: lab.T1 | a.av893 = (P2)
not (R->P0 in ev893)
semantics0[av894, ev894]
all a: lab.T0 | a.av894 = ((P1 + P4))
all a: lab.T1 | a.av894 = ((P0 + (P1 + P2)))
not (R->P0 in ev894)
semantics9[av895, ev895]
all a: lab.T0 | a.av895 = (P4)
all a: lab.T1 | a.av895 = ((P2 + (P3 + P4)))
not (R->P0 in ev895)
semantics9[av896, ev896]
all a: lab.T0 | a.av896 = (P3)
all a: lab.T1 | a.av896 = ((P0 + (P1 + P3)))
not (R->P0 in ev896)
semantics3[av897, ev897]
all a: lab.T0 | a.av897 = ((P0 + P2))
all a: lab.T1 | a.av897 = ((P0 + (P1 + P2)))
not (R->P0 in ev897)
semantics4[av898, ev898]
all a: lab.T0 | a.av898 = ((P1 + P4))
all a: lab.T1 | a.av898 = (P0)
not (R->P0 in ev898)
semantics3[av899, ev899]
all a: lab.T0 | a.av899 = (P1)
all a: lab.T1 | a.av899 = (P4)
not (R->P0 in ev899)
semantics9[av900, ev900]
all a: lab.T0 | a.av900 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av900 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev900)
semantics0[av901, ev901]
all a: lab.T0 | a.av901 = (none)
all a: lab.T1 | a.av901 = ((P0 + (P1 + P4)))
not (R->P0 in ev901)
semantics2[av902, ev902]
all a: lab.T0 | a.av902 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av902 = ((P0 + (P1 + P2)))
not (R->P0 in ev902)
semantics9[av903, ev903]
all a: lab.T0 | a.av903 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av903 = ((P2 + P3))
not (R->P0 in ev903)
semantics13[av904, ev904]
all a: lab.T0 | a.av904 = ((P0 + P1))
all a: lab.T1 | a.av904 = (P0)
not (R->P0 in ev904)
semantics2[av905, ev905]
all a: lab.T0 | a.av905 = (P0)
all a: lab.T1 | a.av905 = ((P0 + P3))
not (R->P0 in ev905)
semantics7[av906, ev906]
all a: lab.T0 | a.av906 = ((P3 + P4))
all a: lab.T1 | a.av906 = ((P3 + P4))
not (R->P0 in ev906)
semantics10[av907, ev907]
all a: lab.T0 | a.av907 = ((P0 + P1))
all a: lab.T1 | a.av907 = ((P0 + P1))
not (R->P0 in ev907)
semantics7[av908, ev908]
all a: lab.T0 | a.av908 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av908 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev908)
semantics9[av909, ev909]
all a: lab.T0 | a.av909 = ((P1 + P3))
all a: lab.T1 | a.av909 = ((P1 + P3))
not (R->P0 in ev909)
semantics0[av910, ev910]
all a: lab.T0 | a.av910 = ((P0 + P4))
all a: lab.T1 | a.av910 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev910)
semantics4[av911, ev911]
all a: lab.T0 | a.av911 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av911 = ((P0 + P3))
not (R->P0 in ev911)
semantics9[av912, ev912]
all a: lab.T0 | a.av912 = ((P2 + P4))
all a: lab.T1 | a.av912 = ((P0 + (P2 + P3)))
not (R->P0 in ev912)
semantics3[av913, ev913]
all a: lab.T0 | a.av913 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av913 = ((P1 + P2))
not (R->P0 in ev913)
semantics7[av914, ev914]
all a: lab.T0 | a.av914 = (P2)
all a: lab.T1 | a.av914 = ((P2 + P4))
not (R->P0 in ev914)
semantics0[av915, ev915]
all a: lab.T0 | a.av915 = ((P1 + P2))
all a: lab.T1 | a.av915 = ((P0 + (P2 + P4)))
not (R->P0 in ev915)
semantics7[av916, ev916]
all a: lab.T0 | a.av916 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av916 = (P3)
not (R->P0 in ev916)
semantics4[av917, ev917]
all a: lab.T0 | a.av917 = (P4)
all a: lab.T1 | a.av917 = ((P1 + P4))
not (R->P0 in ev917)
semantics4[av918, ev918]
all a: lab.T0 | a.av918 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av918 = ((P0 + P2))
not (R->P0 in ev918)
semantics7[av919, ev919]
all a: lab.T0 | a.av919 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av919 = (P0)
not (R->P0 in ev919)
semantics9[av920, ev920]
all a: lab.T0 | a.av920 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av920 = ((P0 + (P2 + P3)))
not (R->P0 in ev920)
semantics14[av921, ev921]
all a: lab.T0 | a.av921 = ((P1 + P2))
all a: lab.T1 | a.av921 = ((P0 + P1))
not (R->P0 in ev921)
semantics0[av922, ev922]
all a: lab.T0 | a.av922 = ((P0 + P2))
all a: lab.T1 | a.av922 = ((P0 + (P2 + P3)))
not (R->P0 in ev922)
semantics9[av923, ev923]
all a: lab.T0 | a.av923 = ((P0 + P3))
all a: lab.T1 | a.av923 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev923)
semantics3[av924, ev924]
all a: lab.T0 | a.av924 = ((P0 + P1))
all a: lab.T1 | a.av924 = ((P0 + (P2 + P4)))
not (R->P0 in ev924)
semantics2[av925, ev925]
all a: lab.T0 | a.av925 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av925 = ((P0 + (P2 + P3)))
not (R->P0 in ev925)
semantics11[av926, ev926]
all a: lab.T0 | a.av926 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av926 = ((P1 + P2))
not (R->P0 in ev926)
semantics4[av927, ev927]
all a: lab.T0 | a.av927 = ((P1 + P2))
all a: lab.T1 | a.av927 = ((P0 + (P1 + P3)))
not (R->P0 in ev927)
semantics9[av928, ev928]
all a: lab.T0 | a.av928 = ((P0 + P1))
all a: lab.T1 | a.av928 = ((P1 + (P3 + P4)))
not (R->P0 in ev928)
semantics7[av929, ev929]
all a: lab.T0 | a.av929 = ((P0 + P1))
all a: lab.T1 | a.av929 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev929)
semantics10[av930, ev930]
all a: lab.T0 | a.av930 = (P2)
all a: lab.T1 | a.av930 = ((P0 + (P1 + P2)))
not (R->P0 in ev930)
semantics4[av931, ev931]
all a: lab.T0 | a.av931 = ((P0 + P4))
all a: lab.T1 | a.av931 = ((P0 + P4))
not (R->P0 in ev931)
semantics9[av932, ev932]
all a: lab.T0 | a.av932 = (P4)
all a: lab.T1 | a.av932 = ((P2 + P3))
not (R->P0 in ev932)
semantics7[av933, ev933]
all a: lab.T0 | a.av933 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av933 = ((P0 + P4))
not (R->P0 in ev933)
semantics9[av934, ev934]
all a: lab.T0 | a.av934 = (P0)
all a: lab.T1 | a.av934 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev934)
semantics4[av935, ev935]
all a: lab.T0 | a.av935 = ((P0 + P4))
all a: lab.T1 | a.av935 = ((P1 + P2))
not (R->P0 in ev935)
semantics12[av936, ev936]
all a: lab.T0 | a.av936 = (P1)
all a: lab.T1 | a.av936 = ((P1 + P2))
not (R->P0 in ev936)
semantics13[av937, ev937]
all a: lab.T0 | a.av937 = (P2)
all a: lab.T1 | a.av937 = ((P1 + P2))
not (R->P0 in ev937)
semantics9[av938, ev938]
all a: lab.T0 | a.av938 = (P0)
all a: lab.T1 | a.av938 = ((P1 + (P2 + P4)))
not (R->P0 in ev938)
semantics7[av939, ev939]
all a: lab.T0 | a.av939 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av939 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev939)
semantics3[av940, ev940]
all a: lab.T0 | a.av940 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av940 = ((P0 + (P1 + P2)))
not (R->P0 in ev940)
semantics9[av941, ev941]
all a: lab.T0 | a.av941 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av941 = (P1)
not (R->P0 in ev941)
semantics9[av942, ev942]
all a: lab.T0 | a.av942 = ((P3 + P4))
all a: lab.T1 | a.av942 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev942)
semantics14[av943, ev943]
all a: lab.T0 | a.av943 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av943 = ((P0 + (P2 + P3)))
not (R->P0 in ev943)
semantics3[av944, ev944]
all a: lab.T0 | a.av944 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av944 = ((P0 + (P2 + P3)))
not (R->P0 in ev944)
semantics3[av945, ev945]
all a: lab.T0 | a.av945 = ((P0 + P1))
all a: lab.T1 | a.av945 = ((P1 + P2))
not (R->P0 in ev945)
semantics14[av946, ev946]
all a: lab.T0 | a.av946 = (P0)
all a: lab.T1 | a.av946 = ((P0 + (P2 + P3)))
not (R->P0 in ev946)
semantics7[av947, ev947]
all a: lab.T0 | a.av947 = ((P1 + P2))
all a: lab.T1 | a.av947 = (P0)
not (R->P0 in ev947)
semantics7[av948, ev948]
all a: lab.T0 | a.av948 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av948 = ((P0 + P3))
not (R->P0 in ev948)
semantics9[av949, ev949]
all a: lab.T0 | a.av949 = ((P2 + P4))
all a: lab.T1 | a.av949 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev949)
semantics3[av950, ev950]
all a: lab.T0 | a.av950 = ((P0 + P4))
all a: lab.T1 | a.av950 = ((P0 + (P1 + P3)))
not (R->P0 in ev950)
semantics9[av951, ev951]
all a: lab.T0 | a.av951 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av951 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev951)
semantics0[av952, ev952]
all a: lab.T0 | a.av952 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av952 = ((P0 + P3))
not (R->P0 in ev952)
semantics4[av953, ev953]
all a: lab.T0 | a.av953 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av953 = ((P0 + P4))
not (R->P0 in ev953)
semantics7[av954, ev954]
all a: lab.T0 | a.av954 = ((P0 + P4))
all a: lab.T1 | a.av954 = ((P0 + (P1 + P3)))
not (R->P0 in ev954)
semantics5[av955, ev955]
all a: lab.T0 | a.av955 = (P2)
all a: lab.T1 | a.av955 = ((P0 + (P1 + P2)))
not (R->P0 in ev955)
semantics3[av956, ev956]
all a: lab.T0 | a.av956 = (P2)
all a: lab.T1 | a.av956 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev956)
semantics3[av957, ev957]
all a: lab.T0 | a.av957 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av957 = ((P0 + P1))
not (R->P0 in ev957)
semantics13[av958, ev958]
all a: lab.T0 | a.av958 = (none)
all a: lab.T1 | a.av958 = (P2)
not (R->P0 in ev958)
semantics5[av959, ev959]
all a: lab.T0 | a.av959 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av959 = (none)
not (R->P0 in ev959)
semantics0[av960, ev960]
all a: lab.T0 | a.av960 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av960 = (P3)
not (R->P0 in ev960)
semantics3[av961, ev961]
all a: lab.T0 | a.av961 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av961 = ((P2 + P4))
not (R->P0 in ev961)
semantics9[av962, ev962]
all a: lab.T0 | a.av962 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av962 = ((P2 + (P3 + P4)))
not (R->P0 in ev962)
semantics3[av963, ev963]
all a: lab.T0 | a.av963 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av963 = (P1)
not (R->P0 in ev963)
semantics5[av964, ev964]
all a: lab.T0 | a.av964 = (P1)
all a: lab.T1 | a.av964 = (P2)
not (R->P0 in ev964)
semantics14[av965, ev965]
all a: lab.T0 | a.av965 = (P3)
all a: lab.T1 | a.av965 = (P1)
not (R->P0 in ev965)
semantics0[av966, ev966]
all a: lab.T0 | a.av966 = (P3)
all a: lab.T1 | a.av966 = ((P1 + (P3 + P4)))
not (R->P0 in ev966)
semantics7[av967, ev967]
all a: lab.T0 | a.av967 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av967 = (P4)
not (R->P0 in ev967)
semantics9[av968, ev968]
all a: lab.T0 | a.av968 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av968 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev968)
semantics9[av969, ev969]
all a: lab.T0 | a.av969 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av969 = ((P1 + P2))
not (R->P0 in ev969)
semantics14[av970, ev970]
all a: lab.T0 | a.av970 = ((P1 + P3))
all a: lab.T1 | a.av970 = (P2)
not (R->P0 in ev970)
semantics3[av971, ev971]
all a: lab.T0 | a.av971 = (P3)
all a: lab.T1 | a.av971 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev971)
semantics7[av972, ev972]
all a: lab.T0 | a.av972 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av972 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev972)
semantics7[av973, ev973]
all a: lab.T0 | a.av973 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av973 = (P4)
not (R->P0 in ev973)
semantics2[av974, ev974]
all a: lab.T0 | a.av974 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av974 = (P2)
not (R->P0 in ev974)
semantics7[av975, ev975]
all a: lab.T0 | a.av975 = (P3)
all a: lab.T1 | a.av975 = ((P1 + (P2 + P4)))
not (R->P0 in ev975)
semantics0[av976, ev976]
all a: lab.T0 | a.av976 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av976 = ((P0 + P4))
not (R->P0 in ev976)
semantics0[av977, ev977]
all a: lab.T0 | a.av977 = (P2)
all a: lab.T1 | a.av977 = ((P0 + (P2 + P3)))
not (R->P0 in ev977)
semantics9[av978, ev978]
all a: lab.T0 | a.av978 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av978 = ((P0 + (P1 + P4)))
not (R->P0 in ev978)
semantics7[av979, ev979]
all a: lab.T0 | a.av979 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av979 = ((P0 + (P1 + P2)))
not (R->P0 in ev979)
semantics11[av980, ev980]
all a: lab.T0 | a.av980 = (none)
all a: lab.T1 | a.av980 = ((P1 + P2))
not (R->P0 in ev980)
semantics7[av981, ev981]
all a: lab.T0 | a.av981 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av981 = ((P1 + P4))
not (R->P0 in ev981)
semantics7[av982, ev982]
all a: lab.T0 | a.av982 = ((P0 + P2))
all a: lab.T1 | a.av982 = ((P1 + (P3 + P4)))
not (R->P0 in ev982)
semantics0[av983, ev983]
all a: lab.T0 | a.av983 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av983 = ((P2 + P4))
not (R->P0 in ev983)
semantics3[av984, ev984]
all a: lab.T0 | a.av984 = ((P1 + P3))
all a: lab.T1 | a.av984 = ((P1 + (P2 + P3)))
not (R->P0 in ev984)
semantics7[av985, ev985]
all a: lab.T0 | a.av985 = (P4)
all a: lab.T1 | a.av985 = ((P1 + (P3 + P4)))
not (R->P0 in ev985)
semantics0[av986, ev986]
all a: lab.T0 | a.av986 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av986 = ((P0 + (P1 + P3)))
not (R->P0 in ev986)
semantics2[av987, ev987]
all a: lab.T0 | a.av987 = (P1)
all a: lab.T1 | a.av987 = ((P0 + (P1 + P2)))
not (R->P0 in ev987)
semantics3[av988, ev988]
all a: lab.T0 | a.av988 = ((P1 + P4))
all a: lab.T1 | a.av988 = ((P1 + (P2 + P3)))
not (R->P0 in ev988)
semantics5[av989, ev989]
all a: lab.T0 | a.av989 = (P0)
all a: lab.T1 | a.av989 = ((P0 + P3))
not (R->P0 in ev989)
semantics4[av990, ev990]
all a: lab.T0 | a.av990 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av990 = ((P0 + (P3 + P4)))
not (R->P0 in ev990)
semantics4[av991, ev991]
all a: lab.T0 | a.av991 = ((P2 + P4))
all a: lab.T1 | a.av991 = ((P1 + (P2 + P3)))
not (R->P0 in ev991)
semantics9[av992, ev992]
all a: lab.T0 | a.av992 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av992 = ((P1 + (P2 + P4)))
not (R->P0 in ev992)
semantics4[av993, ev993]
all a: lab.T0 | a.av993 = (P0)
all a: lab.T1 | a.av993 = ((P2 + P3))
not (R->P0 in ev993)
semantics3[av994, ev994]
all a: lab.T0 | a.av994 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av994 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev994)
semantics14[av995, ev995]
all a: lab.T0 | a.av995 = (P1)
all a: lab.T1 | a.av995 = ((P2 + P3))
not (R->P0 in ev995)
semantics2[av996, ev996]
all a: lab.T0 | a.av996 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av996 = (none)
not (R->P0 in ev996)
semantics3[av997, ev997]
all a: lab.T0 | a.av997 = ((P1 + P3))
all a: lab.T1 | a.av997 = ((P2 + P4))
not (R->P0 in ev997)
semantics4[av998, ev998]
all a: lab.T0 | a.av998 = ((P2 + P4))
all a: lab.T1 | a.av998 = ((P0 + P4))
not (R->P0 in ev998)
semantics9[av999, ev999]
all a: lab.T0 | a.av999 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av999 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev999)
semantics9[av1000, ev1000]
all a: lab.T0 | a.av1000 = (P2)
all a: lab.T1 | a.av1000 = ((P0 + P1))
not (R->P0 in ev1000)
semantics4[av1001, ev1001]
all a: lab.T0 | a.av1001 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av1001 = (P2)
not (R->P0 in ev1001)
semantics9[av1002, ev1002]
all a: lab.T0 | a.av1002 = ((P3 + P4))
all a: lab.T1 | a.av1002 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev1002)
semantics14[av1003, ev1003]
all a: lab.T0 | a.av1003 = (P2)
all a: lab.T1 | a.av1003 = ((P0 + P1))
not (R->P0 in ev1003)
semantics0[av1004, ev1004]
all a: lab.T0 | a.av1004 = ((P1 + P3))
all a: lab.T1 | a.av1004 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev1004)
semantics14[av1005, ev1005]
all a: lab.T0 | a.av1005 = ((P0 + P2))
all a: lab.T1 | a.av1005 = (none)
not (R->P0 in ev1005)
semantics11[av1006, ev1006]
all a: lab.T0 | a.av1006 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1006 = (P1)
not (R->P0 in ev1006)
semantics10[av1007, ev1007]
all a: lab.T0 | a.av1007 = (P0)
all a: lab.T1 | a.av1007 = ((P0 + P1))
not (R->P0 in ev1007)
semantics9[av1008, ev1008]
all a: lab.T0 | a.av1008 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av1008 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev1008)
semantics9[av1009, ev1009]
all a: lab.T0 | a.av1009 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av1009 = ((P0 + (P2 + P4)))
not (R->P0 in ev1009)
semantics0[av1010, ev1010]
all a: lab.T0 | a.av1010 = ((P0 + P2))
all a: lab.T1 | a.av1010 = ((P2 + P3))
not (R->P0 in ev1010)
semantics12[av1011, ev1011]
all a: lab.T0 | a.av1011 = ((P0 + P2))
all a: lab.T1 | a.av1011 = (P2)
not (R->P0 in ev1011)
semantics3[av1012, ev1012]
all a: lab.T0 | a.av1012 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1012 = (P2)
not (R->P0 in ev1012)
semantics3[av1013, ev1013]
all a: lab.T0 | a.av1013 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1013 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev1013)
semantics0[av1014, ev1014]
all a: lab.T0 | a.av1014 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av1014 = ((P1 + P3))
not (R->P0 in ev1014)
semantics9[av1015, ev1015]
all a: lab.T0 | a.av1015 = (P0)
all a: lab.T1 | a.av1015 = ((P0 + P2))
not (R->P0 in ev1015)
semantics9[av1016, ev1016]
all a: lab.T0 | a.av1016 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1016 = ((P1 + P2))
not (R->P0 in ev1016)
semantics7[av1017, ev1017]
all a: lab.T0 | a.av1017 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av1017 = ((P0 + (P2 + P4)))
not (R->P0 in ev1017)
semantics9[av1018, ev1018]
all a: lab.T0 | a.av1018 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1018 = ((P0 + (P1 + P2)))
not (R->P0 in ev1018)
semantics0[av1019, ev1019]
all a: lab.T0 | a.av1019 = ((P0 + P3))
all a: lab.T1 | a.av1019 = (P2)
not (R->P0 in ev1019)
semantics7[av1020, ev1020]
all a: lab.T0 | a.av1020 = ((P0 + P1))
all a: lab.T1 | a.av1020 = (P0)
not (R->P0 in ev1020)
semantics9[av1021, ev1021]
all a: lab.T0 | a.av1021 = ((P0 + P2))
all a: lab.T1 | a.av1021 = (P3)
not (R->P0 in ev1021)
semantics4[av1022, ev1022]
all a: lab.T0 | a.av1022 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1022 = ((P0 + (P2 + P3)))
not (R->P0 in ev1022)
semantics4[av1023, ev1023]
all a: lab.T0 | a.av1023 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av1023 = ((P0 + (P1 + P2)))
not (R->P0 in ev1023)
semantics4[av1024, ev1024]
all a: lab.T0 | a.av1024 = ((P2 + P3))
all a: lab.T1 | a.av1024 = ((P0 + P4))
not (R->P0 in ev1024)
semantics9[av1025, ev1025]
all a: lab.T0 | a.av1025 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av1025 = ((P0 + (P2 + P3)))
not (R->P0 in ev1025)
semantics3[av1026, ev1026]
all a: lab.T0 | a.av1026 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av1026 = ((P1 + (P2 + P4)))
not (R->P0 in ev1026)
semantics4[av1027, ev1027]
all a: lab.T0 | a.av1027 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av1027 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev1027)
semantics11[av1028, ev1028]
all a: lab.T0 | a.av1028 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1028 = (P1)
not (R->P0 in ev1028)
semantics9[av1029, ev1029]
all a: lab.T0 | a.av1029 = ((P0 + P2))
all a: lab.T1 | a.av1029 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev1029)
semantics0[av1030, ev1030]
all a: lab.T0 | a.av1030 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1030 = (P1)
not (R->P0 in ev1030)
semantics14[av1031, ev1031]
all a: lab.T0 | a.av1031 = ((P1 + P3))
all a: lab.T1 | a.av1031 = ((P2 + P3))
not (R->P0 in ev1031)
semantics3[av1032, ev1032]
all a: lab.T0 | a.av1032 = ((P1 + P4))
all a: lab.T1 | a.av1032 = ((P0 + P1))
not (R->P0 in ev1032)
semantics9[av1033, ev1033]
all a: lab.T0 | a.av1033 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av1033 = (P0)
not (R->P0 in ev1033)
semantics4[av1034, ev1034]
all a: lab.T0 | a.av1034 = (none)
all a: lab.T1 | a.av1034 = ((P1 + (P2 + P3)))
not (R->P0 in ev1034)
semantics9[av1035, ev1035]
all a: lab.T0 | a.av1035 = (P1)
all a: lab.T1 | a.av1035 = ((P2 + P4))
not (R->P0 in ev1035)
semantics9[av1036, ev1036]
all a: lab.T0 | a.av1036 = ((P0 + P4))
all a: lab.T1 | a.av1036 = ((P0 + (P2 + P3)))
not (R->P0 in ev1036)
semantics9[av1037, ev1037]
all a: lab.T0 | a.av1037 = (none)
all a: lab.T1 | a.av1037 = ((P2 + P4))
not (R->P0 in ev1037)
semantics9[av1038, ev1038]
all a: lab.T0 | a.av1038 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av1038 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev1038)
semantics7[av1039, ev1039]
all a: lab.T0 | a.av1039 = ((P2 + P3))
all a: lab.T1 | a.av1039 = ((P0 + (P2 + P3)))
not (R->P0 in ev1039)
semantics3[av1040, ev1040]
all a: lab.T0 | a.av1040 = ((P1 + P3))
all a: lab.T1 | a.av1040 = ((P0 + (P1 + P4)))
not (R->P0 in ev1040)
semantics9[av1041, ev1041]
all a: lab.T0 | a.av1041 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av1041 = ((P1 + (P3 + P4)))
not (R->P0 in ev1041)
semantics8[av1042, ev1042]
all a: lab.T0 | a.av1042 = (P0)
all a: lab.T1 | a.av1042 = (P1)
not (R->P0 in ev1042)
semantics4[av1043, ev1043]
all a: lab.T0 | a.av1043 = ((P2 + P4))
all a: lab.T1 | a.av1043 = ((P1 + (P3 + P4)))
not (R->P0 in ev1043)
semantics4[av1044, ev1044]
all a: lab.T0 | a.av1044 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av1044 = (P2)
not (R->P0 in ev1044)
semantics9[av1045, ev1045]
all a: lab.T0 | a.av1045 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av1045 = (P3)
not (R->P0 in ev1045)
semantics3[av1046, ev1046]
all a: lab.T0 | a.av1046 = (P0)
all a: lab.T1 | a.av1046 = ((P1 + P3))
not (R->P0 in ev1046)
semantics4[av1047, ev1047]
all a: lab.T0 | a.av1047 = ((P1 + P2))
all a: lab.T1 | a.av1047 = ((P0 + P4))
not (R->P0 in ev1047)
semantics8[av1048, ev1048]
all a: lab.T0 | a.av1048 = (P1)
all a: lab.T1 | a.av1048 = ((P0 + P1))
not (R->P0 in ev1048)
semantics9[av1049, ev1049]
all a: lab.T0 | a.av1049 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av1049 = ((P1 + P3))
not (R->P0 in ev1049)
semantics5[av1050, ev1050]
all a: lab.T0 | a.av1050 = (P1)
all a: lab.T1 | a.av1050 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev1050)
semantics7[av1051, ev1051]
all a: lab.T0 | a.av1051 = ((P2 + P4))
all a: lab.T1 | a.av1051 = ((P0 + (P1 + P4)))
not (R->P0 in ev1051)
semantics2[av1052, ev1052]
all a: lab.T0 | a.av1052 = (P1)
all a: lab.T1 | a.av1052 = ((P0 + P3))
not (R->P0 in ev1052)
semantics9[av1053, ev1053]
all a: lab.T0 | a.av1053 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1053 = ((P0 + P3))
not (R->P0 in ev1053)
semantics2[av1054, ev1054]
all a: lab.T0 | a.av1054 = ((P0 + P1))
all a: lab.T1 | a.av1054 = ((P0 + P3))
not (R->P0 in ev1054)
semantics5[av1055, ev1055]
all a: lab.T0 | a.av1055 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1055 = ((P0 + (P1 + P3)))
not (R->P0 in ev1055)
semantics9[av1056, ev1056]
all a: lab.T0 | a.av1056 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1056 = ((P1 + (P2 + P4)))
not (R->P0 in ev1056)
semantics9[av1057, ev1057]
all a: lab.T0 | a.av1057 = ((P1 + P3))
all a: lab.T1 | a.av1057 = ((P0 + P3))
not (R->P0 in ev1057)
semantics7[av1058, ev1058]
all a: lab.T0 | a.av1058 = ((P0 + P1))
all a: lab.T1 | a.av1058 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev1058)
semantics0[av1059, ev1059]
all a: lab.T0 | a.av1059 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1059 = ((P2 + P3))
not (R->P0 in ev1059)
semantics9[av1060, ev1060]
all a: lab.T0 | a.av1060 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av1060 = (none)
not (R->P0 in ev1060)
semantics3[av1061, ev1061]
all a: lab.T0 | a.av1061 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av1061 = (P4)
not (R->P0 in ev1061)
semantics4[av1062, ev1062]
all a: lab.T0 | a.av1062 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av1062 = ((P1 + P2))
not (R->P0 in ev1062)
semantics0[av1063, ev1063]
all a: lab.T0 | a.av1063 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av1063 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev1063)
semantics0[av1064, ev1064]
all a: lab.T0 | a.av1064 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1064 = (P3)
not (R->P0 in ev1064)
semantics3[av1065, ev1065]
all a: lab.T0 | a.av1065 = ((P1 + P3))
all a: lab.T1 | a.av1065 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev1065)
semantics0[av1066, ev1066]
all a: lab.T0 | a.av1066 = (P2)
all a: lab.T1 | a.av1066 = ((P0 + (P1 + P4)))
not (R->P0 in ev1066)
semantics0[av1067, ev1067]
all a: lab.T0 | a.av1067 = ((P1 + P4))
all a: lab.T1 | a.av1067 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev1067)
semantics9[av1068, ev1068]
all a: lab.T0 | a.av1068 = ((P2 + P3))
all a: lab.T1 | a.av1068 = ((P0 + (P1 + P4)))
not (R->P0 in ev1068)
semantics3[av1069, ev1069]
all a: lab.T0 | a.av1069 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av1069 = (P0)
not (R->P0 in ev1069)
semantics9[av1070, ev1070]
all a: lab.T0 | a.av1070 = ((P2 + P3))
all a: lab.T1 | a.av1070 = ((P1 + P2))
not (R->P0 in ev1070)
semantics3[av1071, ev1071]
all a: lab.T0 | a.av1071 = ((P3 + P4))
all a: lab.T1 | a.av1071 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev1071)
semantics9[av1072, ev1072]
all a: lab.T0 | a.av1072 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av1072 = ((P1 + (P2 + P4)))
not (R->P0 in ev1072)
semantics12[av1073, ev1073]
all a: lab.T0 | a.av1073 = ((P1 + P2))
all a: lab.T1 | a.av1073 = ((P0 + P2))
not (R->P0 in ev1073)
semantics0[av1074, ev1074]
all a: lab.T0 | a.av1074 = (P2)
all a: lab.T1 | a.av1074 = (P3)
not (R->P0 in ev1074)
semantics9[av1075, ev1075]
all a: lab.T0 | a.av1075 = ((P2 + P3))
all a: lab.T1 | a.av1075 = ((P1 + P4))
not (R->P0 in ev1075)
semantics2[av1076, ev1076]
all a: lab.T0 | a.av1076 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1076 = (P3)
not (R->P0 in ev1076)
semantics7[av1077, ev1077]
all a: lab.T0 | a.av1077 = ((P1 + P3))
all a: lab.T1 | a.av1077 = ((P0 + (P2 + P3)))
not (R->P0 in ev1077)
semantics9[av1078, ev1078]
all a: lab.T0 | a.av1078 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1078 = ((P0 + P1))
not (R->P0 in ev1078)
semantics0[av1079, ev1079]
all a: lab.T0 | a.av1079 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av1079 = ((P1 + P4))
not (R->P0 in ev1079)
semantics3[av1080, ev1080]
all a: lab.T0 | a.av1080 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1080 = ((P1 + P3))
not (R->P0 in ev1080)
semantics3[av1081, ev1081]
all a: lab.T0 | a.av1081 = (none)
all a: lab.T1 | a.av1081 = ((P2 + P4))
not (R->P0 in ev1081)
semantics11[av1082, ev1082]
all a: lab.T0 | a.av1082 = ((P2 + P3))
all a: lab.T1 | a.av1082 = ((P0 + P3))
not (R->P0 in ev1082)
semantics14[av1083, ev1083]
all a: lab.T0 | a.av1083 = (P1)
all a: lab.T1 | a.av1083 = (P3)
not (R->P0 in ev1083)
semantics9[av1084, ev1084]
all a: lab.T0 | a.av1084 = (P0)
all a: lab.T1 | a.av1084 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev1084)
semantics9[av1085, ev1085]
all a: lab.T0 | a.av1085 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1085 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev1085)
semantics4[av1086, ev1086]
all a: lab.T0 | a.av1086 = (P4)
all a: lab.T1 | a.av1086 = ((P1 + (P3 + P4)))
not (R->P0 in ev1086)
semantics0[av1087, ev1087]
all a: lab.T0 | a.av1087 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av1087 = (P3)
not (R->P0 in ev1087)
semantics2[av1088, ev1088]
all a: lab.T0 | a.av1088 = ((P1 + P2))
all a: lab.T1 | a.av1088 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev1088)
semantics9[av1089, ev1089]
all a: lab.T0 | a.av1089 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av1089 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev1089)
semantics4[av1090, ev1090]
all a: lab.T0 | a.av1090 = ((P1 + P4))
all a: lab.T1 | a.av1090 = ((P1 + P3))
not (R->P0 in ev1090)
semantics14[av1091, ev1091]
all a: lab.T0 | a.av1091 = ((P2 + P3))
all a: lab.T1 | a.av1091 = (P3)
not (R->P0 in ev1091)
semantics9[av1092, ev1092]
all a: lab.T0 | a.av1092 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av1092 = ((P0 + P1))
not (R->P0 in ev1092)
semantics3[av1093, ev1093]
all a: lab.T0 | a.av1093 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av1093 = ((P0 + P4))
not (R->P0 in ev1093)
semantics4[av1094, ev1094]
all a: lab.T0 | a.av1094 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av1094 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev1094)
semantics9[av1095, ev1095]
all a: lab.T0 | a.av1095 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1095 = (P3)
not (R->P0 in ev1095)
semantics9[av1096, ev1096]
all a: lab.T0 | a.av1096 = (P4)
all a: lab.T1 | a.av1096 = ((P1 + (P2 + P4)))
not (R->P0 in ev1096)
semantics13[av1097, ev1097]
all a: lab.T0 | a.av1097 = (P0)
all a: lab.T1 | a.av1097 = (P1)
not (R->P0 in ev1097)
semantics7[av1098, ev1098]
all a: lab.T0 | a.av1098 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av1098 = ((P2 + P3))
not (R->P0 in ev1098)
semantics4[av1099, ev1099]
all a: lab.T0 | a.av1099 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av1099 = ((P1 + P2))
not (R->P0 in ev1099)
semantics4[av1100, ev1100]
all a: lab.T0 | a.av1100 = (P4)
all a: lab.T1 | a.av1100 = ((P1 + P2))
not (R->P0 in ev1100)
semantics3[av1101, ev1101]
all a: lab.T0 | a.av1101 = ((P1 + P2))
all a: lab.T1 | a.av1101 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev1101)
semantics0[av1102, ev1102]
all a: lab.T0 | a.av1102 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av1102 = ((P1 + (P2 + P4)))
not (R->P0 in ev1102)
semantics3[av1103, ev1103]
all a: lab.T0 | a.av1103 = (P4)
all a: lab.T1 | a.av1103 = (P3)
not (R->P0 in ev1103)
semantics0[av1104, ev1104]
all a: lab.T0 | a.av1104 = ((P0 + P3))
all a: lab.T1 | a.av1104 = ((P0 + (P1 + P4)))
not (R->P0 in ev1104)
semantics3[av1105, ev1105]
all a: lab.T0 | a.av1105 = ((P3 + P4))
all a: lab.T1 | a.av1105 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev1105)
semantics4[av1106, ev1106]
all a: lab.T0 | a.av1106 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av1106 = ((P0 + P2))
not (R->P0 in ev1106)
semantics3[av1107, ev1107]
all a: lab.T0 | a.av1107 = (P4)
all a: lab.T1 | a.av1107 = ((P1 + (P3 + P4)))
not (R->P0 in ev1107)
semantics7[av1108, ev1108]
all a: lab.T0 | a.av1108 = ((P1 + P4))
all a: lab.T1 | a.av1108 = ((P0 + P1))
not (R->P0 in ev1108)
semantics2[av1109, ev1109]
all a: lab.T0 | a.av1109 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1109 = ((P0 + (P1 + P3)))
not (R->P0 in ev1109)
semantics0[av1110, ev1110]
all a: lab.T0 | a.av1110 = ((P1 + P3))
all a: lab.T1 | a.av1110 = ((P1 + (P2 + P4)))
not (R->P0 in ev1110)
semantics0[av1111, ev1111]
all a: lab.T0 | a.av1111 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av1111 = ((P0 + P2))
not (R->P0 in ev1111)
semantics0[av1112, ev1112]
all a: lab.T0 | a.av1112 = ((P0 + P3))
all a: lab.T1 | a.av1112 = (P3)
not (R->P0 in ev1112)
semantics9[av1113, ev1113]
all a: lab.T0 | a.av1113 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av1113 = ((P0 + (P2 + P3)))
not (R->P0 in ev1113)
semantics4[av1114, ev1114]
all a: lab.T0 | a.av1114 = ((P0 + P4))
all a: lab.T1 | a.av1114 = ((P1 + (P2 + P3)))
not (R->P0 in ev1114)
semantics14[av1115, ev1115]
all a: lab.T0 | a.av1115 = ((P0 + P1))
all a: lab.T1 | a.av1115 = ((P1 + P2))
not (R->P0 in ev1115)
semantics9[av1116, ev1116]
all a: lab.T0 | a.av1116 = ((P0 + P2))
all a: lab.T1 | a.av1116 = (P2)
not (R->P0 in ev1116)
semantics7[av1117, ev1117]
all a: lab.T0 | a.av1117 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1117 = ((P1 + P2))
not (R->P0 in ev1117)
semantics7[av1118, ev1118]
all a: lab.T0 | a.av1118 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av1118 = ((P2 + (P3 + P4)))
not (R->P0 in ev1118)
semantics13[av1119, ev1119]
all a: lab.T0 | a.av1119 = ((P0 + P2))
all a: lab.T1 | a.av1119 = (P1)
not (R->P0 in ev1119)
semantics3[av1120, ev1120]
all a: lab.T0 | a.av1120 = (P3)
all a: lab.T1 | a.av1120 = ((P2 + (P3 + P4)))
not (R->P0 in ev1120)
semantics13[av1121, ev1121]
all a: lab.T0 | a.av1121 = ((P1 + P2))
all a: lab.T1 | a.av1121 = ((P1 + P2))
not (R->P0 in ev1121)
semantics3[av1122, ev1122]
all a: lab.T0 | a.av1122 = ((P0 + P3))
all a: lab.T1 | a.av1122 = ((P2 + P4))
not (R->P0 in ev1122)
semantics3[av1123, ev1123]
all a: lab.T0 | a.av1123 = ((P0 + P4))
all a: lab.T1 | a.av1123 = ((P1 + (P3 + P4)))
not (R->P0 in ev1123)
semantics2[av1124, ev1124]
all a: lab.T0 | a.av1124 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1124 = ((P0 + P2))
not (R->P0 in ev1124)
semantics7[av1125, ev1125]
all a: lab.T0 | a.av1125 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1125 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev1125)
semantics14[av1126, ev1126]
all a: lab.T0 | a.av1126 = ((P0 + P1))
all a: lab.T1 | a.av1126 = ((P0 + P1))
not (R->P0 in ev1126)
semantics9[av1127, ev1127]
all a: lab.T0 | a.av1127 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av1127 = ((P2 + P4))
not (R->P0 in ev1127)
semantics4[av1128, ev1128]
all a: lab.T0 | a.av1128 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av1128 = ((P3 + P4))
not (R->P0 in ev1128)
semantics9[av1129, ev1129]
all a: lab.T0 | a.av1129 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av1129 = (P0)
not (R->P0 in ev1129)
semantics3[av1130, ev1130]
all a: lab.T0 | a.av1130 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av1130 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev1130)
semantics9[av1131, ev1131]
all a: lab.T0 | a.av1131 = ((P1 + P4))
all a: lab.T1 | a.av1131 = ((P0 + (P2 + P4)))
not (R->P0 in ev1131)
semantics6[av1132, ev1132]
all a: lab.T0 | a.av1132 = (P1)
all a: lab.T1 | a.av1132 = ((P0 + P1))
not (R->P0 in ev1132)
semantics9[av1133, ev1133]
all a: lab.T0 | a.av1133 = (P3)
all a: lab.T1 | a.av1133 = ((P0 + (P2 + P3)))
not (R->P0 in ev1133)
semantics7[av1134, ev1134]
all a: lab.T0 | a.av1134 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1134 = ((P2 + (P3 + P4)))
not (R->P0 in ev1134)
semantics7[av1135, ev1135]
all a: lab.T0 | a.av1135 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av1135 = ((P2 + P4))
not (R->P0 in ev1135)
semantics4[av1136, ev1136]
all a: lab.T0 | a.av1136 = (P4)
all a: lab.T1 | a.av1136 = (P2)
not (R->P0 in ev1136)
semantics9[av1137, ev1137]
all a: lab.T0 | a.av1137 = (none)
all a: lab.T1 | a.av1137 = ((P3 + P4))
not (R->P0 in ev1137)
semantics7[av1138, ev1138]
all a: lab.T0 | a.av1138 = (P0)
all a: lab.T1 | a.av1138 = ((P1 + P4))
not (R->P0 in ev1138)
semantics7[av1139, ev1139]
all a: lab.T0 | a.av1139 = ((P0 + P4))
all a: lab.T1 | a.av1139 = ((P0 + (P1 + P2)))
not (R->P0 in ev1139)
semantics3[av1140, ev1140]
all a: lab.T0 | a.av1140 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1140 = ((P1 + P3))
not (R->P0 in ev1140)
semantics9[av1141, ev1141]
all a: lab.T0 | a.av1141 = ((P1 + P3))
all a: lab.T1 | a.av1141 = (none)
not (R->P0 in ev1141)
semantics9[av1142, ev1142]
all a: lab.T0 | a.av1142 = ((P1 + P2))
all a: lab.T1 | a.av1142 = (((P0 + P2) + (P3 + P4)))
not (R->P0 in ev1142)
semantics9[av1143, ev1143]
all a: lab.T0 | a.av1143 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av1143 = (P4)
not (R->P0 in ev1143)
semantics4[av1144, ev1144]
all a: lab.T0 | a.av1144 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av1144 = (P3)
not (R->P0 in ev1144)
semantics4[av1145, ev1145]
all a: lab.T0 | a.av1145 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1145 = ((P0 + P3))
not (R->P0 in ev1145)
semantics5[av1146, ev1146]
all a: lab.T0 | a.av1146 = (P2)
all a: lab.T1 | a.av1146 = (P2)
not (R->P0 in ev1146)
semantics0[av1147, ev1147]
all a: lab.T0 | a.av1147 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av1147 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev1147)
semantics0[av1148, ev1148]
all a: lab.T0 | a.av1148 = ((P2 + P3))
all a: lab.T1 | a.av1148 = ((P3 + P4))
not (R->P0 in ev1148)
semantics9[av1149, ev1149]
all a: lab.T0 | a.av1149 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1149 = (P2)
not (R->P0 in ev1149)
semantics9[av1150, ev1150]
all a: lab.T0 | a.av1150 = (none)
all a: lab.T1 | a.av1150 = ((P1 + (P2 + P3)))
not (R->P0 in ev1150)
semantics7[av1151, ev1151]
all a: lab.T0 | a.av1151 = ((P0 + P1))
all a: lab.T1 | a.av1151 = ((P1 + P2))
not (R->P0 in ev1151)
semantics5[av1152, ev1152]
all a: lab.T0 | a.av1152 = (P1)
all a: lab.T1 | a.av1152 = (none)
not (R->P0 in ev1152)
semantics7[av1153, ev1153]
all a: lab.T0 | a.av1153 = ((P1 + P3))
all a: lab.T1 | a.av1153 = ((P0 + P1))
not (R->P0 in ev1153)
semantics9[av1154, ev1154]
all a: lab.T0 | a.av1154 = ((P1 + P4))
all a: lab.T1 | a.av1154 = (P1)
not (R->P0 in ev1154)
semantics9[av1155, ev1155]
all a: lab.T0 | a.av1155 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1155 = ((P2 + P4))
not (R->P0 in ev1155)
semantics4[av1156, ev1156]
all a: lab.T0 | a.av1156 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av1156 = ((P0 + (P1 + P4)))
not (R->P0 in ev1156)
semantics4[av1157, ev1157]
all a: lab.T0 | a.av1157 = ((P0 + P3))
all a: lab.T1 | a.av1157 = ((P0 + P2))
not (R->P0 in ev1157)
semantics7[av1158, ev1158]
all a: lab.T0 | a.av1158 = ((P2 + P4))
all a: lab.T1 | a.av1158 = ((P0 + (P1 + P2)))
not (R->P0 in ev1158)
semantics2[av1159, ev1159]
all a: lab.T0 | a.av1159 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1159 = (P2)
not (R->P0 in ev1159)
semantics3[av1160, ev1160]
all a: lab.T0 | a.av1160 = ((P0 + P1))
all a: lab.T1 | a.av1160 = ((P0 + P4))
not (R->P0 in ev1160)
semantics7[av1161, ev1161]
all a: lab.T0 | a.av1161 = ((P0 + P3))
all a: lab.T1 | a.av1161 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev1161)
semantics7[av1162, ev1162]
all a: lab.T0 | a.av1162 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av1162 = ((P1 + P4))
not (R->P0 in ev1162)
semantics0[av1163, ev1163]
all a: lab.T0 | a.av1163 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1163 = ((P2 + P3))
not (R->P0 in ev1163)
semantics7[av1164, ev1164]
all a: lab.T0 | a.av1164 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av1164 = (P0)
not (R->P0 in ev1164)
semantics3[av1165, ev1165]
all a: lab.T0 | a.av1165 = ((P3 + P4))
all a: lab.T1 | a.av1165 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev1165)
semantics0[av1166, ev1166]
all a: lab.T0 | a.av1166 = ((P2 + P4))
all a: lab.T1 | a.av1166 = (P4)
not (R->P0 in ev1166)
semantics9[av1167, ev1167]
all a: lab.T0 | a.av1167 = ((P0 + P3))
all a: lab.T1 | a.av1167 = ((P0 + (P2 + P3)))
not (R->P0 in ev1167)
semantics2[av1168, ev1168]
all a: lab.T0 | a.av1168 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av1168 = ((P0 + (P1 + P2)))
not (R->P0 in ev1168)
semantics7[av1169, ev1169]
all a: lab.T0 | a.av1169 = (P1)
all a: lab.T1 | a.av1169 = ((P3 + P4))
not (R->P0 in ev1169)
semantics0[av1170, ev1170]
all a: lab.T0 | a.av1170 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av1170 = ((P3 + P4))
not (R->P0 in ev1170)
semantics2[av1171, ev1171]
all a: lab.T0 | a.av1171 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av1171 = ((P1 + P2))
not (R->P0 in ev1171)
semantics4[av1172, ev1172]
all a: lab.T0 | a.av1172 = ((P3 + P4))
all a: lab.T1 | a.av1172 = ((P0 + P4))
not (R->P0 in ev1172)
semantics9[av1173, ev1173]
all a: lab.T0 | a.av1173 = ((P1 + (P2 + P4)))
all a: lab.T1 | a.av1173 = (P4)
not (R->P0 in ev1173)
semantics9[av1174, ev1174]
all a: lab.T0 | a.av1174 = ((P0 + P1))
all a: lab.T1 | a.av1174 = ((P0 + P1))
not (R->P0 in ev1174)
semantics0[av1175, ev1175]
all a: lab.T0 | a.av1175 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av1175 = ((P0 + (P1 + P4)))
not (R->P0 in ev1175)
semantics9[av1176, ev1176]
all a: lab.T0 | a.av1176 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av1176 = ((P2 + P4))
not (R->P0 in ev1176)
semantics11[av1177, ev1177]
all a: lab.T0 | a.av1177 = ((P0 + P1))
all a: lab.T1 | a.av1177 = (P3)
not (R->P0 in ev1177)
semantics4[av1178, ev1178]
all a: lab.T0 | a.av1178 = ((P0 + P4))
all a: lab.T1 | a.av1178 = ((P0 + P3))
not (R->P0 in ev1178)
semantics0[av1179, ev1179]
all a: lab.T0 | a.av1179 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av1179 = (P4)
not (R->P0 in ev1179)
semantics0[av1180, ev1180]
all a: lab.T0 | a.av1180 = ((P2 + P4))
all a: lab.T1 | a.av1180 = (P1)
not (R->P0 in ev1180)
semantics0[av1181, ev1181]
all a: lab.T0 | a.av1181 = ((P1 + P4))
all a: lab.T1 | a.av1181 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev1181)
semantics7[av1182, ev1182]
all a: lab.T0 | a.av1182 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av1182 = ((P0 + (P2 + P3)))
not (R->P0 in ev1182)
semantics0[av1183, ev1183]
all a: lab.T0 | a.av1183 = (P4)
all a: lab.T1 | a.av1183 = ((P0 + P3))
not (R->P0 in ev1183)
semantics9[av1184, ev1184]
all a: lab.T0 | a.av1184 = (none)
all a: lab.T1 | a.av1184 = ((P2 + (P3 + P4)))
not (R->P0 in ev1184)
semantics0[av1185, ev1185]
all a: lab.T0 | a.av1185 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av1185 = ((P2 + (P3 + P4)))
not (R->P0 in ev1185)
semantics0[av1186, ev1186]
all a: lab.T0 | a.av1186 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av1186 = (none)
not (R->P0 in ev1186)
semantics0[av1187, ev1187]
all a: lab.T0 | a.av1187 = ((P2 + P3))
all a: lab.T1 | a.av1187 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev1187)
semantics4[av1188, ev1188]
all a: lab.T0 | a.av1188 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av1188 = ((P3 + P4))
not (R->P0 in ev1188)
semantics4[av1189, ev1189]
all a: lab.T0 | a.av1189 = (P4)
all a: lab.T1 | a.av1189 = ((P0 + P3))
not (R->P0 in ev1189)
semantics4[av1190, ev1190]
all a: lab.T0 | a.av1190 = ((P0 + P2))
all a: lab.T1 | a.av1190 = ((P0 + P4))
not (R->P0 in ev1190)
semantics7[av1191, ev1191]
all a: lab.T0 | a.av1191 = (P0)
all a: lab.T1 | a.av1191 = (P2)
not (R->P0 in ev1191)
semantics3[av1192, ev1192]
all a: lab.T0 | a.av1192 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1192 = ((P2 + P4))
not (R->P0 in ev1192)
semantics9[av1193, ev1193]
all a: lab.T0 | a.av1193 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1193 = (P0)
not (R->P0 in ev1193)
semantics4[av1194, ev1194]
all a: lab.T0 | a.av1194 = (none)
all a: lab.T1 | a.av1194 = ((P0 + P4))
not (R->P0 in ev1194)
semantics0[av1195, ev1195]
all a: lab.T0 | a.av1195 = ((P0 + P2))
all a: lab.T1 | a.av1195 = ((P0 + (P2 + P4)))
not (R->P0 in ev1195)
semantics7[av1196, ev1196]
all a: lab.T0 | a.av1196 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1196 = ((P0 + P3))
not (R->P0 in ev1196)
semantics7[av1197, ev1197]
all a: lab.T0 | a.av1197 = ((P2 + P4))
all a: lab.T1 | a.av1197 = (P1)
not (R->P0 in ev1197)
semantics9[av1198, ev1198]
all a: lab.T0 | a.av1198 = (P0)
all a: lab.T1 | a.av1198 = ((P1 + P2))
not (R->P0 in ev1198)
semantics3[av1199, ev1199]
all a: lab.T0 | a.av1199 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av1199 = (P4)
not (R->P0 in ev1199)
semantics2[av1200, ev1200]
all a: lab.T0 | a.av1200 = ((P0 + P2))
all a: lab.T1 | a.av1200 = ((P0 + (P1 + P3)))
not (R->P0 in ev1200)
semantics3[av1201, ev1201]
all a: lab.T0 | a.av1201 = ((P1 + P3))
all a: lab.T1 | a.av1201 = (P3)
not (R->P0 in ev1201)
semantics13[av1202, ev1202]
all a: lab.T0 | a.av1202 = (P2)
all a: lab.T1 | a.av1202 = ((P0 + P2))
not (R->P0 in ev1202)
semantics9[av1203, ev1203]
all a: lab.T0 | a.av1203 = ((P0 + P3))
all a: lab.T1 | a.av1203 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev1203)
semantics0[av1204, ev1204]
all a: lab.T0 | a.av1204 = ((P2 + P3))
all a: lab.T1 | a.av1204 = ((P2 + (P3 + P4)))
not (R->P0 in ev1204)
semantics9[av1205, ev1205]
all a: lab.T0 | a.av1205 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1205 = ((P0 + (P2 + P3)))
not (R->P0 in ev1205)
semantics3[av1206, ev1206]
all a: lab.T0 | a.av1206 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av1206 = ((P0 + (P1 + P3)))
not (R->P0 in ev1206)
semantics5[av1207, ev1207]
all a: lab.T0 | a.av1207 = (P1)
all a: lab.T1 | a.av1207 = (P3)
not (R->P0 in ev1207)
semantics3[av1208, ev1208]
all a: lab.T0 | a.av1208 = (((P0 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1208 = ((P1 + (P3 + P4)))
not (R->P0 in ev1208)
semantics4[av1209, ev1209]
all a: lab.T0 | a.av1209 = ((P0 + (P2 + P3)))
all a: lab.T1 | a.av1209 = ((P1 + P4))
not (R->P0 in ev1209)
semantics0[av1210, ev1210]
all a: lab.T0 | a.av1210 = (P0)
all a: lab.T1 | a.av1210 = (P4)
not (R->P0 in ev1210)
semantics0[av1211, ev1211]
all a: lab.T0 | a.av1211 = ((P0 + (P3 + P4)))
all a: lab.T1 | a.av1211 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev1211)
semantics3[av1212, ev1212]
all a: lab.T0 | a.av1212 = (P1)
all a: lab.T1 | a.av1212 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev1212)
semantics3[av1213, ev1213]
all a: lab.T0 | a.av1213 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av1213 = ((P3 + P4))
not (R->P0 in ev1213)
semantics7[av1214, ev1214]
all a: lab.T0 | a.av1214 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1214 = ((P0 + (P2 + P3)))
not (R->P0 in ev1214)
semantics4[av1215, ev1215]
all a: lab.T0 | a.av1215 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av1215 = (P0)
not (R->P0 in ev1215)
semantics9[av1216, ev1216]
all a: lab.T0 | a.av1216 = (((P0 + P1) + (P3 + P4)))
all a: lab.T1 | a.av1216 = (P4)
not (R->P0 in ev1216)
semantics12[av1217, ev1217]
all a: lab.T0 | a.av1217 = (P0)
all a: lab.T1 | a.av1217 = (P1)
not (R->P0 in ev1217)
semantics9[av1218, ev1218]
all a: lab.T0 | a.av1218 = (P3)
all a: lab.T1 | a.av1218 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev1218)
semantics0[av1219, ev1219]
all a: lab.T0 | a.av1219 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1219 = ((P0 + (P2 + P3)))
not (R->P0 in ev1219)
semantics2[av1220, ev1220]
all a: lab.T0 | a.av1220 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av1220 = ((P0 + (P1 + P3)))
not (R->P0 in ev1220)
semantics7[av1221, ev1221]
all a: lab.T0 | a.av1221 = (P3)
all a: lab.T1 | a.av1221 = ((P1 + P4))
not (R->P0 in ev1221)
semantics3[av1222, ev1222]
all a: lab.T0 | a.av1222 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av1222 = (P2)
not (R->P0 in ev1222)
semantics4[av1223, ev1223]
all a: lab.T0 | a.av1223 = ((P1 + P4))
all a: lab.T1 | a.av1223 = (((P1 + P2) + (P3 + P4)))
not (R->P0 in ev1223)
semantics9[av1224, ev1224]
all a: lab.T0 | a.av1224 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av1224 = ((P1 + P4))
not (R->P0 in ev1224)
semantics3[av1225, ev1225]
all a: lab.T0 | a.av1225 = (P0)
all a: lab.T1 | a.av1225 = ((P3 + P4))
not (R->P0 in ev1225)
semantics9[av1226, ev1226]
all a: lab.T0 | a.av1226 = (P2)
all a: lab.T1 | a.av1226 = ((P1 + (P3 + P4)))
not (R->P0 in ev1226)
semantics9[av1227, ev1227]
all a: lab.T0 | a.av1227 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av1227 = ((P1 + (P2 + P4)))
not (R->P0 in ev1227)
semantics4[av1228, ev1228]
all a: lab.T0 | a.av1228 = ((P1 + P2))
all a: lab.T1 | a.av1228 = ((P1 + (P2 + P4)))
not (R->P0 in ev1228)
semantics4[av1229, ev1229]
all a: lab.T0 | a.av1229 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av1229 = ((P0 + (P2 + P3)))
not (R->P0 in ev1229)
semantics14[av1230, ev1230]
all a: lab.T0 | a.av1230 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1230 = ((P1 + P3))
not (R->P0 in ev1230)
semantics7[av1231, ev1231]
all a: lab.T0 | a.av1231 = ((P2 + (P3 + P4)))
all a: lab.T1 | a.av1231 = ((P1 + P4))
not (R->P0 in ev1231)
semantics3[av1232, ev1232]
all a: lab.T0 | a.av1232 = ((P0 + P4))
all a: lab.T1 | a.av1232 = (((P0 + P1) + (P3 + P4)))
not (R->P0 in ev1232)
semantics14[av1233, ev1233]
all a: lab.T0 | a.av1233 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1233 = ((P1 + (P2 + P3)))
not (R->P0 in ev1233)
semantics5[av1234, ev1234]
all a: lab.T0 | a.av1234 = (none)
all a: lab.T1 | a.av1234 = ((P1 + (P2 + P3)))
not (R->P0 in ev1234)
semantics12[av1235, ev1235]
all a: lab.T0 | a.av1235 = (P2)
all a: lab.T1 | a.av1235 = ((P0 + (P1 + P2)))
not (R->P0 in ev1235)
semantics9[av1236, ev1236]
all a: lab.T0 | a.av1236 = ((P1 + P2))
all a: lab.T1 | a.av1236 = (((P0 + P1) + (P2 + (P3 + P4))))
not (R->P0 in ev1236)
semantics3[av1237, ev1237]
all a: lab.T0 | a.av1237 = ((P0 + P4))
all a: lab.T1 | a.av1237 = ((P3 + P4))
not (R->P0 in ev1237)
semantics5[av1238, ev1238]
all a: lab.T0 | a.av1238 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1238 = ((P0 + P3))
not (R->P0 in ev1238)
semantics2[av1239, ev1239]
all a: lab.T0 | a.av1239 = (P3)
all a: lab.T1 | a.av1239 = (P1)
not (R->P0 in ev1239)
semantics9[av1240, ev1240]
all a: lab.T0 | a.av1240 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av1240 = ((P1 + (P2 + P3)))
not (R->P0 in ev1240)
semantics9[av1241, ev1241]
all a: lab.T0 | a.av1241 = ((P1 + (P3 + P4)))
all a: lab.T1 | a.av1241 = ((P0 + (P2 + P3)))
not (R->P0 in ev1241)
semantics3[av1242, ev1242]
all a: lab.T0 | a.av1242 = (((P1 + P2) + (P3 + P4)))
all a: lab.T1 | a.av1242 = (P4)
not (R->P0 in ev1242)
semantics0[av1243, ev1243]
all a: lab.T0 | a.av1243 = (P3)
all a: lab.T1 | a.av1243 = ((P2 + (P3 + P4)))
not (R->P0 in ev1243)
semantics0[av1244, ev1244]
all a: lab.T0 | a.av1244 = ((P1 + P4))
all a: lab.T1 | a.av1244 = ((P1 + P4))
not (R->P0 in ev1244)
semantics0[av1245, ev1245]
all a: lab.T0 | a.av1245 = (P3)
all a: lab.T1 | a.av1245 = ((P0 + (P1 + P2)))
not (R->P0 in ev1245)
semantics9[av1246, ev1246]
all a: lab.T0 | a.av1246 = ((P0 + P4))
all a: lab.T1 | a.av1246 = ((P0 + (P1 + P3)))
not (R->P0 in ev1246)
semantics7[av1247, ev1247]
all a: lab.T0 | a.av1247 = ((P0 + (P1 + P2)))
all a: lab.T1 | a.av1247 = ((P3 + P4))
not (R->P0 in ev1247)
semantics5[av1248, ev1248]
all a: lab.T0 | a.av1248 = (P0)
all a: lab.T1 | a.av1248 = ((P2 + P3))
not (R->P0 in ev1248)
semantics9[av1249, ev1249]
all a: lab.T0 | a.av1249 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av1249 = ((P2 + (P3 + P4)))
not (R->P0 in ev1249)
semantics0[av1250, ev1250]
all a: lab.T0 | a.av1250 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av1250 = ((P0 + (P2 + P3)))
not (R->P0 in ev1250)
semantics0[av1251, ev1251]
all a: lab.T0 | a.av1251 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1251 = (((P0 + P1) + (P2 + P4)))
not (R->P0 in ev1251)
semantics5[av1252, ev1252]
all a: lab.T0 | a.av1252 = (none)
all a: lab.T1 | a.av1252 = ((P0 + (P2 + P3)))
not (R->P0 in ev1252)
semantics0[av1253, ev1253]
all a: lab.T0 | a.av1253 = ((P0 + P3))
all a: lab.T1 | a.av1253 = ((P2 + (P3 + P4)))
not (R->P0 in ev1253)
semantics9[av1254, ev1254]
all a: lab.T0 | a.av1254 = ((P0 + (P1 + P4)))
all a: lab.T1 | a.av1254 = ((P0 + P4))
not (R->P0 in ev1254)
semantics7[av1255, ev1255]
all a: lab.T0 | a.av1255 = ((P2 + P3))
all a: lab.T1 | a.av1255 = ((P0 + (P1 + P2)))
not (R->P0 in ev1255)
semantics2[av1256, ev1256]
all a: lab.T0 | a.av1256 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1256 = ((P0 + (P1 + P2)))
not (R->P0 in ev1256)
semantics2[av1257, ev1257]
all a: lab.T0 | a.av1257 = ((P1 + P3))
all a: lab.T1 | a.av1257 = (P2)
not (R->P0 in ev1257)
semantics3[av1258, ev1258]
all a: lab.T0 | a.av1258 = ((P0 + P4))
all a: lab.T1 | a.av1258 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev1258)
semantics9[av1259, ev1259]
all a: lab.T0 | a.av1259 = (P3)
all a: lab.T1 | a.av1259 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev1259)
semantics2[av1260, ev1260]
all a: lab.T0 | a.av1260 = (P3)
all a: lab.T1 | a.av1260 = ((P0 + (P1 + P2)))
not (R->P0 in ev1260)
semantics5[av1261, ev1261]
all a: lab.T0 | a.av1261 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1261 = ((P1 + P3))
not (R->P0 in ev1261)
semantics7[av1262, ev1262]
all a: lab.T0 | a.av1262 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av1262 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev1262)
semantics4[av1263, ev1263]
all a: lab.T0 | a.av1263 = ((P3 + P4))
all a: lab.T1 | a.av1263 = ((P1 + (P2 + P3)))
not (R->P0 in ev1263)
semantics3[av1264, ev1264]
all a: lab.T0 | a.av1264 = ((P3 + P4))
all a: lab.T1 | a.av1264 = ((P1 + (P2 + P3)))
not (R->P0 in ev1264)
semantics3[av1265, ev1265]
all a: lab.T0 | a.av1265 = ((P3 + P4))
all a: lab.T1 | a.av1265 = ((P1 + P4))
not (R->P0 in ev1265)
semantics9[av1266, ev1266]
all a: lab.T0 | a.av1266 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1266 = (P3)
not (R->P0 in ev1266)
semantics0[av1267, ev1267]
all a: lab.T0 | a.av1267 = ((P0 + (P2 + P4)))
all a: lab.T1 | a.av1267 = ((P1 + (P2 + P4)))
not (R->P0 in ev1267)
semantics3[av1268, ev1268]
all a: lab.T0 | a.av1268 = ((P1 + P2))
all a: lab.T1 | a.av1268 = ((P0 + (P2 + P3)))
not (R->P0 in ev1268)
semantics9[av1269, ev1269]
all a: lab.T0 | a.av1269 = (P2)
all a: lab.T1 | a.av1269 = ((P2 + P3))
not (R->P0 in ev1269)
semantics3[av1270, ev1270]
all a: lab.T0 | a.av1270 = (P4)
all a: lab.T1 | a.av1270 = (P2)
not (R->P0 in ev1270)
semantics2[av1271, ev1271]
all a: lab.T0 | a.av1271 = (P2)
all a: lab.T1 | a.av1271 = (P2)
not (R->P0 in ev1271)
semantics5[av1272, ev1272]
all a: lab.T0 | a.av1272 = (P3)
all a: lab.T1 | a.av1272 = ((P1 + (P2 + P3)))
not (R->P0 in ev1272)
semantics3[av1273, ev1273]
all a: lab.T0 | a.av1273 = ((P0 + P1))
all a: lab.T1 | a.av1273 = (P4)
not (R->P0 in ev1273)
semantics2[av1274, ev1274]
all a: lab.T0 | a.av1274 = ((P0 + (P1 + P3)))
all a: lab.T1 | a.av1274 = (none)
not (R->P0 in ev1274)
semantics9[av1275, ev1275]
all a: lab.T0 | a.av1275 = (((P0 + P1) + (P2 + P3)))
all a: lab.T1 | a.av1275 = ((P0 + (P3 + P4)))
not (R->P0 in ev1275)
semantics4[av1276, ev1276]
all a: lab.T0 | a.av1276 = ((P1 + (P2 + P3)))
all a: lab.T1 | a.av1276 = (((P0 + P1) + (P2 + P3)))
not (R->P0 in ev1276)
semantics0[av1277, ev1277]
all a: lab.T0 | a.av1277 = (((P0 + P1) + (P2 + P4)))
all a: lab.T1 | a.av1277 = ((P0 + (P3 + P4)))
not (R->P0 in ev1277)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 5 Int

open util/ordering[SeqIdx]

abstract sig DAGNode {
	l: set DAGNode,
	r: set DAGNode
}
fact {
	all n: DAGNode | n not in n.^(l + r)
}

sig And, Or, Imply extends DAGNode {} {
	one l
	one r
}

sig Neg, G extends DAGNode {} {
    one l
    no r
}
abstract sig Literal extends DAGNode {} {
	no l
	no r
}

abstract sig SeqIdx {}
abstract sig Trace {
	lasso: SeqIdx -> SeqIdx,
	valuation: DAGNode -> SeqIdx
} {
	// Negation
    all n: Neg, i: seqRange | n->i in valuation iff n.l->i not in valuation
	// Or
    all n: Or, i: seqRange | n->i in valuation iff (n.l->i in valuation or n.r->i in valuation)
	// And
    all n: And, i: seqRange | n->i in valuation iff (n.l->i in valuation and n.r->i in valuation)
	// Imply
    all n: Imply, i: seqRange | n->i in valuation iff (n.l->i not in valuation or n.r->i in valuation)
	// G
    all n: G, i: seqRange | n->i in valuation iff all i': futureIdx[i] | n.l->i' in valuation
    // X
    
	// F
    
	// Until
    
}
fun seqRange[t: Trace]: set SeqIdx {
	let lastOfTrace = t.lasso.SeqIdx | lastOfTrace.prevs + lastOfTrace
}
fun futureIdx[t: Trace, i: SeqIdx]: set SeqIdx {
	i.^((next :> seqRange[t]) + t.lasso) + i
}
abstract sig PositiveTrace extends Trace {}
abstract sig NegativeTrace extends Trace {}
one sig x0, x1, x2 extends Literal {}
one sig T0, T1, T2, T3, T4, T5, T6, T7, T8, T9 extends SeqIdx {}
fact {
    first = T0
    next = T0->T1 + T1->T2 + T2->T3 + T3->T4 + T4->T5 + T5->T6 + T6->T7 + T7->T8 + T8->T9
}

one sig PT0 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x1->T7 + x2->T8 + x0->T9 + x1->T9 in valuation
    no (x2->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x0->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T9) & valuation
}

one sig PT1 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x2->T3 + x0->T6 + x0->T7 + x0->T9 + x2->T9) & valuation
}

one sig PT2 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T5 + x2->T5 + x1->T7 in valuation
    no (x0->T1 + x1->T1 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig PT3 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T4 + x1->T4 + x2->T4 + x1->T5 + x1->T6 + x2->T6 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T5 + x2->T5 + x0->T6 + x0->T7 + x2->T7 + x2->T8 + x2->T9) & valuation
}

one sig PT4 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x2->T4 + x0->T5 + x1->T5 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T5 + x0->T6 + x1->T6 + x0->T8 + x0->T9) & valuation
}

one sig PT5 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T5 + x0->T8 + x2->T8 + x2->T9) & valuation
}

one sig PT6 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T4 + x2->T4 + x1->T5 + x0->T6 + x1->T6 + x1->T8 + x1->T9 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x0->T5 + x2->T5 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT7 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T1 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T7 + x2->T8 + x2->T9) & valuation
}

one sig PT8 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T3 + x1->T3 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x1->T8 + x2->T8 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T3 + x0->T4 + x0->T6 + x0->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig PT9 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x2->T4 + x0->T5 + x1->T5 + x1->T6 + x2->T6 + x2->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T5 + x0->T6 + x0->T7 + x1->T7 + x2->T8) & valuation
}

one sig PT10 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T2 + x2->T4 + x0->T6 + x0->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9) & valuation
}

one sig PT11 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x0->T8 + x1->T8 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x0->T5 + x0->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T9) & valuation
}

one sig PT12 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x1->T9 in valuation
    no (x0->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T4 + x0->T5 + x2->T5 + x0->T9 + x2->T9) & valuation
}

one sig PT13 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 in valuation
    no (x0->T0 + x0->T1 + x0->T2 + x1->T2 + x0->T5 + x1->T5 + x0->T6 + x0->T8 + x1->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig PT14 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T0 + x1->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x2->T9) & valuation
}

one sig PT15 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T0 + x1->T1 + x1->T3 + x2->T3 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x0->T7 + x0->T8 + x2->T8 + x2->T9) & valuation
}

one sig PT16 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T4 + x2->T5 + x1->T6 + x1->T7 + x0->T8 + x1->T8 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x2->T8 + x0->T9 + x1->T9) & valuation
}

one sig PT17 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x2->T7 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T4 + x2->T4 + x0->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x1->T8 + x2->T8) & valuation
}

one sig PT18 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x1->T5 + x2->T5 + x1->T7 + x0->T8 + x1->T8 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x2->T0 + x2->T1 + x2->T4 + x0->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x2->T7 + x2->T8 + x0->T9) & valuation
}

one sig PT19 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x1->T6 + x1->T8 + x2->T8 + x1->T9 in valuation
    no (x0->T0 + x0->T1 + x2->T1 + x0->T3 + x0->T5 + x1->T5 + x0->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT20 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T1 + x1->T1 + x0->T3 + x1->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x2->T6 + x0->T7 + x1->T7 + x1->T8 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T5 + x0->T6 + x1->T6 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig PT21 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T2 + x1->T3 + x2->T4 + x1->T5 + x2->T5 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x2->T1 + x0->T2 + x1->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x0->T6 + x1->T6 + x2->T6 + x2->T7 + x2->T8) & valuation
}

one sig PT22 extends PositiveTrace {} {
    lasso = T9->T0
    x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 + x2->T6 + x1->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x0->T4 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x2->T8) & valuation
}

one sig PT23 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T1 + x2->T2 + x2->T3 + x1->T4 + x2->T4 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x1->T7 + x1->T9 + x2->T9 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x0->T5 + x1->T5 + x0->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x0->T9) & valuation
}

one sig PT24 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T3 + x1->T3 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x1->T7 + x2->T7 + x1->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x2->T3 + x0->T4 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x0->T8 + x2->T8) & valuation
}

one sig PT25 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x1->T7 + x0->T8 + x1->T8 + x1->T9 in valuation
    no (x2->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x2->T7 + x2->T8 + x0->T9 + x2->T9) & valuation
}

one sig PT26 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x0->T7 + x1->T7 + x1->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T2 + x0->T3 + x0->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x2->T7 + x0->T8 + x2->T8) & valuation
}

one sig PT27 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x2->T3 + x2->T5 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x0->T6 + x2->T7 + x0->T8 + x1->T8) & valuation
}

one sig PT28 extends PositiveTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T1 + x2->T3 + x1->T4 + x2->T4 + x0->T7 + x1->T7 + x2->T7 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x1->T3 + x0->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T8 + x1->T8 + x2->T8 + x2->T9) & valuation
}

one sig PT29 extends PositiveTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T6 + x0->T7 + x1->T7 + x0->T8 + x1->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x2->T1 + x2->T2 + x2->T3 + x2->T5 + x0->T6 + x1->T6 + x2->T7 + x2->T8) & valuation
}


one sig NT0 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4 + x1->T5 + x2->T5 + x2->T6 + x0->T7 + x0->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x2->T0 + x0->T1 + x0->T3 + x2->T3 + x1->T4 + x0->T5 + x0->T6 + x1->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x2->T9) & valuation
}

one sig NT1 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x1->T5 + x1->T7 + x2->T7 + x0->T8 + x2->T8 in valuation
    no (x1->T0 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x1->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig NT2 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T5 + x1->T6 + x2->T6 + x1->T7 + x1->T8 + x1->T9) & valuation
}

one sig NT3 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x0->T3 + x0->T4 + x1->T4 + x2->T4 + x1->T6 + x0->T7 + x1->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x2->T6 + x1->T7 + x2->T7 + x0->T8 + x1->T9) & valuation
}

one sig NT4 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x0->T5 + x2->T5 + x2->T6 + x2->T7 + x0->T8 + x2->T8 + x0->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x2->T4 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x1->T7 + x1->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT5 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x1->T3 + x1->T4 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT6 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x2->T8 + x0->T9 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x1->T3 + x1->T4 + x1->T5 + x1->T6 + x1->T7 + x2->T7 + x1->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT7 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x1->T5 + x1->T6 + x1->T7 + x2->T7 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT8 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x2->T3 + x0->T4 + x1->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x0->T9 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x1->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT9 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x0->T4 + x1->T4 + x2->T4 + x2->T5 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 in valuation
    no (x1->T0 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x0->T7 + x0->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig NT10 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x0->T4 + x2->T4 + x0->T5 + x1->T6 + x0->T7 + x1->T7 + x0->T8 + x2->T8 + x0->T9 in valuation
    no (x1->T0 + x0->T1 + x0->T3 + x2->T3 + x1->T4 + x1->T5 + x2->T5 + x0->T6 + x2->T6 + x2->T7 + x1->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT11 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x1->T2 + x0->T4 + x2->T4 + x2->T5 + x0->T6 + x0->T9 in valuation
    no (x1->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x0->T5 + x1->T5 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT12 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x0->T5 + x2->T5 + x0->T6 + x0->T7 + x0->T8 + x2->T8 + x0->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT13 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 + x0->T5 + x0->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x1->T5 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x1->T8 + x1->T9) & valuation
}

one sig NT14 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x0->T1 + x2->T1 + x0->T2 + x0->T3 + x2->T3 + x0->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x0->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x2->T0 + x1->T1 + x1->T2 + x2->T2 + x1->T3 + x1->T4 + x1->T5 + x1->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT15 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x2->T2 + x0->T3 + x1->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x0->T4 + x1->T5 + x1->T6 + x1->T7 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT16 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x0->T1 + x0->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x2->T5 + x0->T7 + x1->T7 + x2->T7 + x0->T8 + x1->T8 + x0->T9 in valuation
    no (x2->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T3 + x1->T4 + x0->T5 + x1->T5 + x0->T6 + x1->T6 + x2->T6 + x2->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT17 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T1 + x0->T3 + x0->T4 + x0->T5 + x2->T5 + x1->T6 + x2->T6 + x0->T7 + x0->T8 + x2->T9 in valuation
    no (x1->T0 + x2->T0 + x0->T1 + x1->T1 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x0->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x0->T9 + x1->T9) & valuation
}

one sig NT18 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x1->T2 + x0->T3 + x1->T3 + x2->T4 + x1->T5 + x0->T6 + x1->T8 + x2->T8 + x0->T9 + x1->T9 + x2->T9 in valuation
    no (x0->T1 + x2->T2 + x2->T3 + x0->T4 + x1->T4 + x0->T5 + x2->T5 + x1->T6 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x0->T8) & valuation
}

one sig NT19 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x0->T2 + x0->T3 + x0->T4 + x0->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 in valuation
    no (x1->T0 + x1->T1 + x2->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x2->T5 + x1->T6 + x1->T7 + x1->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT20 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T3 + x0->T4 + x0->T5 + x1->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 in valuation
    no (x2->T0 + x1->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 + x2->T5 + x1->T6 + x1->T7 + x1->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT21 extends NegativeTrace {} {
    lasso = T9->T0
    x2->T0 + x1->T1 + x1->T3 + x2->T3 + x1->T4 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x2->T6 + x0->T7 + x0->T8 + x1->T8 in valuation
    no (x0->T0 + x1->T0 + x0->T1 + x2->T1 + x0->T2 + x1->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 + x0->T5 + x1->T7 + x2->T7 + x2->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig NT22 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x0->T1 + x1->T2 + x2->T2 + x0->T3 + x2->T3 + x1->T4 + x2->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T1 + x2->T1 + x0->T2 + x1->T3 + x0->T4 + x1->T6 + x1->T7 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT23 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x1->T0 + x2->T0 + x2->T1 + x0->T2 + x1->T2 + x0->T4 + x1->T4 + x0->T5 + x2->T5 + x1->T6 + x2->T6 + x0->T7 + x2->T7 + x2->T8 + x1->T9 + x2->T9 in valuation
    no (x0->T1 + x1->T1 + x2->T2 + x0->T3 + x1->T3 + x2->T3 + x2->T4 + x1->T5 + x0->T6 + x1->T7 + x0->T8 + x1->T8 + x0->T9) & valuation
}

one sig NT24 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x1->T1 + x0->T2 + x2->T2 + x0->T3 + x0->T4 + x2->T4 + x0->T5 + x1->T5 + x0->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x2->T9 in valuation
    no (x1->T0 + x0->T1 + x2->T1 + x1->T2 + x1->T3 + x2->T3 + x1->T4 + x2->T5 + x1->T6 + x2->T6 + x1->T7 + x1->T8 + x0->T9 + x1->T9) & valuation
}

one sig NT25 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x2->T1 + x1->T2 + x2->T2 + x0->T4 + x0->T5 + x2->T5 + x0->T6 + x0->T7 + x0->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x1->T1 + x0->T2 + x0->T3 + x1->T3 + x2->T3 + x1->T4 + x2->T4 + x1->T5 + x1->T6 + x2->T6 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x1->T9) & valuation
}

one sig NT26 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x0->T2 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x2->T5 + x0->T6 + x1->T6 + x0->T8 + x0->T9 + x1->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T3 + x1->T4 + x0->T5 + x1->T5 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x1->T8 + x2->T8 + x2->T9) & valuation
}

one sig NT27 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x2->T1 + x1->T2 + x0->T3 + x1->T3 + x0->T4 + x2->T4 + x2->T5 + x0->T6 + x2->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 in valuation
    no (x0->T0 + x0->T1 + x1->T1 + x0->T2 + x2->T2 + x2->T3 + x1->T4 + x0->T5 + x1->T5 + x1->T6 + x1->T7 + x1->T8 + x1->T9 + x2->T9) & valuation
}

one sig NT28 extends NegativeTrace {} {
    lasso = T9->T0
    x0->T0 + x2->T0 + x0->T1 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x0->T4 + x2->T4 + x0->T5 + x2->T5 + x0->T6 + x0->T7 + x2->T7 + x0->T8 + x2->T8 + x0->T9 + x2->T9 in valuation
    no (x1->T0 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x1->T4 + x1->T5 + x1->T6 + x2->T6 + x1->T7 + x1->T8 + x1->T9) & valuation
}

one sig NT29 extends NegativeTrace {} {
    lasso = T9->T0
    x1->T0 + x2->T0 + x1->T1 + x2->T1 + x0->T2 + x0->T3 + x1->T4 + x0->T5 + x1->T5 + x2->T5 + x0->T6 + x1->T6 + x0->T8 + x1->T8 in valuation
    no (x0->T0 + x0->T1 + x1->T2 + x2->T2 + x1->T3 + x2->T3 + x0->T4 + x2->T4 + x2->T6 + x0->T7 + x1->T7 + x2->T7 + x2->T8 + x0->T9 + x1->T9 + x2->T9) & valuation
}

one sig LearnedLTL {
    Root: DAGNode
}
fun root: one DAGNode { LearnedLTL.Root }
fun childrenOf[n: DAGNode]: set DAGNode { n.^(l+r) }
fun childrenAndSelfOf[n: DAGNode]: set DAGNode { n.*(l+r) }
fun ancestorsOf[n: DAGNode]: set DAGNode { n.~^(l+r) }
fun ancestorsAndSelfOf[n: DAGNode]: set DAGNode { n.~*(l+r) }
fun subDAG[n: DAGNode]: DAGNode -> DAGNode { n.*(l+r) <: (l+r) }

fact {
    root = G0

    all imply: Imply {
        all n: childrenOf[imply] | n in (Literal + And + Or + Neg)
        all n: childrenOf[imply] & Neg | n.l in Literal
        all n: childrenAndSelfOf[imply.l] & Or | no childrenOf[n] & And
        all n: childrenAndSelfOf[imply.r] & And | no childrenOf[n] & Or
    }
}

one sig G0 extends G {} { l = Imply0 }
one sig Imply0 extends Imply {}
one sig And0 extends And {}


fact {
    Imply0.l = x0 or (Imply0.l in And and Imply0.l.l = x0)

    Imply0.r = And0 or (Imply0.r in Or and Imply0.r.l = And0)
    (And0->x1 + And0->x2) in subDAG[Imply0.r]
}

fun experimentReach: set DAGNode { childrenAndSelfOf[root] }
fun experimentKept: DAGNode -> DAGNode { (none->none) & subDAG[root] }
one sig ExperimentCost { used: set DAGNode }
fact { ExperimentCost.used = experimentReach }
fact ExperimentBounds {
  DAGNode = experimentReach + Literal + (none)
  #experimentReach <= 8
  #(experimentReach & (And + Or + Imply)) <= 3
  minsome ExperimentCost.used
}
run {
    all t: PositiveTrace | root->T0 in t.valuation
    all t: NegativeTrace | root->T0 not in t.valuation
    
} for 11 DAGNode, 5 Int
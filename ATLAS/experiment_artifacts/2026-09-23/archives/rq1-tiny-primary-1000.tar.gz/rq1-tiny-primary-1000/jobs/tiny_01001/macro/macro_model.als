abstract sig Unit {}
one sig U0, U1 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7 extends Label {}
abstract sig Q {}
one sig Q0, Q1, Q2 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E2, E4, E8, E12, E17, E19, E20, E23, E26, E30, E32, E33, E35, E37 extends Fiber {}
abstract sig Pos {}
one sig P0, P1 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos }
one sig A0, A1 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos }
one sig R, C0, L0, D0, C1, L1, D1 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { T0 }
fun un: set Label { ((T1 + T2) + (T3 + T4)) }
fun bin: set Label { (T5 + (T6 + T7)) }
fun nonempty: set Fiber { (((E2 + (E4 + E8)) + (E12 + (E19 + E20))) + ((E23 + (E26 + E32)) + (E33 + (E35 + E37)))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { U0->U1 }
fun carrierNext: Carrier -> Carrier { (((A0->A1 + A1->R) + (R->C0 + C0->L0)) + ((L0->D0 + D0->C1) + (C1->L1 + L1->D1))) }
fun child[a: Anchor]: set Port { a.((A0->C0 + A1->C1)) }
fun left[a: Anchor]: set Port { a.((A0->L0 + A1->L1)) }
fun right[a: Anchor]: set Port { a.((A0->D0 + A1->D1)) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
#(lab.bin) <= 0
lone lab.T0
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E2.qi = Q0
E2.qo = Q1
E4.qi = Q0
E4.qo = Q1
E8.qi = Q0
E8.qo = Q1
E12.qi = Q0
E12.qo = Q1
E17.qi = Q1
E17.qo = Q1
E19.qi = Q1
E19.qo = Q2
E20.qi = Q1
E20.qo = Q1
E23.qi = Q1
E23.qo = Q1
E26.qi = Q1
E26.qo = Q1
E30.qi = Q2
E30.qo = Q2
E32.qi = Q2
E32.qo = Q2
E33.qi = Q2
E33.qo = Q2
E35.qi = Q2
E35.qo = Q2
E37.qi = Q2
E37.qo = Q2
all e: used | e.fiber in ((E0 + (E17 + E30))) implies #e.cost = 0
all e: used | e.fiber in ((((E2 + (E4 + E8)) + (E12 + (E19 + E20))) + ((E23 + (E26 + E32)) + (E33 + (E35 + E37))))) implies #e.cost = 1
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in ((Q0 + Q1))
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 and child[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T1 and child[a].fiber.qo = Q1 implies a.state = Q2
all a: active | a.lab = T1 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T2 and child[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T2 and child[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T2 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T3 and child[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T3 and child[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T3 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T4 and child[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T4 and child[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T4 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q2
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q2
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q2
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q2
}
fun range0: set Pos { (P0 + P1) }
fun loop0: set Pos { (P0 + P1) }
fun next0: Pos -> Pos { (P0->P1 + P1->P0) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { (P0->P0 + P1->P1) }
fun shift0_1: Pos -> Pos { (P0->P1 + P1->P0) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in ((E0 + (E17 + E30))) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + (E19 + E32))) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in ((E4 + (E20 + E33))) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in ((E8 + (E23 + E35))) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in ((E12 + (E26 + E37))) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T2 implies a.av = (next0.(child[a].ev))
all a: active | a.lab = T3 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T4 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T5 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T6 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T7 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { P0 }
fun loop1: set Pos { P0 }
fun next1: Pos -> Pos { P0->P0 }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { P0->P0 }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in (((E0 + (E12 + E17)) + (E26 + (E30 + E37)))) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in ((E2 + (E19 + E32))) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in ((E4 + (E20 + E33))) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in ((E8 + (E23 + E35))) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T2 implies a.av = (next1.(child[a].ev))
all a: active | a.lab = T3 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T4 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T5 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T6 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T7 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = (P1)
(R->P0 in ev0)
semantics1[av1, ev1]
all a: lab.T0 | a.av1 = (none)
not (R->P0 in ev1)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact CostBound { #Carrier.cost <= 2 }
run {} for 4 Int


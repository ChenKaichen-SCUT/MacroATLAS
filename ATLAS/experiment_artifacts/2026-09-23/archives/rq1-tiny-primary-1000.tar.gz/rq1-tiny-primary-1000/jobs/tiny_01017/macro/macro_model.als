abstract sig Unit {}
one sig U0, U1, U2, U3 extends Unit {}
abstract sig Label {}
one sig T0, T1, T2, T3, T4, T5, T6, T7 extends Label {}
abstract sig Q {}
one sig Q0, Q1, Q2 extends Q {}
abstract sig Fiber { qi: one Q, qo: one Q }
one sig E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, E10, E11, E12, E14, E15, E16, E18, E19, E20, E21, E22, E23, E24, E26, E27, E28, E30, E31, E32, E34, E35, E36, E39, E42, E48, E49, E50, E51, E52, E53, E54, E55, E56, E57, E59, E60, E62, E63, E64, E65, E66, E68, E69, E71, E72, E74, E75, E77, E79, E84, E85, E86, E87, E88, E89, E90, E91, E92, E93, E94, E95, E96, E97, E98, E99, E100, E101, E102, E103, E105, E107 extends Fiber {}
abstract sig Pos {}
one sig P0, P1, P2, P3, P4, P5, P6 extends Pos {}
abstract sig Carrier { cost: set Unit }
abstract sig Anchor extends Carrier { lab: lone Label, state: lone Q, av0: set Pos, av1: set Pos }
one sig A0, A1 extends Anchor {}
abstract sig Port extends Carrier { src: lone Anchor, target: lone Anchor, fiber: lone Fiber, ev0: set Pos, ev1: set Pos }
one sig R, C0, L0, D0, C1, L1, D1 extends Port {}
fun active: set Anchor { lab.Label }
fun used: set Port { target.Anchor }
fun lit: set Label { T0 }
fun un: set Label { ((T1 + T2) + (T3 + T4)) }
fun bin: set Label { (T5 + (T6 + T7)) }
fun nonempty: set Fiber { ((((((E1 + E2) + (E3 + E4)) + ((E5 + E6) + (E7 + (E8 + E9)))) + (((E10 + E11) + (E12 + (E14 + E15))) + ((E16 + E18) + (E19 + (E20 + E21))))) + ((((E22 + E23) + (E24 + (E26 + E27))) + ((E28 + E30) + (E31 + (E32 + E34)))) + (((E35 + E36) + (E39 + (E42 + E49))) + ((E50 + E51) + (E52 + (E53 + E54)))))) + (((((E55 + E56) + (E57 + E59)) + ((E60 + E62) + (E63 + (E64 + E65)))) + (((E66 + E68) + (E69 + (E71 + E72))) + ((E74 + E75) + (E77 + (E79 + E85))))) + ((((E86 + E87) + (E88 + (E89 + E90))) + ((E91 + E92) + (E93 + (E94 + E95)))) + (((E96 + E97) + (E98 + (E99 + E100))) + ((E101 + E102) + (E103 + (E105 + E107))))))) }
fun graph: Anchor -> Anchor { ~src.target }
fun unitNext: Unit -> Unit { (U0->U1 + (U1->U2 + U2->U3)) }
fun carrierNext: Carrier -> Carrier { (((A0->A1 + A1->R) + (R->C0 + C0->L0)) + ((L0->D0 + D0->C1) + (C1->L1 + L1->D1))) }
fun child[a: Anchor]: set Port { a.((A0->C0 + A1->C1)) }
fun left[a: Anchor]: set Port { a.((A0->L0 + A1->L1)) }
fun right[a: Anchor]: set Port { a.((A0->D0 + A1->D1)) }
fact Structure {
no R.src
one R.target
one R.fiber
all a: Anchor | (some a.lab iff one a.state) and (some a.lab iff one a.cost)
all a: Anchor - active | no a.cost + a.state
all e: Port | (some e.target iff one e.fiber) and e.target in active
all e: Port - used | no e.cost
C0.src = A0
L0.src = A0
D0.src = A0
(some C0.target iff A0.lab in un and some A0.lab)
(some L0.target iff A0.lab in bin and some A0.lab)
(some D0.target iff A0.lab in bin and some A0.lab)
C1.src = A1
L1.src = A1
D1.src = A1
(some C1.target iff A1.lab in un and some A1.lab)
(some L1.target iff A1.lab in bin and some A1.lab)
(some D1.target iff A1.lab in bin and some A1.lab)
no iden & ^graph
active = R.target.*graph
R.target = A0
no A0.graph & (A0)
no A1.graph & ((A0 + A1))
#(lab.bin) <= 0
lone lab.T0
some A0.lab and A0.lab in un implies #(target.A0) > 1
some A1.lab and A1.lab in un implies #(target.A1) > 1
some A1.lab implies some A0.lab
all disj c, d: Carrier | no c.cost & d.cost
all u: Unit - U0 | some cost.u implies some cost.(u.~unitNext)
all u: Unit | some cost.u implies cost.(u.~unitNext) in (cost.u).*~carrierNext
E0.qi = Q0
E0.qo = Q0
E1.qi = Q0
E1.qo = Q2
E2.qi = Q0
E2.qo = Q1
E3.qi = Q0
E3.qo = Q2
E4.qi = Q0
E4.qo = Q1
E5.qi = Q0
E5.qo = Q2
E6.qi = Q0
E6.qo = Q1
E7.qi = Q0
E7.qo = Q2
E8.qi = Q0
E8.qo = Q1
E9.qi = Q0
E9.qo = Q2
E10.qi = Q0
E10.qo = Q1
E11.qi = Q0
E11.qo = Q2
E12.qi = Q0
E12.qo = Q1
E14.qi = Q0
E14.qo = Q1
E15.qi = Q0
E15.qo = Q2
E16.qi = Q0
E16.qo = Q1
E18.qi = Q0
E18.qo = Q1
E19.qi = Q0
E19.qo = Q2
E20.qi = Q0
E20.qo = Q1
E21.qi = Q0
E21.qo = Q2
E22.qi = Q0
E22.qo = Q1
E23.qi = Q0
E23.qo = Q2
E24.qi = Q0
E24.qo = Q1
E26.qi = Q0
E26.qo = Q1
E27.qi = Q0
E27.qo = Q2
E28.qi = Q0
E28.qo = Q1
E30.qi = Q0
E30.qo = Q1
E31.qi = Q0
E31.qo = Q2
E32.qi = Q0
E32.qo = Q1
E34.qi = Q0
E34.qo = Q1
E35.qi = Q0
E35.qo = Q2
E36.qi = Q0
E36.qo = Q1
E39.qi = Q0
E39.qo = Q1
E42.qi = Q0
E42.qo = Q1
E48.qi = Q1
E48.qo = Q1
E49.qi = Q1
E49.qo = Q2
E50.qi = Q1
E50.qo = Q2
E51.qi = Q1
E51.qo = Q1
E52.qi = Q1
E52.qo = Q2
E53.qi = Q1
E53.qo = Q2
E54.qi = Q1
E54.qo = Q1
E55.qi = Q1
E55.qo = Q2
E56.qi = Q1
E56.qo = Q2
E57.qi = Q1
E57.qo = Q1
E59.qi = Q1
E59.qo = Q2
E60.qi = Q1
E60.qo = Q1
E62.qi = Q1
E62.qo = Q2
E63.qi = Q1
E63.qo = Q1
E64.qi = Q1
E64.qo = Q2
E65.qi = Q1
E65.qo = Q2
E66.qi = Q1
E66.qo = Q1
E68.qi = Q1
E68.qo = Q2
E69.qi = Q1
E69.qo = Q1
E71.qi = Q1
E71.qo = Q2
E72.qi = Q1
E72.qo = Q1
E74.qi = Q1
E74.qo = Q2
E75.qi = Q1
E75.qo = Q1
E77.qi = Q1
E77.qo = Q1
E79.qi = Q1
E79.qo = Q1
E84.qi = Q2
E84.qo = Q2
E85.qi = Q2
E85.qo = Q2
E86.qi = Q2
E86.qo = Q2
E87.qi = Q2
E87.qo = Q2
E88.qi = Q2
E88.qo = Q2
E89.qi = Q2
E89.qo = Q2
E90.qi = Q2
E90.qo = Q2
E91.qi = Q2
E91.qo = Q2
E92.qi = Q2
E92.qo = Q2
E93.qi = Q2
E93.qo = Q2
E94.qi = Q2
E94.qo = Q2
E95.qi = Q2
E95.qo = Q2
E96.qi = Q2
E96.qo = Q2
E97.qi = Q2
E97.qo = Q2
E98.qi = Q2
E98.qo = Q2
E99.qi = Q2
E99.qo = Q2
E100.qi = Q2
E100.qo = Q2
E101.qi = Q2
E101.qo = Q2
E102.qi = Q2
E102.qo = Q2
E103.qi = Q2
E103.qo = Q2
E105.qi = Q2
E105.qo = Q2
E107.qi = Q2
E107.qo = Q2
all e: used | e.fiber in ((E0 + (E48 + E84))) implies #e.cost = 0
all e: used | e.fiber in (((((E1 + (E6 + E7)) + ((E10 + E11) + (E12 + E16))) + (((E22 + E23) + (E24 + E28)) + ((E32 + E49) + (E53 + E56)))) + (((E57 + (E60 + E65)) + ((E66 + E69) + (E72 + E85))) + (((E88 + E90) + (E91 + E93)) + ((E96 + E97) + (E99 + E101)))))) implies #e.cost = 2
all e: used | e.fiber in ((((E2 + (E4 + E8)) + (E20 + (E50 + E51))) + ((E54 + (E63 + E86)) + (E87 + (E89 + E95))))) implies #e.cost = 1
all e: used | e.fiber in ((((((E3 + E5) + (E9 + E14)) + ((E15 + E18) + (E19 + (E21 + E26)))) + (((E27 + E30) + (E31 + E34)) + ((E35 + E36) + (E39 + (E42 + E52))))) + ((((E55 + E59) + (E62 + E64)) + ((E68 + E71) + (E74 + (E75 + E77)))) + (((E79 + E92) + (E94 + E98)) + ((E100 + E102) + (E103 + (E105 + E107))))))) implies #e.cost = 3
all e: used | e.fiber.qi = e.target.state
R.fiber.qo in ((Q0 + Q1))
all a: active | a.lab = T0 implies a.state = Q0
all a: active | a.lab = T1 and child[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T1 and child[a].fiber.qo = Q1 implies a.state = Q2
all a: active | a.lab = T1 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T2 and child[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T2 and child[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T2 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T3 and child[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T3 and child[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T3 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T4 and child[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T4 and child[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T4 and child[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T5 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T5 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q2
all a: active | a.lab = T5 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T6 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T6 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q2
all a: active | a.lab = T6 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T7 and left[a].fiber.qo = Q0 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q0 implies a.state = Q1
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q1 implies a.state = Q1
all a: active | a.lab = T7 and left[a].fiber.qo = Q1 and right[a].fiber.qo = Q2 implies a.state = Q2
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q0 implies a.state = Q2
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q1 implies a.state = Q2
all a: active | a.lab = T7 and left[a].fiber.qo = Q2 and right[a].fiber.qo = Q2 implies a.state = Q2
}
fun range0: set Pos { ((P0 + (P1 + P2)) + ((P3 + P4) + (P5 + P6))) }
fun loop0: set Pos { (P4 + (P5 + P6)) }
fun next0: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P4))) }
fun future0: Pos -> Pos { (*next0) & (range0->range0) }
fun shift0_0: Pos -> Pos { ((P0->P0 + (P1->P1 + P2->P2)) + ((P3->P3 + P4->P4) + (P5->P5 + P6->P6))) }
fun shift0_1: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + ((P3->P4 + P4->P5) + (P5->P6 + P6->P4))) }
fun shift0_2: Pos -> Pos { ((P0->P2 + (P1->P3 + P2->P4)) + ((P3->P5 + P4->P6) + (P5->P4 + P6->P5))) }
fun shift0_3: Pos -> Pos { ((P0->P3 + (P1->P4 + P2->P5)) + ((P3->P6 + P4->P4) + (P5->P5 + P6->P6))) }
pred semantics0[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range0
ev in used->range0
all e: used | e.fiber in (((E0 + (E1 + E48)) + (E49 + (E84 + E85)))) implies e.ev = {i: range0 | (i.shift0_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E3) + (E50 + E86))) implies e.ev = {i: range0 | (i.shift0_0) in (range0 - e.target.av)}
all e: used | e.fiber in (((E4 + E5) + (E51 + (E52 + E87)))) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (e.target.av))}
all e: used | e.fiber in (((E6 + E7) + (E53 + E88))) implies e.ev = {i: range0 | some ((i.shift0_0).future0 & (range0 - e.target.av))}
all e: used | e.fiber in (((E8 + E9) + (E54 + (E55 + E89)))) implies e.ev = {i: range0 | (i.shift0_0).future0 in (e.target.av)}
all e: used | e.fiber in (((E10 + E11) + (E56 + E90))) implies e.ev = {i: range0 | (i.shift0_0).future0 in (range0 - e.target.av)}
all e: used | e.fiber in ((E12 + (E57 + E91))) implies e.ev = {i: range0 | loop0 in (e.target.av)}
all e: used | e.fiber in (((E14 + E15) + (E59 + E92))) implies e.ev = {i: range0 | loop0 in (range0 - e.target.av)}
all e: used | e.fiber in ((E16 + (E60 + E93))) implies e.ev = {i: range0 | some (loop0 & (e.target.av))}
all e: used | e.fiber in (((E18 + E19) + (E62 + E94))) implies e.ev = {i: range0 | some (loop0 & (range0 - e.target.av))}
all e: used | e.fiber in (((E20 + E21) + (E63 + (E64 + E95)))) implies e.ev = {i: range0 | (i.shift0_1) in (e.target.av)}
all e: used | e.fiber in (((E22 + E23) + (E65 + E96))) implies e.ev = {i: range0 | (i.shift0_1) in (range0 - e.target.av)}
all e: used | e.fiber in ((E24 + (E66 + E97))) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (e.target.av))}
all e: used | e.fiber in (((E26 + E27) + (E68 + E98))) implies e.ev = {i: range0 | some ((i.shift0_1).future0 & (range0 - e.target.av))}
all e: used | e.fiber in ((E28 + (E69 + E99))) implies e.ev = {i: range0 | (i.shift0_1).future0 in (e.target.av)}
all e: used | e.fiber in (((E30 + E31) + (E71 + E100))) implies e.ev = {i: range0 | (i.shift0_1).future0 in (range0 - e.target.av)}
all e: used | e.fiber in ((E32 + (E72 + E101))) implies e.ev = {i: range0 | (i.shift0_2) in (e.target.av)}
all e: used | e.fiber in (((E34 + E35) + (E74 + E102))) implies e.ev = {i: range0 | (i.shift0_2) in (range0 - e.target.av)}
all e: used | e.fiber in ((E36 + (E75 + E103))) implies e.ev = {i: range0 | some ((i.shift0_2).future0 & (e.target.av))}
all e: used | e.fiber in ((E39 + (E77 + E105))) implies e.ev = {i: range0 | (i.shift0_2).future0 in (e.target.av)}
all e: used | e.fiber in ((E42 + (E79 + E107))) implies e.ev = {i: range0 | (i.shift0_3) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (range0 - child[a].ev)
all a: active | a.lab = T2 implies a.av = (next0.(child[a].ev))
all a: active | a.lab = T3 implies a.av = ({i: range0 | some (i.future0 & child[a].ev)})
all a: active | a.lab = T4 implies a.av = ({i: range0 | i.future0 in child[a].ev})
all a: active | a.lab = T5 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T6 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T7 implies a.av = ((range0 - left[a].ev) + right[a].ev)
}
fun range1: set Pos { ((P0 + (P1 + P2)) + (P3 + (P4 + P5))) }
fun loop1: set Pos { ((P0 + (P1 + P2)) + (P3 + (P4 + P5))) }
fun next1: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P0))) }
fun future1: Pos -> Pos { (*next1) & (range1->range1) }
fun shift1_0: Pos -> Pos { ((P0->P0 + (P1->P1 + P2->P2)) + (P3->P3 + (P4->P4 + P5->P5))) }
fun shift1_1: Pos -> Pos { ((P0->P1 + (P1->P2 + P2->P3)) + (P3->P4 + (P4->P5 + P5->P0))) }
fun shift1_2: Pos -> Pos { ((P0->P2 + (P1->P3 + P2->P4)) + (P3->P5 + (P4->P0 + P5->P1))) }
fun shift1_3: Pos -> Pos { ((P0->P3 + (P1->P4 + P2->P5)) + (P3->P0 + (P4->P1 + P5->P2))) }
pred semantics1[av: Anchor -> Pos, ev: Port -> Pos] {
av in active->range1
ev in used->range1
all e: used | e.fiber in (((E0 + (E1 + E48)) + (E49 + (E84 + E85)))) implies e.ev = {i: range1 | (i.shift1_0) in (e.target.av)}
all e: used | e.fiber in (((E2 + E3) + (E50 + E86))) implies e.ev = {i: range1 | (i.shift1_0) in (range1 - e.target.av)}
all e: used | e.fiber in (((E4 + E5) + (E51 + (E52 + E87)))) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (e.target.av))}
all e: used | e.fiber in (((E6 + E7) + (E53 + E88))) implies e.ev = {i: range1 | some ((i.shift1_0).future1 & (range1 - e.target.av))}
all e: used | e.fiber in (((E8 + E9) + (E54 + (E55 + E89)))) implies e.ev = {i: range1 | (i.shift1_0).future1 in (e.target.av)}
all e: used | e.fiber in (((E10 + E11) + (E56 + E90))) implies e.ev = {i: range1 | (i.shift1_0).future1 in (range1 - e.target.av)}
all e: used | e.fiber in ((E12 + (E57 + E91))) implies e.ev = {i: range1 | loop1 in (e.target.av)}
all e: used | e.fiber in (((E14 + E15) + (E59 + E92))) implies e.ev = {i: range1 | loop1 in (range1 - e.target.av)}
all e: used | e.fiber in ((E16 + (E60 + E93))) implies e.ev = {i: range1 | some (loop1 & (e.target.av))}
all e: used | e.fiber in (((E18 + E19) + (E62 + E94))) implies e.ev = {i: range1 | some (loop1 & (range1 - e.target.av))}
all e: used | e.fiber in (((E20 + E21) + (E63 + (E64 + E95)))) implies e.ev = {i: range1 | (i.shift1_1) in (e.target.av)}
all e: used | e.fiber in (((E22 + E23) + (E65 + E96))) implies e.ev = {i: range1 | (i.shift1_1) in (range1 - e.target.av)}
all e: used | e.fiber in ((E24 + (E66 + E97))) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (e.target.av))}
all e: used | e.fiber in (((E26 + E27) + (E68 + E98))) implies e.ev = {i: range1 | some ((i.shift1_1).future1 & (range1 - e.target.av))}
all e: used | e.fiber in ((E28 + (E69 + E99))) implies e.ev = {i: range1 | (i.shift1_1).future1 in (e.target.av)}
all e: used | e.fiber in (((E30 + E31) + (E71 + E100))) implies e.ev = {i: range1 | (i.shift1_1).future1 in (range1 - e.target.av)}
all e: used | e.fiber in ((E32 + (E72 + E101))) implies e.ev = {i: range1 | (i.shift1_2) in (e.target.av)}
all e: used | e.fiber in (((E34 + E35) + (E74 + E102))) implies e.ev = {i: range1 | (i.shift1_2) in (range1 - e.target.av)}
all e: used | e.fiber in ((E36 + (E75 + E103))) implies e.ev = {i: range1 | some ((i.shift1_2).future1 & (e.target.av))}
all e: used | e.fiber in ((E39 + (E77 + E105))) implies e.ev = {i: range1 | (i.shift1_2).future1 in (e.target.av)}
all e: used | e.fiber in ((E42 + (E79 + E107))) implies e.ev = {i: range1 | (i.shift1_3) in (e.target.av)}
all a: active | a.lab = T1 implies a.av = (range1 - child[a].ev)
all a: active | a.lab = T2 implies a.av = (next1.(child[a].ev))
all a: active | a.lab = T3 implies a.av = ({i: range1 | some (i.future1 & child[a].ev)})
all a: active | a.lab = T4 implies a.av = ({i: range1 | i.future1 in child[a].ev})
all a: active | a.lab = T5 implies a.av = (left[a].ev & right[a].ev)
all a: active | a.lab = T6 implies a.av = (left[a].ev + right[a].ev)
all a: active | a.lab = T7 implies a.av = ((range1 - left[a].ev) + right[a].ev)
}
fact Semantics {
semantics0[av0, ev0]
all a: lab.T0 | a.av0 = ((P2 + (P4 + P6)))
(R->P0 in ev0)
semantics1[av1, ev1]
all a: lab.T0 | a.av1 = ((P3 + P4))
not (R->P0 in ev1)
}
fun kept: Anchor -> Anchor { (none->none) & ~src.( {e: used | e.fiber not in nonempty} <: target ) }
fact Objective { minsome Carrier.cost }
run {} for 4 Int

